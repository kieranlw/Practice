1..1000 | foreach {
    [Console]::Error.WriteLine("stderr")
}
1..1000 | foreach {
    Write-Output "stdout"
}