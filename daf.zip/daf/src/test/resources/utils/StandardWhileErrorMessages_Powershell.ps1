1..1000 | foreach {
    Write-Output "stdout"
    [Console]::Error.WriteLine("stderr")
}