1..1000 | foreach {
    Write-Output "stdout"
}
1..1000 | foreach {
    [Console]::Error.WriteLine("stderr")
}