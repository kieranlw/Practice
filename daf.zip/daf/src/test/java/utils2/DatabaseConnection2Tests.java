package utils2;

import org.testng.annotations.Test;
import utils2.DatabaseConnection2;

import java.io.IOException;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.startsWith;

public class DatabaseConnection2Tests {
    @Test
    public void canGetDBOffsetHours() {
        assertThat(DatabaseConnection2.getDBOffsetHoursSql(), startsWith("SELECT"));
    }
}
