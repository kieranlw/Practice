package utils2;

import common.Is;
import common.RowFilter;
import common.Verify;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import utils2.tableData.Row;
import utils2.tableData.getInfo.GetRow;

import java.util.List;

public class GetRowTests {
    private static final Row ROW_0_MARY_QUEEN_OF_SCOTS = Row.of("First Name", "Mary", "Last Name", "Queen of Scots", "Birthday", "12/8/1542");
    private static final Row ROW_1_JOHN_DOE = Row.of("First Name", "John", "Last Name", "Doe", "Birthday", "1/1/2000");
    private static final Row ROW_2_JOHN_SMITH = Row.of("First Name", "John", "Last Name", "Smith", "Birthday", "1/1/2000");
    private static final Row ROW_3_RICHARD_ROE = Row.of("First Name", "Richard", "Last Name", "Roe", "Birthday", "12/15/1950");

    private GetRow getRow;
    private List<Row> tableRows;

    @BeforeMethod
    public void beforeMethod() {
        TableData2 table = new TableData2();
        tableRows = table.data;
        table.data.add(ROW_0_MARY_QUEEN_OF_SCOTS);
        table.data.add(ROW_1_JOHN_DOE);
        table.data.add(ROW_2_JOHN_SMITH);
        table.data.add(ROW_3_RICHARD_ROE);

        getRow = table.get().row();
    }

    @Test
    public void by_ReturnsFirstMatch() {
        final RowFilter filter = RowFilter.of(
                "First Name", Is.equalTo("John"),
                "Birthday", Is.equalTo("1/1/2000"));
        final Row result = getRow.by(filter);
        Verify.that(result, Is.sameInstanceAs(ROW_1_JOHN_DOE));
    }

    @Test
    public void by_ReturnsNullOnFailure() {
        final RowFilter filter = RowFilter.of(
                "First Name", Is.equalTo("John"),
                "Birthday", Is.equalTo("10/26/1985"));
        final Row result = getRow.by(filter);
        Verify.that(result, Is.equalTo(null));
    }

    @Test
    public void byIndex() {
        final Row result = getRow.byIndex(Index.zeroBased(2));
        Verify.that(result, Is.sameInstanceAs(ROW_2_JOHN_SMITH));
    }

    @Test
    public void byIndex_ThrowsOnFailure() {
        Verify.that(() -> getRow.byIndex(Index.zeroBased(99)))
                .throwsException(IndexOutOfBoundsException.class);
    }

    @Test
    public void byMap_ReturnsFirstMatch() {
        Row map = Row.of("First Name", "John", "Birthday", "1/1/2000");
        final Row result = getRow.byMap(map);
        Verify.that(result, Is.sameInstanceAs(ROW_1_JOHN_DOE));
    }

    @Test
    public void byMap_ReturnsNullOnFailure() {
        Row map = Row.of("First Name", "John", "Birthday", "10/26/1985");
        final Row result = getRow.byMap(map);
        Verify.that(result, Is.equalTo(null));
    }

    @Test
    public void byMapByPartialText_ReturnsFirstMatch() {
        Row map = Row.of("First Name", "h", "Birthday", "2000");
        final Row result = getRow.byMapByPartialText(map);
        Verify.that(result, Is.sameInstanceAs(ROW_1_JOHN_DOE));
    }

    @Test
    public void byMapByPartialText_ReturnsNullOnFailure() {
        Row map = Row.of("First Name", "h", "Birthday", "xyz");
        final Row result = getRow.byMapByPartialText(map);
        Verify.that(result, Is.equalTo(null));
    }

    @Test
    public void byMapLastEntry_ReturnsLastMatch() {
        Row map = Row.of("First Name", "John", "Birthday", "1/1/2000");
        final Row result = getRow.byMap_LastEntry(map);
        Verify.that(result, Is.sameInstanceAs(ROW_2_JOHN_SMITH));
    }

    @Test
    public void byMapLastEntry_ReturnsNullOnFailure() {
        Row map = Row.of("First Name", "John", "Birthday", "10/26/1985");
        final Row result = getRow.byMap_LastEntry(map);
        Verify.that(result, Is.equalTo(null));
    }

    @Test
    public void byMapLastEntryByPartialText_ReturnsLastMatch() {
        Row map = Row.of("First Name", "h", "Birthday", "2000");
        final Row result = getRow.byMap_LastEntryByPartialText(map);
        Verify.that(result, Is.sameInstanceAs(ROW_2_JOHN_SMITH));
    }

    @Test
    public void byMapLastEntryByPartialText_ReturnsNullOnFailure() {
        Row map = Row.of("First Name", "h", "Birthday", "xyz");
        final Row result = getRow.byMap_LastEntryByPartialText(map);
        Verify.that(result, Is.equalTo(null));
    }

    @Test
    public void byMatchingField_ReturnsFirstMatch() {
        final Row result = getRow.byMatchingField("First Name", "John");
        Verify.that(result, Is.sameInstanceAs(ROW_1_JOHN_DOE));
    }

    @Test
    public void byMatchingField_ReturnsNullOnFailure() {
        final Row result = getRow.byMatchingField("First Name", "Julius");
        Verify.that(result, Is.equalTo(null));
    }

    @Test
    public void byMatchingFields_ReturnsFirstMatch() {
        final Row result = getRow.byMatchingFields(
                "First Name", "John",
                "Birthday", "1/1/2000");
        Verify.that(result, Is.sameInstanceAs(ROW_1_JOHN_DOE));
    }

    @Test
    public void byMatchingFields_ReturnsNullOnFailure() {
        final Row result = getRow.byMatchingFields(
                "First Name", "John",
                "Birthday", "10/26/1985");
        Verify.that(result, Is.equalTo(null));
    }

    @Test
    public void byPartialMatchingField_ReturnsFirstMatch() {
        final Row result = getRow.byPartialMatchingField("Last Name", "oe");
        Verify.that(result, Is.sameInstanceAs(ROW_1_JOHN_DOE));
    }

    @Test
    public void byPartialMatchingField_ReturnsNullOnFailure() {
        final Row result = getRow.byPartialMatchingField("Last Name", "McFly");
        Verify.that(result, Is.equalTo(null));
    }

    @Test
    public void firstRow() {
        final Row result = getRow.firstRow();
        Verify.that(result, Is.sameInstanceAs(ROW_0_MARY_QUEEN_OF_SCOTS));
    }

    @Test
    public void firstRow_ThrowsIfEmpty() {
        tableRows.clear();
        Verify.that(() -> getRow.firstRow())
                .throwsException(IndexOutOfBoundsException.class);
    }

    @Test
    public void last_ReturnsLastMatch() {
        final RowFilter filter = RowFilter.of(
                "First Name", Is.equalTo("John"),
                "Birthday", Is.equalTo("1/1/2000"));
        final Row result = getRow.last(filter);
        Verify.that(result, Is.sameInstanceAs(ROW_2_JOHN_SMITH));
    }

    @Test
    public void last_ReturnsNullOnFailure() {
        final RowFilter filter = RowFilter.of(
                "First Name", Is.equalTo("John"),
                "Birthday", Is.equalTo("10/26/1985"));
        final Row result = getRow.last(filter);
        Verify.that(result, Is.equalTo(null));
    }
}
