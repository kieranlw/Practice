package utils2;

import com.fasterxml.jackson.annotation.JsonProperty;
import common.Directory;
import common.Is;
import common.Verify;
import common.WritableFile;
import org.testng.annotations.Test;
import utils2.tableData.Row;
import utils2.tableData.RowWithIndex;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.sameInstance;

public class TableData2Tests {
    private static class DataObjectThatTakesRow {
        public final Row row;

        private DataObjectThatTakesRow(Row row) {
            this.row = row;
        }
    }

    private static class DataObjectThatTakesRowWithIndex {
        public final RowWithIndex rowWithIndex;

        private DataObjectThatTakesRowWithIndex(RowWithIndex rowWithIndex) {
            this.rowWithIndex = rowWithIndex;
        }
    }

    private static class DataObjectThatTakesMap {
        public final Map<String, String> map;

        private DataObjectThatTakesMap(Map<String, String> map) {
            this.map = map;
        }
    }

    private static class DataObjectWithNoParameters {
    }

    private static class JacksonTestClass {
        @JsonProperty("test1")
        private double test1;

        public double getTest1() {
            return test1;
        }
    }

    @Test
    public void getDataAs_CallsConstructorThatTakesMap_EvenIfConstructorIsPrivate() {
        Row firstRow = Row.of("Name", "First");
        Row secondRow = Row.of("Name", "Second");
        TableData2 table = new TableData2(Arrays.asList(firstRow, secondRow));
        List<DataObjectThatTakesMap> data = table.getDataAs(DataObjectThatTakesMap.class);

        assertThat("Count", data.size(), equalTo(2));
        assertThat("First element", data.get(0).map.get("Name"), equalTo("First"));
        assertThat("Second element", data.get(1).map.get("Name"), equalTo("Second"));
    }

    @Test
    public void getDataAs_CallsConstructorThatTakesRow_EvenIfConstructorIsPrivate() {
        Row firstRow = new Row();
        Row secondRow = new Row();
        TableData2 table = new TableData2(Arrays.asList(firstRow, secondRow));
        List<DataObjectThatTakesRow> data = table.getDataAs(DataObjectThatTakesRow.class);

        assertThat("Count", data.size(), equalTo(2));
        assertThat("First element", data.get(0).row, sameInstance(firstRow));
        assertThat("Second element", data.get(1).row, sameInstance(secondRow));
    }

    @Test
    public void getDataAs_CallsConstructorThatTakesRowWithIndex_EvenIfConstructorIsPrivate() {
        Row firstRow = new Row();
        Row secondRow = new Row();
        TableData2 table = new TableData2(Arrays.asList(firstRow, secondRow));
        List<DataObjectThatTakesRowWithIndex> data = table.getDataAs(DataObjectThatTakesRowWithIndex.class);

        assertThat("Count", data.size(), equalTo(2));
        assertThat("First element row", data.get(0).rowWithIndex.getRow(), sameInstance(firstRow));
        assertThat("First element index", data.get(0).rowWithIndex.getIndex(), equalTo(Index.zeroBased(0)));
        assertThat("Second element row", data.get(1).rowWithIndex.getRow(), sameInstance(secondRow));
        assertThat("Second element index", data.get(1).rowWithIndex.getIndex(), equalTo(Index.zeroBased(1)));
    }

    @Test
    public void getDataAs_WithParameterlessConstructor() {
        Row firstRow = new Row();
        Row secondRow = new Row();
        TableData2 table = new TableData2(Arrays.asList(firstRow, secondRow));
        List<DataObjectWithNoParameters> data = table.getDataAs(DataObjectWithNoParameters.class);
        assertThat("Count", data.size(), equalTo(2));
    }

    @Test(expectedExceptions = RuntimeException.class,
            expectedExceptionsMessageRegExp = ".*Cannot deserialize value.*")
    public void getDataAs_StringExpectedDouble_ThrowError() {
        Row firstRow = Row.of("test1", "ab");
        Row secondRow = new Row();
        TableData2 table = new TableData2(Arrays.asList(firstRow, secondRow));
        table.getDataAs(JacksonTestClass.class);
    }

    @Test
    public void getDataAs_ValidDoubleConversion() {
        Row firstRow = Row.of("test1", "5.0");
        Row secondRow = new Row();
        TableData2 table = new TableData2(Arrays.asList(firstRow, secondRow));
        List<JacksonTestClass> data = table.getDataAs(JacksonTestClass.class);
        assertThat("Value Stored", data.get(0).getTest1(), equalTo(5.0));
        assertThat("Count", data.size(), equalTo(2));
    }

    @Test
    public void afterConstructingFromArrayList_AllowsAdding() {
        ArrayList<Row> list = new ArrayList<>();
        list.add(Row.of("Name", "Bob"));
        list.add(Row.of("Name", "Ned"));
        final TableData2 table = new TableData2(list);
        Verify.that(() ->
                table.data.add(Row.of("Name", "Clyde"))
        ).doesNotThrow();
    }

    @Test
    public void afterConstructingFromParams_AllowsAdding() {
        final TableData2 table = new TableData2(Row.of("Name", "Bob"), Row.of("Name", "Ned"));
        Verify.that(() ->
                table.data.add(Row.of("Name", "Clyde"))
        ).doesNotThrow();
    }

    @Test
    public void toCsv_EmptyTable() {
        final TableData2 table = new TableData2();
        Verify.that(table.toCsv(), Is.equalTo(""));
    }

    @Test
    public void toCsv_SingleRow() {
        final TableData2 table = new TableData2(Row.of("First Name", "John", "Last Name", "Doe"));
        Verify.that(table.toCsv(), Is.equalTo("First Name,Last Name\r\n" +
                "John,Doe\r\n"));
    }

    @Test
    public void toCsv_AddsQuotesForValuesWithCommas() {
        final TableData2 table = new TableData2(Row.of("Commas, with", "Commas, value with"));
        Verify.that(table.toCsv(), Is.equalTo("\"Commas, with\"\r\n" +
                "\"Commas, value with\"\r\n"));
    }

    @Test
    public void toCsv_AddsQuotesForValuesWithNewlines() {
        final TableData2 table = new TableData2(Row.of("With\nLF", "Value with\nLF", "With\r\nCRLF", "Value with\r\nCRLF"));
        Verify.that(table.toCsv(), Is.equalTo("\"With\nLF\",\"With\r\nCRLF\"\r\n" +
                "\"Value with\nLF\",\"Value with\r\nCRLF\"\r\n"));
    }

    @Test
    public void toCsv_MultipleRows() {
        final TableData2 table = new TableData2(
                Row.of("First Name", "John", "Last Name", "Doe"),
                Row.of("First Name", "Richard", "Last Name", "Roe"));
        Verify.that(table.toCsv(), Is.equalTo("First Name,Last Name\r\n" +
                "John,Doe\r\n" +
                "Richard,Roe\r\n"));
    }

    @Test
    public void toCsv_WhenDifferentRowsHaveDifferentColumns() {
        // For the second row, add columns in a different order, and add a new column
        final TableData2 table = new TableData2(
                Row.of("First Name", "John", "Last Name", "Doe"),
                Row.of("Last Name", "Roe", "First Name", "Richard", "Suffix", "III"));
        Verify.that(table.toCsv(), Is.equalTo("First Name,Last Name,Suffix\r\n" +
                "John,Doe,\r\n" +
                "Richard,Roe,III\r\n"));
    }

    @Test
    public void saveCsv() {
        final Directory tempDirectory = Directory.createTempDirectory(getClass().getName());
        tempDirectory.deleteFiles("*");

        final TableData2 table = new TableData2(Row.of("First Name", "John", "Last Name", "Doe"));
        final WritableFile file = tempDirectory.file("Saved.csv");
        table.saveCsv(file);

        Verify.that(file.readAllText(), Is.equalTo("First Name,Last Name\r\n" +
                "John,Doe\r\n"));
    }
}
