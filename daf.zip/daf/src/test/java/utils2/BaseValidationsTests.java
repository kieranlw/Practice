package utils2;

import common.BaseHamcrestTest;
import org.mockito.Mockito;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import utils2.page_components.*;

import java.util.HashMap;

public class BaseValidationsTests extends BaseHamcrestTest {
    private static final String UNABLE_TO_FIND_ELEMENT = "Unable to find element 'Friendly Name'!";

    private RemoteWebElement element;

    @BeforeMethod
    public void setUp() {
        HashMap<String, Object> capabilitiesMap = new HashMap<>();

        Capabilities capabilities = Mockito.mock(Capabilities.class);
        Mockito.when(capabilities.asMap()).thenReturn(capabilitiesMap);

        RemoteWebDriver driver = Mockito.mock(RemoteWebDriver.class);
        Mockito.when(driver.getCapabilities()).thenReturn(capabilities);

        element = Mockito.mock(RemoteWebElement.class);
        Mockito.when(element.getWrappedDriver()).thenReturn(driver);

        // Some reasonable defaults
        Mockito.when(element.getTagName()).thenReturn("div");
        Mockito.when(element.getText()).thenReturn("");
        Mockito.when(element.isEnabled()).thenReturn(true);
        // getCssValue returns an empty string on not-found (unlike getAttribute which returns null)
        Mockito.when(element.getCssValue(Mockito.anyString())).thenReturn("");
    }

    private BaseValidations verify(WebElement element) {
        return new BaseValidations("Friendly Name", element);
    }

    @Test
    public void exists_Pass() {
        verify(element).exists();
    }

    @Test
    public void exists_Fail() {
        assertFails(
                () -> verify(null).exists(),
                "Condition 'Element 'Friendly Name' was found.' was false.");
    }

    @Test
    public void doesNotExist_Pass() {
        verify(null).doesNotExist();
    }

    @Test
    public void doesNotExist_Fail() {
        assertFails(
                () -> verify(element).doesNotExist(),
                "Condition 'Element 'Friendly Name' does not exist.' was false.");
    }

    @Test
    public void notDisplayed_Pass_ElementDoesNotExist() {
        verify(null).notDisplayed();
    }

    @Test
    public void notDisplayed_Pass_Hidden() {
        Mockito.when(element.isDisplayed()).thenReturn(false);
        verify(element).notDisplayed();
    }

    @Test
    public void notDisplayed_Fail() {
        Mockito.when(element.isDisplayed()).thenReturn(true);
        assertFails(
                () -> verify(element).notDisplayed(),
                "Element Friendly Name was displayed."
        );
    }

    @Test
    public void displayed_Pass() {
        Mockito.when(element.isDisplayed()).thenReturn(true);
        verify(element).displayed();
    }

    @Test
    public void displayed_Fail() {
        Mockito.when(element.isDisplayed()).thenReturn(false);
        assertFails(
                () -> verify(element).displayed(),
                "Element Friendly Name was NOT displayed."
        );
    }

    @Test
    public void displayed_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).displayed(),
                "Unable to find element 'Friendly Name'!"
        );
    }

    @Test
    public void disabled_Pass_DisabledClass() {
        Mockito.when(element.getAttribute("class")).thenReturn("disabled");
        verify(element).disabled();
    }

    @Test
    public void disabled_Pass_ReadOnlyAttribute() {
        Mockito.when(element.getAttribute("readonly")).thenReturn("true");
        verify(element).disabled();
    }

    @Test
    public void disabled_Pass_Disabled() {
        Mockito.when(element.isEnabled()).thenReturn(false);
        verify(element).disabled();
    }

    @Test
    public void disabled_Fail() {
        assertFails(
                () -> verify(element).disabled(),
                "Element Friendly Name was enabled."
        );
    }

    @Test
    public void disabled_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).disabled(),
                "Unable to find element 'Friendly Name'!"
        );
    }

    @Test
    public void enabled_Pass() {
        verify(element).enabled();
    }

    @Test
    public void enabled_Fail_DisabledClass() {
        Mockito.when(element.getAttribute("class")).thenReturn("disabled");
        assertFails(
                () -> verify(element).enabled(),
                "Element Friendly Name was NOT enabled."
        );
    }

    @Test
    public void enabled_Fail_ReadOnlyAttribute() {
        Mockito.when(element.getAttribute("readonly")).thenReturn("true");
        assertFails(
                () -> verify(element).enabled(),
                "Element Friendly Name was NOT enabled."
        );
    }

    @Test
    public void enabled_Fail_Disabled() {
        Mockito.when(element.isEnabled()).thenReturn(false);
        assertFails(
                () -> verify(element).enabled(),
                "Element Friendly Name was NOT enabled."
        );
    }

    @Test
    public void enabled_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).enabled(),
                "Unable to find element 'Friendly Name'!"
        );
    }

    @Test
    public void textEquals_Pass() {
        Mockito.when(element.getText()).thenReturn("abc");
        verify(element).textEquals("abc");
    }

    @Test
    public void textEquals_Fail() {
        Mockito.when(element.getText()).thenReturn("abc");
        assertFails(
                () -> verify(element).textEquals("def"),
                "Element 'Friendly Name' text\n" +
                        "Expected: \"def\"\n" +
                        "     but: \"abc\"\n" +
                        " differs:  ^ starting at index 0"
        );
    }

    @Test
    public void textEquals_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).textEquals("def"),
                "Unable to find element 'Friendly Name'!"
        );
    }

    @Test
    public void textNotEquals_Pass() {
        Mockito.when(element.getText()).thenReturn("abc");
        verify(element).textNotEquals("def");
    }

    @Test
    public void textNotEquals_Fail() {
        Mockito.when(element.getText()).thenReturn("abc");
        assertFails(
                () -> verify(element).textNotEquals("abc"),
                "Element 'Friendly Name' text\n" +
                        "Expected: not \"abc\"\n" +
                        "     but: was \"abc\""
        );
    }

    @Test
    public void textNotEquals_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).textNotEquals("abc"),
                "Unable to find element 'Friendly Name'!"
        );
    }

    @Test
    public void textContains_Pass() {
        Mockito.when(element.getText()).thenReturn("abc");
        verify(element).textContains("b");
    }

    @Test
    public void textContains_Fail() {
        Mockito.when(element.getText()).thenReturn("abc");
        assertFails(
                () -> verify(element).textContains("d"),
                "Element 'Friendly Name' text\n" +
                        "Expected: a string containing \"d\"\n" +
                        "     but: was \"abc\""
        );
    }

    @Test
    public void textContains_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).textContains("d"),
                "Unable to find element 'Friendly Name'!"
        );
    }

    @Test
    public void textDoesNOTContain_Pass() {
        Mockito.when(element.getText()).thenReturn("abc");
        verify(element).textDoesNOTContain("d");
    }

    @Test
    public void textDoesNOTContain_Fail() {
        Mockito.when(element.getText()).thenReturn("abc");
        assertFails(
                () -> verify(element).textDoesNOTContain("b"),
                "Element 'Friendly Name' text\n" +
                        "Expected: not a string containing \"b\"\n" +
                        "     but: was \"abc\""
        );
    }

    @Test
    public void textDoesNOTContain_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).textDoesNOTContain("b"),
                "Unable to find element 'Friendly Name'!"
        );
    }

    @Test
    public void attributeEquals_Pass() {
        Mockito.when(element.getAttribute("abc")).thenReturn("def");
        verify(element).attributeEquals("abc", "def");
    }

    @Test
    public void attributeEquals_Fail() {
        Mockito.when(element.getAttribute("abc")).thenReturn("def");
        assertFails(
                () -> verify(element).attributeEquals("abc", "xyz"),
                "Element 'Friendly Name' attribute 'abc'\n" +
                        "Expected: \"xyz\"\n" +
                        "     but: \"def\"\n" +
                        " differs:  ^ starting at index 0"
        );
    }

    @Test
    public void attributeEquals_Fail_AttributeDoesNotExist() {
        assertFails(
                () -> verify(element).attributeEquals("abc", "def"),
                "Element 'Friendly Name' attribute 'abc'\n" +
                        "Expected: \"def\"\n" +
                        "     but: was null"
        );
    }

    @Test
    public void attributeEquals_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).attributeEquals("abc", "def"),
                "Unable to find element 'Friendly Name'!"
        );
    }

    @Test
    public void attributeDoesNotEqual_Pass() {
        Mockito.when(element.getAttribute("abc")).thenReturn("def");
        verify(element).attributeDoesNotEqual("abc", "xyz");
    }

    @Test
    public void attributeDoesNotEqual_Pass_AttributeDoesNotExist() {
        verify(element).attributeDoesNotEqual("abc", "xyz");
    }

    @Test
    public void attributeDoesNotEqual_Fail() {
        Mockito.when(element.getAttribute("abc")).thenReturn("def");
        assertFails(
                () -> verify(element).attributeDoesNotEqual("abc", "def"),
                "Element 'Friendly Name' attribute 'abc'\n" +
                        "Expected: not \"def\"\n" +
                        "     but: was \"def\""
        );
    }

    @Test
    public void attributeDoesNotEqual_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).attributeDoesNotEqual("abc", "def"),
                UNABLE_TO_FIND_ELEMENT
        );
    }

    @Test
    public void attributeContains_Pass() {
        Mockito.when(element.getAttribute("abc")).thenReturn("def");
        verify(element).attributeContains("abc", "e");
    }

    @Test
    public void attributeContains_Fail() {
        Mockito.when(element.getAttribute("abc")).thenReturn("def");
        assertFails(
                () -> verify(element).attributeContains("abc", "z"),
                "Element 'Friendly Name' attribute 'abc'\n" +
                        "Expected: a string containing \"z\"\n" +
                        "     but: was \"def\""
        );
    }

    @Test
    public void attributeContains_Fail_AttributeDoesNotExist() {
        assertFails(
                () -> verify(element).attributeContains("abc", "e"),
                "Element 'Friendly Name' attribute 'abc'\n" +
                        "Expected: a string containing \"e\"\n" +
                        "     but: was null"
        );
    }

    @Test
    public void attributeContains_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).attributeContains("abc", "e"),
                "Unable to find element 'Friendly Name'!"
        );
    }

    @Test
    public void attributeNotContains_Pass() {
        Mockito.when(element.getAttribute("abc")).thenReturn("def");
        verify(element).attributeNotContains("abc", "x");
    }

    @Test
    public void attributeNotContains_Pass_AttributeDoesNotExist() {
        verify(element).attributeNotContains("abc", "def");
    }

    @Test
    public void attributeNotContains_Fail() {
        Mockito.when(element.getAttribute("abc")).thenReturn("def");
        assertFails(
                () -> verify(element).attributeNotContains("abc", "e"),
                "Element 'Friendly Name' attribute 'abc'\n" +
                        "Expected: not a string containing \"e\"\n" +
                        "     but: was \"def\""
        );
    }

    @Test
    public void attributeNotContains_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).attributeNotContains("abc", "e"),
                "Unable to find element 'Friendly Name'!"
        );
    }

    @Test
    public void attributeDoesNOTExist_Pass() {
        verify(element).attributeDoesNOTExist("abc");
    }

    @Test
    public void attributeDoesNOTExist_Fail() {
        Mockito.when(element.getAttribute("abc")).thenReturn("");
        assertFails(
                () -> verify(element).attributeDoesNOTExist("abc"),
                "Element 'Friendly Name' attribute 'abc'\n" +
                        "Expected: null\n" +
                        "     but: was \"\""
        );
    }

    @Test
    public void attributeDoesNOTExist_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).attributeDoesNOTExist("abc"),
                UNABLE_TO_FIND_ELEMENT
        );
    }

    @Test
    public void attributeDoesNotHaveValue_Pass_AttributeDoesNotExist() {
        verify(element).attributeDoesNotHaveValue("abc");
    }

    @Test
    public void attributeDoesNotHaveValue_Pass_ValueIsEmpty() {
        Mockito.when(element.getAttribute("abc")).thenReturn("");
        verify(element).attributeDoesNotHaveValue("abc");
    }

    @Test
    public void attributeDoesNotHaveValue_Fail() {
        Mockito.when(element.getAttribute("abc")).thenReturn("def");
        assertFails(
                () -> verify(element).attributeDoesNotHaveValue("abc"),
                "Element 'Friendly Name' attribute 'abc'\n" +
                        "Expected: one of {null, \"\"}\n" +
                        "     but: was \"def\""
        );
    }

    @Test
    public void attributeDoesNotHaveValue_Fail_ElementDoesNotExist() {
        Mockito.when(element.getAttribute("abc")).thenReturn("def");
        assertFails(
                () -> verify(null).attributeDoesNotHaveValue("abc"),
                UNABLE_TO_FIND_ELEMENT
        );
    }

    @Test
    public void cssEquals_Pass() {
        Mockito.when(element.getCssValue("color")).thenReturn("blue");
        verify(element).cssEquals("color", "blue");
    }

    @Test
    public void cssEquals_Fail() {
        Mockito.when(element.getCssValue("color")).thenReturn("blue");
        assertFails(
                () -> verify(element).cssEquals("color", "red"),
                "Element 'Friendly Name' CSS style 'color'\n" +
                        "Expected: \"red\"\n" +
                        "     but: \"blue\"\n" +
                        " differs:  ^ starting at index 0"
        );
    }

    @Test
    public void cssEquals_Fail_PropertyDoesNotExist() {
        assertFails(
                () -> verify(element).cssEquals("color", "blue"),
                "Element 'Friendly Name' CSS style 'color'\n" +
                        "Expected: \"blue\"\n" +
                        "     but: \"\"\n" +
                        " differs:  ^ starting at index 0"
        );
    }

    @Test
    public void cssEquals_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).cssEquals("color", "blue"),
                UNABLE_TO_FIND_ELEMENT
        );
    }

    @Test
    public void cssContains_Pass() {
        Mockito.when(element.getCssValue("title")).thenReturn("abc");
        verify(element).cssContains("title", "b");
    }

    @Test
    public void cssContains_Fail() {
        Mockito.when(element.getCssValue("title")).thenReturn("abc");
        assertFails(
                () -> verify(element).cssContains("title", "e"),
                "Element 'Friendly Name' CSS style 'title'\n" +
                        "Expected: a string containing \"e\"\n" +
                        "     but: was \"abc\""
        );
    }

    @Test
    public void cssContains_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).cssContains("title", "b"),
                UNABLE_TO_FIND_ELEMENT
        );
    }

    @Test
    public void textLengthEquals_Pass() {
        Mockito.when(element.getText()).thenReturn("abc");
        verify(element).textLengthEquals(3);
    }

    @Test
    public void textLengthEquals_Pass_NoTextAndExpecting0() {
        verify(element).textLengthEquals(0);
    }

    @Test
    public void textLengthEquals_Fail() {
        Mockito.when(element.getText()).thenReturn("abc");
        assertFails(
                () -> verify(element).textLengthEquals(5),
                "Element 'Friendly Name' text\n" +
                        "Expected: a CharSequence with length <5>\n" +
                        "     but: length was <3>"
        );
    }

    @Test
    public void textLengthEquals_Fail_NoText() {
        assertFails(
                () -> verify(element).textLengthEquals(5),
                "Element 'Friendly Name' text\n" +
                        "Expected: a CharSequence with length <5>\n" +
                        "     but: length was <0>"
        );
    }

    @Test
    public void textLengthEquals_Fail_ElementDoesNotExist() {
        assertFails(
                () -> verify(null).textLengthEquals(5),
                UNABLE_TO_FIND_ELEMENT
        );
    }
}
