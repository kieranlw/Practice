package utils;

import common.Is;
import common.ResourceFile;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LocatorTests {
    @BeforeClass
    public void beforeClass() {
        Locator.loadObjectRepository(
                new ResourceFile("utils/unitTestRepo.txt"));
    }

    @Test
    public void getXrXpath_XrName() {
        String xpath = Locator.get_XR_XPath("byXrName", null, null);
        BaseUI.assertThat(xpath, Is.equalTo("//*[./WidgetName[./text()='MyName']]"));
    }

    @Test
    public void getXrXpath_XrType() {
        String xpath = Locator.get_XR_XPath("byXrType", null, null);
        BaseUI.assertThat(xpath, Is.equalTo("//*[./WidgetType[./text()='MyType']]"));
    }

    @Test
    public void getXrXpath_XrLabel() {
        String xpath = Locator.get_XR_XPath("byXrLabel", null, null);
        BaseUI.assertThat(xpath, Is.equalTo("//*[./WidgetLabel[./text()='MyLabel']]"));
    }

    @Test
    public void getXrXpath_XrValue() {
        String xpath = Locator.get_XR_XPath("byXrValue", null, null);
        BaseUI.assertThat(xpath, Is.equalTo("//*[./WidgetValue[./text()='MyValue']]"));
    }

    @Test
    public void getXrXpath_XrXpath_NoPlaceholders() {
        String xpath = Locator.get_XR_XPath("byXrXpathNoPlaceholders", null, null);
        BaseUI.assertThat(xpath, Is.equalTo("//*"));
    }

    @Test
    public void getXrXpath_XrXpath_WithPlaceholders() {
        String xpath = Locator.get_XR_XPath("byXrXpathWithPlaceholders", "var1", "var2");
        BaseUI.assertThat(xpath, Is.equalTo("//var1/var2"));
    }
}
