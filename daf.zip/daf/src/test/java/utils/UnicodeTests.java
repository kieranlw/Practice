package utils;

import common.Is;
import org.testng.annotations.Test;
import utils.BaseUI;

public class UnicodeTests {
    @Test
    public void compilerReadsJavaFilesAsUtf8() {
        BaseUI.assertThat("\u2022", Is.equalTo("•"));
    }
}
