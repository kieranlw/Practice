package common;

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class IsTests extends BaseHamcrestTest {
    @Test
    public void equalTo_Pass() {
        Verify.that(10, Is.equalTo(10), "message");
    }

    @Test
    public void equalTo_Fail() {
        assertFails(
                () -> Verify.that(10, Is.equalTo(15), "message"),
                "message\nExpected: <15>\n     but: was <10>");
    }

    @Test
    public void equalToString_Pass() {
        Verify.that("abc", Is.equalTo("abc"), "message");
    }

    @Test
    public void equalToString_Fail_ShowsLocationOfMismatch() {
        assertFails(
                () -> Verify.that("something", Is.equalTo("somewhere"), "message"),
                "message\nExpected: \"somewhere\"\n     but: \"something\"\n differs:      ^ starting at index 4"
        );
    }

    @Test
    public void equalToString_Fail_WhenLeadingCharactersAreDisplayedEscaped_MarkerIndentationIsAdjusted() {
        // For certain characters, like newline, tab, and backslash, TestNG shows their escaped forms -
        // backslash n, backslash t, etc. - when showing values in error messages. Our context marker
        // should adjust its indentation to account for those backslashes. For example:
        //
        //     Expected: "\n\n\t\t somewhere"
        //          but: "\n\n\t\t something"
        //      differs:               ^ starting at index 9
        //
        // has to indent more than 9 spaces, because the first 4 characters are shown double-width.

        assertFails(
                () -> Verify.that("\n\n\t\t something", Is.equalTo("\n\n\t\t somewhere"), "message"),
                "message\nExpected: \"\\n\\n\\t\\t somewhere\"\n     but: \"\\n\\n\\t\\t something\"\n differs:               ^ starting at index 9"
        );
    }

    @Test
    public void equalTo_Fail_StringAndNull() {
        // We don't actually have to handle this one in our code, it ends up using the default matcher instead of ours
        assertFails(
                () -> Verify.that("abc", Is.equalTo(null), "message"),
                "message\nExpected: null\n     but: was \"abc\""
        );
    }

    @Test
    public void equalTo_Fail_NullAndString() {
        // We don't actually have to handle this one in our code, it's done in the base class (TypeSafeMatcher)
        assertFails(
                () -> Verify.that(null, Is.equalTo("abc"), "message"),
                "message\nExpected: \"abc\"\n     but: was null"
        );
    }

    @Test
    public void notEqualTo_Pass() {
        Verify.that(1 + 1, Is.notEqualTo(3));
    }

    @Test
    public void notEqualTo_Fail() {
        assertFails(
                () -> Verify.that(1 + 1, Is.notEqualTo(2), "description"),
                "description\nExpected: not <2>\n     but: was <2>");
    }

    @Test
    public void notEqualToString_Pass() {
        Verify.that("abc", Is.notEqualTo("def"));
    }

    @Test
    public void notEqualToString_Fail() {
        // notEqualTo doesn't show the "^" to show where values differ, because if we fail, they *don't* differ
        assertFails(
                () -> Verify.that("abc", Is.notEqualTo("abc"), "description"),
                "description\nExpected: not \"abc\"\n     but: was \"abc\"");
    }

    @Test
    public void equalToIgnoringCase_Pass_IdenticalInputs() {
        Verify.that("abc", Is.equalToIgnoringCase("abc"), "description");
    }

    @Test
    public void equalToIgnoringCase_Pass_InputsDifferingByCase() {
        Verify.that("abc", Is.equalToIgnoringCase("aBC"), "description");
    }

    @Test
    public void equalToIgnoringCase_Pass_NullAndNull() {
        Verify.that(null, Is.equalToIgnoringCase(null), "description");
    }

    @Test
    public void equalToIgnoringCase_Fail_PointsToFirstCharacterDifferentByOtherThanCase() {
        assertFails(
                () -> Verify.that("abc def", Is.equalToIgnoringCase("ABC xyz"), "description"),
                "description\n" +
                        "Expected: (ignoring case) \"ABC xyz\"\n" +
                        "     but:                 \"abc def\"\n" +
                        " differs:                      ^ starting at index 4"
        );
    }

    @Test
    public void equalToIgnoringCase_Fail_NullAndNonNull() {
        assertFails(
                () -> Verify.that(null, Is.equalToIgnoringCase("null"), "description"),
                "description\n" +
                        "Expected: (ignoring case) \"null\"\n" +
                        "     but:                 was null"
        );
    }

    @Test
    public void equalToIgnoringCase_Fail_NonNullAndNull() {
        assertFails(
                () -> Verify.that("null", Is.equalToIgnoringCase(null), "description"),
                "description\n" +
                        "Expected: (ignoring case) null\n" +
                        "     but:                 was \"null\""
        );
    }

    @Test
    public void lessThan_WhenLess_ShouldPass() {
        Verify.that(9, Is.lessThan(10), "message");
    }

    @Test
    public void lessThan_WhenEqual_ShouldFail() {
        assertFails(
                () -> Verify.that(10, Is.lessThan(10), "message"),
                "message\nExpected: a value less than <10>\n     but: <10> was equal to <10>");
    }

    @Test
    public void lessThan_WhenGreater_ShouldFail() {
        assertFails(
                () -> Verify.that(11, Is.lessThan(10), "message"),
                "message\nExpected: a value less than <10>\n     but: <11> was greater than <10>");
    }

    @Test
    public void lessThanOrEqualTo_WhenLess_ShouldPass() {
        Verify.that(9, Is.lessThanOrEqualTo(10), "message");
    }

    @Test
    public void lessThanOrEqualTo_WhenEqual_ShouldPass() {
        Verify.that(10, Is.lessThanOrEqualTo(10), "message");
    }

    @Test
    public void lessThanOrEqualTo_WhenGreater_ShouldFail() {
        assertFails(
                () -> Verify.that(11, Is.lessThanOrEqualTo(10), "message"),
                "message\nExpected: a value less than or equal to <10>\n     but: <11> was greater than <10>");
    }

    @Test
    public void greaterThan_WhenLess_ShouldFail() {
        assertFails(
                () -> Verify.that(9, Is.greaterThan(10), "message"),
                "message\nExpected: a value greater than <10>\n     but: <9> was less than <10>");
    }

    @Test
    public void greaterThan_WhenEqual_ShouldFail() {
        assertFails(
                () -> Verify.that(10, Is.greaterThan(10), "message"),
                "message\nExpected: a value greater than <10>\n     but: <10> was equal to <10>");
    }

    @Test
    public void greaterThan_WhenGreater_ShouldPass() {
        Verify.that(11, Is.greaterThan(10), "message");
    }

    @Test
    public void greaterThanOrEqualTo_WhenLess_ShouldFail() {
        assertFails(
                () -> Verify.that(9, Is.greaterThanOrEqualTo(10), "message"),
                "message\nExpected: a value equal to or greater than <10>\n     but: <9> was less than <10>");
    }

    @Test
    public void greaterThanOrEqualTo_WhenEqual_ShouldPass() {
        Verify.that(10, Is.greaterThanOrEqualTo(10), "message");
    }

    @Test
    public void greaterThanOrEqualTo_WhenGreater_ShouldPass() {
        Verify.that(11, Is.greaterThanOrEqualTo(10), "message");
    }

    @Test
    public void not_Pass() {
        Verify.that(10, Is.not(Is.equalTo(15)), "message");
    }

    @Test
    public void not_Fail() {
        assertFails(
                () -> Verify.that(10, Is.not(Is.equalTo(10)), "message"),
                "message\nExpected: not <10>\n     but: was <10>");
    }

    @Test
    public void isEmptyCollection_Pass() {
        List<String> list = new ArrayList<>();
        Verify.that(list, Is.emptyCollection(), "message");
    }

    @Test
    public void isEmptyCollection_Fail() {
        List<Integer> list = Arrays.asList(5, 2, 8);
        assertFails(
                () -> Verify.that(list, Is.emptyCollection(), "message"),
                "message\nExpected: an empty collection\n     but: <[5, 2, 8]>");
    }

    @Test
    public void isNonEmptyCollection_Pass() {
        List<Integer> list = Arrays.asList(5, 2, 8);
        Verify.that(list, Is.nonEmptyCollection(), "message");
    }

    @Test
    public void isNonEmptyCollection_Fail() {
        List<String> list = new ArrayList<>();
        assertFails(
                () -> Verify.that(list, Is.nonEmptyCollection(), "message"),
                "message\nExpected: not an empty collection\n     but: was <[]>");
    }

    @Test
    public void sameInstanceAs_Pass() {
        List<String> collection = Arrays.asList("abc", "def");
        Verify.that(collection, Is.sameInstanceAs(collection), "message");
    }

    @Test
    public void sameInstanceAs_Fail() {
        List<String> first = Arrays.asList("abc", "def");
        List<String> second = Arrays.asList("abc", "def");
        assertFails(
                () -> Verify.that(first, Is.sameInstanceAs(second), "message"),
                "message\nExpected: sameInstance(<[abc, def]>)\n     but: was <[abc, def]>");
    }

    @Test
    public void differentInstanceThan_Pass() {
        List<String> first = Arrays.asList("abc", "def");
        List<String> second = Arrays.asList("abc", "def");
        Verify.that(first, Is.differentInstanceThan(second), "message");
    }

    @Test
    public void differentInstanceThan_Fail() {
        List<String> collection = Arrays.asList("abc", "def");
        assertFails(
                () -> Verify.that(collection, Is.differentInstanceThan(collection), "message"),
                "message\nExpected: not sameInstance(<[abc, def]>)\n     but: was <[abc, def]>");
    }

    @Test
    public void stringContaining_Pass() {
        Verify.that("apple, pear, banana", Is.stringContaining("pear"));
    }

    @Test
    public void stringContaining_Fail() {
        assertFails(
                () -> Verify.that("apple, kiwi, banana", Is.stringContaining("pear"), "message"),
                "message\nExpected: a string containing \"pear\"\n     but: was \"apple, kiwi, banana\""
        );
    }

    @Test
    public void stringNotContaining_Pass() {
        Verify.that("apple, pear, banana", Is.stringNotContaining("kiwi"));
    }

    @Test
    public void stringNotContaining_Fail() {
        assertFails(
                () -> Verify.that("apple, pear, banana", Is.stringNotContaining("pear"), "message"),
                "message\nExpected: not a string containing \"pear\"\n     but: was \"apple, pear, banana\""
        );
    }

    @Test
    public void oneOf_Pass() {
        Verify.that("apple", Is.oneOf("apple", "banana", "cherry"));
    }

    @Test
    public void oneOf_Fail() {
        assertFails(
                () -> Verify.that("lettuce", Is.oneOf("apple", "banana", "cherry"), "message"),
                "message\nExpected: one of {\"apple\", \"banana\", \"cherry\"}\n     but: was \"lettuce\""
        );
    }

    @Test
    public void alphanumeric_Pass() {
        Verify.that("a", Is.alphanumeric());
        Verify.that("A", Is.alphanumeric());
        Verify.that("1", Is.alphanumeric());
        Verify.that("aA1", Is.alphanumeric());
    }

    @Test
    public void alphanumeric_Fail() {
        assertFails(
                () -> Verify.that("", Is.alphanumeric(), "message"),
                "message\nExpected: an alphanumeric string\n     but: was \"\""
        );

        assertFails(
                () -> Verify.that("!@#$%", Is.alphanumeric(), "message"),
                "message\nExpected: an alphanumeric string\n     but: was \"!@#$%\""
        );
    }

    @Test
    public void alphanumericOrEmpty_Pass() {
        Verify.that("", Is.alphanumericOrEmpty());
        Verify.that("a", Is.alphanumericOrEmpty());
        Verify.that("A", Is.alphanumericOrEmpty());
        Verify.that("1", Is.alphanumericOrEmpty());
        Verify.that("aA1", Is.alphanumericOrEmpty());
    }

    @Test
    public void alphanumericOrEmpty_Fail() {
        assertFails(
                () -> Verify.that("!@#$%", Is.alphanumericOrEmpty(), "message"),
                "message\nExpected: an alphanumeric or empty string\n     but: was \"!@#$%\""
        );
    }

    @Test
    public void stringWhoseLength_EqualTo_Pass() {
        Verify.that("", Is.stringWhoseLength(Is.equalTo(0)));
        Verify.that("abc", Is.stringWhoseLength(Is.equalTo(3)));
    }

    @Test
    public void stringWhoseLength_EqualTo_Fail_Null() {
        assertFails(
                () -> Verify.that(null, Is.stringWhoseLength(Is.equalTo(0)), "message"),
                "message\nExpected: a CharSequence with length <0>\n     but: was null"
        );
    }

    @Test
    public void stringWhoseLength_EqualTo_Fail_WrongLength() {
        assertFails(
                () -> Verify.that("abc", Is.stringWhoseLength(Is.equalTo(0)), "message"),
                "message\nExpected: a CharSequence with length <0>\n     but: length was <3>"
        );
    }

    @Test
    public void stringWhoseLength_NotEqualTo_Pass() {
        Verify.that("", Is.stringWhoseLength(Is.notEqualTo(5)));
        Verify.that("abc", Is.stringWhoseLength(Is.notEqualTo(0)));
    }

    @Test
    public void stringWhoseLength_NotEqualTo_Fail_Null() {
        assertFails(
                () -> Verify.that(null, Is.stringWhoseLength(Is.notEqualTo(0)), "message"),
                "message\nExpected: a CharSequence with length not <0>\n     but: was null"
        );
    }

    @Test
    public void stringWhoseLength_NotEqualTo_Fail() {
        assertFails(
                () -> Verify.that("abc", Is.stringWhoseLength(Is.notEqualTo(3)), "message"),
                "message\nExpected: a CharSequence with length not <3>\n     but: length was <3>"
        );
    }

    @Test
    public void nullOrEmptyString_Pass() {
        Verify.that(null, Is.nullOrEmptyString());
        Verify.that("", Is.nullOrEmptyString());
    }

    @Test
    public void nullOrEmptyString_Fail() {
        assertFails(
                () -> Verify.that(" ", Is.nullOrEmptyString(), "message"),
                "message\nExpected: one of {null, \"\"}\n     but: was \" \""
        );
    }

    @Test
    public void notNullOrEmptyString_Pass() {
        Verify.that(" ", Is.notNullOrEmptyString());
        Verify.that("abc", Is.notNullOrEmptyString());
    }

    @Test
    public void notNullOrEmptyString_Fail_Null() {
        assertFails(
                () -> Verify.that(null, Is.notNullOrEmptyString(), "message"),
                "message\nExpected: not one of {null, \"\"}\n     but: was null"
        );
    }

    @Test
    public void notNullOrEmptyString_Fail_EmptyString() {
        assertFails(
                () -> Verify.that("", Is.notNullOrEmptyString(), "message"),
                "message\nExpected: not one of {null, \"\"}\n     but: was \"\""
        );
    }

    @Test
    public void closeTo_Pass_ExactlyEqual() {
        Verify.that(1.01, Is.closeTo(1.01, 0.005));
    }

    @Test
    public void closeTo_Pass_WithinAcceptableError() {
        Verify.that(1.01, Is.closeTo(1.02, 0.015));
    }

    @Test
    public void closeTo_IsSubjectToFloatingPointError() {
        // Just because values look 0.01 apart, doesn't mean they'll pass with an acceptableError
        // of 0.01. See https://stackoverflow.com/questions/588004/is-floating-point-math-broken.
        assertFails(
                () -> Verify.that(1.01, Is.closeTo(1.02, 0.01)),
                null
        );

        // Adding a small value to acceptableError will make the verification pass.
        Verify.that(1.01, Is.closeTo(1.02, 0.01 + 1e-10));
    }

    @Test
    public void closeTo_Fail() {
        assertFails(
                () -> Verify.that(1.75, Is.closeTo(1.25, 0.25)),
                "\n" +
                        "Expected: a numeric value within <0.25> of <1.25>\n" +
                        "     but: <1.75> differed by <0.25> more than delta <0.25>"
        );
    }
}
