package common;

import org.jetbrains.annotations.NotNull;
import org.testng.annotations.Test;

public class CommandLineTests {

    @NotNull
    private String getResourceFilePath(String fileName) {
        return new ResourceFile("utils/" + fileName).getAbsolutePath();
    }

    @Test
    public void validateMixOfStandardAndErrorMessages() {
        CommandOutput output = new CommandLine(Shell.POWERSHELL)
                .displayOutput(false)
                .execute(getResourceFilePath("StandardWhileErrorMessages_Powershell.ps1"));
        Verify.that(output.standardOutputLines().size(), Is.equalTo(1000));
        Verify.that(output.standardErrorLines().size(), Is.equalTo(1000));
    }

    @Test
    public void validateFirstStandardThenErrorMessages() {
        CommandOutput output = new CommandLine(Shell.POWERSHELL)
                .displayOutput(false)
                .execute(getResourceFilePath("StandardMessagesThenErrorMessages_Powershell.ps1"));
        Verify.that(output.standardOutputLines().size(), Is.equalTo(1000));
        Verify.that(output.standardErrorLines().size(), Is.equalTo(1000));
    }

    @Test
    public void validateFirstErrorThenStandardMessages() {
        CommandOutput output = new CommandLine(Shell.POWERSHELL)
                .displayOutput(false)
                .execute(getResourceFilePath("ErrorMessagesThenStandardMessages_Powershell.ps1"));
        Verify.that(output.standardOutputLines().size(), Is.equalTo(1000));
        Verify.that(output.standardErrorLines().size(), Is.equalTo(1000));
    }

    @Test
    public void exitCode_NoShell() {
        // net.exe, with no arguments, will print usage information and return 1
        CommandOutput output = new CommandLine(Shell.NONE)
                .execute("net.exe");
        Verify.that(output.exitCode(), Is.equalTo(1));
    }

    @Test
    public void exitCode_Cmd() {
        CommandOutput output = new CommandLine(Shell.CMD)
                .execute("exit", "/b", "255");
        Verify.that(output.exitCode(), Is.equalTo(255));
    }

    @Test
    public void exitCode_PowerShell() {
        CommandOutput output = new CommandLine(Shell.POWERSHELL)
                .execute("exit", "42");
        Verify.that(output.exitCode(), Is.equalTo(42));
    }
}
