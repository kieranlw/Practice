package common;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.List;

public class DirectoryTests {
    private Directory directory;

    @BeforeMethod
    public void beforeMethod() {
        directory = Directory.createTempDirectory(getClass().getSimpleName());
        directory.clean();
    }

    // createDirectory

    @Test
    public void createDirectory() {
        directory.createDirectory("sub");
        Verify.that(directory.directory("sub").exists(), Is.equalTo(true));
    }

    @Test
    public void createDirectory_WhenDirectoryAlreadyExists_Succeeds() {
        directory.createDirectory("sub");
        directory.createDirectory("sub");
        Verify.that(directory.directory("sub").exists(), Is.equalTo(true));
    }

    @Test
    public void createDirectory_CanCreateMultipleLevels() {
        directory.createDirectory("a/b/c");
        Verify.that(directory.directory("a").directory("b").directory("c").exists(), Is.equalTo(true));
    }

    // exists

    @DataProvider
    public Object[][] existsData() {
        return new Object[][]{
                //@formatter:off
                // Scenario name              Given         When            Then
                //                            Items exist   Path to check   Expected result
                {"Directory doesn't exist",   "",           "nonexistent",  false},
                {"Directory exists",          "abc/",       "abc",          true},
                {"Parent dir doesn't exist",  "",           "a/b/c",        false},
                {"Path is a file          ",  "abc",        "abc",          false}
                //@formatter:on
        };
    }

    @Test(dataProvider = "existsData")
    public void exists(@SuppressWarnings("unused") String scenarioName,
                       String itemsToCreate, String path, boolean expectedResult) {
        directory.createItems(itemsToCreate);
        Verify.that(directory.directory(path).exists(), Is.equalTo(expectedResult));
    }

    // findFiles

    @DataProvider
    public Object[][] findFilesData() {
        return new Object[][]{
                //@formatter:off
                {"No matches",                "red,yellow",         "*b*",    ""},
                {"Non-recursive matches",     "red,blue,xyz/black", "*b*",    "blue"},
                {"Recursive matches",         "red,blue,xyz/black", "**/*b*", "blue,xyz/black"},
                {"Doesn't match directories", "black,blue/",        "*b*",    "black"}
                //@formatter:on
        };
    }

    @Test(dataProvider = "findFilesData")
    public void findFiles(@SuppressWarnings("unused") String scenarioName,
                          String itemsToCreate, String pattern, String expectedMatches) {
        directory.createItems(itemsToCreate);
        final List<WritableFile> results = directory.findFiles(pattern);
        Verify.that(directory.stringifyFiles(results), Is.equalTo(expectedMatches));
    }

    // deleteFiles and recycleFiles

    @DataProvider
    public Object[][] deleteFilesData() {
        return new Object[][]{
                //@formatter:off
                {"No matches",                     "green",                    "*b*",    "green"},
                {"Non-recursive pattern",          "red,blue,xyz/black",       "*b*",    "red,xyz/,xyz/black"},
                {"Recursive pattern",              "blue,xyz/green,xyz/black", "**/*b*", "xyz/,xyz/green"},
                {"Won't delete empty directories", "xyz/black",                "**/*b*", "xyz/"},
                {"Doesn't match directory names",  "blue/",                    "*b*",    "blue/"}
                //@formatter:on
        };
    }

    @Test(dataProvider = "deleteFilesData")
    public void deleteFiles(@SuppressWarnings("unused") String scenarioName,
                            String itemsToCreate, String patternToDelete, String expectedContentsAfterward) {
        directory.createItems(itemsToCreate);
        directory.deleteFiles(patternToDelete);
        Verify.that(directory.stringifyContents(), Is.equalTo(expectedContentsAfterward));
    }

    @Test(dataProvider = "deleteFilesData")
    public void recycleFiles(@SuppressWarnings("unused") String scenarioName,
                             String itemsToCreate, String patternToRecycle, String expectedContentsAfterward) {
        directory.createItems(itemsToCreate);
        directory.recycleFiles(patternToRecycle);
        Verify.that(directory.stringifyContents(), Is.equalTo(expectedContentsAfterward));
    }

    // delete[IfExists] and recycle[IfExists]

    @DataProvider
    public Object[][] deleteData() {
        return new Object[][]{
                //@formatter:off
                // Scenario                 Given items  Delete  Non-"IfExists" exception  Contents after
                {"Directory exists",        "sub/",      "sub/", null,                     ""},
                {"Directory is non-empty",  "sub/xyz",   "sub/", null,                     ""},
                {"Directory doesn't exist", "",          "sub/", RuntimeIOException.class, ""},
                //@formatter:on
        };
    }

    @Test(dataProvider = "deleteData")
    public void delete(@SuppressWarnings("unused") String scenarioName,
                       String itemsToCreate, String directoryToDelete,
                       Class<Exception> expectedException, String expectedContentsAfterward) {
        directory.createItems(itemsToCreate);
        Verify.allOf(() -> {
            Verify.that(() ->
                    directory.directory(directoryToDelete).delete()
            ).throwsException(expectedException);
            Verify.that(directory.stringifyContents(), Is.equalTo(expectedContentsAfterward));
        });
    }

    @Test(dataProvider = "deleteData")
    public void deleteIfExists(@SuppressWarnings("unused") String scenarioName,
                               String itemsToCreate, String directoryToDelete,
                               @SuppressWarnings("unused") Class<Exception> unused,
                               String expectedContentsAfterward) {
        directory.createItems(itemsToCreate);
        directory.directory(directoryToDelete).deleteIfExists();
        Verify.that(directory.stringifyContents(), Is.equalTo(expectedContentsAfterward));
    }

    @Test(dataProvider = "deleteData")
    public void recycle(@SuppressWarnings("unused") String scenarioName,
                        String itemsToCreate, String directoryToDelete,
                        Class<Exception> expectedException, String expectedContentsAfterward) {
        directory.createItems(itemsToCreate);
        Verify.allOf(() -> {
            Verify.that(() ->
                    directory.directory(directoryToDelete).recycle()
            ).throwsException(expectedException);
            Verify.that(directory.stringifyContents(), Is.equalTo(expectedContentsAfterward));
        });
    }

    @Test(dataProvider = "deleteData")
    public void recycleIfExists(@SuppressWarnings("unused") String scenarioName,
                                String itemsToCreate, String directoryToDelete,
                                @SuppressWarnings("unused") Class<Exception> unused,
                                String expectedContentsAfterward) {
        directory.createItems(itemsToCreate);
        directory.directory(directoryToDelete).recycleIfExists();
        Verify.that(directory.stringifyContents(), Is.equalTo(expectedContentsAfterward));
    }
}
