package common;

import org.testng.annotations.Test;
import utils2.tableData.Row;

import java.util.HashMap;
import java.util.Map;

public class RowFilterTests {
    @Test
    public void of_WithMatchers_Matching() {
        final RowFilter filter = RowFilter.of(
                "First Name", Is.equalTo("John"),
                "Last Name", Is.stringContaining("oe"));
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Doe")), Is.equalTo(true));
    }

    @Test
    public void of_WithMatchers_NotMatching() {
        final RowFilter filter = RowFilter.of(
                "First Name", Is.equalTo("John"),
                "Last Name", Is.stringContaining("xyz"));
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Doe")), Is.equalTo(false));
    }

    @Test
    public void of_WithStrings_Matching() {
        final RowFilter filter = RowFilter.of("First Name", "John", "Last Name", "Doe");
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Doe")), Is.equalTo(true));
    }

    @Test
    public void of_WithStrings_NotMatching() {
        final RowFilter filter = RowFilter.of("First Name", "John", "Last Name", "Doe");
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Smith")), Is.equalTo(false));
    }

    @Test
    public void of_TreatsNullAsIsEqualToNull() {
        final RowFilter filter = RowFilter.of("First Name", null);
        Verify.that(filter.matches(Row.of("First Name", null)), Is.equalTo(true));
        Verify.that(filter.matches(Row.of("First Name", "John")), Is.equalTo(false));
    }

    @Test
    public void of_FailsGracefullyIfGivenAMatcherOfNonString() {
        // Because of type erasure, we can't tell whether a matcher is a
        // Matcher<String> or a Matcher<something else>. If it's something
        // else, our strings won't match, but it shouldn't blow up either.
        final RowFilter filter = RowFilter.of("Answer", Is.equalTo(42));
        Verify.that(filter.matches(Row.of("Answer", "42")), Is.equalTo(false));
    }

    @Test
    public void ofMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("First Name", "John");
        map.put("Last Name", Is.equalTo("Doe"));
        final RowFilter filter = RowFilter.of(map);
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Doe")), Is.equalTo(true));
        Verify.that(filter.matches(Row.of("First Name", "Jack", "Last Name", "Doe")), Is.equalTo(false));
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Smith")), Is.equalTo(false));
    }

    @Test
    public void ofMapAndMatcherFactory() {
        Map<String, Object> map = new HashMap<>();
        map.put("First Name", "J");
        map.put("Last Name", Is.equalTo("Doe"));
        final RowFilter filter = RowFilter.of(map, Is::stringContaining);
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Doe")), Is.equalTo(true));
        Verify.that(filter.matches(Row.of("First Name", "Rob", "Last Name", "Doe")), Is.equalTo(false));
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Does")), Is.equalTo(false));
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Smith")), Is.equalTo(false));
    }

    @Test
    public void withString() {
        final RowFilter filter = RowFilter.of("First Name", "John")
                .with("Last Name", "Doe");
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Doe")), Is.equalTo(true), "Exact match");
        Verify.that(filter.matches(Row.of("First Name", "James", "Last Name", "Doe")), Is.equalTo(false), "Should keep original criteria");
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Smith")), Is.equalTo(false), "Should include 'with' criteria");
    }

    @Test
    public void withMatcher() {
        final RowFilter filter = RowFilter.of("First Name", "John")
                .with("Last Name", Is.stringContaining("D"));
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Doe")), Is.equalTo(true), "Exact match");
        Verify.that(filter.matches(Row.of("First Name", "James", "Last Name", "Doe")), Is.equalTo(false), "Should keep original criteria");
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Smith")), Is.equalTo(false), "Should include 'with' criteria");
    }

    @Test
    public void emptyFilter_ReturnsTrue() {
        final RowFilter filter = RowFilter.of();
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Doe")), Is.equalTo(true));
    }

    @Test
    public void allMatch_ReturnsTrue() {
        final RowFilter filter = RowFilter.of("First Name", "John", "Last Name", "Doe");
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Doe")), Is.equalTo(true));
    }

    @Test
    public void anyColumnsNotMatching_ReturnsFalse() {
        final RowFilter filter = RowFilter.of("First Name", "John", "Last Name", "Doe");
        Verify.that(filter.matches(Row.of("First Name", "John", "Last Name", "Smith")), Is.equalTo(false));
    }

    @Test
    public void missingColumn_MatchesAsNull() {
        final Row row = new Row();

        Verify.that(
                RowFilter.of("First Name", "John").matches(row),
                Is.equalTo(false));

        Verify.that(
                RowFilter.of("First Name", null).matches(row),
                Is.equalTo(true));
    }
}
