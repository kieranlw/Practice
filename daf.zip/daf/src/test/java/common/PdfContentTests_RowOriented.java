package common;

import org.testng.annotations.Test;
import utils2.Index;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class PdfContentTests_RowOriented {
    private static final Index PAGE_ZERO = Index.zeroBased(0);
    private static final Index PAGE_ONE = Index.zeroBased(1);
    private static final List<PdfCell> IRRELEVANT_CELLS = Collections.emptyList();
    private static final NumberFormat FORMAT_OPTIONAL_DECIMAL_PLACES = new DecimalFormat("#.##");

    private PdfCell createCellWithText(String text) {
        return new EmptyPdfCell() {
            @Override
            public String getText() {
                return text;
            }
        };
    }

    private PdfRow createRow(Index page, double y, String... cellValues) {
        final List<PdfCell> cells = ListUtils.map(cellValues, this::createCellWithText);
        return new PdfRow(page, y, cells);
    }

    private static List<String> rowKeys(PdfContent content) {
        return ListUtils.map(content.getRows(), r -> "p" + r.getPage().asZeroBased() +
                "y" + FORMAT_OPTIONAL_DECIMAL_PLACES.format(r.getY()));
    }

    private String contentToString(PdfContent content) {
        final List<String> rowValues = ListUtils.map(content.getRows(), this::rowToString);
        return String.join("\n", rowValues);
    }

    private String rowToString(PdfRow row) {
        final List<String> cellValues = ListUtils.map(row.getCells(), PdfCell::getText);
        return String.join(" | ", cellValues);
    }

    @Test
    public void rowsAreInitiallySortedByPageAndY() {
        final PdfContent content = new PdfContent(Arrays.asList(
                new PdfRow(PAGE_ZERO, 3.0, IRRELEVANT_CELLS),
                new PdfRow(PAGE_ONE, 2.0, IRRELEVANT_CELLS),
                new PdfRow(PAGE_ZERO, 1.0, IRRELEVANT_CELLS),
                new PdfRow(PAGE_ZERO, 2.0, IRRELEVANT_CELLS)
        ));

        Verify.that(rowKeys(content), Is.equalTo(Arrays.asList("p0y1", "p0y2", "p0y3", "p1y2")));
    }

    @Test
    public void rowsStaySorted() {
        final PdfContent content = new PdfContent(Arrays.asList(
                new PdfRow(PAGE_ZERO, 1.0, IRRELEVANT_CELLS),
                new PdfRow(PAGE_ZERO, 2.0, IRRELEVANT_CELLS),
                new PdfRow(PAGE_ONE, 1.0, IRRELEVANT_CELLS)
        ));

        content.getRows().add(new PdfRow(PAGE_ZERO, 3.0, IRRELEVANT_CELLS));
        Verify.that(rowKeys(content), Is.equalTo(Arrays.asList("p0y1", "p0y2", "p0y3", "p1y1")));
    }

    @Test
    public void fixRowAlignment() {
        final PdfContent content = new PdfContent(Arrays.asList(
                new PdfRow(PAGE_ZERO, 1.0, IRRELEVANT_CELLS),
                new PdfRow(PAGE_ZERO, 1.1, IRRELEVANT_CELLS),
                new PdfRow(PAGE_ZERO, 1.9, IRRELEVANT_CELLS),
                new PdfRow(PAGE_ZERO, 2.0, IRRELEVANT_CELLS),
                new PdfRow(PAGE_ZERO, 3.0, IRRELEVANT_CELLS),
                new PdfRow(PAGE_ONE, 1.2, IRRELEVANT_CELLS)
        ));

        content.fixRowAlignment(1.0);

        Verify.that(rowKeys(content), Is.equalTo(Arrays.asList("p0y1", "p0y2", "p0y3", "p1y1.2")));
    }

    @Test
    public void trimPageHeaders() {
        final PdfContent content = new PdfContent(Arrays.asList(
                createRow(PAGE_ZERO, 0.8, "First Page First Header"),
                createRow(PAGE_ZERO, 0.9, "First Page Second Header"),
                createRow(PAGE_ZERO, 1.0, "Content One"),
                createRow(PAGE_ZERO, 2.0, "Content Two"),
                createRow(PAGE_ONE, 0.8, "Second Page First Header"),
                createRow(PAGE_ONE, 0.9, "Second Page Second Header"),
                createRow(PAGE_ONE, 1.0, "Content Three")
        ));

        content.trimPageHeaders("First Page Second Header");

        Verify.that(contentToString(content), Is.equalTo("Content One\nContent Two\nContent Three"));
    }
    @Test
    public void trimPageFooters() {
        final PdfContent content = new PdfContent(Arrays.asList(
                createRow(PAGE_ZERO, 1, "Content One"),
                createRow(PAGE_ZERO, 2, "Content Two"),
                createRow(PAGE_ZERO, 2.1, "First Page First Footer"),
                createRow(PAGE_ZERO, 2.2, "First Page Second Footer"),
                createRow(PAGE_ONE, 1, "Content Three"),
                createRow(PAGE_ONE, 2.1, "Second Page First Footer"),
                createRow(PAGE_ONE, 2.2, "Second Page Second Footer")
        ));

        content.trimPageFooters("First Page First Footer");

        Verify.that(contentToString(content), Is.equalTo("Content One\nContent Two\nContent Three"));
    }
}
