package common;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Objects;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class StringUtilsTests {
    @DataProvider(name = "angleQuoteData")
    public Object[][] angleQuoteData() {
        return new Object[][]{
                new Object[]{null, "null"},
                new Object[]{"", "«»"},
                new Object[]{"abc", "«abc»"}
        };
    }

    @Test(dataProvider = "angleQuoteData")
    public void angleQuote(String input, String expectedOutput) {
        final String actualOutput = StringUtils.angleQuote(input);
        assertThat(actualOutput, equalTo(expectedOutput));
    }

    @DataProvider(name = "getOptionsData")
    public Object[][] getOptionsData() {
        return new Object[][]{
                new Object[]{"", 0, ""},
                new Object[]{"", 1, ""},
                new Object[]{"", 2, ""},
                new Object[]{"", 3, ""},
                new Object[]{"a", 0, ""},
                new Object[]{"a", 1, "a"},
                new Object[]{"a", 2, "a"},
                new Object[]{"a", 3, "a"},
                new Object[]{"a,b", 0, ""},
                new Object[]{"a,b", 1, "a"},
                new Object[]{"a,b", 2, "a,b"},
                new Object[]{"a,b", 3, "a,b"},
                new Object[]{"a,b,c", 0, ""},
                new Object[]{"a,b,c", 1, "a"},
                new Object[]{"a,b,c", 2, "a,b"},
                new Object[]{"a,b,c", 3, "a,b,c"},
        };
    }

    @Test(dataProvider = "getOptionsData")
    public void getOptions(String input, int numberOfIndexesToKeep, String expectedOutput) {
        final String actualOutput = StringUtils.getOptions(input, numberOfIndexesToKeep);
        assertThat(actualOutput, equalTo(expectedOutput));
    }

    @DataProvider(name = "expandXPathPlaceholders")
    @SuppressWarnings("SpellCheckingInspection")
    public Object[][] expandXPathPlaceholdersData() {
        return new Object[][]{
                // No placeholders
                new Object[]{"", new String[]{}, ""},
                new Object[]{"", new String[]{"x", "y"}, ""},
                new Object[]{"simple text", new String[]{"x", "y"}, "simple text"},
                // Multiple values, varying order
                new Object[]{"A{0}B{1}C", new String[]{"x", "y"}, "AxByC"},
                new Object[]{"A{1}B{0}C", new String[]{"x", "y"}, "AyBxC"},
                new Object[]{"A{0}B", new String[]{"x", "y"}, "AxB"},
                new Object[]{"A{1}B", new String[]{"x", "y"}, "AyB"},
                // Same placeholder multiple times
                new Object[]{"A{0}B{0}C{0}D", new String[]{"x"}, "AxBxCxD"},
                // Unquoted placeholder -> verbatim replacement
                new Object[]{"A{0}B", new String[]{"'"}, "A'B"},
                new Object[]{"A{0}B", new String[]{"\""}, "A\"B"},
                new Object[]{"'{0} or {1}'", new String[]{"'", "\""}, "'' or \"'"},
                new Object[]{"'{0}\"", new String[]{"'"}, "''\""},
                // Matching quotes directly around the placeholder -> auto-quoted replacement
                new Object[]{"A'{0}'B", new String[]{"x"}, "A\"x\"B"},
                new Object[]{"A'{0}'B", new String[]{"'"}, "A\"'\"B"},
                new Object[]{"A'{0}'B", new String[]{"\""}, "A'\"'B"},
                new Object[]{"A'{0}'B", new String[]{"x'y\"z"}, "Aconcat(\"x'y\", '\"', \"z\")B"},
                // Unused replacements can be null
                new Object[]{"", new String[]{null, null}, ""},
                // Don't recursively replace (could lead to infinite loops, plus it's hard to see why we'd bother)
                new Object[]{"A{0}B", new String[]{"{0}"}, "A{0}B"},
                // Edge case: input contains characters with special meaning to MessageFormat
                new Object[]{"'quotes' \"quotes\" {0}{1}", new String[]{"x", "y"}, "'quotes' \"quotes\" xy"},
                // Edge case: replacement contains strings with special meaning to String.replaceAll
                new Object[]{"A{0}B{1}C", new String[]{"\\0", "$0"}, "A\\0B$0C"},
                new Object[]{"A{0}B{1}C", new String[]{"\\1", "$1"}, "A\\1B$1C"},
        };
    }

    @Test(dataProvider = "expandXPathPlaceholders")
    public void expandXPathPlaceholders(String inputXPath, String[] placeholders, String expectedOutput) {
        final String actualOutput = StringUtils.expandXPathPlaceholders(inputXPath, placeholders);
        assertThat(actualOutput, equalTo(expectedOutput));
    }

    @Test
    public void expandXPathPlaceholders_IfPlaceholderHasNoReplacement_FixItMessage() {
        String newXPath = StringUtils.expandXPathPlaceholders("{0}");
        assertThat(newXPath, equalTo("IF YOU SEE THIS FIX YOUR ComponentFactory.init TO PASS IN APPROPRIATE VALUE FOR INDEX 0"));
    }

    @Test
    public void expandXPathPlaceholders_IfPlaceholderHasNullReplacement_FixItMessage() {
        String newXPath = StringUtils.expandXPathPlaceholders("{0}", new String[]{null});
        assertThat(newXPath, equalTo("IF YOU SEE THIS FIX YOUR ComponentFactory.init TO PASS IN APPROPRIATE VALUE FOR INDEX 0"));
    }

    @Test
    public void camelCaseToHumanReadable() {
        String input = "theQuickBrownFoxJumpsOverTheLazyDog";
        String expected = "The Quick Brown Fox Jumps Over The Lazy Dog";
        String output = StringUtils.camelCaseToHumanReadable(input);
        assertThat(output, equalTo(expected));
    }

    @DataProvider(name = "leadingSubstringData")
    private static Object[][] getLeadingSubstringData() {
        return new Object[][]{
                new Object[]{"", "", ""},
                new Object[]{"abc", "aBc", "a"},
                new Object[]{"something", "something", "something"},
                new Object[]{"something longer", "something", "something"},
                new Object[]{"something", "something longer", "something"},
                new Object[]{"something", "somewhere", "some"},
                new Object[]{"first character", "1st character", ""},
                new Object[]{"last character = X", "last character = Y", "last character = "},
        };
    }

    @Test(dataProvider = "leadingSubstringData")
    public void leadingSubstring(String a, String b, String expectedResult) {
        Verify.that(StringUtils.leadingSubstring(a, b, Objects::equals), Is.equalTo(expectedResult));
    }

    @DataProvider(name = "leadingSubstringData_IgnoreCase")
    private static Object[][] getLeadingSubstringData_IgnoreCase() {
        return new Object[][]{
                new Object[]{"", "", ""},
                new Object[]{"abc", "aBc", "abc"},
        };
    }

    @Test(dataProvider = "leadingSubstringData_IgnoreCase")
    public void leadingSubstring_IgnoreCase(String a, String b, String expectedResult) {
        Verify.that(StringUtils.leadingSubstring(a, b, String::equalsIgnoreCase), Is.equalTo(expectedResult));
    }

    @DataProvider(name = "normalizeWhitespaceData")
    private static Object[][] getNormalizeWhitespaceData() {
        return new Object[][]{
                new Object[]{"", ""},
                new Object[]{"abc", "abc"},
                new Object[]{"  \r\n\t  ", ""},
                new Object[]{"\r\n\t  abc  \r\n\t", "abc"},
                new Object[]{"\r\n\tabc\r\n\tdef\r\n\t", "abc def"}
        };
    }

    @Test(dataProvider = "normalizeWhitespaceData")
    public void normalizeWhitespace(String input, String expectedOutput) {
        Verify.that(StringUtils.normalizeWhitespace(input), Is.equalTo(expectedOutput));
    }
}
