package common;

public class BaseHamcrestTest {
    protected interface Action {
        void run() throws Exception;
    }

    protected void assertFails(Action action, String expectedExceptionMessage) {

        boolean gotException;
        try {
            action.run();
            gotException = false;
        } catch (AssertionError e) {
            gotException = true;

            if (expectedExceptionMessage != null) {
                Verify.that(e.getMessage(), Is.equalTo(expectedExceptionMessage));
            }
        } catch (Exception e) {
            throw new AssertionError("Expected AssertionError but got: " + e, e);
        }

        Verify.that(gotException, Is.equalTo(true), "Was an exception thrown?");
    }
}
