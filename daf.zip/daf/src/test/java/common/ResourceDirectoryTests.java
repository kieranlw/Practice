package common;

import org.testng.annotations.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ResourceDirectoryTests {
    private static final String VALID_DIRECTORY_PATH = "common/resource_files";
    private static final ResourceDirectory VALID_DIRECTORY = new ResourceDirectory(VALID_DIRECTORY_PATH);
    private static final String NONEXISTENT_DIRECTORY_PATH = "invalidDirectoryName";
    private static final ResourceDirectory NONEXISTENT_DIRECTORY = new ResourceDirectory(NONEXISTENT_DIRECTORY_PATH);

    @Test
    public void exists_WhenDirectoryExists_ReturnsTrue() {
        Verify.that(VALID_DIRECTORY.exists(), Is.equalTo(true));
    }

    @Test
    public void exists_WhenDirectoryDoesNotExist_ReturnsFalse() {
        Verify.that(NONEXISTENT_DIRECTORY.exists(), Is.equalTo(false));
    }

    @Test
    public void getAbsolutePath_WhenDirectoryExists_ReturnsValidAbsolutePath() {
        Path path = Paths.get(VALID_DIRECTORY.getAbsolutePath());
        Verify.that(Files.exists(path), "exists");
        Verify.that(path.isAbsolute(), Is.equalTo(true), "is absolute path");
    }

    @Test
    public void getAbsolutePath_WhenDirectoryDoesNotExist_Throws() {
        Verify.that(NONEXISTENT_DIRECTORY::getAbsolutePath).throwsException(
                RuntimeException.class,
                "Resource path not found: " + NONEXISTENT_DIRECTORY_PATH);
    }

    @Test
    public void getFiles_WhenDirectoryExists_ReturnsFiles() throws IOException {
        // Build a string that lists all the filenames, and assert against that.
        // That way, if our test fails, the error message will show which files *were* found.
        String fileNames = String.join("\n", ListUtils.map(VALID_DIRECTORY.getFiles(), ReadableFile::getAbsolutePath));
        Verify.that(fileNames, Is.stringContaining("ResourceFile.txt"));
    }

    @Test
    public void getFiles_WhenDirectoryDoesNotExist_Throws() {
        Verify.that(NONEXISTENT_DIRECTORY::getFiles).throwsException(
                RuntimeException.class,
                "Resource path not found: " + NONEXISTENT_DIRECTORY_PATH);
    }

    @Test
    public void toString_ContainsOriginalPath() {
        Verify.that(VALID_DIRECTORY.toString(), Is.equalTo("[" + VALID_DIRECTORY_PATH + "]"));
        Verify.that(NONEXISTENT_DIRECTORY.toString(), Is.equalTo("[" + NONEXISTENT_DIRECTORY_PATH + "]"));
    }
}
