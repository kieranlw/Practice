package common;

import org.testng.annotations.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ResourceFileTests {
    private static final String VALID_FILE_PATH = "common/resource_files/ResourceFile.txt";
    private static final ResourceFile VALID_FILE = new ResourceFile(VALID_FILE_PATH);
    private static final String NONEXISTENT_FILE_PATH = "common/FileThatDoesNotExist.txt";
    private static final ResourceFile NONEXISTENT_FILE = new ResourceFile(NONEXISTENT_FILE_PATH);

    @Test
    public void exists_WhenFileExists_ReturnsTrue() {
        Verify.that(VALID_FILE.exists(), Is.equalTo(true));
    }

    @Test
    public void exists_WhenFileDoesNotExist_ReturnsFalse() {
        Verify.that(NONEXISTENT_FILE.exists(), Is.equalTo(false));
    }

    @Test
    public void getAbsolutePath_WhenFileExists_ReturnsValidAbsolutePath() {
        Path path = Paths.get(VALID_FILE.getAbsolutePath());
        Verify.that(Files.exists(path), "exists");
        Verify.that(path.isAbsolute(), Is.equalTo(true), "is absolute path");
    }

    @Test
    public void getAbsolutePath_WhenFileDoesNotExist_Throws() {
        Verify.that(NONEXISTENT_FILE::getAbsolutePath).throwsException(
                RuntimeException.class,
                "Resource path not found: " + NONEXISTENT_FILE_PATH);
    }

    @Test
    public void withFileNameSuffix() {
        ResourceFile baseName = new ResourceFile("common/resource_files/ResourceFile");
        ReadableFile withSuffix = baseName.withFileNameSuffix(".txt");
        Verify.that(withSuffix.exists(), Is.equalTo(true), "file exists: " + withSuffix);
        Verify.that(withSuffix.getAbsolutePath(), Is.stringContaining("common\\resource_files\\ResourceFile.txt"));
    }

    @Test
    public void toString_ContainsOriginalPath() {
        Verify.that(VALID_FILE.toString(), Is.equalTo("[" + VALID_FILE_PATH + "]"));
        Verify.that(NONEXISTENT_FILE.toString(), Is.equalTo("[" + NONEXISTENT_FILE_PATH + "]"));
    }
}
