package common;

import common.Is;
import common.Verify;
import org.testng.annotations.Test;

public class VerifyTests_VerifyAllOf {
    private String getErrorMessage(Runnable block) {
        try {
            Verify.allOf(block);
            throw new RuntimeException("Expected an error but got none");
        } catch (AssertionError ex) {
            return ex.getMessage();
        }
    }

    @Test
    public void withoutDescription_Passing() {
        Verify.allOf(() -> {
            Verify.that(1 + 1, Is.equalTo(2));
            Verify.that(2 + 2, Is.equalTo(4));
        });
    }

    @Test
    public void withoutDescription_Failing() {
        String errorMessage = getErrorMessage(() -> {
            Verify.that(1 + 1, Is.equalTo(3));
            Verify.that(2 + 2, Is.equalTo(3));
        });
        Verify.that(errorMessage, Is.stringContaining("Expected: <3>\n     but: was <2>"));
        Verify.that(errorMessage, Is.stringContaining("Expected: <3>\n     but: was <4>"));
    }

    @Test
    public void withDescription_Passing() {
        Verify.allOf(() -> {
            Verify.that(1 + 1, Is.equalTo(2), "description1");
            Verify.that(2 + 2, Is.equalTo(4), "description2");
        });
    }

    @Test
    public void withDescription_Failing() {
        String errorMessage = getErrorMessage(() -> {
            Verify.that(1 + 1, Is.equalTo(3), "description1");
            Verify.that(2 + 2, Is.equalTo(3), "description2");
        });
        Verify.that(errorMessage, Is.stringContaining("description1\nExpected: <3>\n     but: was <2>"));
        Verify.that(errorMessage, Is.stringContaining("description2\nExpected: <3>\n     but: was <4>"));
    }

    @Test
    public void boolean_WithoutDescription_Passing() {
        Verify.allOf(() -> {
            Verify.that(true);
            Verify.that(true);
        });
    }

    @Test
    public void boolean_WithoutDescription_Failing() {
        String errorMessage = getErrorMessage(() -> {
            Verify.that(false);
            Verify.that(false);
        });
        Verify.that(errorMessage, Is.stringContaining("\n\nExpected: <true>\n     but: was <false>\n\nExpected: <true>\n     but: was <false>"));
    }

    @Test
    public void boolean_WithDescription_Passing() {
        Verify.allOf(() -> {
            Verify.that(true, "description1");
            Verify.that(true, "description2");
        });
    }

    @Test
    public void boolean_WithDescription_Failing() {
        String errorMessage = getErrorMessage(() -> {
            Verify.that(false, "description1");
            Verify.that(false, "description2");
        });
        Verify.that(errorMessage, Is.stringContaining("description1\nExpected: <true>\n     but: was <false>"));
        Verify.that(errorMessage, Is.stringContaining("description2\nExpected: <true>\n     but: was <false>"));
    }

    @Test
    public void nested_Pass() {
        Verify.allOf(() -> {
            Verify.allOf(() -> {
                Verify.that(2 + 2, Is.equalTo(4));
                Verify.that(3 + 3, Is.equalTo(6));
            });
            Verify.allOf(() -> {
                Verify.that(4 * 4, Is.equalTo(16));
                Verify.that(5 * 5, Is.equalTo(25));
            });
        });
    }

    @Test
    public void nested_OnFailure_AccumulatesEverything() {
        // We shouldn't throw until the end of the outermost Verify.allOf
        String errorMessage = getErrorMessage(() -> {
            Verify.allOf(() -> {
                Verify.that(2 + 2, Is.equalTo(10));
                Verify.that(3 + 3, Is.equalTo(11));
            });
            Verify.allOf(() -> {
                Verify.that(4 * 4, Is.equalTo(12));
                Verify.that(5 * 5, Is.equalTo(13));
            });
        });
        Verify.that(errorMessage, Is.stringContaining("Expected: <10>\n     but: was <4>"));
        Verify.that(errorMessage, Is.stringContaining("Expected: <11>\n     but: was <6>"));
        Verify.that(errorMessage, Is.stringContaining("Expected: <12>\n     but: was <16>"));
        Verify.that(errorMessage, Is.stringContaining("Expected: <13>\n     but: was <25>"));
    }
}
