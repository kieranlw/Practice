package common;

import utils2.Index;

public class EmptyPdfCell implements PdfCell {
    @Override
    public Index getPageIndex() {
        return Index.zeroBased(0);
    }

    @Override
    public double getX() {
        return 0;
    }

    @Override
    public double getEndX() {
        return 0;
    }

    @Override
    public double getY() {
        return 0;
    }

    @Override
    public String getText() {
        return "";
    }
}
