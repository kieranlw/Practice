package common;

import org.testng.annotations.Test;
import utils.RunnableWithException;

import java.util.concurrent.Callable;

public class VerifyTests_ThrowsException {
    private static class SampleExceptionBase extends Exception {
        public SampleExceptionBase(String s) {
            super(s);
        }
    }

    private static class SampleException extends SampleExceptionBase {
        public SampleException(String s) {
            super(s);
        }
    }

    private void shouldFail(Runnable lambda, String expectedMessage) {
        try {
            lambda.run();
            throw new RuntimeException("Expected an exception but none was thrown");
        } catch (AssertionError e) {
            Verify.that(e.getMessage(), Is.equalTo(expectedMessage));
        }
    }

    private void verifyReturnsCorrectFluentInterface(Object obj) {
        Verify.that(obj.getClass(), Is.equalTo(Verify.LambdaVerifications.class));
    }

    // 1. Normal usage / overload-resolution tests
    // The main tests, below, don't actually pass "() -> ..." inline in their parameter lists;
    // they put the lambda into a variable first, so they can be 100% sure they specify
    // whether they're using Callable (value-returning lambda) or RunnableWithException
    // (void-returning lambda). But normal usage *will* pass inline lambdas. So make sure we
    // have at least one test that calls the verifications that way, to make sure the compiler
    // doesn't give overload-resolution errors.

    @Test
    public void compilerAcceptsInlineLambdas() {
        verifyReturnsCorrectFluentInterface(Verify.that(() -> null));
        verifyReturnsCorrectFluentInterface(Verify.that(OsUtils::isMac));
        verifyReturnsCorrectFluentInterface(Verify.that(() -> ProxyUtils.getProxyUrl("http")));
        verifyReturnsCorrectFluentInterface(Verify.that(() -> {
        }));
        verifyReturnsCorrectFluentInterface(Verify.that(() -> System.out.println("out")));
        verifyReturnsCorrectFluentInterface(Verify.that(() -> {
            throw new RuntimeException();
        }));
    }

    // 2. Primary tests: specify the Callable<Object> overloads
    // 2a. Lambda doesn't throw anything

    @Test
    public void whenLambdaDoesNotThrow_VerificationFails() {
        Callable<Object> lambda = () -> null;
        shouldFail(
                () -> Verify.that(lambda).throwsException(ArithmeticException.class),
                "Expected exception of type java.lang.ArithmeticException, but none was thrown");
    }

    // 2b. Lambda throws, we call throwsException(class)

    @Test
    public void whenLambdaThrowsCorrectException_VerificationPasses() {
        Callable<Object> lambda = () -> {
            throw new SampleException("message");
        };
        Verify.that(lambda).throwsException(SampleException.class);
    }

    @Test
    public void whenLambdaThrowsWrongException_VerificationFails() {
        // The exception type is an exact match, not a "this type or descendants" match
        Callable<Object> lambda = () -> {
            throw new SampleException("message");
        };
        shouldFail(
                () -> Verify.that(lambda).throwsException(SampleExceptionBase.class),
                "The following assertions failed:\n" +
                        "\n" +
                        "Exception type\n" +
                        "Expected: <class common.VerifyTests_ThrowsException$SampleExceptionBase>\n" +
                        "     but: was <class common.VerifyTests_ThrowsException$SampleException>");
    }

    // 2c. Lambda throws, we call throwsException(class, message)
    // Don't bother testing the wrong-exception-only overload; we can presume that's
    // already covered by the above tests and we don't need to repeat ourselves

    @Test
    public void whenLambdaThrowsCorrectMessage_VerificationPasses() {
        Callable<Object> lambda = () -> {
            throw new SampleException("message");
        };
        Verify.that(lambda).throwsException(SampleException.class, "message");
    }

    @Test
    public void whenLambdaThrowsWrongMessage_VerificationFails() {
        // The exception type is an exact match, not a "this type or descendants" match
        Callable<Object> lambda = () -> {
            throw new SampleException("actual");
        };
        shouldFail(
                () -> Verify.that(lambda).throwsException(SampleException.class, "expected"),
                "The following assertions failed:\n" +
                        "\n" +
                        "Exception message\n" +
                        "Expected: \"expected\"\n" +
                        "     but: \"actual\"\n" +
                        " differs:  ^ starting at index 0");
    }

    @Test
    public void whenLambdaThrowsWrongExceptionAndMessage_VerificationFails() {
        // The exception type is an exact match, not a "this type or descendants" match
        Callable<Object> lambda = () -> {
            throw new SampleException("actual");
        };
        shouldFail(
                () -> Verify.that(lambda).throwsException(SampleExceptionBase.class, "expected"),
                "The following assertions failed:\n" +
                        "\n" +
                        "Exception type\n" +
                        "Expected: <class common.VerifyTests_ThrowsException$SampleExceptionBase>\n" +
                        "     but: was <class common.VerifyTests_ThrowsException$SampleException>\n" +
                        "\n" +
                        "Exception message\n" +
                        "Expected: \"expected\"\n" +
                        "     but: \"actual\"\n" +
                        " differs:  ^ starting at index 0");
    }

    // 3. Spot-check the RunnableWithException overloads
    // We can assume these basically work, so we don't need to test them exhaustively
    // like we did the above, but we should still have a few tests for them.

    @Test
    public void lambdaReturnsVoid_WhenLambdaDoesNotThrow_VerificationFails() {
        RunnableWithException lambda = () -> {
        };
        shouldFail(
                () -> Verify.that(lambda).throwsException(ArithmeticException.class),
                "Expected exception of type java.lang.ArithmeticException, but none was thrown");
    }

    @Test
    public void lambdaReturnsVoid_WhenLambdaThrowsWrongExceptionAndMessage_VerificationFails() {
        // The exception type is an exact match, not a "this type or descendants" match
        RunnableWithException lambda = () -> {
            throw new SampleException("actual");
        };
        shouldFail(
                () -> Verify.that(lambda).throwsException(SampleExceptionBase.class, "expected"),
                "The following assertions failed:\n" +
                        "\n" +
                        "Exception type\n" +
                        "Expected: <class common.VerifyTests_ThrowsException$SampleExceptionBase>\n" +
                        "     but: was <class common.VerifyTests_ThrowsException$SampleException>\n" +
                        "\n" +
                        "Exception message\n" +
                        "Expected: \"expected\"\n" +
                        "     but: \"actual\"\n" +
                        " differs:  ^ starting at index 0");
    }
}
