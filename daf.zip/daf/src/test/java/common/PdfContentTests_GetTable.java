package common;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils2.Index;
import utils2.TableData2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class PdfContentTests_GetTable {
    private static final Column TOO_FAR_LEFT = new Column(0.0, 25.0, "Too far left");
    private static final Column COL1 = new Column(100.0, 125.0, "Col1");
    private static final Column COL2 = new Column(200.0, 225.0, "Col2");
    private static final Column COL3 = new Column(300.0, 325.0, "Col3");
    private static final Column TOO_FAR_RIGHT = new Column(400.0, 425.0, "Too far right");
    private static final String TOTAL_NAME = "Total";

    private List<PdfRow> rows;

    private void addRow(int pageNumber, PdfCell... cells) {
        final Index pageIndex = Index.oneBased(pageNumber);

        // If we're on the same page as the previous row, increment y by 10.
        // Otherwise, start at y=10 for the first row of the new page.
        // The exact values aren't really important, they just need to be unique
        // and increasing.
        double y = 10.0;
        if (rows.size() > 0) {
            final PdfRow previousRow = rows.get(rows.size() - 1);
            if (Objects.equals(previousRow.getPage(), pageIndex)) {
                y = previousRow.getY() + 10.0;
            }
        }

        rows.add(new PdfRow(pageIndex, y, Arrays.asList(cells)));
    }

    private PdfCell cell(double x, double endX, String text) {
        return new EmptyPdfCell() {
            @Override
            public double getX() {
                return x;
            }

            @Override
            public double getEndX() {
                return endX;
            }

            @Override
            public String getText() {
                return text;
            }
        };
    }

    private PdfContent createContent() {
        addRow(99, cell(COL1.x(), COL1.columnHeaderEndX(), TOTAL_NAME));
        addRow(99, cell(COL1.x(), COL1.columnHeaderEndX(), "After table footer"));
        return new PdfContent(rows);
    }

    private TableData2 getTable() {
        final TableData2 table = createContent()
                .getTable(COL1.name(), COL3.name(),
                        TOTAL_NAME, Endpoint.EXCLUDE);
        return table;
    }

    private void verifyOneRowWithNoColumns() {
        final TableData2 table = getTable();
        table.verify()
                .rowCount(Is.equalTo(1))
                .row(0).cellCount(Is.equalTo(0));
    }

    private void verifyOneRowWithTextInColumn(String expectedText, Column expectedColumn) {
        final TableData2 table = getTable();
        table.verify()
                .rowCount(Is.equalTo(1))
                .row(0)
                .cellCount(Is.equalTo(1))
                .cell(expectedColumn.name(), Is.equalTo(expectedText));
    }

    @DataProvider(name = "Columns")
    public Object[][] getColumns() {
        return new Object[][]{{COL1}, {COL2}, {COL3}};
    }

    @BeforeMethod
    public void beforeMethod() {
        rows = new ArrayList<>();
        addRow(1, cell(COL1.x(), COL1.columnHeaderEndX(), "Before table header"));
        addRow(1,
                cell(TOO_FAR_LEFT.x(), TOO_FAR_LEFT.columnHeaderEndX(), TOO_FAR_LEFT.name()),
                cell(COL1.x(), COL1.columnHeaderEndX(), COL1.name()),
                cell(COL2.x(), COL2.columnHeaderEndX(), COL2.name()),
                cell(COL3.x(), COL3.columnHeaderEndX(), COL3.name()),
                cell(TOO_FAR_RIGHT.x(), TOO_FAR_RIGHT.columnHeaderEndX(), TOO_FAR_RIGHT.name())
        );
    }

    @Test
    public void withNoDataRows_ReturnsEmptyTable() {
        getTable().verify().tableSize(0);
    }

    @Test
    public void dataToLeftOfMainColumns_IsIgnored() {
        addRow(1, cell(TOO_FAR_LEFT.x(), TOO_FAR_LEFT.columnHeaderEndX(), "Off to the left"));
        verifyOneRowWithNoColumns();
    }

    @Test
    public void dataToRightOfMainColumns_IsIgnored() {
        addRow(1, cell(TOO_FAR_RIGHT.x(), TOO_FAR_RIGHT.columnHeaderEndX(), "Off to the right"));
        verifyOneRowWithNoColumns();
    }

    @Test(dataProvider = "Columns")
    public void leftJustified(Column column) {
        addRow(1, cell(column.x(), column.columnHeaderEndX() + 10, "Left justified"));
        verifyOneRowWithTextInColumn("Left justified", column);
    }

    @Test(dataProvider = "Columns")
    public void leftJustifiedAndIndented(Column column) {
        addRow(1, cell(column.x() + 10, column.columnHeaderEndX() + 10, "Left justified"));
        verifyOneRowWithTextInColumn("Left justified", column);
    }

    @Test(dataProvider = "Columns")
    public void leftJustifiedAndMisaligned(Column column) {
        addRow(1, cell(column.x() - 1, column.columnHeaderEndX() + 10, "Left justified"));
        verifyOneRowWithTextInColumn("Left justified", column);
    }

    @Test(dataProvider = "Columns")
    public void rightJustified(Column column) {
        addRow(1, cell(column.x() - 10, column.columnHeaderEndX(), "Right justified"));
        verifyOneRowWithTextInColumn("Right justified", column);
    }

    @Test(dataProvider = "Columns")
    public void rightJustifiedAndMisaligned(Column column) {
        addRow(1, cell(column.x() - 10, column.columnHeaderEndX() + 1, "Right justified"));
        verifyOneRowWithTextInColumn("Right justified", column);
    }

    @Test(dataProvider = "Columns")
    public void leftJustifiedAndSpanningMultipleColumns(Column column) {
        addRow(1, cell(column.x(), column.columnHeaderEndX() + 300.0, "Column span"));
        verifyOneRowWithTextInColumn("Column span", column);
    }

    @Test
    public void dataToLeftOfMainColumns_AndSpanningIntoTheTable_IsIgnored() {
        addRow(1, cell(TOO_FAR_LEFT.x(), COL2.columnHeaderEndX(), "Column span"));
        verifyOneRowWithNoColumns();
    }

    private static class Column {
        private final double x;
        private final double columnHeaderEndX;
        private final String name;

        private Column(double x, double columnHeaderEndX, String name) {
            this.x = x;
            this.columnHeaderEndX = columnHeaderEndX;
            this.name = name;
        }

        public double x() {
            return x;
        }

        public double columnHeaderEndX() {
            return columnHeaderEndX;
        }

        public String name() {
            return name;
        }

        @Override
        public String toString() {
            return name();
        }
    }
}
