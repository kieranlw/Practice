package common;

import org.testng.annotations.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.function.Consumer;

public class VerifyTests_VerifyAllOf_WithSoftAssertAdapter {
    private String getErrorMessage(Consumer<Verify.SoftAssertAdapter> block) {
        try {
            Verify.allOf(block);
            throw new RuntimeException("Expected an error but got none");
        } catch (AssertionError ex) {
            return ex.getMessage();
        }
    }

    @Test
    public void assertEquals_Boolean_WithDescription_Pass() {
        Verify.allOf(verify -> {
            verify.assertEquals(false, false, "description1");
            verify.assertEquals(true, true, "description2");
        });
    }

    @Test
    public void assertEquals_Boolean_WithDescription_Fail() {
        String errorMessage = getErrorMessage(verify -> {
            verify.assertEquals(true, false, "description1");
            verify.assertEquals(false, true, "description2");
        });
        Verify.that(errorMessage, Is.stringContaining("description1\nExpected: <false>\n     but: was <true>"));
        Verify.that(errorMessage, Is.stringContaining("description2\nExpected: <true>\n     but: was <false>"));
    }

    @Test
    public void assertEquals_Int_Pass() {
        Verify.allOf(verify -> {
            verify.assertEquals(1 + 1, 2);
            verify.assertEquals(2 + 2, 4);
        });
    }

    @Test
    public void assertEquals_Int_Fail() {
        String errorMessage = getErrorMessage(verify -> {
            verify.assertEquals(1 + 1, 3);
            verify.assertEquals(2 + 2, 3);
        });
        Verify.that(errorMessage, Is.stringContaining("Expected: <3>\n     but: was <2>"));
        Verify.that(errorMessage, Is.stringContaining("Expected: <3>\n     but: was <4>"));
    }

    @Test
    public void assertEquals_Int_WithMessage_Pass() {
        Verify.allOf(verify -> {
            verify.assertEquals(1 + 1, 2, "description1");
            verify.assertEquals(2 + 2, 4, "description2");
        });
    }

    @Test
    public void assertEquals_Int_WithDescription_Fail() {
        String errorMessage = getErrorMessage(verify -> {
            verify.assertEquals(1 + 1, 3, "description1");
            verify.assertEquals(2 + 2, 3, "description2");
        });
        Verify.that(errorMessage, Is.stringContaining("description1\nExpected: <3>\n     but: was <2>"));
        Verify.that(errorMessage, Is.stringContaining("description2\nExpected: <3>\n     but: was <4>"));
    }

    @Test
    public void assertEquals_Long_WithDescription_Pass() {
        Verify.allOf(verify -> {
            verify.assertEquals(1L + 1L, 2L, "description1");
            verify.assertEquals(2L + 2L, 4L, "description2");
        });
    }

    @Test
    public void assertEquals_Long_WithDescription_Fail() {
        String errorMessage = getErrorMessage(verify -> {
            verify.assertEquals(1L + 1L, 3L, "description1");
            verify.assertEquals(2L + 2L, 3L, "description2");
        });
        Verify.that(errorMessage, Is.stringContaining("description1\nExpected: <3L>\n     but: was <2L>"));
        Verify.that(errorMessage, Is.stringContaining("description2\nExpected: <3L>\n     but: was <4L>"));
    }

    @Test
    public void assertEquals_String_Pass() {
        Verify.allOf(verify -> {
            verify.assertEquals("", "");
            verify.assertEquals("abc", "abc");
        });
    }

    @Test
    public void assertEquals_String_Fail() {
        String errorMessage = getErrorMessage(verify -> {
            verify.assertEquals(null, "abc");
            verify.assertEquals("abc", null);
            verify.assertEquals("", "abc");
            verify.assertEquals("abc", "");
        });
        Verify.that(errorMessage, Is.stringContaining("Expected: \"abc\"\n     but: was null"));
        Verify.that(errorMessage, Is.stringContaining("Expected: null\n     but: was \"abc\""));
        Verify.that(errorMessage, Is.stringContaining("Expected: \"abc\"\n     but: \"\"\n differs:  ^ starting at index 0"));
        Verify.that(errorMessage, Is.stringContaining("Expected: \"\"\n     but: \"abc\"\n differs:  ^ starting at index 0"));
    }

    @Test
    public void assertEquals_String_WithDescription_Pass() {
        Verify.allOf(verify -> {
            final String nullString = null;
            verify.assertEquals(nullString, nullString, "String1");
            verify.assertEquals("", "", "String1");
            verify.assertEquals("abc", "abc", "String2");
        });
    }

    @Test
    public void assertEquals_String_WithDescription_Fail() {
        String errorMessage = getErrorMessage(verify -> {
            verify.assertEquals(null, "abc", "String1");
            verify.assertEquals("abc", null, "String2");
            verify.assertEquals("", "abc", "String3");
            verify.assertEquals("abc", "", "String4");
        });
        Verify.that(errorMessage, Is.stringContaining("String1\nExpected: \"abc\"\n     but: was null"));
        Verify.that(errorMessage, Is.stringContaining("String2\nExpected: null\n     but: was \"abc\""));
        Verify.that(errorMessage, Is.stringContaining("String3\nExpected: \"abc\"\n     but: \"\"\n differs:  ^ starting at index 0"));
        Verify.that(errorMessage, Is.stringContaining("String4\nExpected: \"\"\n     but: \"abc\"\n differs:  ^ starting at index 0"));
    }

    @Test
    public void assertEquals_T_WithDescription_Pass() {
        Verify.allOf(verify -> {
            final ClassLoader classLoader = null;
            verify.assertEquals(new BigDecimal("1.23"), new BigDecimal("1.23"), "BigDecimal");
            verify.assertEquals(Integer.valueOf(5000), Integer.valueOf(5000), "Integer");
            verify.assertEquals(LocalDate.of(2020, 1, 15), LocalDate.of(2020, 1, 15), "LocalDate");
            verify.assertEquals(LocalDateTime.of(2020, 1, 15, 23, 58), LocalDateTime.of(2020, 1, 15, 23, 58), "LocalDateTime");
            verify.assertEquals(Long.valueOf(9000), Long.valueOf(9000), "Long");
            verify.assertEquals(classLoader, null, "ClassLoader");
        });
    }

    @Test
    public void assertEquals_T_WithDescription_Fail() {
        // Integer.valueOf and Long.valueOf will cache small values and return
        // the same instance. This test is more interesting if we know each
        // value is a new instance, so we use larger values.
        String errorMessage = getErrorMessage(verify -> {
            verify.assertEquals(new BigDecimal("1.23"), new BigDecimal("1.230"), "BigDecimal1");
            verify.assertEquals(new BigDecimal("1.23"), null, "BigDecimal2");
            verify.assertEquals(null, new BigDecimal("1.230"), "BigDecimal3");
            verify.assertEquals(Integer.valueOf(500), Integer.valueOf(600), "Integer1");
            verify.assertEquals(5, null, "Integer2");
            verify.assertEquals(null, 6, "Integer3");
            verify.assertEquals(LocalDate.of(2020, 1, 15), LocalDate.of(2020, 1, 16), "LocalDate1");
            verify.assertEquals(LocalDate.of(2020, 1, 15), null, "LocalDate2");
            verify.assertEquals(null, LocalDate.of(2020, 1, 16), "LocalDate3");
            verify.assertEquals(LocalDateTime.of(2020, 1, 15, 23, 58), LocalDateTime.of(2020, 1, 15, 23, 59), "LocalDateTime1");
            verify.assertEquals(LocalDateTime.of(2020, 1, 15, 23, 58), null, "LocalDateTime2");
            verify.assertEquals(null, LocalDateTime.of(2020, 1, 15, 23, 59), "LocalDateTime3");
            verify.assertEquals(Long.valueOf(9000), Long.valueOf(900000), "Long1");
            verify.assertEquals(90L, null, "Long2");
            verify.assertEquals(null, 9000L, "Long3");
        });
        Verify.allOf(() -> {
            Verify.that(errorMessage, Is.stringContaining("BigDecimal1\nExpected: <1.230>\n     but: was <1.23>"));
            Verify.that(errorMessage, Is.stringContaining("BigDecimal2\nExpected: null\n     but: was <1.23>"));
            Verify.that(errorMessage, Is.stringContaining("BigDecimal3\nExpected: <1.230>\n     but: was null"));
            Verify.that(errorMessage, Is.stringContaining("Integer1\nExpected: <600>\n     but: was <500>"));
            Verify.that(errorMessage, Is.stringContaining("Integer2\nExpected: null\n     but: was <5>"));
            Verify.that(errorMessage, Is.stringContaining("Integer3\nExpected: <6>\n     but: was null"));
            Verify.that(errorMessage, Is.stringContaining("LocalDate1\nExpected: <2020-01-16>\n     but: was <2020-01-15>"));
            Verify.that(errorMessage, Is.stringContaining("LocalDate2\nExpected: null\n     but: was <2020-01-15>"));
            Verify.that(errorMessage, Is.stringContaining("LocalDate3\nExpected: <2020-01-16>\n     but: was null"));
            Verify.that(errorMessage, Is.stringContaining("LocalDateTime1\nExpected: <2020-01-15T23:59>\n     but: was <2020-01-15T23:58>"));
            Verify.that(errorMessage, Is.stringContaining("LocalDateTime2\nExpected: null\n     but: was <2020-01-15T23:58>"));
            Verify.that(errorMessage, Is.stringContaining("LocalDateTime3\nExpected: <2020-01-15T23:59>\n     but: was null"));
            Verify.that(errorMessage, Is.stringContaining("Long1\nExpected: <900000L>\n     but: was <9000L>"));
            Verify.that(errorMessage, Is.stringContaining("Long2\nExpected: null\n     but: was <90L>"));
            Verify.that(errorMessage, Is.stringContaining("Long3\nExpected: <9000L>\n     but: was null"));
        });
    }

    @Test
    public void assertFalse_WithDescription_Pass() {
        Verify.allOf(verify -> {
            verify.assertFalse(false, "description1");
            verify.assertFalse(false, "description2");
        });
    }

    @Test
    public void assertFalse_WithDescription_Fail() {
        String errorMessage = getErrorMessage(verify -> {
            verify.assertFalse(true, "description1");
            verify.assertFalse(true, "description2");
        });
        Verify.that(errorMessage, Is.stringContaining("description1\nExpected: <false>\n     but: was <true>"));
        Verify.that(errorMessage, Is.stringContaining("description2\nExpected: <false>\n     but: was <true>"));
    }

    @Test
    public void assertNotEquals_Pass() {
        Verify.allOf(verify -> {
            verify.assertNotEquals(null, "");
            verify.assertNotEquals("", "abc");
            verify.assertNotEquals("abc", null);
        });
    }

    @Test
    public void assertNotEquals_Fail() {
        String errorMessage = getErrorMessage(verify -> {
            verify.assertNotEquals(null, null);
            verify.assertNotEquals("", "");
            verify.assertNotEquals("abc", "abc");
        });
        Verify.that(errorMessage, Is.stringContaining("Expected: not null\n     but: was null"));
        Verify.that(errorMessage, Is.stringContaining("Expected: not \"\"\n     but: was \"\""));
        Verify.that(errorMessage, Is.stringContaining("Expected: not \"abc\"\n     but: was \"abc\""));
    }

    @Test
    public void assertNotEquals_WithDescription_Pass() {
        Verify.allOf(verify -> {
            verify.assertNotEquals(null, "", "description1");
            verify.assertNotEquals("", "abc", "description2");
            verify.assertNotEquals("abc", null, "description3");
        });
    }

    @Test
    public void assertNotEquals_WithDescription_Fail() {
        String errorMessage = getErrorMessage(verify -> {
            verify.assertNotEquals(null, null, "description1");
            verify.assertNotEquals("", "", "description2");
            verify.assertNotEquals("abc", "abc", "description3");
        });
        Verify.that(errorMessage, Is.stringContaining("description1\nExpected: not null\n     but: was null"));
        Verify.that(errorMessage, Is.stringContaining("description2\nExpected: not \"\"\n     but: was \"\""));
        Verify.that(errorMessage, Is.stringContaining("description3\nExpected: not \"abc\"\n     but: was \"abc\""));
    }

    @Test
    public void assertNotNull_Pass() {
        Verify.allOf(verify -> {
            verify.assertNotNull(42);
            verify.assertNotNull("value");
        });
    }

    @Test
    public void assertNotNull_Fail() {
        String errorMessage = getErrorMessage(verify -> {
            verify.assertNotNull(null);
            verify.assertNotNull(null);
        });
        Verify.that(errorMessage, Is.stringContaining("Expected: not null\n     but: was null\n\nExpected: not null\n     but: was null"));
    }

    @Test
    public void assertTrue_Pass() {
        Verify.allOf(verify -> {
            verify.assertTrue(true);
            verify.assertTrue(true);
        });
    }

    @Test
    public void assertTrue_Fail() {
        String errorMessage = getErrorMessage(verify -> {
            verify.assertTrue(false);
            verify.assertTrue(false);
        });
        Verify.that(errorMessage, Is.stringContaining("Expected: <true>\n     but: was <false>\n\nExpected: <true>\n     but: was <false>"));
    }

    @Test
    public void assertTrue_WithDescription_Pass() {
        Verify.allOf(verify -> {
            verify.assertTrue(true, "description1");
            verify.assertTrue(true, "description2");
        });
    }

    @Test
    public void assertTrue_WithDescription_Fail() {
        String errorMessage = getErrorMessage(verify -> {
            verify.assertTrue(false, "description1");
            verify.assertTrue(false, "description2");
        });
        Verify.that(errorMessage, Is.stringContaining("description1\nExpected: <true>\n     but: was <false>"));
        Verify.that(errorMessage, Is.stringContaining("description2\nExpected: <true>\n     but: was <false>"));
    }

    @Test
    public void failWithDescription() {
        String errorMessage = getErrorMessage(verify -> {
            verify.fail("description1");
            verify.fail("description2");
        });
        Verify.that(errorMessage, Is.stringContaining("description1"));
        Verify.that(errorMessage, Is.stringContaining("description2"));
    }
}
