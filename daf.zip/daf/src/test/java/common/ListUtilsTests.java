package common;

import common.Is;
import common.ListUtils;
import common.Verify;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class ListUtilsTests {
    @Test
    public void nextAfter_HappyPath() {
        List<String> list = Arrays.asList("a", "b", "MATCH", "c", "d");
        Verify.that(ListUtils.nextAfter(list, e -> e.equals("MATCH")), Is.equalTo(Optional.of("c")));
    }

    @Test
    public void nextAfter_StopsAtFirstMatch() {
        List<String> list = Arrays.asList("a", "b", "MATCH", "c", "d", "MATCH", "e");
        Verify.that(ListUtils.nextAfter(list, e -> e.equals("MATCH")), Is.equalTo(Optional.of("c")));
    }

    @Test
    public void nextAfter_IfListIsEmpty_ReturnsEmpty() {
        List<String> list = Collections.emptyList();
        Verify.that(ListUtils.nextAfter(list, e -> true), Is.equalTo(Optional.empty()));
    }

    @Test
    public void nextAfter_IfLambdaMatchesLastElement_ReturnsEmpty() {
        List<String> list = Arrays.asList("a", "b", "c", "d", "MATCH");
        Verify.that(ListUtils.nextAfter(list, e -> e.equals("MATCH")), Is.equalTo(Optional.empty()));
    }

    @Test
    public void nextAfter_IfNoMatch_ReturnsEmpty() {
        List<String> list = Arrays.asList("a", "b", "c", "d");
        Verify.that(ListUtils.nextAfter(list, e -> false), Is.equalTo(Optional.empty()));
    }
}
