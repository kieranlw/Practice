# Trusted server certificates

This directory contains certificates for certificate authorities (CAs) that we want to consider "trusted" on
any machine that runs DAF tests. For example, the "Deluxe Root CA" and "Deluxe Enterprise CA" certificates that
are used to sign individual web servers' HTTPS certs in the DEC.

Call TrustedServerCertificates.load() at startup to load these certificates into the Java app.

## File extensions and formats

Certificate files in this directory should have either the .cer or .pem extension, and can be in formats
variously described as:

* PEM (cert)
* DER encoded binary X.509 (.CER)
* Base-64 encoded X.509 (CER)

Some of these formats are binary and some are text, but none of them are human-readable, so it doesn't really
matter which you pick.

## How to create these files

You can export these files from a web browser. (Safari and Firefox are easiest; it takes more steps in Chrome.)
Browse to the server, click the padlock icon in the address bar, and go from there. In Safari, you need to drag
the big certificate image into a Finder window.

Don't export the web server's own certificate, but do include *all* its parents, not just the root.
