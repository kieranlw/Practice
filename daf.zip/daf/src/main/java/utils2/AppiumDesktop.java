package utils2;

import common.DesktopApplicationStartupSettings;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.windows.WindowsDriver;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import utils2.page_components.*;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class AppiumDesktop {

    public static final ElementInfo DCM_WINDOWINFO = ElementInfo.createElementInfo("Main Window", By.xpath("//*[contains(@Name, 'ImageRPS(R) DCM *TEST System*')]"));
    public static final ElementInfo RCP_WINDOWINFO = ElementInfo.createElementInfo("RCP Main Window", By.xpath("//*[contains(@Name, 'Site Service Installation Manager')]"));
    public static final ElementInfo FRS_INSTALLATION_WINDOWINFO = ElementInfo.createElementInfo("RCP Main Window", By.xpath("//*[contains(@Name, 'Reco Service Installation Manager')]"));

    public static WindowsDriver<WebElement> startDesktopDriver(DesktopApplicationStartupSettings startupSettings) {

        DesiredCapabilities capabilities =  getBaseCapabilities();
        capabilities.setCapability("appArguments", startupSettings.get_applicationArguments());
        capabilities.setCapability("app", startupSettings.get_applicationPath());


        URL url = getServerUrl(startupSettings.get_serverName(), startupSettings.get_port());
        LogInfo.log_Status("Connecting to Appium at " + url);
        return new WindowsDriver<>(url, capabilities);
    }

    public static WindowsDriver<WebElement> startDesktopDriver(DesktopApplicationStartupSettings startupSettings, ElementInfo windowInfo) {
        WindowsDriver<WebElement> driver = startDesktopDriver(startupSettings);

        return switchToWindow(windowInfo, startupSettings);
    }

    private static URL getServerUrl(String serverName, int port) {
        try {
            return new URL("http://" + serverName + ":" + port + "/wd/hub");
        } catch (MalformedURLException e) {
            throw new RuntimeException("Got an error trying to build the URL for the Appium server: " + e.getMessage(), e);
        }
    }

    private static DesiredCapabilities getBaseCapabilities(){
        DesiredCapabilities appCapabilities = new DesiredCapabilities();

        appCapabilities.setCapability("deviceName", "WindowsPC");
        appCapabilities.setCapability("platformName", "Windows");
        appCapabilities.setCapability("newCommandTimeout", 0);

        return appCapabilities;
    }

    public static WindowsDriver<WebElement> switchToRoot(DesktopApplicationStartupSettings startupSettings) {
        DesiredCapabilities appCapabilities = getBaseCapabilities();
        appCapabilities.setCapability("app", "Root");

        WindowsDriver<WebElement> desktopDriver = new WindowsDriver<>(getServerUrl(startupSettings.get_serverName(), startupSettings.get_port()), appCapabilities);
        return desktopDriver;
    }

    public static WindowsDriver<WebElement> switchToWindow(ElementInfo mainWindowElementInfo, DesktopApplicationStartupSettings startupSettings) {
        WindowsDriver<WebElement> desktopDriver = switchToRoot(startupSettings);
        Label mainWindow = new Label(desktopDriver, mainWindowElementInfo);

        mainWindow.waitUntil(Duration.ofMinutes(2)).displayed();

        return getDriverForWindowElement(startupSettings, mainWindow);
    }

    @Nullable
    public static WindowsDriver<WebElement> getDriverIfWindowExists(ElementInfo windowElementInfo, DesktopApplicationStartupSettings startupSettings) {
        WindowsDriver<WebElement> desktopDriver = switchToRoot(startupSettings);
        Label windowElement = new Label(desktopDriver, windowElementInfo);
        if (windowElement.exists()) {
            return getDriverForWindowElement(startupSettings, windowElement);
        } else {
            return null;
        }
    }

    @NotNull
    private static WindowsDriver<WebElement> getDriverForWindowElement(DesktopApplicationStartupSettings startupSettings, Label windowElement) {
        String windowHandle = windowElement.getAttribute("NativeWindowHandle");
        long windowHandleInt = Long.parseLong(windowHandle);
        String windowHandleHex = Long.toHexString(windowHandleInt);

        DesiredCapabilities finalDriverCapabilities = getBaseCapabilities();
        finalDriverCapabilities.setCapability("appTopLevelWindow", windowHandleHex);
        WindowsDriver<WebElement> driverFinal =
                new WindowsDriver<>(getServerUrl(startupSettings.get_serverName(), startupSettings.get_port()), finalDriverCapabilities);
        return driverFinal;
    }

    public static boolean isWindowsPlatform(@Nullable WebDriver driver) {
        return (driver instanceof AppiumDriver)
                && ((AppiumDriver<?>) driver).getCapabilities().getPlatform() != null
                && ((AppiumDriver<?>) driver).getCapabilities().getPlatform().toString().equals("WINDOWS");
    }
}
