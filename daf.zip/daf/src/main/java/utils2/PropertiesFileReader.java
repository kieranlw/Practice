package utils2;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesFileReader {

    private Properties properties = new Properties();

    /**
     * Creates a new Instance of PropertiesFileReader
     * - loads the given file
     * - Prints the Key Value pairs to System.Out
     * - Creates System Properties for the Key Value pairs (i.e. use System.getProperty(<key>) to retrieve the value
     * @param file String representation of the path and filename
     */
    public PropertiesFileReader(@NotNull String file) {
        this(new File(file));
    }

    /**
     * Creates a new Instance of PropertiesFileReader
     * - loads the given file
     * - Prints the Key Value pairs to System.Out
     * - Creates System Properties for the Key Value pairs (i.e. use System.getProperty(<key>) to retrieve the value
     * @param file File, properties file to load
     */
    public PropertiesFileReader(@NotNull File file) {
        loadFile(file);
        properties.list(System.out);
        generateSystemProperties();
    }

    /**
     * Returns an instance of java.util.Properties
     * @return properties
     */
    protected Properties getProperties() { return properties; }

    /**
     * Returns the value for the given key in the Properties
     * or throws a RuntimeException if the key is not found
     * @param key String value of the key to lookup
     * @return String value
     */
    public String getProperty(@NotNull String key) {
        String value = properties.getProperty(key);
        if (value==null) { throw new RuntimeException("No value found for key " + key + " in the properties file"); }
        return value;
    }

    private void loadFile(@NotNull File file) {
        try (FileInputStream fis = new FileInputStream(file)) {
            properties.load(fis);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void generateSystemProperties() {
        for(Object key : properties.keySet()) {
            if(key instanceof String) {
                String keyAsString = (String) key;
                System.setProperty(keyAsString, properties.getProperty(keyAsString));
            }
        }
    }

}
