package utils2;

import common.BrowserOptions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import utils2.page_components.*;

import java.lang.reflect.Constructor;
import java.net.MalformedURLException;
import java.net.URI;

public class DriverSetup {

    private static final String SELENOID_URI = "http://reportportal.deluxe.com:4444/wd/hub";

    private DriverInfo _driverInfo;

    //Class needs to be refactored.  A number of the methods in here are deprecated.

    public enum DriverType {
        WINIUM("winium"),
        CHROME("chrome"),
        CHROME_LOCAL("chrome_local"),
        FIREFOX("firefox"),
        INTERNET_EXPLORER("internet explorer"),
        APPIUM("appium"),
        ANDROID("android"),
        IPHONE_SIMULATED("iphonesimulated"),
        SELENOID_CHROME("selenoid_chrome"),
        SELENOID_FIREFOX("selenoid_firefox"),
        SELENOID_OPERA("selenoid_opera");

        private String value;

        public String getValue() {
            return value;
        }

        private DriverType(final String val) {
            value = val;
        }

        @Override
        public String toString() {
            return value;
        }

        public static DriverType getEnumByString(String browser){
            for(DriverType driverType : DriverType.values()){
                if(driverType.value.equals(browser)) return driverType;
            }
            LogInfo.log_AndFail("Unrecognized Driver of " + browser);
            return null;
        }
    }

    public DriverSetup(DriverInfo driverInfo) {
        _driverInfo = driverInfo;
    }

    public WebDriver startDriver(String url, boolean logURL) {

        WebDriver driver = null;

        LogInfo.log_Status("Launching " + _driverInfo.getDriverType().toString() + " browser.");

        switch (_driverInfo.getDriverType()) {
            case FIREFOX:
                FirefoxOptions option = BrowserOptions.forFirefox(url, _driverInfo.getDownloadLocation());
                driver = new FirefoxDriver(option);
                break;
            case CHROME:
                ChromeOptions options = BrowserOptions.forChromeRemote(_driverInfo);
                driver = new RemoteWebDriver(options);
                break;
            case CHROME_LOCAL:
                ChromeOptions options2 = BrowserOptions.forChromeLocal(_driverInfo);
                driver = new ChromeDriver(options2);
                break;
            case INTERNET_EXPLORER:
                InternetExplorerOptions options1 = BrowserOptions.forInternetExplorer(url);
                driver = new InternetExplorerDriver(options1);
                break;
            case ANDROID:
                ChromeOptions chromeOptions = BrowserOptions.forAndroid();
                driver = new ChromeDriver(chromeOptions);
                break;
            case IPHONE_SIMULATED:
                ChromeOptions optionsSimulated = BrowserOptions.forIPhoneSimulated();
                driver = new ChromeDriver(optionsSimulated);
                break;
            case SELENOID_CHROME:
                try {
                    ChromeOptions chromeOptions1 = new ChromeOptions();
                    chromeOptions1.setCapability("name", "DAF");
                    chromeOptions1.setCapability("enableVNC", true);
                    chromeOptions1.setCapability("enabledVideo", false);

                    driver = new RemoteWebDriver(
                            URI.create(SELENOID_URI).toURL(),
                            chromeOptions1
                    );

                    break;
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }
            case SELENOID_FIREFOX:
                try {
                    DesiredCapabilities capabilities = new DesiredCapabilities();
                    capabilities.setBrowserName("firefox");
                    capabilities.setCapability("enableVNC", true);
                    capabilities.setCapability("enableVideo", false);

                    driver = new RemoteWebDriver(
                            URI.create(SELENOID_URI).toURL(),
                            capabilities
                    );

                    break;

                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }
            case SELENOID_OPERA:
                try {
                    DesiredCapabilities capabilities = new DesiredCapabilities();
                    capabilities.setBrowserName("opera");
                    capabilities.setCapability("enableVNC", true);
                    capabilities.setCapability("enableVideo", false);

                    driver = new RemoteWebDriver(
                            URI.create(SELENOID_URI).toURL(),
                            capabilities
                    );
                    break;

                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }
            default:
                LogInfo.log_AndFail("Unrecognized Driver Type of " + _driverInfo.getDriverType().toString());
        }
        driver.manage().window().maximize();
        driver.get(url);

        if(logURL) {
            LogInfo.log_Status("Opened " + url + " with " + _driverInfo.getDriverType().toString());
        }

        return driver;
    }

    public WebDriver startDriver(String url) {
        return startDriver(url, true);
    }

    public <T extends BasePageObject> T startDriver(String url, Class<T> classToWaitFor) throws Exception {
        WebDriver driver = startDriver(url);
        Constructor<T> cons = classToWaitFor.getConstructor(WebDriver.class);

        T pageObject = cons.newInstance(driver);
        pageObject.waitForPageToLoad();
        return pageObject;
    }

}
