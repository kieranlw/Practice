package utils2.autosmoketestable;

import common.ClassFinderUtils;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Comparator;

public class PageAutoSmokeTestUtils {

    /**
     * Scans all classes accessible from the context class loader with belong to the given package and subpackages
     * that implement the AutoSmokeTestable interface
     *
     * @param packageName The packageName to scan
     * @return Object[][] for the classes for use in a dataprovider
     * @throws ClassNotFoundException
     * @throws IOException
     */

    public static Object[][] getAutoSmokeTestableClasses(String packageName) throws ClassNotFoundException, IOException {
        return Arrays.stream(ClassFinderUtils.getAssignableClasses(packageName, AutoSmokeTestable.class))
                .filter(clz -> !Modifier.isAbstract(clz.getModifiers())) //filter out abstract classes
                .filter(clz -> !clz.isInterface()) // filter out interfaces;
                .sorted(Comparator.comparing(Class::getSimpleName))
                .map(clz -> new Object[] { clz} )
                .toArray(Object[][]::new);
    }

    /**
     * Scans all classes accessible from the context class loader with belong to the given package and subpackages
     * that implement the AutoSmokeTestable interface
     *
     * @param packageToInclude The name of the package to include in the scan
     * @param packageToExclude The name of the package to exclude in the scan
     * @return Object[][] for the classes for use in a dataprovider
     * @throws ClassNotFoundException
     * @throws IOException
     */
    public static Object[][] getAutoSmokeTestableClassesExcludingPackage(String packageToInclude, String packageToExclude) throws ClassNotFoundException, IOException {
        Class<?>[] classesToExclude = ClassFinderUtils.getAssignableClasses(packageToExclude, AutoSmokeTestable.class);

        return Arrays.stream(ClassFinderUtils.getAssignableClasses(packageToInclude, AutoSmokeTestable.class))
                .filter(clz -> Arrays.stream(classesToExclude).noneMatch(clz::equals)) //filter out excluded classes
                .filter(clz -> !Modifier.isAbstract(clz.getModifiers())) //filter out abstract classes
                .filter(clz -> !clz.isInterface()) // filter out interfaces;
                .sorted(Comparator.comparing(Class::getSimpleName))
                .map(clz -> new Object[]{clz})
                .toArray(Object[][]::new);
    }

    /**
     * Creates a new instance of the passed in PageObject class and calls navigateTo and then verifyPageLoaded
     * on the instance as a smoke test
     *
     * @param driver WebDriver instance
     * @param clazz The PageObject Class to smoke test
     * @throws NoSuchMethodException
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     */
    public static void verifyPageObjectLoads(WebDriver driver, Class<AutoSmokeTestable> clazz)
            throws NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException {

        Constructor<AutoSmokeTestable> cons = clazz.getConstructor(WebDriver.class);
        cons.newInstance(driver)
                .navigateTo()
                .verifyPageLoaded();
    }

}
