package utils2.autosmoketestable;

/**
 * Allows a Page Object to automatically be included in a smoke test suite
 */
public interface AutoSmokeTestable {

    /**
     * Navigates to the Page and should wait until the page is ready for user action.
     * @return the Page Object for method chaining
     */
    AutoSmokeTestable navigateTo();

    /**
     * Asserts the critical elements of the Page
     * @return the Page Object for method chaining
     */
    AutoSmokeTestable verifyPageLoaded();

}
