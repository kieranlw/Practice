package utils2;

import com.google.api.client.util.Objects;
import common.Verify;
import org.apache.commons.beanutils.BeanUtils;
import org.testng.asserts.SoftAssert;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ModelUtils {

    public static void verifyModelsAreEqual(Object expectedObject, Object actualObject) {
        verifyModelsAreEqual(expectedObject, actualObject, new String[0]);
    }

    public static void verifyModelsAreEqual(Object expectedObject, Object actualObject, String[] ignoreFields) {
        List<Map<String, Object>> expectedFieldMap = getFieldMapList(expectedObject, ignoreFields);
        List<Map<String, Object>> actualFieldMap = getFieldMapList(actualObject, ignoreFields);

        Verify.that(expectedFieldMap.size() > 0, "Did NOT find expected Entries");
        Verify.that(expectedFieldMap.get(0).keySet().size() > 0, "Did NOT find Fields");
        Verify.that(expectedFieldMap.size() == actualFieldMap.size(), "Expected models to have same number of fields");

        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < expectedFieldMap.size(); i++) {
            for (String key : expectedFieldMap.get(i).keySet()) {
                softAssert.assertEquals(actualFieldMap.get(i).get(key), expectedFieldMap.get(i).get(key), "Data row: " + i + " - Value for '" + key
                        + "' did not match expected value of '" + expectedFieldMap.get(i).get(key) +
                        "' seeing '" + actualFieldMap.get(i).get(key) + "'");
            }
        }

        softAssert.assertAll();
    }

    private static List<Map<String, Object>> getFieldMapList(Object objectToExtract, String[] fieldExclusionList) {
        List<Map<String, Object>> fieldMapList = new ArrayList<>();
        if (objectToExtract.getClass().isArray()) {
            Object[] objects = (Object[]) objectToExtract;

            for (Object object : objects) {
                fieldMapList.add(getFieldMap(object, fieldExclusionList));
            }
        } else {
            fieldMapList.add(getFieldMap(objectToExtract, fieldExclusionList));
        }

        return fieldMapList;
    }

    public static Map<String, Object> getFieldMap(Object objectToExtract, String[] exclusionList) {
        Class<?> proxyIn = objectToExtract.getClass();
        Map<String, Object> fieldMap = new HashMap<>();
        Field[] fields = proxyIn.getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);
            try {
                fieldMap.put(field.getName(), field.get(objectToExtract));
            } catch (IllegalAccessException e) {
                LogInfo.log_AndFail(e.getMessage());
            }
        }

        if (exclusionList != null) {
            excludeFields(fieldMap, exclusionList);
        }

        return fieldMap;
    }

    //Repackage dissimilar objects.
    public static <T> T copyProperties(Object originObject, T targetObject) {
        try {
            BeanUtils.copyProperties(targetObject, originObject);
        } catch (IllegalAccessException | InvocationTargetException e) {
            LogInfo.log_AndFail("Encountered error while copying properties: " + e.getMessage());
        }

        return targetObject;
    }

    private static void excludeFields(Map<String, Object> fieldMap, String[] exclusionList) {
        for (String field : exclusionList) {
            fieldMap.remove(field);
        }
    }

    public static void setFieldValue(Object objectToUpdate, String fieldName, Object fieldValue) {
        Class<?> proxyIn = objectToUpdate.getClass();
        try {
            Field fieldToUpdate = proxyIn.getDeclaredField(fieldName);
            fieldToUpdate.setAccessible(true);
            fieldToUpdate.set(objectToUpdate, fieldValue);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            LogInfo.log_AndFail(e.getMessage());
        }
    }
}