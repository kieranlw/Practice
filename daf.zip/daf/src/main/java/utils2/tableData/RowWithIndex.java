package utils2.tableData;

import utils2.Index;

public final class RowWithIndex {
    private final Row row;
    private final Index index;

    public RowWithIndex(Row row, Index index) {
        this.row = row;
        this.index = index;
    }

    public Row getRow() {
        return row;
    }

    public Index getIndex() {
        return index;
    }
}
