package utils2.tableData;

import utils2.tableData.getInfo.GetRow;
import utils2.tableData.getInfo.GetRowWithIndex;

public class GetTableData {
    private final Rows rows;

    public GetTableData(Rows rows) {
        this.rows = rows;
    }

    public GetRow row() {
        return new GetRow(rows);
    }

    public GetRowWithIndex rowWithIndex() {
        return new GetRowWithIndex(rows);
    }
}
