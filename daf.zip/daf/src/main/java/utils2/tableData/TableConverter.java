package utils2.tableData;

import common.ResourceFile;
import utils.DataBuilder;
import utils.TableData;
import utils2.Index;
import utils2.TableData2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Convert table from TableData object.  Intermediary step in conversion.
public class TableConverter {
    public static TableData2 convertToTableData2(TableData oldTableFormat) {
        List<Row> rows = new ArrayList<>();
        for (int i = 0; i < oldTableFormat.data.size(); i++) {
            Map<String, String> newMapping = new HashMap<>();

            for (String key : oldTableFormat.data.get(i).keySet()) {
                newMapping.put(key, oldTableFormat.data.get(i).get(key));
            }

            rows.add(new Row(newMapping));
        }

        return new TableData2(rows);
    }

    public static TableData2 extractDataFromCsv(String filePath, String delimiter) {
        return convertToTableData2(DataBuilder
                .returnTableData_ForComparison(new ResourceFile(filePath), delimiter));
    }
}
