package utils2.tableData;

import common.ListUtils;

import java.util.ArrayList;
import java.util.List;

public class FilteredRows {
    private final List<RowWithIndex> filteredRowsWithIndexes;

    public FilteredRows(List<RowWithIndex> filteredRowsWithIndexes) {
        this.filteredRowsWithIndexes = filteredRowsWithIndexes;
    }

    public List<Row> toRows() {
        return ListUtils.map(filteredRowsWithIndexes, rowWithIndex -> rowWithIndex.getRow());
    }

    public List<RowWithIndex> toRowsWithIndexes() {
        return new ArrayList<>(filteredRowsWithIndexes);
    }
}
