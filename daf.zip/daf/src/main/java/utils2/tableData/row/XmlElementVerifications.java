package utils2.tableData.row;

import common.XmlUtils;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import utils2.LogInfo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class XmlElementVerifications {

    private final Node _element;

    public XmlElementVerifications(Node element) {
        _element = element;
    }

    public void withAttributes(String... expectedValues) {
        withAttributes(stringArrayToHashMap(expectedValues));
    }

    public void withAttributes(Map<String, String> expectedAttributes) {
        Map<String, Node> foundAttributes = XmlUtils.namedNodeMapToMap(_element.getAttributes());

        HashSet<String> expectedNames = new HashSet<>(expectedAttributes.keySet());
        expectedNames.removeAll(foundAttributes.keySet());

        if (expectedNames.size() != 0) {
            LogInfo.log_AndFail("Expected attributes were not found: " + expectedNames);
        } else
            LogInfo.log_AndPass("Found all expected attributes");
    }

    public void withOnlyAttributes(String... expectedValues) {
        withOnlyAttributes(stringArrayToHashMap(expectedValues));
    }

    public void withOnlyAttributes(Map<String, String> expectedAttributes) {
        Map<String, Node> foundAttributes = XmlUtils.namedNodeMapToMap(_element.getAttributes());

        if (expectedAttributes.size() != foundAttributes.size()) {
            LogInfo.log_AndFail("Number of expected attributes matches number of found attributes: " + expectedAttributes.size());
        } else {
            HashSet<String> expectedNames = new HashSet<>(expectedAttributes.keySet());
            expectedNames.removeAll(foundAttributes.keySet());

            if (expectedNames.size() != 0) {
                LogInfo.log_AndFail("Expected attributes were not found: " + expectedNames);
            } else
                LogInfo.log_AndPass("Found all expected attributes");
        }
    }

    private Map<String, String> stringArrayToHashMap(String... args) {
        Map<String, String> temp = new HashMap<>();
        for (int i = 0; i < args.length; i += 2) {
            temp.put(args[i], args[i + 1]);
        }

        return temp;
    }
}