package utils2.tableData.row;

import common.Is;
import common.Verify;
import common.XmlUtils;
import org.hamcrest.Matcher;
import org.testng.asserts.SoftAssert;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import utils2.LogInfo;
import utils2.tableData.Row;

import java.util.Map;

public class RowVerifications {

    private Map<String, String> _row;

    public RowVerifications(Map<String, String> row) {
        _row = row;
    }

    public void cell(String cellHeader, Matcher<String> expectedValue) {
        Verify.that(_row.get(cellHeader), expectedValue, "Value for column '" + cellHeader + "'");
    }

    public void cellEquals(String cellHeader, String expectedValue) {
        String cellToCheck = _row.get(cellHeader).trim();
        if (cellToCheck != null && cellToCheck.equals(expectedValue)) {
            LogInfo.log_AndPass(cellHeader + " matched expected value of '" + expectedValue + "'.");
        } else {
            LogInfo.log_AndFail(cellHeader + " did NOT match expected value of '" + expectedValue + "'. Seeing '" + cellToCheck + "'.");
        }
    }

    public void cellNotEquals(String cellHeader, String expectedValue) {
        String cellToCheck = _row.get(cellHeader).trim();
        if (!(cellToCheck != null && cellToCheck.equals(expectedValue))) {
            LogInfo.log_AndPass(cellHeader + " did NOT match expected value of '" + expectedValue + "'.");
        } else {
            LogInfo.log_AndFail(cellHeader + " matched expected value of '" + expectedValue + "'.");
        }
    }

    public void cellContains(String cellHeader, String expectedValue) {
        String cellToCheck = _row.get(cellHeader).trim();
        if (cellToCheck != null && cellToCheck.contains(expectedValue)) {
            LogInfo.log_AndPass(cellHeader + " contains expected value of '" + expectedValue + "'.");
        } else {
            LogInfo.log_AndFail(cellHeader + " did NOT contain expected value of '" + expectedValue + "'. Seeing '" + cellToCheck + "'.");
        }
    }

    public XmlElementVerifications cellContainsXmlElement(String cellHeader, String xPath) {
        String cellText = _row.get(cellHeader).trim();
        Document document = XmlUtils.parseDocument(cellText);
        NodeList nodeList = XmlUtils.evaluateXpath(document, xPath);
        Verify.that(nodeList.getLength(), Is.equalTo(1), "Node count return by Xpath: " + xPath);

        return new XmlElementVerifications(nodeList.item(0));
    }

    public void containsValues(Row otherRow) {
        SoftAssert softAssert = new SoftAssert();
        for (String key : otherRow.keySet()) {
            String rowValue = _row.get(key);
            softAssert.assertTrue(rowValue != null, "Row for key " + key + " was null");
            if (rowValue != null) {
                softAssert.assertTrue(otherRow.get(key).equals(rowValue),
                        "For Column " + key + " Row values did NOT match, expected '" + otherRow.get(key) + "'. But seeing '" + rowValue + "'");
            }
        }
        softAssert.assertAll();
    }

    public void notContainsValues(Row otherRow) {
        SoftAssert softAssert = new SoftAssert();
        for (String key : otherRow.keySet()) {
            String rowValue = _row.get(key);
            softAssert.assertTrue(rowValue != null, "Row for key " + key + " was null");
            if (rowValue != null) {
                softAssert.assertFalse(otherRow.get(key).equals(rowValue),
                        "For Column " + key + " Row values did match, expected '" + otherRow.get(key) + "'. But seeing '" + rowValue + "'");
            }
        }
        softAssert.assertAll();
    }

    public void cellsNotEqual(Row otherRow, String cellHeader) {
        String thisRowCell = _row.get(cellHeader).trim();
        String otherRowCell = otherRow.get(cellHeader).trim();

        if (!thisRowCell.equals(otherRowCell)) {
            LogInfo.log_AndPass("Cells were different.");
        } else {
            LogInfo.log_AndFail("Cells were NOT different.");
        }
    }

    public void cellNotEmpty(String cellHeader) {
        String cellToCheck = _row.get(cellHeader).trim();
        if (cellToCheck != null && !cellToCheck.equals("") && cellToCheck.length() > 0) {
            LogInfo.log_AndPass(cellHeader + " was NOT empty.");
        } else {
            LogInfo.log_AndFail(cellHeader + " was empty.");
        }
    }

    public void cellEmpty(String cellHeader) {
        String cellToCheck = _row.get(cellHeader).trim();
        if (cellToCheck != null && cellToCheck.equals("")) {
            LogInfo.log_AndPass(cellHeader + " was empty.");
        } else {
            LogInfo.log_AndFail(cellHeader + " was NOT empty.");
        }
    }

    public void cellIsNull(String cellHeader) {
        String cellToCheck = _row.get(cellHeader);
        LogInfo.verify_ConditionTrue(cellToCheck == null, cellHeader + " is null");
    }

    public RowVerifications cellCount(Matcher<Integer> matcher) {
        Verify.that(_row.size(), matcher, "Cell count of row " + _row);
        return this;
    }
}