package utils2.tableData;

public enum SortMechanism {
    NUMERIC, ALPHA_SQL, ALPHA_CASESENSITIVE, ALPHA_CASEINSENSITIVE
}
