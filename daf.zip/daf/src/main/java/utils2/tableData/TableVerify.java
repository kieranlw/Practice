package utils2.tableData;

import common.Is;
import common.RowFilter;
import common.Verify;
import org.hamcrest.Matcher;
import org.testng.asserts.SoftAssert;
import utils2.LogInfo;
import utils2.TableData2;
import utils2.tableData.row.RowVerifications;
import utils2.tableData.verify.VerifyColumn;
import utils2.tableData.verify.VerifyColumns;
import utils2.tableData.verify.VerifyHeaders;
import utils2.tableData.verify.VerifyRow;

import java.util.List;

public class TableVerify {

    private List<Row> _data;

    public TableVerify(List<Row> data) {
        _data = data;
    }

    public VerifyColumn column(String headerText) {
        return new VerifyColumn(_data, headerText);
    }

    public VerifyColumns columns() {
        return new VerifyColumns(_data);
    }

    public VerifyHeaders headers() {
        return new VerifyHeaders(_data);
    }

    public RowVerifications row(int index) {
        return new RowVerifications(_data.get(index).getMap());
    }

    public VerifyRow row(Row rowToCheck) {
        return new VerifyRow(new Rows(_data), RowFilter.of(rowToCheck.getMap()));
    }

    public VerifyRow row(RowFilter filter) {
        return new VerifyRow(new Rows(_data), filter);
    }

    public TableVerify dataFound() {
        if (_data.size() > 0) {
            LogInfo.log_AndPass("Found Data for table.");
        } else {
            LogInfo.log_AndFail("Did NOT find data for table.");
        }
        return this;
    }

    public TableVerify tableSize(int expectedSize) {
        return rowCount(expectedSize);
    }

    public TableVerify rowCount(int expected) {
        return rowCount(Is.equalTo(expected));
    }

    public TableVerify rowCount(Matcher<Integer> matcher) {
        Verify.that(_data.size(), matcher, "Table's row count");
        return this;
    }

    @SuppressWarnings("UnusedReturnValue") // Intended as fluent API even if not used that way yet
    public TableVerify tableSizeLessThan(int expectedSizeToBeLessThan) {
        int actualSize = _data.size();
        if (actualSize < expectedSizeToBeLessThan) {
            LogInfo.log_AndPass("Table had less records than " + expectedSizeToBeLessThan);
        } else {
            LogInfo.log_AndFail("Table size expected less than " + expectedSizeToBeLessThan + " but seeing " + actualSize);
        }
        return this;
    }

    public TableVerify tableMatches(TableData2 expectedTable) {
        tableSize(expectedTable.size());

        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < expectedTable.size(); i++) {
            Row currentRow = expectedTable.data.get(i);
            for (String key : currentRow.keySet()) {
                softAssert.assertTrue(_data.get(i).get(key).equals(currentRow.get(key)),
                        "Row '" + (i + 1) + "': Key '" + key + "' value of '" + _data.get(i).get(key) + "' should match '"
                                + currentRow.get(key) + "'");
            }
        }
        softAssert.assertAll();
        return this;
    }
}
