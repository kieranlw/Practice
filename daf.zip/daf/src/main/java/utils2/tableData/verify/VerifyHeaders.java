package utils2.tableData.verify;

import org.testng.asserts.SoftAssert;
import utils2.LogInfo;
import utils2.tableData.Row;

import java.util.List;
import java.util.Set;

public class VerifyHeaders {
    private List<Row> _data;

    public VerifyHeaders(List<Row> data) {
        _data = data;
    }

    public void headersMatch(String[] expectedColumns){

        Set<String> keyset = _data.get(0).keySet();
        if(keyset.size() == 0){
            LogInfo.log_AndFail("Unable to get headers");
        }

        if(keyset.size() != expectedColumns.length){
            LogInfo.log_Status(keyset.toString());
            StringBuilder builder = new StringBuilder();
            for(String value : expectedColumns) {
                builder.append(value);
                builder.append(", ");
            }
            LogInfo.log_Status(builder.toString());

            LogInfo.log_AndFail("Mismatch between keyset and expected columns.  Expected "
                    + expectedColumns.length + " But seeing " + keyset.size());
        }

        SoftAssert softAssert = new SoftAssert();
        for(String column : expectedColumns) {
            softAssert.assertTrue(keyset.contains(column), "Did NOT find column " + column);
        }
        softAssert.assertAll();
    }


}
