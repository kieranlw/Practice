package utils2.tableData.verify;

import org.testng.asserts.SoftAssert;
import utils2.LogInfo;
import utils2.tableData.Row;

import java.util.List;

public class VerifyColumns {

    private List<Row> _data;

    public VerifyColumns(List<Row> data) {
        _data = data;
    }

    public void headersExist(String[] expectedHeaders){
        if(expectedHeaders.length < 1){
            LogInfo.log_AndFail("Did not pass in acceptable Header String, must have at least one entry.");
        }

        SoftAssert softAssert = new SoftAssert();
        for(String header : expectedHeaders){
            softAssert.assertTrue(_data.get(0).keySet().contains(header), "Expected header " + header +" was not found.");
        }
        softAssert.assertAll();
    }

}
