package utils2.tableData.verify;

import common.Is;
import common.Verify;
import org.testng.asserts.SoftAssert;
import utils2.Index;
import utils2.LogInfo;
import utils2.tableData.Row;
import utils2.tableData.SortMechanism;
import utils2.tableData.SortOrder;

import java.text.Collator;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.RuleBasedCollator;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.function.BiPredicate;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

public class VerifyColumn {

    private List<Row> _data;
    private final String headerText;

    public VerifyColumn(List<Row> data, String headerText) {
        _data = data;
        this.headerText = headerText;
    }

    public List<String> values() {
        return _data.stream()
                .map(row -> row.get(headerText))
                .collect(Collectors.toList());
    }

    public void sorted(SortMechanism sortMechanism, SortOrder sortOrder) {
        switch (sortMechanism) {
            case ALPHA_SQL:
                sortedAlphabeticallySQL(sortOrder);
                break;
            case ALPHA_CASESENSITIVE:
                sortedAlphabetically_CaseSensitive(sortOrder);
                break;
            case ALPHA_CASEINSENSITIVE:
                sortedAlphabetically_CaseInsensitive(sortOrder);
                break;
            case NUMERIC:
                sortedNumerically(sortOrder);
                break;
            default:
                LogInfo.log_AndFail("Unrecognized Sort of " + sortMechanism + " please add validation.");
        }
    }

    public void datesSorted(SortOrder sortOrder, String dateFormat) {
        DateTimeFormatter format = DateTimeFormatter.ofPattern(dateFormat);

        if (sortOrder.equals(SortOrder.ASCENDING)) {
            verify_Column_Sorted(headerText, (previousValue, currentValue) -> {
                LocalDate beforeDate = LocalDate.parse(previousValue, format);
                LocalDate afterDate = LocalDate.parse(currentValue, format);
                return (beforeDate.isBefore(afterDate) || beforeDate.equals(afterDate));
            });
        } else {
            verify_Column_Sorted(headerText, (previousValue, currentValue) -> {
                LocalDate beforeDate = LocalDate.parse(previousValue, format);
                LocalDate afterDate = LocalDate.parse(currentValue, format);
                return (!beforeDate.isBefore(afterDate) || beforeDate.equals(afterDate));
            });
        }
    }

    private void sortedNumerically(SortOrder sortOrder) {
        if (sortOrder.equals(SortOrder.ASCENDING)) {
            verify_Column_Sorted(headerText, (previousValue, currentValue) -> {
                double previousDouble = Double.parseDouble(previousValue);
                double currentDouble = Double.parseDouble(currentValue);

                return previousDouble <= currentDouble;
            });
        } else {
            verify_Column_Sorted(headerText, (previousValue, currentValue) -> {
                double previousDouble = Double.parseDouble(previousValue);
                double currentDouble = Double.parseDouble(currentValue);

                return previousDouble >= currentDouble;
            });
        }
    }

    private void sortedAlphabeticallySQL(SortOrder sortOrder) {
        //CompareTo was different between Java and SQL.  Using Collator as workaround.
        String rules = ((RuleBasedCollator) Collator.getInstance(Locale.US)).getRules();
        try {
            final RuleBasedCollator correctedCollator = new RuleBasedCollator(rules.replaceAll("<'\u005f'", "<' '<'\u005f'"));
            correctedCollator.setStrength(Collator.IDENTICAL);

            if (sortOrder.equals(SortOrder.ASCENDING)) {
                verify_Column_Sorted(headerText, (previousValue, currentValue) -> {
                    int comparison = correctedCollator.compare(currentValue, previousValue);
                    return comparison >= 0;
                });
            } else {
                verify_Column_Sorted(headerText, (previousValue, currentValue) -> {
                    int comparison = correctedCollator.compare(currentValue, previousValue);
                    return comparison <= 0;
                });
            }
        } catch (ParseException e) {
            LogInfo.log_AndFail("Encountered error " + e.getMessage());
        }
    }

    private void sortedAlphabetically_CaseSensitive(SortOrder sortOrder) {
        if (sortOrder.equals(SortOrder.ASCENDING)) {
            verify_Column_Sorted(headerText, (previousValue, currentValue) -> {
                int comparison = currentValue.compareTo(previousValue);
                return comparison >= 0;
            });
        } else {
            verify_Column_Sorted(headerText, (previousValue, currentValue) -> {
                int comparison = currentValue.compareTo(previousValue);
                return comparison <= 0;
            });
        }
    }

    private void sortedAlphabetically_CaseInsensitive(SortOrder sortOrder) {
        if (sortOrder.equals(SortOrder.ASCENDING)) {
            verify_Column_Sorted(headerText, (previousValue, currentValue) -> {
                int comparison = currentValue.compareToIgnoreCase(previousValue);
                return comparison >= 0;
            });
        } else {
            verify_Column_Sorted(headerText, (previousValue, currentValue) -> {
                int comparison = currentValue.compareToIgnoreCase(previousValue);
                return comparison <= 0;
            });
        }
    }

    private void verify_Column_Sorted(String columnName, BiPredicate<String, String> areValuesInOrder) {
        for (int i = 1; i < _data.size(); i++) {
            String previousValue = _data.get(i - 1).get(columnName);
            String currentValue = _data.get(i).get(columnName);

            // "Row 32 (Boo) and row 33 (Foo) are [NOT] in the expected order."
            String messagePrefix = MessageFormat.format("Checking that Row {0} ({1}) and row {2} ({3}) are in the expected order", i - 1, previousValue, i,
                    currentValue);

            LogInfo.verify_ConditionTrue(areValuesInOrder.test(previousValue, currentValue), messagePrefix);
        }
    }

    public void allCellsMatch(String matcher) {
        if (_data.size() == 0) {
            LogInfo.log_AndFail("Table was empty.");
        }

        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < _data.size(); i++) {
            Row row = _data.get(i);
            final Index index = Index.zeroBased(i);

            String cellValue = row.get(headerText);
            softAssert.assertTrue(cellValue.matches(matcher),
                    "Row " + index.asOneBased() + " : Expecting match against '" + matcher + "' value was '" + cellValue + "'");
        }
        softAssert.assertAll();
    }

    public void allCellsMatchIgnoreCase(String matcher) {
        if (_data.size() == 0) {
            LogInfo.log_AndFail("Table was empty.");
        }

        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < _data.size(); i++) {
            Row row = _data.get(i);
            final Index index = Index.zeroBased(i);

            String cellValue = row.get(headerText);
            softAssert.assertTrue(cellValue.compareToIgnoreCase(matcher) == 0,
                    "Row " + index.asOneBased() + " : Expecting match against '" + matcher + "' value was '" + cellValue + "'");
        }
        softAssert.assertAll();
    }

    public void allCellsMatchPartialValue(String matcher) {
        if (_data.size() == 0) {
            LogInfo.log_AndFail("Table was empty.");
        }

        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < _data.size(); i++) {
            Row row = _data.get(i);
            final Index index = Index.zeroBased(i);

            String cellValue = row.get(headerText);
            softAssert.assertTrue(cellValue.contains(matcher),
                    "Row " + index.asOneBased() + " : Expecting match against '" + matcher + "' value was '" + cellValue + "'");
        }
        softAssert.assertAll();
    }

    public void hasCellMatching(String valueToMatch) {
        boolean matchFound = false;
        for (Row row : _data) {
            if (row.get(headerText).equals(valueToMatch)) {
                LogInfo.log_AndPass("Found cell matching " + valueToMatch);
                matchFound = true;
                break;
            }
        }
        if (!matchFound) {
            LogInfo.log_AndFail("Could not find value " + valueToMatch + " in column " + headerText);
        }
    }

    public void hasCellMatchIgnoreCase(String valueToMatch) {
        boolean matchFound = false;
        for (Row row : _data) {
            if (row.get(headerText).equalsIgnoreCase(valueToMatch)) {
                LogInfo.log_AndPass("Found cell matching " + valueToMatch);
                matchFound = true;
                break;
            }
        }
        if (!matchFound) {
            LogInfo.log_AndFail("Could not find value " + valueToMatch + " in column " + headerText);
        }
    }

    public void doesNotHaveCellMatching(String valueToMatch) {
        boolean matchFound = false;
        for (Row row : _data) {
            if (row.get(headerText).equals(valueToMatch)) {
                LogInfo.log_AndPass("Found cell matching " + valueToMatch);
                matchFound = true;
                break;
            }
        }
        if (matchFound) {
            LogInfo.log_AndFail("Found cell matching " + valueToMatch + " in column " + headerText);
        }
    }

    public void doesNotHaveCellContaining(String valueToMatch) {
        boolean matchFound = false;
        for (Row row : _data) {
            if (row.get(headerText).contains(valueToMatch)) {
                LogInfo.log_AndPass("Found cell containing " + valueToMatch);
                matchFound = true;
                break;
            }
        }
        if (matchFound) {
            LogInfo.log_AndFail("Found cell containing " + valueToMatch + " in column " + headerText);
        }
    }

    public void hasNumberOfRowsMatchingValue(int expectedCount, String valueToMatch) {

        int count = 0;
        for (Row row : _data) {
            if (row.get(headerText).equals(valueToMatch)) {
                count++;
            }
        }

        Verify.that(count, Is.equalTo(expectedCount), "count");
    }

    public void hasValuesInAnyOrder(String... expectedValues) {
        List<String> expected = Arrays.asList(expectedValues);
        List<String> actual = values();
        expected.sort(String::compareTo);
        actual.sort(String::compareTo);
        assertThat(actual, equalTo(expected));
    }

    public void hasValuesInParticularOrder(List<String> listToCompare) {
        assertThat(values(), Is.equalTo(listToCompare));
    }
}
