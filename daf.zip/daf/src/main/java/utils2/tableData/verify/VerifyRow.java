package utils2.tableData.verify;

import common.RowFilter;
import utils2.LogInfo;
import utils2.tableData.Row;
import utils2.tableData.Rows;
import utils2.tableData.getInfo.GetRow;

public class VerifyRow {
    private final Rows rows;
    private final RowFilter filter;

    public VerifyRow(Rows rows, RowFilter filter) {
        this.rows = rows;
        this.filter = filter;
    }

    public void found() {
        GetRow getRow = new GetRow(rows);
        Row row = getRow.by(filter);

        if (row == null) {
            LogInfo.log_AndFail("Did not find row " + filter.toString());
        } else {
            LogInfo.log_AndPass("Found Row " + filter);
        }
    }

    public void notFound() {
        GetRow getRow = new GetRow(rows);
        Row row = getRow.by(filter);

        if (row != null) {
            LogInfo.log_AndFail("Found row " + filter.toString());
        } else {
            LogInfo.log_AndPass("Did NOT find Row " + filter);
        }
    }
}
