package utils2.tableData;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import utils2.Index;
import utils2.LogInfo;
import utils2.TableData2;
import utils2.page_components.element_utils.ElementUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GetTable {

    private WebDriver _driver;

    public GetTable(WebDriver driver) {
        _driver = driver;
    }

    public TableData2 getTableByCells(By cellsIdentifier, List<String> headers) {
        return getTableByCells(cellsIdentifier, headers.toArray(new String[0]));
    }

    public TableData2 getTableByCells(By cellsIdentifier, String[] headers) {
        if (headers.length == 0) {
            LogInfo.log_AndFail("Headers not found, cannot parse table.");
        }

        List<WebElement> cells = _driver.findElements(cellsIdentifier);

        List<String> cellExtracts = new ArrayList<>();
        for (WebElement cell : cells) {
            String tagName = cell.getTagName();
            if (tagName.equals("select")) {
                ElementUtils elementUtils = new ElementUtils("Table Cell", cell);
                cellExtracts.add(elementUtils.getSelectedOption());
            } else if (isCheckbox(cell, tagName)) {
                cellExtracts.add(cell.isSelected() ? "true" : "false");
            } else if (tagName.equals("input") || tagName.equals("XCUIElementTypeStaticText")) {
                cellExtracts.add(cell.getAttribute("value"));
            } else if (tagName.equals("android.widget.TextView")) {
                cellExtracts.add(cell.getAttribute("text"));
            } else if (tagName.equals("center")) {
                if (cell.getAttribute("innerHTML").contains("img")) {
                    cellExtracts.add("true");
                } else {
                    cellExtracts.add("false");
                }
            } else {
                cellExtracts.add(cell.getAttribute("innerText"));
            }
        }

        int cellCount = cellExtracts.size();
        int headerCount = headers.length;

        if (cellCount % headerCount != 0) {
            LogInfo.log_AndFail("There is something off with either the Header identifier or the cell identifier.  Header count was " + headerCount + " cell count was " + cellCount);
        }

        List<Row> newMapList = new ArrayList<>();

        for (int i = 0; i < cellCount; ) {
            Map<String, String> rowMap = new HashMap<>();

            for (int j = 0; j < headerCount; j++) {
                rowMap.put(headers[j], cellExtracts.get(i).trim());

                i++;
            }
            newMapList.add(new Row(rowMap));
        }
        // cells are split up by /t/t/t/t and then /n for line.

        TableData2 newTable = new TableData2(newMapList);

        return newTable;
    }

    private boolean isCheckbox(WebElement cellElement, String tagName) {
        boolean isTypeOfCheckbox = false;
        try {
            if (cellElement.getAttribute("type").equals("checkbox")) {
                isTypeOfCheckbox = true;
            }
        } catch (Exception e) {
        }

        return tagName.equals("input") && isTypeOfCheckbox;
    }

    public TableData2 getTableByCells(By cellsIdentifier, String[] headers, boolean bByPassEmptyText) {
        if (!bByPassEmptyText) {
            return getTableByCells(cellsIdentifier, headers);
        }

        if (headers.length == 0) {
            LogInfo.log_AndFail("Headers not found, cannot parse table.");
        }

        List<WebElement> cells = _driver.findElements(cellsIdentifier);

        List<String> cellExtracts = new ArrayList<>();
        for (WebElement cell : cells) {
            if (cell.getTagName().equals("input") || cell.getTagName().equals("XCUIElementTypeStaticText")) {
                cellExtracts.add(cell.getAttribute("value"));
            } else if (cell.getTagName().equals("android.widget.TextView")) {
                cellExtracts.add(cell.getAttribute("text"));
            } else if (cell.getAttribute("innerText").trim().length() > 0) {
                cellExtracts.add(cell.getAttribute("innerText"));
            }
        }

        int cellCount = cellExtracts.size();
        int headerCount = headers.length;

        if (cellCount % headerCount != 0) {
            LogInfo.log_AndFail("There is something off with either the Header identifier or the cell identifier.  Header count was " + headerCount + " cell count was " + cellCount);
        }

        List<Row> newMapList = new ArrayList<>();

        for (int i = 0; i < cellCount; ) {
            Map<String, String> rowMap = new HashMap<>();

            for (int j = 0; j < headerCount; j++) {
                rowMap.put(headers[j], cellExtracts.get(i).trim());

                i++;
            }
            newMapList.add(new Row(rowMap));
        }
        // cells are split up by /t/t/t/t and then /n for line.

        TableData2 newTable = new TableData2(newMapList);

        return newTable;
    }
}
