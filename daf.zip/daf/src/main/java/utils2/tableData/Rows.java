package utils2.tableData;

import common.RowFilter;
import utils2.Index;

import java.util.ArrayList;
import java.util.List;

public class Rows {
    private final List<Row> originalRows;

    public Rows(List<Row> originalRows) {
        this.originalRows = originalRows;
    }

    public FilteredRows filter(RowFilter filter) {
        List<RowWithIndex> results = new ArrayList<>();
        for (int i = 0; i < originalRows.size(); i++) {
            final Row row = originalRows.get(i);
            if (filter.matches(row)) {
                results.add(new RowWithIndex(row, Index.zeroBased(i)));
            }
        }
        return new FilteredRows(results);
    }

    public Row get(int index) {
        return originalRows.get(index);
    }
}
