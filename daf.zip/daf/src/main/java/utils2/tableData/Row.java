package utils2.tableData;

import utils2.tableData.row.RowVerifications;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public class Row {

    private Map<String, String> _row;

    public Row(Map<String, String> row) {
        _row = row;
    }

    public Row() {
        Map<String, String> freshRow = new LinkedHashMap<>();
        _row = freshRow;
    }

    /**
     * Creates a Row using the given values as alternating keys and values.
     * For example, Row.of("a", "1", "b", "2") would return a Row with two
     * values: row.get("a") == "1" and row.get("b") == "2".
     *
     * @param keysAndValues Key1, value1, key2, value2, key3, value3, ...
     * @return The new Row
     */
    public static Row of(String... keysAndValues) {
        Row row = new Row();
        for (int i = 0; i < keysAndValues.length; i += 2) {
            row.put(keysAndValues[i], keysAndValues[i + 1]);
        }
        return row;
    }

    public void put(String column, String value) {
        _row.put(column, value);
    }

    public Map<String, String> getMap() {
        return _row;
    }

    public String get(String valueToGet) {
        return _row.get(valueToGet);
    }

    public Optional<String> getOptional(String valueToGet) {
        return Optional.ofNullable(get(valueToGet));
    }

    public String remove(String key) {
        return _row.remove(key);
    }

    public Set<String> keySet() {
        return _row.keySet();
    }

    public RowVerifications verify() {
        return new RowVerifications(_row);
    }

    public int size() {
        return _row.keySet().size();
    }

    @Override
    public String toString() {
        return _row.toString();
    }

    public String getNullable(String valueToGet) {
        String cellContent = _row.get(valueToGet);
        return cellContent.equalsIgnoreCase("null") || cellContent.equalsIgnoreCase("") ? null : cellContent;
    }
}
