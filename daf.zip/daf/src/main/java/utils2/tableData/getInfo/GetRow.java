package utils2.tableData.getInfo;

import common.RowFilter;
import org.jetbrains.annotations.NotNull;
import utils2.Index;
import utils2.tableData.Row;
import utils2.tableData.Rows;

import java.util.List;

public class GetRow extends GetRowBase<Row> {
    public GetRow(Rows rows) {
        super(rows);
    }

    @Override
    public Row byIndex(Index index) {
        return rows.get(index.asZeroBased());
    }

    @Override
    @NotNull
    protected List<Row> filter(RowFilter filter) {
        return rows.filter(filter).toRows();
    }
}
