package utils2.tableData.getInfo;

import common.RowFilter;
import org.jetbrains.annotations.NotNull;
import utils2.Index;
import utils2.tableData.RowWithIndex;
import utils2.tableData.Rows;

import java.util.List;

public class GetRowWithIndex extends GetRowBase<RowWithIndex> {
    public GetRowWithIndex(Rows rows) {
        super(rows);
    }

    @Override
    @NotNull
    protected List<RowWithIndex> filter(RowFilter filter) {
        return rows.filter(filter).toRowsWithIndexes();
    }

    @Override
    public RowWithIndex byIndex(Index index) {
        return new RowWithIndex(rows.get(index.asZeroBased()), index);
    }
}
