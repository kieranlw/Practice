package utils2.tableData.getInfo;

import common.Is;
import common.RowFilter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import utils2.Index;
import utils2.tableData.Row;
import utils2.tableData.Rows;

import java.util.List;

public abstract class GetRowBase<R> {
    protected final Rows rows;

    public GetRowBase(Rows rows) {
        this.rows = rows;
    }

    /**
     * Finds the first row that matches the given filter.
     *
     * @param filter Filter to match
     * @return The first matching row, or null if no match was found.
     * @see #last(RowFilter)
     */
    @Nullable
    public R by(RowFilter filter) {
        final List<R> matches = filter(filter);
        return matches.size() > 0 ? matches.get(0) : null;
    }

    /**
     * Finds the last row that matches the given filter.
     *
     * @param filter Filter to match
     * @return The last matching row, or null if no match was found.
     * @see #by(RowFilter)
     */
    @Nullable
    public R last(RowFilter filter) {
        final List<R> matches = filter(filter);
        return matches.size() > 0 ? matches.get(matches.size() - 1) : null;
    }

    @NotNull
    protected abstract List<R> filter(RowFilter filter);

    public R firstRow() {
        return byIndex(Index.zeroBased(0));
    }

    public R byMatchingField(String column, String value) {
        return by(RowFilter.of(column, value));
    }

    public R byMatchingFields(String column1, String value1, String column2, String value2) {
        return by(RowFilter.of(column1, value1, column2, value2));
    }

    public R byPartialMatchingField(String column, String value) {
        return by(RowFilter.of(column, Is.stringContaining(value)));
    }

    public R byMap_LastEntry(Row mapToLocate) {
        return last(RowFilter.of(mapToLocate.getMap()));
    }

    public R byMap_LastEntryByPartialText(Row mapToLocate) {
        return last(RowFilter.of(mapToLocate.getMap(), Is::stringContaining));
    }

    public abstract R byIndex(Index index);

    public R byMap(Row mapToLocate) {
        return by(RowFilter.of(mapToLocate.getMap()));
    }

    public R byMapByPartialText(Row mapToLocate) {
        return by(RowFilter.of(mapToLocate.getMap(), Is::stringContaining));
    }
}
