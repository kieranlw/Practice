package utils2.tableData.sort;

public class SortColumn {
}
