package utils2.tableData.format;

import utils2.tableData.Row;

import java.util.List;
import java.util.ListIterator;

public class FormatHeaders {

    private List<Row> _data;

    public FormatHeaders(List<Row> data){
        _data = data;
    }

    public void removeCharacter(String characterToRemove) {

        for (ListIterator<Row> iterator = _data.listIterator(); iterator.hasNext();) {

            Row tableRow = iterator.next();
            Row updatedTableRow = new Row(tableRow.getMap());

            for (String key : tableRow.keySet()) {
                updatedTableRow.put(key.replace(characterToRemove, ""), tableRow.get(key));

            }

            iterator.set(updatedTableRow);

        }
    }


}
