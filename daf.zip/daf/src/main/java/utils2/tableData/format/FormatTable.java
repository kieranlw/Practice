package utils2.tableData.format;

import utils2.Index;
import utils2.tableData.Row;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;

public class FormatTable {

    private List<Row> _data;

    public FormatTable(List<Row> data) {
        _data = data;
    }

    public void removeCharacter(String characterToRemove) {
        for (Row dataRow : _data) {
            for (String key : dataRow.keySet()) {
                String cellText = dataRow.get(key);
                if (cellText != null) {
                    cellText = cellText.replace(characterToRemove, "");
                    dataRow.put(key, cellText);
                }
            }
        }
    }

    public void trim() {
        for (ListIterator<Row> iterator = _data.listIterator(); iterator.hasNext(); ) {

            Row tableRow = iterator.next();
            Row updatedTableRow = new Row();

            for (String key : tableRow.keySet()) {
                updatedTableRow.put(key.trim(), tableRow.get(key).trim());
            }

            iterator.set(updatedTableRow);
        }
    }

    public void replaceNullWithEmpty() {
        for (Row dataRow : _data) {
            for (String key : dataRow.keySet()) {
                if (dataRow.get(key) == null) {
                    dataRow.put(key, "");
                }
            }
        }
    }

    public void replaceNullOrEmptyWithValue(String newValue) {
        for (Row dataRow : _data) {
            for (String key : dataRow.keySet()) {
                if (dataRow.get(key) == null || dataRow.get(key).isEmpty()) {
                    dataRow.put(key, newValue);
                }
            }
        }
    }

    public void replaceValuesIgnoringCase(String target, String replacement) {
        for (Row dataRow : _data) {
            for (String key : dataRow.keySet()) {
                if (dataRow.get(key).equalsIgnoreCase(target)) {
                    dataRow.put(key, replacement);
                }
            }
        }
    }

    // Replaces Old Date Format with New Date Format. This Overload only
    // performs the formatting
    // to a specific passed in column
    public void replace_DateFormats(String columnToFormat, String oldFormat, String newFormat) throws ParseException {
        for (Row dataRow : _data) {
            DateFormat fromFormat = new SimpleDateFormat(oldFormat);
            fromFormat.setLenient(false);
            DateFormat toFormat = new SimpleDateFormat(newFormat);
            toFormat.setLenient(false);
            Date date = fromFormat.parse(dataRow.get(columnToFormat));
            // toFormat.format(date);
            dataRow.put(columnToFormat, toFormat.format(date));
        }
    }
}
