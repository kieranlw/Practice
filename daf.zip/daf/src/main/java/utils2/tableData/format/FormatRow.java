package utils2.tableData.format;

import utils2.tableData.Row;

import java.util.List;

public class FormatRow {

    private List<Row> _data;

    public FormatRow(List<Row> data){
        _data = data;
    }
}
