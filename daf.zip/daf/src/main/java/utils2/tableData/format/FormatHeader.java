package utils2.tableData.format;

import utils2.tableData.Row;

import java.util.List;

public class FormatHeader {

    private List<Row> _data;

    private String _headerText;

    public FormatHeader(List<Row> data, String headerText){
        _data = data;
        _headerText = headerText;
    }

    // Overload only removes the character from the column name that is passed in.
    public void removeCharacter(String characterToRemove) {
        for (Row dataRow : _data) {
            String cellText = dataRow.get(_headerText);
            if (cellText != null) {
                cellText = cellText.replace(characterToRemove, "");
                dataRow.put(_headerText, cellText);
            }
        }
    }

}
