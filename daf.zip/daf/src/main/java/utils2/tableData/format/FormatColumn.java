package utils2.tableData.format;

import utils2.tableData.Row;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class FormatColumn {

    private List<Row> _data;
    private String _columnName;

    public FormatColumn(List<Row> data, String columnName){
        _data = data;
        _columnName = columnName;
    }

    // Replaces Old Date Format with New Date Format. This Overload only
    // performs the formatting
    // to a specific passed in column
    public void replace_DateFormats( String oldFormat, String newFormat) throws ParseException {
        for (Row dataRow : _data) {
            DateFormat fromFormat = new SimpleDateFormat(oldFormat);
            fromFormat.setLenient(false);
            DateFormat toFormat = new SimpleDateFormat(newFormat);
            toFormat.setLenient(false);
            Date date = fromFormat.parse(dataRow.get(_columnName));
            dataRow.put(_columnName, toFormat.format(date));
        }
    }

    public void trim() {
        for (Row dataRow : _data) {
            String cellText = dataRow.get(_columnName);
            if (cellText != null) {
                dataRow.put(_columnName, cellText.trim());
            }
        }
    }

}
