package utils2.tableData;

import utils2.tableData.format.*;
import java.util.List;

public class Format {

    public final FormatRow row;
    public final FormatHeaders headers;
    public final FormatTable table;

    private List<Row> _data;

    public Format(List<Row> data){
        _data = data;
        row = new FormatRow(_data);
        headers = new FormatHeaders(_data);
        table = new FormatTable(_data);
    }

    public FormatHeader header(String headerToPick){
        return new FormatHeader(_data, headerToPick);
    }

    public FormatColumn column(String columnName){
        return new FormatColumn(_data, columnName);
    }
}
