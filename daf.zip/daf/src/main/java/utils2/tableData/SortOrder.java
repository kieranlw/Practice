package utils2.tableData;

public enum SortOrder {
    ASCENDING, DESCENDING
}
