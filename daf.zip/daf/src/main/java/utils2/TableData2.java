package utils2;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opencsv.CSVWriter;
import common.ReadableFile;
import common.WritableFile;
import org.json.JSONArray;
import org.json.JSONObject;
import utils.TableData;
import utils2.tableData.*;

import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;

public class TableData2 {

    //Still working on this, I want to restructure our Table Data object.

    public List<Row> data;

    public TableData2(Row... rows) {
        // Arrays.asList returns a fixed-length list. Wrap it in an ArrayList
        // so that we'll be able to add more rows to the table after creation.
        this(new ArrayList<>(Arrays.asList(rows)));
    }

    public TableData2(List<Row> rows) {
        data = rows;
    }

    public static TableData2 createFromMaps(List<Map<String, String>> maps) {
        List<Row> rows = new ArrayList<>();
        for (int i = 0; i < maps.size(); i++) {
            rows.add(new Row(maps.get(i)));
        }
        return new TableData2(rows);
    }

    public static TableData2 loadDelimited(ReadableFile file, String delimiter) {
        TableData oldTableFormat = TableData.loadDelimited(file, delimiter);
        return oldTableFormat.toTableData2(oldTableFormat);
    }

    public static TableData2 loadCsv(ReadableFile file) {
        TableData oldTableFormat = TableData.loadCsv(file);
        return oldTableFormat.toTableData2(oldTableFormat);
    }

    public void saveCsv(WritableFile file) {
        file.writeAllText(toCsv());
    }

    public Format format() {
        return new Format(data);
    }

    public int size() {
        return data.size();
    }

    public TableVerify verify() {
        return new TableVerify(data);
    }

    public GetTableData get() {
        return new GetTableData(new Rows(data));
    }

    // Pass in lambda expression to apply to each row.
    public void forEachRow(Consumer<Row> lambdaExpression) {
        data.forEach(lambdaExpression);
    }

    public String getJson() {
        List<JSONObject> jsonObject = new ArrayList<>();
        data.forEach(row -> jsonObject.add(new JSONObject(row.getMap())));
        return new JSONArray(jsonObject).toString();
    }

    public TableData2 cloneTable() {
        List<Row> tableObject = new ArrayList<>();
        for (Row row : data) {
            final Map<String, String> clonedMap = new LinkedHashMap<>(row.getMap());
            tableObject.add(new Row(clonedMap));
        }
        return new TableData2(tableObject);
    }

    public void logTable() {
        for (int i = 0; i < data.size(); i++) {
            Row row = data.get(i);
            final Index index = Index.zeroBased(i);

            LogInfo.log_Status("Table row " + index.asZeroBased() + " : " + row.getMap().toString());
        }
    }

    public <T> List<T> getDataAs(Class<T> cls) {
        Constructor<?> rowConstructor = tryGetConstructor(cls, Row.class);
        if (rowConstructor != null) {
            return getDataAs(cls, rowConstructor, rowWithIndex -> rowWithIndex.getRow());
        }

        Constructor<?> rowWithIndexConstructor = tryGetConstructor(cls, RowWithIndex.class);
        if (rowWithIndexConstructor != null) {
            return getDataAs(cls, rowWithIndexConstructor, rowWithIndex -> rowWithIndex);
        }

        Constructor<?> mapConstructor = tryGetConstructor(cls, Map.class);
        if (mapConstructor != null) {
            return getDataAs(cls, mapConstructor, rowWithIndex -> rowWithIndex.getRow().getMap());
        }

        try {
            ObjectMapper mapper = new ObjectMapper();
            JavaType type = mapper.getTypeFactory().constructCollectionType(List.class, cls);
            return mapper.readValue(getJson(), type);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Encountered Jackson error: " + e.getMessage());
        }
    }

    private Constructor<?> tryGetConstructor(Class<?> cls, Class<?>... parameterTypes) {
        Constructor<?>[] constructors = cls.getDeclaredConstructors();
        return Arrays.stream(constructors)
                .filter(c -> Arrays.equals(c.getParameterTypes(), parameterTypes))
                .findFirst().orElse(null);
    }

    private <T> List<T> getDataAs(Class<T> cls, Constructor<?> constructor, Function<RowWithIndex, Object> getConstructorParameter) {

        constructor.setAccessible(true);

        List<T> list = new ArrayList<>();
        for (int i = 0; i < data.size(); i++) {
            Row row = data.get(i);
            Index index = Index.zeroBased(i);
            try {
                Object parameter = getConstructorParameter.apply(new RowWithIndex(row, index));
                @SuppressWarnings("unchecked") T instance = (T) constructor.newInstance(parameter);
                list.add(instance);
            } catch (IllegalAccessException | InstantiationException | InvocationTargetException e) {
                // If InvocationTargetException, unwrap to get the original error
                Throwable error = (e instanceof InvocationTargetException && e.getCause() != null) ? e.getCause() : e;

                error.printStackTrace();
                throw new RuntimeException("Error converting table to List<" + cls.getName() + ">: " + error.getMessage(), error);
            }
        }
        return list;
    }

    public Map<String, String> toMap(String keyColumn, String valueColumn) {
        return toMap(keyColumn, valueColumn, value -> value);
    }

    public <T> Map<String, T> toMap(String keyColumn, String valueColumn, Function<String, T> parseValue) {
        Map<String, T> results = new HashMap<>();
        forEachRow(row -> results.put(row.get(keyColumn), parseValue.apply(row.get(valueColumn))));
        return results;
    }

    private Collection<String> getColumnHeaders() {
        Set<String> result = new LinkedHashSet<>();
        for (Row row : data) {
            result.addAll(row.keySet());
        }
        return result;
    }

    public String toCsv() {
        if (size() == 0) {
            return "";
        }

        final StringWriter stringWriter = new StringWriter();
        final CSVWriter csvWriter = new CSVWriter(stringWriter, ',', '"', '"', "\r\n");
        final Collection<String> columnHeaders = getColumnHeaders();
        csvWriter.writeNext(columnHeaders.toArray(new String[0]), false);
        for (Row row : data) {
            final List<String> cells = new ArrayList<>();
            for (String columnHeader : columnHeaders) {
                cells.add(row.get(columnHeader));
            }
            csvWriter.writeNext(cells.toArray(new String[0]), false);
        }
        return stringWriter.toString();
    }

    public void sort(String sortBy) {
        sort(sortBy, OrderBy.ASC);
    }

    public void sort(String sortBy, OrderBy direction) {
        Comparator<String> nullSafeStringComparator = Comparator
                .nullsFirst(String::compareTo);

        if (direction == OrderBy.DESC) {
            sort(Comparator.comparing((Row r) -> r.get(sortBy), nullSafeStringComparator).reversed());
        } else {
            sort(Comparator.comparing(r -> r.get(sortBy), nullSafeStringComparator));
        }
    }

    public void sort(Comparator<Row> sortBy) {
        this.data.sort(sortBy);
    }
}
