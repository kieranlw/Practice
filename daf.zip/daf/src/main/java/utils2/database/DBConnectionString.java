package utils2.database;

public class DBConnectionString {

    public static String getConnectionString(DBConnectionInfo connectionInfo) {
        //If there isn't a Domain that means it's a SQL user, which will require a different connection string/library from an AD user.
        if (connectionInfo.getDomain() == null || connectionInfo.getDomain().equals("") ) {
            return getStandardConnectionString(connectionInfo);
        } else {
            return getJTDSConnectionString(connectionInfo);
        }
    }

    private static String getJTDSConnectionString(DBConnectionInfo connectionInfo) {
        StringBuilder sb = new StringBuilder("jdbc:jtds:sqlserver://")
            .append(connectionInfo.getServer())
            .append("/" + connectionInfo.getDatabaseName())
            .append(";domain=" + connectionInfo.getDomain())
            .append(";user=" + connectionInfo.getUser())
            .append(";password=" + connectionInfo.getPassword());

        if(connectionInfo.useNTLNv2()) {
            sb.append(";useNTLMv2=true");
        }

        return sb.toString();
    }

    private static String getStandardConnectionString(DBConnectionInfo connectionInfo) {
        String connectionString = "jdbc:sqlserver://" + connectionInfo.getServer()
                + ";user=" + connectionInfo.getUser() + ";password=" + connectionInfo.getPassword() + ";databaseName="
                + connectionInfo.getDatabaseName();
        return connectionString;
    }
}
