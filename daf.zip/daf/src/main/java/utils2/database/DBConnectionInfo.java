package utils2.database;

import utils2.LogInfo;

public class DBConnectionInfo {

    private String server;
    private String databaseName;
    private String user;
    private String password;
    private String domain;
    private boolean useNTLMv2 = false;

    public String getServer() {
        return server;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public String getDomain() {
        return domain;
    }

    public boolean useNTLNv2() { return useNTLMv2; }

    private DBConnectionInfo(ConnectionBuilder builder) {
        server = builder.server;
        databaseName = builder.databaseName;
        user = builder.user;
        password = builder.password;
        domain = builder.domain;
        useNTLMv2 = builder.useNTLMv2;
    }

    public static ConnectionBuilder Builder(){
        return new ConnectionBuilder();
    }


    public String getConnectionString() {
        return DBConnectionString.getConnectionString(this);
    }

    public static class ConnectionBuilder {
        private String server;
        private String databaseName;
        private String user;
        private String password;
        private String domain;
        private boolean useNTLMv2;

        public ConnectionBuilder() {
        }

        public ConnectionBuilder setServer(String server) {
            this.server = server;
            return this;
        }

        public ConnectionBuilder setDatabaseName(String databaseName) {
            this.databaseName = databaseName;
            return this;
        }

        public ConnectionBuilder setUser(String user) {
            this.user = user;
            return this;
        }

        public ConnectionBuilder setPassword(String password) {
            this.password = password;
            return this;
        }

        public ConnectionBuilder setDomain(String domain) {
            this.domain = domain;
            return this;
        }

        public ConnectionBuilder setUseNTLMv2(boolean useNTLMv2) {
            this.useNTLMv2 = useNTLMv2;
            return this;
        }

        public DBConnectionInfo build() {
            validate();
            return new DBConnectionInfo(this);
        }

        private void validate(){
            LogInfo.verify_ConditionTrue(this.server != null && !this.server.isEmpty(), "Server should not be empty.");
            LogInfo.verify_ConditionTrue(this.databaseName != null && !this.databaseName.isEmpty(), "Database Name should not be empty.");
            LogInfo.verify_ConditionTrue(this.user != null && !this.user.isEmpty(), "User Name should not be empty.");
            LogInfo.verify_ConditionTrue(this.password != null && !this.password.isEmpty(), "Password should not be empty.");
        }
    }
}