package utils2;

import org.openqa.selenium.NoSuchElementException;

/**
 * Same as {@link NoSuchElementException}, but without Selenium's extra
 * diagnostic information (i.e., without the "For documentation...",
 * "Build info...", etc.)
 */
public class SimpleNoSuchElementException extends NoSuchElementException {
    private final String message;

    public SimpleNoSuchElementException(String reason) {
        super(reason);
        message = reason;
    }

    @SuppressWarnings("unused")
    public SimpleNoSuchElementException(String reason, Throwable cause) {
        super(reason, cause);
        message = reason;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
