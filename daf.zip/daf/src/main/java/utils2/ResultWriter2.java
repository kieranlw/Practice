package utils2;

import io.appium.java_client.AppiumDriver;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.winium.WiniumDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestResult;
import testng_Listeners.ListenerUtils;
import utils.ResultWriter;
import utils.ScreenShot;
import utils.SystemVariables;
import utils2.ResultWriter.DriverAndScreenshotDedupe;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class ResultWriter2 {

    private static final Logger LOGGER = LoggerFactory.getLogger(ResultWriter2.class);

    private static int resultCounter = 0;

    private final static ArrayList<DriverAndScreenshotDedupe> _duplicateList = new ArrayList<>();

    public static void checkForFailureAndScreenshot(ITestResult result, WebDriver driver) throws Exception {
        if (result.getStatus() == ITestResult.FAILURE || result.getStatus() == ITestResult.SKIP) {
            saveScreenshotOnError(result, driver);
        }
    }

    private static boolean duplicateEntryFound(WebDriver driver, String screenshotInfo) {

        for (DriverAndScreenshotDedupe dupeEntry : _duplicateList) {
            if (screenshotInfo.equals(dupeEntry.get_ScreenshotInfo()) && driver.toString().equals(dupeEntry.get_DriverString())) {
                return true;
            }
        }
        return false;
    }


    private static void saveScreenshotOnError(ITestResult result, WebDriver driver) throws Exception {
        resultCounter++;
        if (driver == null) {
            return;
        }

        String resultName = result.getName();

        String filePath = getScreenshotPath(result, resultName);
        String filePath2 = getScreenshotPath(result, resultName + "-2");

        DriverAndScreenshotDedupe newDupeCheck = new DriverAndScreenshotDedupe(driver.toString(), resultName);

        if (duplicateEntryFound(driver, resultName)) {

        } else {
            _duplicateList.add(newDupeCheck);
            try {

                try {
                    boolean isWinium = driver instanceof WiniumDriver;
                    boolean isAppium = driver instanceof AppiumDriver;
                    boolean isAppiumWindows = AppiumDesktop.isWindowsPlatform(driver);
                    // Selenium supports getting the current URL, and we can do full-page screenshots.
                    // Appium doesn't have URLs, and we can do full-page screenshots on mobile, but not on desktop.
                    boolean showUrl = !isWinium && !isAppium;
                    boolean includeFullPageScreenshot = !isWinium && !isAppiumWindows;

                    String messageSuffix = showUrl ? " of " + driver.getCurrentUrl() : "";

                    File destination = new File(filePath);
                    File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
                    ListenerUtils.logScreenshot(LOGGER, scrFile.getAbsolutePath(), "Screenshot" + messageSuffix);
                    FileUtils.copyFile(scrFile, destination);

                    //Need to add conditions where we don't take full screenshot like Appium and Winium
                    File destination2 = new File(filePath2);
                    if (includeFullPageScreenshot) {
                        ScreenShot.makeFullScreenshot(driver, destination2.getAbsolutePath());
                        ListenerUtils.logScreenshot(LOGGER, destination2.getAbsolutePath(), "Full-page screenshot" + messageSuffix);
                    }

                    Object screenshotsObj = result.getAttribute("Screenshots");
                    if (screenshotsObj == null) {
                        ArrayList<File> screenshots = new ArrayList<>();
                        screenshots.add(destination);
                        if (includeFullPageScreenshot) {
                            screenshots.add(destination2);
                        }
                        result.setAttribute("Screenshots", screenshots);
                    } else {

                        Object screenObject = result.getAttribute("Screenshots");

                        ArrayList<File> screenshots = convertObjectToArrayListOfFiles(screenObject);
                        screenshots.add(destination);
                        if (includeFullPageScreenshot) {
                            screenshots.add(destination2);
                        }
                    }
                } catch (InterruptedException | org.openqa.selenium.UnhandledAlertException | org.openqa.selenium.JavascriptException e) {
                    System.out.println("Encountered error while taking screenshot: " + e.getMessage());
                }
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }

    //Return empty list if not compatible.  Couldn't find clean way to do cast check due to Java limitations.
    @SuppressWarnings (value="unchecked")
    public static ArrayList<File> convertObjectToArrayListOfFiles(Object objToConvert){
        ArrayList<File> fileList = new ArrayList<>();
        if (objToConvert instanceof ArrayList<?> && ((ArrayList<?>) objToConvert).get(0) instanceof File) {
            fileList = (ArrayList<File>) objToConvert;
        }
        return fileList;
    }

    public static String getScreenshotPath(ITestResult result, String testNamePlaceholderForFileName) throws
            Exception {
        String className = result.getTestClass().getName();
        String testStartTime = SystemVariables.testStartTime;

        Date todaysDate = Calendar.getInstance().getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
        String strTodayDate = dateFormat.format(todaysDate);

        String userHome = System.getProperty( "user.home");
        userHome = userHome.startsWith("C:") ? "C:" : userHome;

        String path = userHome + "/DAF/screenshots/" + strTodayDate + "/" + className + "/";

        path = FilenameUtils.normalize(path);

        File file = new File(path);
        file.mkdirs();

        Object[] parameters = result.getParameters();
        String parameterOutput = "";
        if(parameters != null){
            for(Object param : parameters){
               if(parameterOutput.length() > 20){
                   break;
               }
               if(param != null) {
                    parameterOutput += param.toString()
                            .replace("/", "")
                            .replace(":", "")
                            .replace(",","")
                            .replace("-", "")
                            .replace("[","")
                            .replace("]","");
               }
            }
        }

        parameterOutput = parameterOutput.length() >= 30? parameterOutput.substring(0, 30) : parameterOutput;

        String fullScreenshotPath = path + testNamePlaceholderForFileName + "_" + parameterOutput + "_"+ testStartTime + "_SS_" + resultCounter
                + ".jpg";

        String message = "Screenshot: " + "path=" + fullScreenshotPath + "; " + "class=" + className + "; " + "method="
                + result.getName() + ResultWriter.describeParameterList(result.getParameters());

        LogInfo.log_Status(message);

        ResultWriter.ScreenshotCleanup(  FilenameUtils.normalize(userHome + "/DAF/screenshots/"));

        return fullScreenshotPath;
    }
}//End off class