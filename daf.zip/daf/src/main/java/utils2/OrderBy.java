package utils2;

public enum OrderBy {
    ASC("Ascending"),
    DESC("Descending");

    public final String friendlyName;

    OrderBy(String direction) {
        this.friendlyName = direction;
    }
}
