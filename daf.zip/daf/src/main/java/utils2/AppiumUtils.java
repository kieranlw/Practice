package utils2;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import utils2.page_components.*;

import java.time.Duration;

public class AppiumUtils {

    private AppiumDriver<?> _driver;

    public AppiumUtils(AppiumDriver<?> driver) {
        _driver = driver;
    }

    public void swipe(Component elementToSwipeFrom, Component elementToSwipeTo) {
        int startX = elementToSwipeFrom.getXCoordinate();
        int startY = elementToSwipeFrom.getYCoordinate();
        int endX = elementToSwipeTo.getXCoordinate();
        int endY = elementToSwipeTo.getYCoordinate();

        // while (!pickEndDateButton.exists()) {
        (new TouchAction<>(_driver))
                .press(PointOption.point(startX, startY))
                .waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000)))
                .moveTo(PointOption.point(endX, endY))
                .release()
                .perform();
        // }
    }
    public void tap(Component elementToSwipeFrom) {
        int startX = elementToSwipeFrom.getXCoordinate();
        int startY = elementToSwipeFrom.getYCoordinate();

        (new TouchAction<>(_driver))
                .press(PointOption.point(startX, startY))
                .release()
                .perform();
    }




    public boolean isAndroid() {


    String browserType = (String) ((RemoteWebDriver) _driver).getCapabilities().asMap().get("BROWSER_NAME");
    if(browserType.equals("Android"))
    {
        return true;
    }
    else

    {
        return false;
    }
}

    public boolean isIOS() {


        String browserType = (String) ((RemoteWebDriver) _driver).getCapabilities().asMap().get("BROWSER_NAME");
        if(browserType.equals("Android"))
        {
            return false;
        }
        else

        {
            return true;
        }
    }

    public void scrollDownUntilVisible(Component startingElement, Component elementToScrollTo) {

        Dimension windowSize = _driver.manage().window().getSize();
        int starty = startingElement.getYCoordinate();
        int startx = windowSize.width/2;
        int endy = (int)(windowSize.height * .02);

        int maxCount = 0;

        WebElement elementToStopOn = elementToScrollTo.findNullableElement();
        while(elementToStopOn == null || !elementToStopOn.isDisplayed()){

            if(maxCount > 20){
                break;
            }

            (new TouchAction<>(_driver))
                    .press(PointOption.point(startx, starty))
                    .waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000)))
                    .moveTo(PointOption.point(startx, endy))
                    .release()
                    .perform();
            LogInfo.log_Status("Scrolling Down");
            elementToStopOn = elementToScrollTo.findNullableElement();

            maxCount++;

        }

    }

    public void rotateToLandscapeMode(){
        _driver.rotate(ScreenOrientation.LANDSCAPE);
    }

    public void rotateToPortraitMode(){
        _driver.rotate(ScreenOrientation.PORTRAIT);
    }

    public void dismissKeyboard(){
        _driver.hideKeyboard();

    }
    public void getKeyboard(){
        _driver.getKeyboard();
    }

}
