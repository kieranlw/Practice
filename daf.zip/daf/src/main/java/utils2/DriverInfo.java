package utils2;

import common.DataFile;
import org.openqa.selenium.PageLoadStrategy;
import utils.DataBuilder;

import java.util.HashMap;

public class DriverInfo {

    private DriverSetup.DriverType _driverType;

    private boolean headlessMode = false;

    private PageLoadStrategy pageLoadStrategy;

    private String _downloadLocation;

    private boolean logPerformanceInfo = false;

    private boolean startMaximized = false;

    public boolean isLogPerformanceInfo() {
        return logPerformanceInfo;
    }

    public DriverInfo setLogPerformanceInfo(boolean logPerformanceInfo) {
        this.logPerformanceInfo = logPerformanceInfo;
        return this;
    }

    public boolean isStartMaximized(){
        return startMaximized;
    }

    public void setStartMaximized(boolean maximize){
        startMaximized = maximize;
    }

    public DriverInfo(DriverSetup.DriverType driverType) {
        _driverType = driverType;

        //set default directory
        _downloadLocation = getDefaultDownloadLocation();
    }

    public DriverInfo(String driverType) {
        _driverType = DriverSetup.DriverType.getEnumByString(driverType);

        try {
            _downloadLocation = getDefaultDownloadLocation();
        } catch (Throwable e) {
            LogInfo.log_Warning("Saw error: " + e.getMessage());
        }
    }

    public static String getDefaultDownloadLocation() {
        HashMap<String, String> seleniumServerUser = new HashMap<>();
        DataFile file = new DataFile("c:\\selenium\\seleniumserveruser.csv");
        if (file.exists()) {
            seleniumServerUser = DataBuilder.readConfigFile(file);
            return "c:\\users\\" + seleniumServerUser.get("userName") + "\\downloads";
        } else {
            String userName = System.getProperty("user.name");
            return "c:\\users\\" + userName;
        }
    }

    public PageLoadStrategy getPageLoadStrategy() {
        return pageLoadStrategy;
    }

    public DriverInfo setPageLoadStrategy(PageLoadStrategy pageLoadStrategy) {
        this.pageLoadStrategy = pageLoadStrategy;
        return this;
    }

    public DriverSetup.DriverType getDriverType() {
        return _driverType;
    }

    public void setDriverType(DriverSetup.DriverType _driverType) {
        this._driverType = _driverType;
    }

    public boolean isHeadlessMode() {
        return headlessMode;
    }

    public void setHeadlessMode(boolean headlessMode) {
        this.headlessMode = headlessMode;
    }

    public String getDownloadLocation() {
        return _downloadLocation;
    }

    public void setDownloadLocation(String _downloadLocation) {
        this._downloadLocation = _downloadLocation;
    }
}
