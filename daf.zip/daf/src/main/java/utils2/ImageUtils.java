package utils2;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class ImageUtils {

    public static BufferedImage getImage(File imageFile) {
        BufferedImage img = null;
        try {
            img = ImageIO.read(imageFile);
        } catch (IOException e) {
            LogInfo.log_AndFail("Encountered error attempting to read image: " + e.getMessage());
        }

        return img;
    }

    public static void verify_ImagesEqual(BufferedImage expectedImage, BufferedImage actualImage) {
        LogInfo.verify_ConditionTrue(imagesEqual(expectedImage, actualImage), "Images were not equivalent.");
    }

    public static boolean imagesEqual(BufferedImage img1, BufferedImage img2) {
        if (img1.getWidth() == img2.getWidth() && img1.getHeight() == img2.getHeight()) {
            for (int x = 0; x < img1.getWidth(); x++) {
                for (int y = 0; y < img1.getHeight(); y++) {
                    if (img1.getRGB(x, y) != img2.getRGB(x, y)) {
                        return false;
                    }
                }
            }
            return true;
        }
        return false;
    }
}
