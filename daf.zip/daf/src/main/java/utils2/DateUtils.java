package utils2;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Date;

public class DateUtils {

    public static Date getDate(String dateString, String format) {
        Date date = null;

        try {
            SimpleDateFormat sdt = new SimpleDateFormat(format);
            date = sdt.parse(dateString);
        } catch (Exception e) {
            LogInfo.log_AndFail("Failed to parse String, error " + e.getMessage());
        }

        return date;
    }

    public static String getTodaysDateAsString(String format) {
        SimpleDateFormat sdt = new SimpleDateFormat(format);
        Date date = new Date();
        return sdt.format(date);
    }

    public static DateTime getDateTime(String dateString, String format) {
        DateTimeFormatter formatter = DateTimeFormat.forPattern(format);
        DateTime dt = formatter.parseDateTime(dateString);
        return dt;
    }

    //Returns Complete day of the week eg: "Sunday"
    public static String getDayOfTheWeekAsString() {

        String format = "EEEE";
        Date now = new Date();
        DateFormat dateFormat = new SimpleDateFormat(format);
        String dayOfTheWeek = dateFormat.format(now);
        return dayOfTheWeek;
    }

    //Database time doesn't have a timezone timestamp by default.  By getting the time offset we can fix that.
    public static DateTime normalizeTimeToLocalTimeZone(DateTime dateTimeToUpdate, int dateTimeOffset) {
        int systemTimeOffset = getSystemOffsetHours();

        int hoursToUpdate = Math.abs(Math.abs(systemTimeOffset) - Math.abs(dateTimeOffset));
        if (systemTimeOffset < dateTimeOffset) {
            dateTimeToUpdate = dateTimeToUpdate.minusHours(hoursToUpdate);
        } else if (systemTimeOffset > dateTimeOffset) {
            dateTimeToUpdate = dateTimeToUpdate.plusHours(hoursToUpdate);
        }
        return dateTimeToUpdate;
    }

    public static int getSystemOffsetHours() {
        int secondsOffSet = ZoneOffset.systemDefault().getRules().getOffset(Instant.now()).getTotalSeconds();
        secondsOffSet = secondsOffSet / 3600;
        return secondsOffSet;
    }

    public static void verify_DateTime_InAcceptableMinuteRange(DateTime expectedDateTime, DateTime actualDateTime, int minutesDifference) {
        DateTime minimumDateTime = expectedDateTime.minusMinutes(minutesDifference);
        DateTime maximumDateTime = expectedDateTime.plusMinutes(minutesDifference);

        boolean timeWithinRange = (minimumDateTime.isBefore(actualDateTime) && maximumDateTime.isAfter(actualDateTime));

        LogInfo.verify_ConditionTrue(timeWithinRange, "Expecting " + expectedDateTime.toString("MM/dd/yyy HH:mm:ss")
                + " to be between " + -minutesDifference + " and " + minutesDifference + ", Seeing " + actualDateTime);
    }

    //This method will convert Date to String.
    public static String returnDateAsString(Date date, String format) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        return dateFormat.format(date);
    }

    public static String returnDateAsString(DateTime date, String format) {
        DateTimeFormatter formatter = DateTimeFormat.forPattern(format);
        String dt = date.toString(formatter);
        return dt;
    }
}
