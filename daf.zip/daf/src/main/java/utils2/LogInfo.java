package utils2;

import common.Verify;
import org.jetbrains.annotations.Contract;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LogInfo {

    private static final Logger LOGGER = LoggerFactory.getLogger(LogInfo.class);

    //I want to restructure this class at some point after I've taken the logging out of the Extent Report Listener 2

    @Contract(value = "_ -> fail")
    public static void log_AndFail(String failureToLog) {
        Verify.fail(failureToLog);
    }

    public static void log_AndPass(String passToLog) {
        // When Logback logs the class+method, it'll be us (log_AndPass). Until we replace these
        // helper methods with direct logger usage, we should log our caller as well.
        LOGGER.debug(getPriorPageObject_AndMethod() + " - " + passToLog);
    }

    public static void log_Status(String textToLog) {
        // When Logback logs the class+method, it'll be us (log_Status). Until we replace these
        // helper methods with direct logger usage, we should log our caller as well.
        LOGGER.info(getPriorPageObject_AndMethod() + " - " + textToLog);
    }

    public static void log_Warning(String warningToLog) {
        // When Logback logs the class+method, it'll be us (log_Warning). Until we replace these
        // helper methods with direct logger usage, we should log our caller as well.
        LOGGER.warn(getPriorPageObject_AndMethod() + " - " + warningToLog);
    }

    public static void verify_ConditionTrue(boolean condition, String conditionText) {
        if (condition) {
            log_AndPass("Condition '" + conditionText + "' was true.");
        } else {
            log_AndFail("Condition '" + conditionText + "' was false.");
        }
    }

    private static boolean shouldSkipStackFrame(String className) {
        return className.contains("utils2") ||
                className.contains("common.Verify");
    }

    private static String getPriorPageObject_AndMethod() {
        String packageToAvoid = "utils2";

        StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
        int indexWeWant = 0;

        for (int i = 0; i < stackTraceElements.length - 1; i++) {

            String className = stackTraceElements[i].getClassName();
            String nextClassName = stackTraceElements[i + 1].getClassName();

            if (shouldSkipStackFrame(className) && !shouldSkipStackFrame(nextClassName)) {
                indexWeWant = i + 1;
                break;
            }
        }

        String pageObjectAndMethod = stackTraceElements[indexWeWant].getFileName().split("\\.")[0] + "."
                + stackTraceElements[indexWeWant].getMethodName();

        return pageObjectAndMethod;
    }
}
