package utils2.page_components;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface AfterClick_HardCodedSleep {
    int milliseconds();

    /**
     * Hard-coded sleeps should always be a last resort. If you need to add one,
     * you need to also add an explanation of why other waits were inadequate.
     * This is a glorified (but required) comment, and doesn't affect any behavior.
     */
    String why();
}
