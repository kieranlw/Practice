package utils2.page_components;

/**
 * Wraps a date-format string. This is meant to be a constructor parameter to
 * components that are aware of date formats; by wrapping the format string in
 * a DateFormatInfo class, instead of just passing a string, we can be sure
 * that the component is specifically expecting a date format for that parameter.
 */
public class DateFormatInfo {
    private final String format;

    public DateFormatInfo(String format) {
        this.format = format;
    }

    public String getFormat() {
        return format;
    }
}
