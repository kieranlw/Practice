package utils2.page_components;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface ComponentFindBy {
    String friendlyName() default "";
    String id() default "";
    String name() default "";
    String className() default "";
    String linkText() default "";
    String partialLinkText() default "";
    String xpath() default "";
}
