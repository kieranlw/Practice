package utils2.page_components;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import utils2.page_components.element_utils.ElementUtils;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.time.Duration;
import java.util.Set;

public class NavigateTo<TTargetPage extends BasePageObject> extends Component {
    private final Class<TTargetPage> _targetPageType;

    public NavigateTo(Class<TTargetPage> targetPageType, WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
        _targetPageType = targetPageType;
    }

    public BaseValidations verify() {
        return new BaseValidations(_elementInfo.getFriendlyName(), findNullableElement());
    }

    public String getAttribute(String attributeToGet) {
        return new ElementUtils(_elementInfo.getFriendlyName(), findElement()).getAttribute(attributeToGet);
    }

    public String getCSSValue(String attributeToGet) {
        return new ElementUtils(_elementInfo.getFriendlyName(), findElement()).getCSSValue(attributeToGet);
    }

    public void click() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).click();
        waitForComponent();
    }

    public void doubleClick() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).doubleClick();
    }

    public void hover() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).hover();
    }

    public TTargetPage clickAndSwitchToWindow() throws Exception {
        try {
            TTargetPage instance = getInstance();
            clickAndSwitchToWindow_DontWait();
            instance.waitForPageToLoad();
            return instance;
        } catch (NoSuchMethodException | IllegalAccessException | InstantiationException | InvocationTargetException e) {
            throw new RuntimeException("Error creating " + _targetPageType.getName() + ": " + e.getMessage());
        }
    }

    public void clickAndSwitchToWindow_DontWait() {
        Set<String> handles = _driver.getWindowHandles();
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).click();
        String newHandle = waitUntil(Duration.ofSeconds(90)).newWindowExists(handles);
        _driver.switchTo().window(newHandle);
    }

    public TTargetPage clickToNavigate() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).click();
        return this.navigateToTTargetPage();
    }

    public TTargetPage doubleClickToNavigate() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).doubleClick();
        return this.navigateToTTargetPage();
    }

    public TTargetPage clickToNavigate_JS() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).click_JS();
        return this.navigateToTTargetPage();
    }

    public TTargetPage enterTextToNavigate(String textToEnter) {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).enterText(textToEnter);
        return this.navigateToTTargetPage();
    }

    public void enableComponentThroughJavaScript() {
        String js = "arguments[0].removeAttribute(\"disabled\");";
        ((JavascriptExecutor) _driver).executeScript(js, findElement());
    }

    private TTargetPage navigateToTTargetPage() {
        try {
            TTargetPage instance = getInstance();
            instance.waitForPageToLoad();
            return instance;
        } catch (InvocationTargetException e) {
            throw new RuntimeException("InvocationTargetException creating " + _targetPageType.getName() + ": " + e.getTargetException().getMessage(), e.getTargetException());
        } catch (Exception e) {
            throw new RuntimeException(e.getClass().getName() + " creating " + _targetPageType.getName() + ": " + e.getMessage(), e);
        }
    }

    protected TTargetPage getInstance() throws Exception {
        try {
            Constructor<TTargetPage> constructor = _targetPageType.getConstructor(WebDriver.class);
            return constructor.newInstance(_driver);
        }catch (NoSuchMethodException e){
            Constructor<TTargetPage> constructor = _targetPageType.getConstructor();
            return constructor.newInstance();
        }
    }

}
