package utils2.page_components;

import org.openqa.selenium.By;
import utils2.LogInfo;

import java.time.Duration;
import java.util.function.BooleanSupplier;

public class ElementInfo {

    private String _friendlyEnglishName;

    private By _elementLocator;

    private BooleanSupplier waitSupplier;
    private Duration durationToWait;
    private Duration durationToSleep;

    private ElementInfo(String friendlyName, By elementLocator, BooleanSupplier waitLogic, Duration timeToWait, Duration timeToSleep) {
        _friendlyEnglishName = friendlyName;
        _elementLocator = elementLocator;
        this.waitSupplier = waitLogic;
        this.durationToWait = timeToWait;
        this.durationToSleep = timeToSleep;
    }

    public static ElementInfo createElementInfo(String friendlyName, By elementLocator) {
        return new ElementInfo(friendlyName, elementLocator, null, Duration.ofSeconds(0), Duration.ofSeconds(0));
    }

    public static ElementInfo createElementInfo_WithSleep(String friendlyName, By elementLocator, Duration sleepForDuration) {
        return new ElementInfo(friendlyName, elementLocator, null, Duration.ofSeconds(0), sleepForDuration);
    }

    public static ElementInfo createElementInfo_WithWaitLogic(String friendlyName, By elementLocator, BooleanSupplier waitLogic, Duration durationToWait, Duration durationToSleep) {
        if (waitLogic != null && !waitLogic.equals("") && (durationToWait == null || durationToWait.toMillis() <= 0)) {
            LogInfo.log_AndFail("Need to specify wait time > 0 using the waitForDurationInMilliseconds field for the WaitFor annotation.");
        }

        return new ElementInfo(friendlyName, elementLocator, waitLogic, durationToWait, durationToSleep);
    }

    public Duration getDurationToSleep() {
        return durationToSleep;
    }

    public String getElementXpath() {
        String elementInfoType = getElementLocator_Type();
        if (elementInfoType.equals("xpath")) {
            return getElementLocator_String();
        } else if (elementInfoType.equals("id")) {
            String id = "//*[@id=\"" + getElementLocator_String() + "\" or @AutomationId=\""
                    + getElementLocator_String() + "\"]";
            return "//*[@id=\"" + getElementLocator_String() + "\" or @AutomationId=\""
                    + getElementLocator_String() + "\"]";
        } else if (elementInfoType.equals("name")) {
            return "//*[@Name=\"" + getElementLocator_String() + "\" or @name=\"" + getElementLocator_String() + "\"]";
        } else {
            LogInfo.log_AndFail("Unrecognized element locator for conversion. Update this method.");
            return null;
        }
    }

    public Duration getDurationToWait() {
        return durationToWait;
    }

    public BooleanSupplier getWaitSupplier() {
        return waitSupplier;
    }

    public String getFriendlyName() {
        return _friendlyEnglishName;
    }

    public By getElementLocator() {
        return _elementLocator;
    }

    public String getElementLocator_Type() {
        return _elementLocator.toString().split(":\\s", 2)[0].split("\\.")[1];
    }

    public String getElementLocator_String() {
        return _elementLocator.toString().split(":\\s", 2)[1];
    }
}
