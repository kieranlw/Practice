package utils2.page_components;

import org.openqa.selenium.WebElement;
import utils.BaseUI;
import utils2.LogInfo;

public class CheckboxValidations  {

    protected boolean _controlExists = false;
    protected WebElement _elementToValidate;
    protected String _friendlyName;
    private BaseValidations _baseValidations;

    //Using this method internally to avoid unnecessary logging unless we call for it.
    protected void elementExists() {
        if (!_controlExists) {
            LogInfo.log_AndFail("Unable to find element '"+_friendlyName+ "'!");
        }
    }

    public CheckboxValidations exists() {
        BaseUI.verify_true_AndLog(_controlExists, "Element was found.", "Element was NOT found.");
        return this;
    }

    public CheckboxValidations doesNotExist() {
        LogInfo.verify_ConditionTrue(!_controlExists, "Element '" + _friendlyName + "' does not exist.");
        return this;
    }

    public CheckboxValidations notDisplayed() {
        _baseValidations.notDisplayed();
        return this;
    }

    public CheckboxValidations displayed() {
        _baseValidations.displayed();
        return this;
    }

    public CheckboxValidations disabled() {
        _baseValidations.disabled();
        return this;
    }

    public CheckboxValidations enabled() {
        _baseValidations.enabled();
        return this;
    }

    public CheckboxValidations(String friendlyName, WebElement element) {
        if (element != null) {
            _controlExists = true;
        }
        _elementToValidate = element;
        _friendlyName = friendlyName;
        _baseValidations = new BaseValidations(friendlyName, element);
    }

    protected boolean isChecked() {
        return _elementToValidate.isSelected();
    }

    public CheckboxValidations checked() {
        elementExists();

        if (isChecked()) {
            LogInfo.log_AndPass("Element " + _friendlyName + " was checked.");
        } else {
            LogInfo.log_AndFail("Element " + _friendlyName + " was NOT checked.");
        }
        return this;
    }

    // Using for Data driven tests.  Useful if we just want to switch back and forth to make sure it updates.
    public CheckboxValidations checkedOrUnchecked(boolean shouldBeChecked) {
        elementExists();

        if (isChecked() && shouldBeChecked) {
            LogInfo.log_AndPass("Element " + _friendlyName + " was checked.");
        } else if (isChecked() && !shouldBeChecked) {
            LogInfo.log_AndFail("Element " + _friendlyName + " was NOT checked.");
        } else if(!isChecked() &&!shouldBeChecked){
            LogInfo.log_AndPass("Element " + _friendlyName + " was unchecked.");
        }else{
            LogInfo.log_AndFail("Element " + _friendlyName + " was checked.");
        }

        return this;
    }




    public CheckboxValidations unchecked() {
        elementExists();

        if (!isChecked()) {
            LogInfo.log_AndPass("Element " + _friendlyName + " was NOT checked.");
        } else {
            LogInfo.log_AndFail("Element " + _friendlyName + " was checked.");
        }
        return this;
    }


}
