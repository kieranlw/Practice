package utils2.page_components;

import org.openqa.selenium.WebDriver;

public abstract class BasePageObject {

    public abstract void waitForPageToLoad() throws Exception;

    @FunctionalInterface
    public interface PageConstructor<T, R> {
        public R construct(T value) throws Exception;
    }

    /**
     * Creates a page object and calls its waitForPageToLoad method.
     *
     * @param pageConstructor Constructor for the page object, e.g. <code>SomePageObject::new</code>.
     * @param driver          The WebDriver instance
     * @param <P>             Type of the new page
     * @param <D>             Type of the driver
     * @return The new page
     */
    public static <P extends BasePageObject, D extends WebDriver> P createAndLoad(PageConstructor<D, P> pageConstructor, D driver) {
        P page;

        try {
            page = pageConstructor.construct(driver);
        } catch (Exception ex) {
            throw new RuntimeException("Error creating page: " + ex.getMessage(), ex);
        }

        try {
            page.waitForPageToLoad();
        } catch (Exception ex) {
            throw new RuntimeException("Error creating " + page.getClass().getName() + ": " + ex.getMessage(), ex);
        }

        return page;
    }

    public static <P extends BasePageObject> P createAndLoad(PageConstructor2<P> pageConstructor) {
        P page;
        try {
            page = pageConstructor.construct();
        } catch (Exception ex) {
            throw new RuntimeException("Error creating page: " + ex.getMessage(), ex);
        }
        try {
            page.waitForPageToLoad();
        } catch (Exception ex) {
            throw new RuntimeException("Error creating " + page.getClass().getName() + ": " + ex.getMessage(), ex);
        }
        return page;
    }

    @FunctionalInterface
    public interface PageConstructor2<T> {
        public T construct() throws Exception;
    }
}
