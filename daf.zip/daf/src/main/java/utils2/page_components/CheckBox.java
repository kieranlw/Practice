package utils2.page_components;

import org.openqa.selenium.WebDriver;
import utils2.page_components.element_utils.ElementUtils;

public class CheckBox extends Component {

    public CheckBox(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
    }

    public CheckboxValidations verify() {
        return new CheckboxValidations(_elementInfo.getFriendlyName(), findNullableElement());
    }

    public boolean isChecked() {
        return new ElementUtils(_elementInfo.getFriendlyName(), findElement()).isChecked();
    }

    public void check() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).check();
    }

    public void check_JS() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).check_JS();
    }
    public void uncheck() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).uncheck();
    }

    public void toggle(Boolean turnOn) {
        if(turnOn == null) {
            return;
        }

        if (turnOn) {
            check();
        } else {
            uncheck();
        }
    }
}
