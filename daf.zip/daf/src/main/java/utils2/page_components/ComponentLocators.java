package utils2.page_components;

public interface ComponentLocators {
    String friendlyName();
    String id();
    String name();
    String className();
    String linkText();
    String partialLinkText();
    String xpath();
}
