package utils2.page_components;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface AfterClick_Wait {
    /**
     * The name of a method on the page/parent class. This method should have
     * a boolean return type, and should return true if the wait condition
     * is completed, false otherwise.
     */
    String waitMethodName();

    int timeoutInMilliseconds() default 5000;
}
