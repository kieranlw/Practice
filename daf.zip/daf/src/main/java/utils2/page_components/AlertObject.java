package utils2.page_components;

import common.ThreadUtils;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import utils.BaseUI;
import utils2.WebDriverUtils;

public class AlertObject extends BasePageObject {

    private WebDriver _driver;

    private org.openqa.selenium.Alert _alert;

    public org.openqa.selenium.Alert getAlert() {
        return _alert;
    }

    public String getAlertText() {
        return _alert.getText();
    }

    public boolean isAlertPresent_AndAccept() {
        try {
            //TODO seeing weird issues around trying to accept separately, will need to dink around with this at some point.
            _driver.switchTo().alert().accept();
            return true;
        } catch (NoAlertPresentException Ex) {
            return false;
        }
    }

    public void accept() throws Exception {
        _alert.accept();
        ThreadUtils.sleep(300);
    }

    public void verifyText(String expectedText) {
        BaseUI.baseStringCompare("Alert Text", expectedText, getAlertText());
    }

    @Override
    public void waitForPageToLoad() throws Exception {
        _alert = new WebDriverUtils(_driver).waitForAlert();
    }

    public AlertObject(WebDriver driver) {
        _driver = driver;
    }
}
