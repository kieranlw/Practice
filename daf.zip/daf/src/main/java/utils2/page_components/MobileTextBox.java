package utils2.page_components;

import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.WebDriver;
import utils2.AppiumUtils;
import utils2.page_components.element_utils.ElementUtils;

public class MobileTextBox extends TextBox {

    public MobileTextBox(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
    }

    @Override
    public MobileTextBox enterText(String valueToSet) {

        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).enterText(valueToSet);
        AppiumUtils _appiumUtils = new AppiumUtils((AppiumDriver<?>) _driver);
        if ((_appiumUtils).isAndroid()) {
            _appiumUtils.dismissKeyboard();
        }

        return this;
    }
}
