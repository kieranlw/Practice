package utils2.page_components;

import org.openqa.selenium.WebDriver;
import utils2.page_components.element_utils.ElementUtils;

public class Label extends Component {

    public Label(WebDriver driver, ElementInfo elementInfo){
       super(driver, elementInfo);
    }

    public BaseValidations verify(){
        return new BaseValidations(_elementInfo.getFriendlyName(), findNullableElement());
    }

    public String getText() {
        String textToReturn = new ElementUtils(_elementInfo.getFriendlyName(), findElement()).getText();
        return textToReturn;
    }

    public void injectTextNode(String textToInject) {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).injectTextNode(textToInject);
    }

    public String getAttribute(String attributeToGet) {
        String textToReturn = new ElementUtils(_elementInfo.getFriendlyName(), findElement()).getAttribute(attributeToGet);
        return textToReturn;
    }

    public String getCSSValue(String attributeToGet) {
        String textToReturn = new ElementUtils(_elementInfo.getFriendlyName(), findElement()).getCSSValue(attributeToGet);
        return textToReturn;
    }
}
