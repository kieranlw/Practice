package utils2.page_components;

public class TableInfo {
    private String[] headers;
    private String tableCellsXpath;
    private String headerCellsXpath;
    private ElementInfo elementInfo;
    private String firstCellXpath;

    protected TableInfo(ElementInfo elementInfo, String[] headers, String headerCellsXpath, String tableCellsXpath, String firstCellXpath) {
        this.elementInfo = elementInfo;
        this.headers = headers;
        this.headerCellsXpath = headerCellsXpath;
        this.tableCellsXpath = tableCellsXpath;
        this.firstCellXpath = firstCellXpath;
    }

    public static TableInfo createTableInfo(ElementInfo elementInfo, String[] headers, String headerCellsXpath, String tableCellsXpath, String firstCellXpath) {
        return new TableInfo(elementInfo, headers, headerCellsXpath, tableCellsXpath, firstCellXpath);
    }

    public static TableInfo createTableInfo(ElementInfo elementInfo, String[] headers, String headerCellsXpath, String tableCellsXpath) {
        return new TableInfo(elementInfo, headers, headerCellsXpath, tableCellsXpath, "({0}//tbody//td)[1]");
    }

    public ElementInfo getElementInfo() {
        return elementInfo;
    }

    public String[] getHeaders() {
        return headers;
    }

    public String getFirstCellXpath() {
        return firstCellXpath.replace("{0}", elementInfo.getElementXpath());
    }

    public String getTableCellsXpath() {
        return tableCellsXpath.replace("{0}", elementInfo.getElementXpath());
    }

    public String getHeaderCellsXpath() {
        return headerCellsXpath.replace("{0}", elementInfo.getElementXpath());
    }
}
