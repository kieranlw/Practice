package utils2.page_components.unit_tests;

import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

public class PageWithMultipleComponentConstructors extends BasePageObject {
    @ComponentFindBy(id = "vanilla")
    public TestComponent testComponent;

    @ComponentFindBy(id = "withTableInfo")
    @Tableizer(headerCellsXpath = "xpathWithTableInfo")
    public TestComponentWithTableInfo testComponentWithTableInfo;

    @ComponentFindBy(id = "withDateFormat")
    @DateFormat(value = "yyyy-MM-dd")
    public TestComponentWithDateFormat testComponentWithDateFormat;

    @ComponentFindBy(id = "withGeneric")
    public TestGenerifiedComponent<String> testGenerifiedComponent;

    @ComponentFindBy(id = "withGenericAndTableInfo")
    @Tableizer(headerCellsXpath = "xpathWithGenericAndTableInfo")
    public TestGenerifiedComponentWithTableInfo<String> testGenerifiedComponentWithTableInfo;

    public PageWithMultipleComponentConstructors(WebDriver driver) {
        ComponentFactory.initElements(driver, this);
    }

    @Override
    public void waitForPageToLoad() throws Exception {
    }

    public static class TestComponent extends Component {
        protected TestComponent(WebDriver driver, ElementInfo elementInfo) {
            super(driver, elementInfo);
        }

        public WebDriver getDriver() {
            return _driver;
        }
    }

    public static class TestComponentWithTableInfo extends TestComponent {
        private final TableInfo tableInfo;

        protected TestComponentWithTableInfo(WebDriver driver, TableInfo tableInfo) {
            super(driver, tableInfo.getElementInfo());
            this.tableInfo = tableInfo;
        }

        public TableInfo getTableInfo() {
            return tableInfo;
        }
    }

    public static class TestComponentWithDateFormat extends TestComponent {
        private final DateFormatInfo dateFormatInfo;

        public TestComponentWithDateFormat(WebDriver driver, ElementInfo elementInfo, DateFormatInfo dateFormatInfo) {
            super(driver, elementInfo);
            this.dateFormatInfo = dateFormatInfo;
        }

        public DateFormatInfo getDateFormatInfo() {
            return dateFormatInfo;
        }
    }

    public static class TestGenerifiedComponent<T> extends TestComponent {
        private final Class<T> classParameter;

        protected TestGenerifiedComponent(Class<T> classParameter, WebDriver driver, ElementInfo elementInfo) {
            super(driver, elementInfo);
            this.classParameter = classParameter;
        }

        public Class<T> getClassParameter() {
            return classParameter;
        }
    }

    public static class TestGenerifiedComponentWithTableInfo<T> extends TestGenerifiedComponent<T> {
        private final TableInfo tableInfo;

        protected TestGenerifiedComponentWithTableInfo(Class<T> classParameter, WebDriver driver, TableInfo tableInfo) {
            super(classParameter, driver, tableInfo.getElementInfo());
            this.tableInfo = tableInfo;
        }

        public TableInfo getTableInfo() {
            return tableInfo;
        }
    }
}
