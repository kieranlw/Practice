package utils2.page_components.unit_tests;

import org.openqa.selenium.WebDriver;

import utils2.page_components.*;

import java.time.Duration;

public class PageWithWaits extends BasePageObject {
    private static final int EXPLICIT_TIMEOUT_MS = 1500;
    public static final Duration EXPLICIT_TIMEOUT = Duration.ofMillis(EXPLICIT_TIMEOUT_MS);

    private static final int HARD_CODED_SLEEP_MS = 1500;
    public static final Duration HARD_CODED_SLEEP = Duration.ofMillis(HARD_CODED_SLEEP_MS);

    @ComponentFindBy(id = "noWait")
    public TestComponent withNoWait;

    @ComponentFindBy(id = "withWait")
    @AfterClick_Wait(waitMethodName = "afterClick")
    public TestComponent withWaitAndDefaultTimeout;

    @ComponentFindBy(id = "withWait")
    @AfterClick_Wait(waitMethodName = "afterClick", timeoutInMilliseconds = EXPLICIT_TIMEOUT_MS)
    public TestComponent withWaitAndExplicitTimeout;

    @ComponentFindBy(id = "withSleep")
    @AfterClick_HardCodedSleep(milliseconds = HARD_CODED_SLEEP_MS, why = "Used by unit tests")
    public TestComponent withHardCodedSleep;

    @ComponentFindBy(id = "withWaitAndSleep")
    @AfterClick_Wait(waitMethodName = "afterClick")
    @AfterClick_HardCodedSleep(milliseconds = HARD_CODED_SLEEP_MS, why = "Used by unit tests")
    public TestComponent withWaitAndSleep;

    @ComponentFindBy(id = "withWaitTimeoutAndSleep")
    @AfterClick_Wait(waitMethodName = "afterClick", timeoutInMilliseconds = EXPLICIT_TIMEOUT_MS)
    @AfterClick_HardCodedSleep(milliseconds = HARD_CODED_SLEEP_MS, why = "Used by unit tests")
    public TestComponent withWaitAndTimeoutAndSleep;

    public PageWithWaits(WebDriver driver) {
        ComponentFactory.initElements(driver, this);
    }

    @WaitMethod
    private boolean afterClick() {
        return true;
    }

    @Override
    public void waitForPageToLoad() throws Exception {
    }

    public static class TestComponent extends Component {
        protected TestComponent(WebDriver driver, ElementInfo elementInfo) {
            super(driver, elementInfo);
        }
    }
}
