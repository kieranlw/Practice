package utils2.page_components.unit_tests;

import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

public class SampleAndroidComponent extends Component implements SampleMobileComponent {
    public SampleAndroidComponent(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
    }
}
