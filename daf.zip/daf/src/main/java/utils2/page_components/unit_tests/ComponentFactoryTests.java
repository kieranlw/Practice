package utils2.page_components.unit_tests;

import common.Is;
import common.Verify;
import org.mockito.Mockito;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class ComponentFactoryTests {
    private Map<String, Object> capabilitiesMap;
    private RemoteWebDriver driver;
    private WebElement element;

    @BeforeMethod
    public void beforeMethod() {
        // The factory checks capabilities.asMap to see whether we're Android or not
        capabilitiesMap = new HashMap<>();

        driver = MockWebDriver.create(capabilitiesMap);
        element = Mockito.mock(WebElement.class);
    }

    @Test
    public void singleComponent() {
        Mockito.when(driver.findElement(By.id("id1"))).thenReturn(element);
        PageWithGenericComponent page = new PageWithGenericComponent(driver);
        Verify.that(page.component.findElement(), Is.sameInstanceAs(element));
    }

    @Test
    public void navigationComponent_GetsCorrectTargetPageType() {
        Mockito.when(driver.findElement(By.id("link"))).thenReturn(element);
        PageWithNavigationComponent page = new PageWithNavigationComponent(driver);
        PageWithGenericComponent navigationTarget = page.link.clickToNavigate();
        Verify.that(navigationTarget.getClass(), Is.equalTo(PageWithGenericComponent.class));
    }

    @Test
    public void mobilePlatformSelector_Ios() {
        PageWithMobileComponent page = new PageWithMobileComponent(driver);
        Verify.that(page.component.getClass(), Is.equalTo(SampleIosComponent.class));
    }

    @Test
    public void mobilePlatformSelector_Android() {
        capabilitiesMap.put("BROWSER_NAME", "Android");
        PageWithMobileComponent page = new PageWithMobileComponent(driver);
        Verify.that(page.component.getClass(), Is.equalTo(SampleAndroidComponent.class));
    }
}
