package utils2.page_components.unit_tests;

import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

public class PageWithMobileComponent extends BasePageObject {
    @ComponentFindBy(id = "mobile1")
    public SampleMobileComponent component;

    public PageWithMobileComponent(WebDriver driver) {
        ComponentFactory.initElements(driver, this);
    }

    @Override
    public void waitForPageToLoad() throws Exception {
    }
}
