package utils2.page_components.unit_tests;

import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

public class PageWithNavigationComponent extends BasePageObject {
    @ComponentFindBy(id = "link")
    public NavigateTo<PageWithGenericComponent> link;

    public PageWithNavigationComponent(WebDriver driver) {
        ComponentFactory.initElements(driver, this);
    }

    @Override
    public void waitForPageToLoad() throws Exception {
    }
}
