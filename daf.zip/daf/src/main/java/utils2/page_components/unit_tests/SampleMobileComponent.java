package utils2.page_components.unit_tests;

import utils2.page_components.*;

@MobilePlatformSelector(android = SampleAndroidComponent.class, ios = SampleIosComponent.class)
public interface SampleMobileComponent {
}
