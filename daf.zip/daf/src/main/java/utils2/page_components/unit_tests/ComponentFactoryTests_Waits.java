package utils2.page_components.unit_tests;

import common.Is;
import common.Verify;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.function.Function;

public class ComponentFactoryTests_Waits {
    private static boolean HAS_WAIT_METHOD = true;
    private static boolean NO_WAIT_METHOD = false;

    private static final Duration DEFAULT_TIMEOUT = Duration.ofSeconds(5);
    private static final Duration EXPLICIT_TIMEOUT = PageWithWaits.EXPLICIT_TIMEOUT;
    private static final Duration NO_TIMEOUT = Duration.ZERO;

    private static final Duration NO_SLEEP = Duration.ZERO;
    private static final Duration HARD_CODED_SLEEP = PageWithWaits.HARD_CODED_SLEEP;

    private <T extends PageWithWaits.TestComponent>
    void verifyComponent(Function<PageWithWaits, T> getComponent,
                         boolean expectWaitMethodToExist, Duration expectedWaitTimeout,
                         Duration expectedHardCodedSleep) {
        final RemoteWebDriver driver = MockWebDriver.create();
        final PageWithWaits page = new PageWithWaits(driver);
        final T component = getComponent.apply(page);

        Verify.that(component, Is.notEqualTo(null));
        Verify.allOf(() -> {
            Verify.that(component.getElementInfo().getWaitSupplier() != null, Is.equalTo(expectWaitMethodToExist), "Does wait method exist?");
            Verify.that(component.getElementInfo().getDurationToWait(), Is.equalTo(expectedWaitTimeout), "Wait timeout");
            Verify.that(component.getElementInfo().getDurationToSleep(), Is.equalTo(expectedHardCodedSleep), "Hard-coded sleep");
        });
    }

    @Test
    public void withNoWait() {
        verifyComponent(page -> page.withNoWait,
                NO_WAIT_METHOD, NO_TIMEOUT, NO_SLEEP);
    }

    @Test
    public void withWaitAndDefaultTimeout() {
        verifyComponent(page -> page.withWaitAndDefaultTimeout,
                HAS_WAIT_METHOD, DEFAULT_TIMEOUT, NO_SLEEP);
    }

    @Test
    public void withWaitAndExplicitTimeout() {
        verifyComponent(page -> page.withWaitAndExplicitTimeout,
                HAS_WAIT_METHOD, EXPLICIT_TIMEOUT, NO_SLEEP);
    }

    @Test
    public void withHardCodedSleep() {
        verifyComponent(page -> page.withHardCodedSleep,
                NO_WAIT_METHOD, NO_TIMEOUT, HARD_CODED_SLEEP);
    }

    @Test
    public void withWaitAndSleep() {
        verifyComponent(page -> page.withWaitAndSleep,
                HAS_WAIT_METHOD, DEFAULT_TIMEOUT, HARD_CODED_SLEEP);
    }

    @Test
    public void withWaitAndTimeoutAndSleep() {
        verifyComponent(page -> page.withWaitAndTimeoutAndSleep,
                HAS_WAIT_METHOD, EXPLICIT_TIMEOUT, HARD_CODED_SLEEP);
    }
}
