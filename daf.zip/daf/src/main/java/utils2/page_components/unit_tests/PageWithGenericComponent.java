package utils2.page_components.unit_tests;

import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

public class PageWithGenericComponent extends BasePageObject {
    @ComponentFindBy(id = "id1")
    public GenericComponent component;

    public PageWithGenericComponent(WebDriver driver) {
        ComponentFactory.initElements(driver, this);
    }

    @Override
    public void waitForPageToLoad() throws Exception {
    }
}
