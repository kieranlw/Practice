package utils2.page_components.unit_tests;

import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

public class SampleIosComponent extends Component implements SampleMobileComponent {
    public SampleIosComponent(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
    }
}
