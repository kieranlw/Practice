package utils2.page_components.unit_tests;

import org.mockito.Mockito;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.HashMap;
import java.util.Map;

public final class MockWebDriver {
    private MockWebDriver() {
    }

    public static RemoteWebDriver create() {
        return create(new HashMap<>());
    }

    public static RemoteWebDriver create(Map<String, Object> capabilitiesMap) {
        Capabilities capabilities = Mockito.mock(Capabilities.class);
        Mockito.when(capabilities.asMap()).thenReturn(capabilitiesMap);

        RemoteWebDriver driver = Mockito.mock(RemoteWebDriver.class);
        Mockito.when(driver.getCapabilities()).thenReturn(capabilities);

        return driver;
    }
}
