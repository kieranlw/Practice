package utils2.page_components.unit_tests;

import common.Is;
import common.Verify;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import java.util.function.Consumer;
import java.util.function.Function;

@SuppressWarnings("CodeBlock2Expr")
public class ComponentFactoryTests_ComponentConstructorArguments {
    private String getId(PageWithMultipleComponentConstructors.TestComponent component) {
        final String locatorString = component.getElementInfo().getElementLocator().toString();
        // locatorString will be something like "By.id: Id1"
        return locatorString.split(":")[1].trim();
    }

    private <T extends PageWithMultipleComponentConstructors.TestComponent>
    void verifyComponent(Function<PageWithMultipleComponentConstructors, T> getComponent,
                         String expectedId, Consumer<T> alsoVerify) {
        final RemoteWebDriver driver = MockWebDriver.create();
        final PageWithMultipleComponentConstructors page = new PageWithMultipleComponentConstructors(driver);
        final T component = getComponent.apply(page);

        Verify.allOf(() -> {
            Verify.that(component.getDriver(), Is.sameInstanceAs(driver));
            Verify.that(getId(component), Is.equalTo(expectedId));
            alsoVerify.accept(component);
        });
    }

    @Test
    public void simpleComponent() {
        verifyComponent(page -> page.testComponent, "vanilla", component -> {});
    }

    @Test
    public void componentWithTableInfo() {
        verifyComponent(page -> page.testComponentWithTableInfo, "withTableInfo", component -> {
            Verify.that(component.getTableInfo().getHeaderCellsXpath(), Is.equalTo("xpathWithTableInfo"));
        });
    }

    @Test
    public void componentWithDateFormat() {
        verifyComponent(page -> page.testComponentWithDateFormat, "withDateFormat", component -> {
            Verify.that(component.getDateFormatInfo().getFormat(), Is.equalTo("yyyy-MM-dd"));
        });
    }

    @Test
    public void generifiedComponent() {
        verifyComponent(page -> page.testGenerifiedComponent, "withGeneric", component -> {
            Verify.that(component.getClassParameter(), Is.equalTo(String.class));
        });
    }

    @Test
    public void generifiedComponentWithTableInfo() {
        verifyComponent(page -> page.testGenerifiedComponentWithTableInfo, "withGenericAndTableInfo", component -> {
            Verify.that(component.getClassParameter(), Is.equalTo(String.class));
            Verify.that(component.getTableInfo().getHeaderCellsXpath(), Is.equalTo("xpathWithGenericAndTableInfo"));
        });
    }
}
