package utils2.page_components;

import common.Is;
import common.Verify;
import org.hamcrest.Matcher;
import org.openqa.selenium.WebElement;
import utils2.LogInfo;
import utils2.page_components.element_utils.ElementUtils;

@SuppressWarnings("UnusedReturnValue")
public class BaseValidations {

    private final boolean _controlExists;
    private final WebElement _elementToValidate;
    private final String _friendlyName;

    public BaseValidations(String friendlyName, WebElement element) {
        _controlExists = element != null;
        _elementToValidate = element;
        _friendlyName = friendlyName;
    }

    public BaseValidations text(Matcher<? super String> condition) {
        elementExists();

        String elementText = new ElementUtils(_friendlyName, _elementToValidate).getText();
        Verify.that(elementText, condition, "Element '" + _friendlyName + "' text");

        return this;
    }

    public BaseValidations attribute(String attributeName, Matcher<? super String> condition) {
        elementExists();

        String attributeValue = _elementToValidate.getAttribute(attributeName);
        Verify.that(attributeValue, condition, "Element '" + _friendlyName + "' attribute '" + attributeName + "'");

        return this;
    }

    public BaseValidations cssStyle(String property, Matcher<? super String> condition) {
        elementExists();

        String propertyValue = _elementToValidate.getCssValue(property);
        Verify.that(propertyValue, condition, "Element '" + _friendlyName + "' CSS style '" + property + "'");

        return this;
    }

    //Using this method internally to avoid unnecessary logging unless we call for it.
    protected void elementExists() {
        if (!_controlExists) {
            LogInfo.log_AndFail("Unable to find element '" + _friendlyName + "'!");
        }
    }

    //Syntactic Sugar
    public BaseValidations and() {
        return this;
    }

    public BaseValidations exists() {
        LogInfo.verify_ConditionTrue(_controlExists, "Element '" + _friendlyName + "' was found.");
        return this;
    }

    public BaseValidations doesNotExist() {
        LogInfo.verify_ConditionTrue(!_controlExists, "Element '" + _friendlyName + "' does not exist.");
        return this;
    }

    public BaseValidations notDisplayed() {
        if (!_controlExists) {
            LogInfo.log_AndPass("Element " + _friendlyName + " was NOT found and therefore was NOT displayed.");
        } else if (!(new ElementUtils(_friendlyName, _elementToValidate).isDisplayed())) {
            LogInfo.log_AndPass("Element " + _friendlyName + " was NOT displayed.");
        } else {
            LogInfo.log_AndFail("Element " + _friendlyName + " was displayed.");
        }

        return this;
    }

    public BaseValidations displayed() {
        elementExists();

        if (new ElementUtils(_friendlyName, _elementToValidate).isDisplayed()) {
            LogInfo.log_AndPass("Element " + _friendlyName + " was displayed.");
        } else {
            LogInfo.log_AndFail("Element " + _friendlyName + " was NOT displayed.");
        }

        return this;
    }

    public BaseValidations disabled() {
        elementExists();

        if (!new ElementUtils(_friendlyName, _elementToValidate).isEnabled()) {
            LogInfo.log_AndPass("Element " + _friendlyName + " was NOT enabled.");
        } else {
            LogInfo.log_AndFail("Element " + _friendlyName + " was enabled.");
        }

        return this;
    }

    public BaseValidations enabled() {
        elementExists();

        if (new ElementUtils(_friendlyName, _elementToValidate).isEnabled()) {
            LogInfo.log_AndPass("Element " + _friendlyName + " was enabled.");
        } else {
            LogInfo.log_AndFail("Element " + _friendlyName + " was NOT enabled.");
        }

        return this;
    }

    public BaseValidations textEquals(String expectedText) {
        return text(Is.equalTo(expectedText));
    }

    public BaseValidations textNotEquals(String expectedText) {
        return text(Is.notEqualTo(expectedText));
    }

    public BaseValidations textContains(String expectedText) {
        return text(Is.stringContaining(expectedText));
    }

    public BaseValidations textEndsWith(String expectedText) {
        return text(Is.stringEndsWithIgnoreCase(expectedText));
    }

    public BaseValidations textDoesNOTContain(String expectedText) {
        return text(Is.stringNotContaining(expectedText));
    }

    public BaseValidations attributeEquals(String attribute, String expectedAttribute) {
        return attribute(attribute, Is.equalTo(expectedAttribute));
    }
    public BaseValidations attributeDoesNotEqual(String attribute, String expectedAttribute) {
        return attribute(attribute, Is.notEqualTo(expectedAttribute));
    }

    public BaseValidations attributeContains(String attribute, String expectedAttribute) {
        return attribute(attribute, Is.stringContaining(expectedAttribute));
    }

    public BaseValidations attributeNotContains(String attribute, String expectedAttribute) {
        return attribute(attribute, Is.stringNotContaining(expectedAttribute));
    }

    public BaseValidations attributeDoesExist(String attribute) {
        return attribute(attribute, Is.notNullOrEmptyString());
    }

    public BaseValidations attributeDoesNOTExist(String attribute) {
        return attribute(attribute, Is.equalTo(null));
    }

    public BaseValidations attributeDoesNotHaveValue(String attribute) {
        return attribute(attribute, Is.nullOrEmptyString());
    }
    public BaseValidations attributeHasValue(String attribute, String value) {
        return attribute(attribute, Is.equalTo(value));
    }

    public BaseValidations cssEquals(String cssAttribute, String expectedAttribute) {
        return cssStyle(cssAttribute, Is.equalTo(expectedAttribute));
    }

    public BaseValidations cssContains(String cssAttribute, String expectedAttribute) {
        return cssStyle(cssAttribute, Is.stringContaining(expectedAttribute));
    }

    public BaseValidations textLengthEquals(int expectedLength) {
        return text(Is.stringWhoseLength(Is.equalTo(expectedLength)));
    }
}
