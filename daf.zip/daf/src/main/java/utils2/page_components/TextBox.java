package utils2.page_components;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import utils2.page_components.element_utils.ElementUtils;

public class TextBox extends GenericComponent {

    public TextBox(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
    }

    //some textboxes require different clearing logic
    protected TextBox clearText(WebElement textBox) {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).clearText();
        return this;
    }

    public TextBox deleteAllText() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).deleteAllText();
        return this;
    }

    public TextBox removeAttribute(String attribute) {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).removeAttribute(attribute);
        return this;
    }

    public TextBox enterText(String valueToSet) {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).enterText(valueToSet);
        return this;
    }

    public TextBox enterKey(Keys valueToSet) {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).enterKey(valueToSet);
        return this;
    }

    public TextBox enterText_JS(String valueToSet) {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).enterText_JS(valueToSet);
        return this;
    }
}
