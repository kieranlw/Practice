package utils2.page_components;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Quotes;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils2.DriverUtils;
import utils2.LogInfo;
import utils2.page_components.element_utils.ElementFinder;

import java.lang.reflect.InvocationTargetException;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.Function;

public class WaitUtils {

    private ElementInfo _elementInfo;

    private WebDriver _driver;

    private Duration _timeToWait;

    private ElementFinder _elementFinder;

    private DriverUtils driverUtils;

    public WaitUtils(WebDriver driver, ElementInfo elementInfo, Duration timeToWait) {
        _elementInfo = elementInfo;
        _driver = driver;
        _timeToWait = timeToWait;
        _elementFinder = new ElementFinder(_driver, _elementInfo);
        driverUtils = new DriverUtils(driver);
    }

    public void secondaryElementExists(By secondaryLocator) {
        try {
            WebDriverWait wait = new WebDriverWait(_driver, _timeToWait.getSeconds());
            wait.ignoring(NullPointerException.class).ignoring(StaleElementReferenceException.class)
                    .ignoring(NoSuchElementException.class)
                    .until(driver -> !driver.findElement(_elementInfo.getElementLocator())
                            .findElement(secondaryLocator).getAttribute("outerHTML").equals(""));
        } catch (TimeoutException e) {
            LogInfo.log_AndFail("Waited for secondary element with locator of "
                    + Quotes.escape(secondaryLocator.toString()) + " and encountered error " + e.getMessage());
        }
    }

    //You will need to do something to determine page is in a state where it is loading before calling this.
    //If the next page has not started loading prior to calling this method, the script will look at prior page and think it's done intermittently.
    public void readyStateComplete() {
        driverUtils.waitForReadyStateComplete(_timeToWait);
    }

    public void isSelected() {
        LogInfo.log_Status("Waiting for element " + _elementInfo.getFriendlyName() + " to be selected");
        try {
            WebDriverWait wait = new WebDriverWait(_driver, _timeToWait.getSeconds());
            wait.ignoring(StaleElementReferenceException.class)
                    .until(driver -> _elementFinder.findElement().isSelected());
        } catch (Throwable e) {
            LogInfo.log_AndFail(
                    MessageFormat.format("Waited for element ''{0}'' to be selected and encountered error: {1}", _elementInfo.getFriendlyName(), e.toString()));
        }
    }

    public void notSelected() {
        LogInfo.log_Status("Waiting for element " + _elementInfo.getFriendlyName() + " to be selected");
        try {
            WebDriverWait wait = new WebDriverWait(_driver, _timeToWait.getSeconds());
            wait.ignoring(StaleElementReferenceException.class)
                    .until(driver -> !_elementFinder.findElement().isSelected());
        } catch (Throwable e) {
            LogInfo.log_AndFail(
                    MessageFormat.format("Waited for element ''{0}'' to be selected and encountered error: {1}", _elementInfo.getFriendlyName(), e.toString()));
        }
    }

    public void displayed() {
        displayed(true);
    }

    public boolean displayed(boolean failOnNotFound) {
        LogInfo.log_Status("Waiting for element " + _elementInfo.getFriendlyName() + " to be displayed.");
        boolean status = false;

        try {
            WebDriverWait wait = new WebDriverWait(_driver, _timeToWait.getSeconds());
            status = wait.ignoring(StaleElementReferenceException.class)
                    .until(driver -> _elementFinder.findElement().isDisplayed());
        } catch (Throwable e) {
            if (failOnNotFound) {
                LogInfo.log_AndFail(
                        MessageFormat.format("Waited for element ''{0}'' to be displayed using identifier ''{1}'' and encountered error: {2}", _elementInfo.getFriendlyName(),
                                _elementInfo.getElementLocator(), e.toString()));
            } else {
                LogInfo.log_Warning("Element " + _elementInfo.getFriendlyName() + " was not found in the given timeframe.");
            }
        }
        return status;
    }

    public void exists() {
        LogInfo.log_Status("Waiting for element " + _elementInfo.getFriendlyName() + " to be displayed.");

        try {
            WebDriverWait wait = new WebDriverWait(_driver, _timeToWait.getSeconds());
            wait.ignoring(NullPointerException.class).ignoring(StaleElementReferenceException.class)
                    .until(driver -> {
                        //Should throw NoSuchElement exception if element not found which should get picked up by WebDriverWait.
                        WebElement element = _elementFinder.findElement();
                        return true;
                    });
        } catch (Exception e) {
            LogInfo.log_AndFail(
                    MessageFormat.format("Waited for element ''{0}'' to be exist and encountered error: {1}", _elementInfo.getFriendlyName(), e.toString()));
        }
    }

    public void attributeDoesNOTContain(String attribute, String valueToNOTHave) {
        LogInfo.log_Status("Waiting for element " + _elementInfo.getFriendlyName() + " to NOT contain expected attribute " + attribute
                + " with value " + valueToNOTHave);

        try {
            WebDriverWait wait = new WebDriverWait(_driver, _timeToWait.getSeconds());
            wait.ignoring(NullPointerException.class).ignoring(StaleElementReferenceException.class).until(driver ->
                    !_driver.findElement(_elementInfo.getElementLocator())
                            .getAttribute(attribute).contains(valueToNOTHave));
        } catch (Exception e) {
            LogInfo.log_AndFail(
                    MessageFormat.format("Waited for element to NOT have attribute match and encountered error: {0}", e.toString()));
        }
    }

    public void attributeContains(String attribute, String valueToContain) {
        LogInfo.log_Status("Waiting for element " + _elementInfo.getFriendlyName() + " to contain expected attribute " + attribute
                + " with value " + valueToContain);

        try {
            WebDriverWait wait = new WebDriverWait(_driver, _timeToWait.getSeconds());
            wait.ignoring(StaleElementReferenceException.class).until(driver ->
                    _driver.findElement(_elementInfo.getElementLocator())
                            .getAttribute(attribute).contains(valueToContain));
        } catch (Exception e) {
            LogInfo.log_AndFail(
                    MessageFormat.format("Waited for element to have attribute match and encountered error: {0}", e.toString()));
        }
    }

    public void attributeNotEmpty(String attribute) {
        LogInfo.log_Status("Waiting for element " + _elementInfo.getFriendlyName() + " to contain a value for " + attribute);

        try {
            WebDriverWait wait = new WebDriverWait(_driver, _timeToWait.getSeconds());
            wait.ignoring(NullPointerException.class).ignoring(StaleElementReferenceException.class).until(driver ->
                    _driver.findElement(_elementInfo.getElementLocator())
                            .getAttribute(attribute).length() > 0);
        } catch (Exception e) {
            LogInfo.log_AndFail(
                    MessageFormat.format("Waited for element to not be empty but encountered an error: {0}", e.toString()));
        }
    }

    public void textContains(String textToContain) {
        LogInfo.log_Status("Waiting for element " + _elementInfo.getFriendlyName() + " to contain text '" + textToContain + "'");

        try {
            WebDriverWait wait = new WebDriverWait(_driver, _timeToWait.getSeconds());
            wait.ignoring(StaleElementReferenceException.class).until(driver ->
                    _driver.findElement(_elementInfo.getElementLocator())
                            .getText().contains(textToContain));
        } catch (Exception e) {
            LogInfo.log_AndFail(
                    MessageFormat.format("Waited for element to contain text ''{0}'' but encountered an error: {1}", textToContain, e.toString()));
        }
    }

    public static void conditionMet(BooleanSupplier condition, String waitFor, Duration timeToWait) {
        LogInfo.log_Status("Waiting for condition to be met");

        try {
            Object dummy = new Object();
            FluentWait<Object> wait = new FluentWait<>(dummy).withTimeout(timeToWait);
            wait.ignoring(StaleElementReferenceException.class)
                    .ignoring(InvocationTargetException.class)
                    .ignoring(NullPointerException.class)
                    .until(
                            // Do not convert this to a lambda - lambdas don't
                            // allow us to control their .toString().
                            new Function<Object, Object>() {
                                @Override
                                public Object apply(Object o) {
                                    return condition.getAsBoolean();
                                }

                                @Override
                                public String toString() {
                                    return waitFor;
                                }
                            });
        } catch (Exception e) {
            String message = "Waiting";
            if (!e.getMessage().contains(waitFor)) {
                message += " for \"" + waitFor + "\"";
            }
            message += " but encountered error: " + e.getMessage();
            LogInfo.log_AndFail(message);
        }
    }

    public void textDoesNOTEqual(String textToContain) {
        LogInfo.log_Status("Waiting for element " + _elementInfo.getFriendlyName() + " to not equal text '" + textToContain + "'");

        try {
            WebDriverWait wait = new WebDriverWait(_driver, _timeToWait.getSeconds());
            wait.ignoring(StaleElementReferenceException.class).until(driver ->
                    !_driver.findElement(_elementInfo.getElementLocator())
                            .getText().equals(textToContain));
        } catch (Exception e) {
            LogInfo.log_AndFail(
                    MessageFormat.format("Waited for element to not equal text but encountered an error: {0}", e.toString()));
        }
    }

    public void notDisplayed() {
        LogInfo.log_Status("Waiting for element " + _elementInfo.getFriendlyName() + " to NOT be displayed.");

        try {
            WebDriverWait wait = new WebDriverWait(_driver, _timeToWait.getSeconds());

            wait.ignoring(NullPointerException.class).until(ExpectedConditions
                    .invisibilityOfElementLocated(_elementInfo.getElementLocator()));
        } catch (Exception e) {
            LogInfo.log_AndFail(MessageFormat.format("Waited for element ''{0}'' to NOT be displayed and encountered error: {1}",
                    _elementInfo.getFriendlyName(), e.toString()));
        }
    }

    public void enabled() {
        LogInfo.log_Status("Waiting for element " + _elementInfo.getFriendlyName() + " to be enabled.");

        try {
            WebDriverWait wait = new WebDriverWait(_driver, _timeToWait.getSeconds());

            wait.ignoring(NullPointerException.class).until(ExpectedConditions
                    .elementToBeClickable(_elementInfo.getElementLocator()));
        } catch (Exception e) {
            LogInfo.log_AndFail(MessageFormat.format("Waited for element ''{0}'' to be enabled and encountered error: {1}",
                    _elementInfo.getFriendlyName(), e.toString()));
        }
    }

    public void disabled() {
        LogInfo.log_Status("Waiting for element " + _elementInfo.getFriendlyName() + " to be disabled.");

        try {
            WebDriverWait wait = new WebDriverWait(_driver, _timeToWait.getSeconds());

            wait.ignoring(NullPointerException.class).until(ExpectedConditions.not(
                    ExpectedConditions.elementToBeClickable(_elementInfo.getElementLocator())));
        } catch (Exception e) {
            LogInfo.log_AndFail(MessageFormat.format("Waited for element ''{0}'' to be disabled and encountered error: {1}",
                    _elementInfo.getFriendlyName(), e.toString()));
        }
    }

    public String newWindowExists(Set<String> priorHandles) {
        try {
            WebDriverWait wait = new WebDriverWait(_driver, _timeToWait.getSeconds());
            return wait.until(driver -> {
                List<String> newHandles = new ArrayList<String>();
                newHandles.addAll(driver.getWindowHandles());
                for (String handle : newHandles) {
                    if (!priorHandles.contains(handle)) {
                        return handle;
                    }
                }

                return null;
            });
        } catch (Exception e) {
            LogInfo.log_AndFail(
                    MessageFormat.format("Waited for new window and encountered error: {0}", e.toString()));
        }

        return null;
    }
}
