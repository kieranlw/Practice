package utils2.page_components;


import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface Tableizer {
    String[] headers() default {};
    String tableCellsXpath() default "";
    String headerCellsXpath() default "";
    String firstCellXpath() default "({0}//tbody//td)[1]";

}
