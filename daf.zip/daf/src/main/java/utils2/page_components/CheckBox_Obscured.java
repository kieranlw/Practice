package utils2.page_components;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

/**
 * Check/uncheck methods are done via click on the location of the element.
 */
public class CheckBox_Obscured extends CheckBox {
    public CheckBox_Obscured(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
    }

    @Override
    public void check() {
        WebElement checkboxElement = findElement();
        if(!checkboxElement.isSelected()) {
            Actions action = new Actions(_driver);
            action.moveToElement(checkboxElement)
                    .click().build().perform();
        }
    }

    @Override
    public void uncheck() {
        WebElement checkboxElement = findElement();
        if(checkboxElement.isSelected()) {
            Actions action = new Actions(_driver);
            action.moveToElement(checkboxElement)
                    .click().build().perform();
        }
    }
}
