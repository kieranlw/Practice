package utils2.page_components;

import common.Is;
import common.Verify;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;
import utils2.LogInfo;
import utils2.page_components.element_utils.ElementUtils;

import java.util.List;
import java.util.stream.Collectors;

public class DropdownValidations {

    protected boolean _controlExists = false;
    protected WebElement _elementToValidate;
    protected String _friendlyName;
    private BaseValidations _baseValidations;

    public DropdownValidations(String friendlyName, WebElement element) {
        if (element != null) {
            _controlExists = true;
        }
        _elementToValidate = element;
        _friendlyName = friendlyName;
        _baseValidations = new BaseValidations(friendlyName, element);
    }

    //Syntactic Sugar
    public DropdownValidations and() {
        return this;
    }

    public DropdownValidations disabled(){
        _baseValidations.disabled();
        return this;
    }

    public DropdownValidations enabled(){
        _baseValidations.enabled();
        return this;
    }

    public DropdownValidations displayed(){
        _baseValidations.displayed();
        return this;
    }

    public DropdownValidations notDisplayed(){
        _baseValidations.notDisplayed();
        return this;
    }


    public DropdownValidations optionsMatch(String[] expectedOptions){
        List<String> allOptions = new ElementUtils(_friendlyName, _elementToValidate).getOptions();

        if(allOptions.size() != expectedOptions.length){
            LogInfo.log_AndFail("Expected " + expectedOptions.length +" options, but seeing " + allOptions.size() + " options");
        }

        allOptions = allOptions.stream().map(String::trim).collect(Collectors.toList());

        SoftAssert softAssert = new SoftAssert();
        for(String option : expectedOptions){
            softAssert.assertTrue(allOptions.contains(option.trim()), "Checking that '" + option.trim() + "' was in dropdown.");
        }
        softAssert.assertAll();

        return this;
    }

    public DropdownValidations optionsDoNotMatch(String[] unexpectedOptions) {
        List<String> allOptions = new ElementUtils(_friendlyName, _elementToValidate).getOptions();

        allOptions = allOptions.stream().map(String::trim).collect(Collectors.toList());

        SoftAssert softAssert = new SoftAssert();
        for (String option : unexpectedOptions) {
            softAssert.assertFalse(allOptions.contains(option.trim()), "Checking that '" + option.trim() + "' was not in dropdown.");
        }
        softAssert.assertAll();

        return this;
    }

    public DropdownValidations hasItem(String expectedItem) {
        List<String> allOptions = new ElementUtils(_friendlyName, _elementToValidate).getOptions();
        LogInfo.verify_ConditionTrue(allOptions.contains(expectedItem),
                "Dropdown contains expected item " + expectedItem);

        return this;
    }

    public DropdownValidations doesNotHaveItem(String text) {
        List<String> allOptions = new ElementUtils(_friendlyName, _elementToValidate).getOptions();
        LogInfo.verify_ConditionTrue(!allOptions.contains(text),
                "Dropdown does NOT contain expected item " + text);

        return this;
    }

    public DropdownValidations itemSelected(String expectedSelectedItem) {
        _baseValidations.elementExists();
        String selectedOption = new ElementUtils(_friendlyName, _elementToValidate).getSelectedOption();
        Verify.that(selectedOption.trim(), Is.equalToIgnoringCase(expectedSelectedItem.trim()), "Selected Item");
        return this;
    }

    public DropdownValidations itemSelected_DoesNotMatch(String expectedSelectedItem) {
        _baseValidations.elementExists();
        String selectedOption = new ElementUtils(_friendlyName, _elementToValidate).getSelectedOption();
        Verify.that(selectedOption.trim(), Is.not(Is.equalToIgnoringCase(expectedSelectedItem.trim())), "Selected Item");
        return this;
    }

    public DropdownValidations noItemSelected() {
        _baseValidations.elementExists();

        boolean optionSelected = new ElementUtils(_friendlyName, _elementToValidate).optionSelected();

        if (!optionSelected) {
            LogInfo.log_AndPass("Element " + _friendlyName + " had NO selected item");
        } else {
            LogInfo.log_AndFail("Element " + _friendlyName + " did have a selected item");
        }

        return this;
    }
}
