package utils2.page_components;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import utils.BaseUI;
import utils2.LogInfo;
import utils2.TableData2;
import utils2.tableData.GetTable;

import java.util.ArrayList;
import java.util.List;

public class TableizerBase extends GenericComponent {
    protected final TableInfo tableInfo;

    public TableizerBase(WebDriver driver, TableInfo tableInfo) {
        super(driver, tableInfo.getElementInfo());
        this.tableInfo = tableInfo;
        ComponentFactory.initElements(_driver, this, new String[]{tableInfo.getElementInfo().getElementXpath()});
    }

    public TableData2 getTableData() {
        TableData2 table_Data;

        GetTable tableFetcher = new GetTable(_driver);

        String[] tableHeaders = getTableHeaders();

        table_Data = tableFetcher.getTableByCells(By.xpath(tableInfo.getTableCellsXpath()), tableHeaders);

        return table_Data;
    }

    public String[] getTableHeaders() {
        if (tableInfo.getHeaders() != null && tableInfo.getHeaders().length > 0) {
            return tableInfo.getHeaders();
        }

        List<WebElement> tableHeaderElements = _driver.findElements(By.xpath(tableInfo.getHeaderCellsXpath()));
        ArrayList<String> tableHeaders = new ArrayList<String>();
        for (WebElement headerElement : tableHeaderElements) {
            String headerText = BaseUI.get_Attribute_FromField(headerElement, "innerText").trim();
            if (!headerText.equals("")) {
                tableHeaders.add(headerText);
            }
        }
        return tableHeaders.toArray(new String[0]);
    }

    /**
     * Gets the number of rows in the &lt;tbody&gt;.
     *
     * @return The row count
     */
    public int getBodyRowCount() {
        String xpath = _elementInfo.getElementXpath() + "/tbody/tr";
        final int count = _driver.findElements(By.xpath(xpath)).size();
        LogInfo.log_Status("Table '" + _elementInfo.getFriendlyName() + "' has " +
                count + " body row" + (count == 1 ? "" : "s"));
        return count;
    }
}
