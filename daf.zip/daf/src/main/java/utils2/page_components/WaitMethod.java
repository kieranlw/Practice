package utils2.page_components;

public @interface WaitMethod {
}
