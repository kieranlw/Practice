package utils2.page_components;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import utils2.LogInfo;
import utils2.page_components.element_utils.ElementUtils;

/**
 * Radio-button control that also has text. Probably only useful for Appium.
 */
public class RadioButtonWithText extends Component {

    public static class Validations extends CheckboxValidations {
        public Validations(String friendlyName, WebElement element) {
            super(friendlyName, element);
        }

        public Validations textContains(String expectedText) {
            elementExists();

            String elementText = new ElementUtils(_friendlyName, _elementToValidate).getText();
            LogInfo.verify_ConditionTrue(elementText.contains(expectedText),
                    "Element '" + _friendlyName + "' should contain text '" + expectedText + "'");

            return this;
        }
    }

    public RadioButtonWithText(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
    }

    public Validations verify() {
        return new Validations(_elementInfo.getFriendlyName(), findNullableElement());
    }

    public boolean isChecked() {
        return new ElementUtils(_elementInfo.getFriendlyName(), findElement()).isChecked();
    }

    public void check() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).check();
    }
}
