package utils2.page_components.element_utils;

import org.openqa.selenium.By;

public class AppiumBy {
    private AppiumBy() {
    }

    public static By windowHandle(long windowHandle) {
        // If we're looking for, say, window handle 1000, don't match RuntimeId="42.10008"
        return By.xpath("//*[contains(concat(@RuntimeId, '$'), '." + windowHandle + "$')]");
    }
}
