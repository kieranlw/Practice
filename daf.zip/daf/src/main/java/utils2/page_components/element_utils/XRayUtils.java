package utils2.page_components.element_utils;

import common.StringUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Quotes;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import utils.TableData;
import utils.XmlData;
import utils2.Index;
import utils2.LogInfo;
import utils2.TableData2;
import utils2.tableData.TableConverter;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

public class XRayUtils extends XRayUtilsBase<Document> {

    public XRayUtils(WebDriver driver) {
        super(driver);
    }

    public XRayUtils(WebDriver driver, String xrayLocation) {
        super(driver, xrayLocation);
    }

    @Override
    protected Document loadData(String xrayLocation) throws LoadException {
        try {
            return DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new File(xrayLocation));
        } catch (SAXException | ParserConfigurationException | IOException e) {
            throw new LoadException(e.getMessage(), e);
        }
    }

    private String getSubNodeValue(String name, String subNode) throws Exception {

        Document data = getData();

        XmlData xml = new XmlData(data);

        String xpath = "//*[./WidgetName[./text()='" + name + "']]";

        String valueWeWant = "";
        Node matchingNode = xml.findNode(xpath);
        NodeList nodes = matchingNode.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++) {
            if (nodes.item(i).getNodeType() == Node.ELEMENT_NODE) {
                Element el = (Element) nodes.item(i);
                if (el.getTagName().equals(subNode)) {
                    valueWeWant = el.getTextContent();

                    break;
                }
            }
        }

        return valueWeWant;
    }

    public String getToolTip(String xrayName) throws Exception {
        return getSubNodeValue(xrayName, "WidgetToolTip");
    }

    public TableData return_Table(String[] columnNames) {
        return return_Table(columnLocatorsFromLabels(columnNames));
    }

    public TableData return_Table(XRayColumnLocator[] columnLocators) {
        TableData xmlTableData = new TableData();

        Document data = getData();

        XmlData xml = new XmlData(data);

        for (XRayColumnLocator locator : columnLocators) {
            String xpath = StringUtils.expandXPathPlaceholders("//ttbBrowseRowDetail[./WidgetType[./text()='Column (FILL-IN)']][./{0}[./text()='{1}']]/WidgetValue",
                    locator.type, locator.value);
            NodeList columnCellList = xml.findNodes(xpath);

            for (int i = 0; i < columnCellList.getLength(); i++) {
                HashMap<String, String> tableRow;

                if (xmlTableData.data.size() == 0 || xmlTableData.data.size() <= i) {
                    tableRow = new HashMap<>();
                    tableRow.put(locator.value, columnCellList.item(i).getTextContent().trim());
                    xmlTableData.data.add(tableRow);
                } else {
                    xmlTableData.data.get(i).put(locator.value, columnCellList.item(i).getTextContent().trim());
                }
            }
        }
        return xmlTableData;
    }

    @Override
    public TableData2 return_TableData2(XRayColumnLocator[] columnLocators) {
        return TableConverter.convertToTableData2(return_Table(columnLocators));
    }

    public void navigate_ToLocation_InTable(TableData tableToMatchAgainst, String columnName, String columnValue) {

        Integer indexOfItem = tableToMatchAgainst.first_IndexOf(columnName, columnValue);
        if (indexOfItem == null) {
            LogInfo.log_AndFail("Unable to find value for column " + Quotes.escape(columnName)
                    + " with column value " + Quotes.escape(columnValue));
        }

        navigate_ToLocation_InTable(Index.zeroBased(indexOfItem));
    }

    public void navigate_ToLocation_InTable(Index index) {
        sendKeys(Keys.HOME);

        for (int i = 0; i < index.asZeroBased(); i++) {
            sendKeys(Keys.DOWN);
        }
    }
}
