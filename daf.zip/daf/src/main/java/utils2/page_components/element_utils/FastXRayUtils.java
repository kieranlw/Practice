package utils2.page_components.element_utils;

import org.openqa.selenium.WebDriver;
import utils2.LogInfo;
import utils2.TableData2;

import javax.xml.stream.XMLStreamException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * <p>
 * Trimmed-down version of XRayUtils for large XML files.
 * </p><p>
 * This reads the file using the StAX streaming API, so it uses much less memory, and is much
 * faster, than XRayUtils for tens- or hundreds-of-megabyte XML files (e.g. from the System
 * Workflow screen). However, because it doesn't load the whole file into memory, it can't do
 * XPath operations.
 * </p>
 */
public class FastXRayUtils extends XRayUtilsBase<FastXRay> {
    public FastXRayUtils(WebDriver driver) {
        super(driver);
    }

    public FastXRayUtils(WebDriver driver, String xrayLocation) {
        super(driver, xrayLocation);
    }

    @Override
    protected FastXRay loadData(String xrayLocation) throws LoadException {
        if (!Files.exists(Paths.get(xrayLocation)))
            throw new LoadException("File does not exist yet", null);

        try {
            LogInfo.log_Status("Xray file exists. Loading...");
            return new FastXRayReader().load(xrayLocation);
        } catch (IOException | XMLStreamException e) {
            throw new LoadException(e.getMessage(), e);
        }
    }

    @Override
    public TableData2 return_TableData2(XRayColumnLocator[] columnLocators) {
        List<Map<String, String>> tableRows = getData().rows.stream()
                .map(xrayRow -> {
                    // Only create a Map if values actually exist to put into it. This is for
                    // screens with more than one grid (e.g. Data Maintenance > Batch Menu >
                    // View System Workflow), where xray.rows.size() is the max of the two grids.
                    Map<String, String> values = null;
                    for (XRayColumnLocator columnLocator : columnLocators) {
                        String key = columnLocator.toString();
                        if (xrayRow.containsKey(key)) {
                            if (values == null) {
                                values = new HashMap<>();
                            }
                            values.put(columnLocator.value, xrayRow.get(key));
                        }
                    }
                    return values;
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        return TableData2.createFromMaps(tableRows);
    }
}
