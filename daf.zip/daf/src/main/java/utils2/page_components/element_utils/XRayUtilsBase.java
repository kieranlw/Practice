package utils2.page_components.element_utils;

import common.ThreadUtils;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import utils.BaseUI;
import utils.FileOperations;
import utils2.DriverUtils;
import utils2.LogInfo;
import utils2.TableData2;

import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;

public abstract class XRayUtilsBase<D> {

    protected static class LoadException extends Exception {
        public LoadException(String s, Throwable throwable) {
            super(s, throwable);
        }
    }

    private static final Duration DEFAULT_XRAY_TIMEOUT = Duration.ofSeconds(30);

    private final WebDriver driver;
    private final DriverUtils driverUtils;
    private final String xrayLocation;
    private D data;
    private Duration timeout = DEFAULT_XRAY_TIMEOUT;

    public XRayUtilsBase(WebDriver driver) {
        this(driver, System.getProperty("xraypath"));
    }

    public XRayUtilsBase(WebDriver driver, String xrayLocation) {
        this.driver = driver;
        this.xrayLocation = xrayLocation;

        driverUtils = new DriverUtils(driver);
    }

    @NotNull
    protected XRayColumnLocator[] columnLocatorsFromLabels(String[] columnLabels) {
        return Arrays.stream(columnLabels)
                .map(XRayColumnLocator::byLabel)
                .toArray(XRayColumnLocator[]::new);
    }

    public final D getData() {
        if (data == null) {
            takeXray();
        }
        return data;
    }

    public final void invalidateXRay() {
        data = null;
    }

    protected abstract D loadData(String xrayLocation) throws LoadException;

    private D loadDataWithTimeout() {
        Instant endTime = Instant.now().plus(timeout);
        while (Instant.now().isBefore(endTime)) {
            try {
                return loadData(xrayLocation);
            } catch (LoadException e) {
                // continue looping
            }
        }

        // The caller isn't going to try to recover from this error
        throw new RuntimeException("Thick client did not respond to screen-scrape request within the specified " +
                BaseUI.durationToString(timeout) + " timeout");
    }

    public final TableData2 return_TableData2(String[] columnLabels) {
        return return_TableData2(columnLocatorsFromLabels(columnLabels));
    }

    public abstract TableData2 return_TableData2(XRayColumnLocator[] columnLocators);

    protected final void sendKeys(Keys key) {
        driverUtils.send_KeyWithActionBuilder(key);
    }

    public final void setTimeout(Duration timeout) {
        this.timeout = timeout;
    }

    private void takeXray() {
        // If we can't delete the xray file, for example because we're on a separate domain and
        // haven't logged into QALabs, then we want to fail fast
        FileOperations.delete_SpecificFile_AndThrowOnError(xrayLocation);

        LogInfo.log_Status("Taking xray");
        new Actions(driver)
                .keyDown(Keys.LEFT_ALT)
                .keyDown(Keys.LEFT_CONTROL)
                .sendKeys("a")
                .build().perform();
        try {
            //Adding sleep here, saw some interesting behavior after ctrl+alt+s that could interfere with trying to perform operations directly after.
            ThreadUtils.sleep(500);

            data = loadDataWithTimeout();

            LogInfo.log_Status("Xray complete");
        } finally {
            new Actions(driver)
                    .keyUp(Keys.LEFT_CONTROL)
                    .keyUp(Keys.LEFT_ALT)
                    .build().perform();
        }
    }
}
