package utils2.page_components.element_utils;

import common.OsUtils;
import common.ThreadUtils;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.Quotes;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.winium.WiniumDriver;
import utils2.Index;
import utils2.LogInfo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ElementUtils {

    private String _friendlyName;
    private WebElement _element;

    public WebDriver getElementDriver() {
        return ((RemoteWebElement) _element).getWrappedDriver();
    }

    public ElementUtils(String friendlyName, WebElement elementToCheck) {
        if (elementToCheck == null) {
            LogInfo.log_AndFail("Element " + friendlyName + " was not found.");
        }

        _friendlyName = "'" + friendlyName + "'";
        _element = elementToCheck;
    }

    // Generic action to click on a field. Typically used with buttons, links,
    // checkboxes, but can be used by anything
    public void click() {
        String textToLog = "Clicking on WebElement " + _friendlyName;
        LogInfo.log_Status(textToLog);
        _element.click();
    }

    public boolean isDisplayed() {
        boolean isDisplayed = _element.isDisplayed();
        LogInfo.log_Status("Element " + _friendlyName + " was displayed: " + isDisplayed);
        return isDisplayed;
    }

    public boolean isEnabled() {
        List<String> mobileDriverTypes = Arrays.asList("iphone", "android");
        String driverType = (String) ((RemoteWebDriver) getElementDriver()).getCapabilities().asMap().get("BROWSER_NAME");
        boolean isEnabled = false;
        //ios is very finicky about checking attributes that may or may not exist.
        if(driverType != null && mobileDriverTypes.contains(driverType.toLowerCase())) {
            String attribute = _element.getAttribute("enabled");
            isEnabled = (attribute != null) ? attribute.equals("true") : _element.isEnabled();
        } else if(!elementContainsClassDisabled() && !elementContainsAttributeReadOnly()) {
            isEnabled = _element.isEnabled();
        }

        LogInfo.log_Status("Element " + _friendlyName + " was enabled: " + isEnabled);
        return isEnabled;
    }

    private boolean elementContainsClassDisabled() {
        String classValue =_element.getAttribute("class");
        return (classValue != null && classValue.contains("disabled"));
    }

    private boolean elementContainsAttributeReadOnly() {
        String readonlyValue = _element.getAttribute("readonly");
        return readonlyValue != null && (readonlyValue.equals("") || readonlyValue.equals("true"));
    }

    public void scrollToElement() {
        ((JavascriptExecutor) getElementDriver()).executeScript("arguments[0].scrollIntoView();", _element);
        ThreadUtils.sleep(300);
    }

    public void injectTextNode(String textToInject) {
        LogInfo.log_Status("Attempting to inject text into element. Text is " + textToInject);
        JavascriptExecutor js = (JavascriptExecutor) getElementDriver();
        js.executeScript("arguments[0].appendChild(document.createTextNode('" + textToInject + "'))",
                _element, textToInject);
    }

    public void doubleClick() {
        LogInfo.log_Status("Double clicking on WebElement " + _element.getText());
        Actions action = new Actions(getElementDriver());
        action.doubleClick(_element).perform();
    }

    // Click with JavaScript. Work around for some of the tricky elements.
    public void click_JS() {
        LogInfo.log_Status("Clicking using JavaScript on WebElement " + _friendlyName);
        String javaScript = "var evObj = document.createEvent('MouseEvents');"
                + "evObj.initMouseEvent(\"click\",true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);"
                + "arguments[0].dispatchEvent(evObj);";

        JavascriptExecutor executor = (JavascriptExecutor) getElementDriver();
        executor.executeScript(javaScript, _element);
    }

    public String getText() {
        LogInfo.log_Status("Getting Text from element " + _friendlyName);
        String textToGet;

        if (!(getElementDriver() instanceof WiniumDriver) && !(getElementDriver() instanceof AppiumDriver) && _element.getTagName().equals("input")
                && (_element.getAttribute("type").equals("text") || _element.getAttribute("type").equals("tel")  || _element.getAttribute("type").equals("number"))) {
            textToGet = _element.getAttribute("value");
        } else {
            textToGet = _element.getText();
        }

        LogInfo.log_Status("Text was: " + textToGet);
        return textToGet;
    }

    public void hover() {
        LogInfo.log_Status("Hovering on element " + _friendlyName);
        Actions action = new Actions(getElementDriver());
        action.moveToElement(_element).perform();
    }

    public String getAttribute(String attributeToGet) {
        LogInfo.log_Status("Getting Attribute " + attributeToGet + " from element " + _friendlyName);
        String textToGet = _element.getAttribute(attributeToGet);
        LogInfo.log_Status("Attribute of " + attributeToGet + " was: " + textToGet);
        return textToGet;
    }

    public String getCSSValue(String cssValue) {
        LogInfo.log_Status("Getting CSS Attribute " + cssValue + " from element " + _friendlyName);
        String cssACTUALValue = _element.getCssValue(cssValue);
        LogInfo.log_Status("CSS Value of " + cssValue + " was: " + cssACTUALValue);
        return cssACTUALValue;
    }

    //Dropdown methods
    //
    //
    //

    public void selectValue(String valueToSet) {
        if (valueToSet == null) return; //Don't attempt anything if valueToSet is null
        LogInfo.log_Status("Selecting " + valueToSet + " from WebElement " + _friendlyName);
        new Select(_element).selectByVisibleText(valueToSet);
    }

    public void selectValueByIndex(Index indexToPick) {
        LogInfo.log_Status("Selecting " + indexToPick.asZeroBased() + " from WebElement " + _friendlyName);
        new Select(_element).selectByIndex(indexToPick.asZeroBased());
    }

    public String getSelectedOption() {
        Select select = new Select(_element);
        String selectedValue = select.getFirstSelectedOption().getText();
        LogInfo.log_Status("Selected Value for element " + _friendlyName + " was: " + selectedValue);
        return selectedValue;
    }

    //determine if an option is selected
    public boolean optionSelected() {
        Select select = new Select(_element);
        List<WebElement> selectedOptions = select.getAllSelectedOptions();

        if (selectedOptions.size() > 0) {
            LogInfo.log_Status("At least one option was selected");
            return true;
        } else {
            LogInfo.log_Status("No options were selected.");
            return false;
        }
    }

    public List<String> getOptions() {
        LogInfo.log_Status("Getting options from WebElement " + _friendlyName);

        Select dropdownSelector = new Select(_element);
        List<WebElement> optionsElements = dropdownSelector.getOptions();

        if (optionsElements.size() == 0) {
            LogInfo.log_AndFail("Could not find options for " + _friendlyName);
        }

        List<String> options = new ArrayList<>();
        for (WebElement optionElement : optionsElements) {
            options.add(optionElement.getText());
        }

        LogInfo.log_Status("Returning options " + options.toString());

        return options;
    }

    //End Dropdown methods
    //
    //

    //Checkbox methods
    //
    //

    public void check() {
        if (!_element.isSelected()) {
            LogInfo.log_Status("Checking checkbox " + _friendlyName);
            _element.click();
        } else {
            LogInfo.log_Status("Checkbox already checked " + _friendlyName);
        }
    }

    public void uncheck() {
        if (_element.isSelected()) {
            LogInfo.log_Status("Unchecking checkbox " + _friendlyName);
            _element.click();
        } else {
            LogInfo.log_Status("Checkbox already unchecked " + _friendlyName);
        }
    }

    public void check_JS() {
        if (!_element.isSelected()) {
            LogInfo.log_Status("Checking checkbox " + _friendlyName);
            ((JavascriptExecutor) getElementDriver()).executeScript("arguments[0].checked = true;", _element);
        } else {
            LogInfo.log_Status("Checkbox already checked " + _friendlyName);
        }
    }

    public void uncheck_JS() {
        if (_element.isSelected()) {
            LogInfo.log_Status("Unchecking checkbox " + _friendlyName);
            ((JavascriptExecutor) getElementDriver()).executeScript("arguments[0].checked = false;", _element);
        } else {
            LogInfo.log_Status("Checkbox already unchecked " + _friendlyName);
        }
    }

    public boolean isChecked() {
        boolean checkboxChecked = _element.isSelected();
        LogInfo.log_Status("Checkbox checked: " + checkboxChecked);
        return checkboxChecked;
    }

    //End Checkbox methods
    //
    //

    //Textbox methods
    //
    //

    //some textboxes require different clearing logic
    public void clearText() {
        String logText = "Clearing WebElement " + _friendlyName;
        LogInfo.log_Status(logText);
        _element.clear();
    }

    public void deleteAllText() {
        _element.sendKeys(Keys.chord(Keys.CONTROL, "a"));
        _element.sendKeys(Keys.DELETE);
    }

    public void enterText(String valueToSet) {
        if (valueToSet == null) return; //Don't attempt anything if valueToSet is null
        clearText();
        String logText = "Entering " + valueToSet + " into WebElement " + _friendlyName;
        LogInfo.log_Status(logText);
        _element.sendKeys(valueToSet);
    }

    public void removeAttribute( String attributeName ) {
        ((JavascriptExecutor) getElementDriver()).executeScript("arguments[0].removeAttribute(arguments[1]);",
                _element, attributeName);

    }

    public void enterText_JS(String valueToSet) {
        if (valueToSet == null) return;
        String logText = "Entering " + valueToSet + " into WebElement " + _friendlyName;
        LogInfo.log_Status(logText);
        clearText();
        ((JavascriptExecutor) getElementDriver()).executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);",
                _element, "value", valueToSet);
    }

    public void clearText_Finicky(){
        _element.click();
        Actions builder = new Actions(getElementDriver());

        if (OsUtils.isMac()) {
            String textBoxText = _element.getAttribute("value");
            for (char c : textBoxText.toCharArray()) {
                _element.sendKeys(Keys.BACK_SPACE);
            }
        } else {
            builder.keyDown(Keys.LEFT_CONTROL);
            builder.build().perform();
            builder.sendKeys("a").build().perform();
            builder.keyUp(Keys.LEFT_CONTROL).build().perform();
            builder.sendKeys(Keys.DELETE).build().perform();
        }
    }

    //Method for when there's finicky clearing of text from element
    public void enterText_Finicky(String valueToSet) {
        if(valueToSet == null){
            return;
        }
        clearText_Finicky();

        _element.sendKeys(valueToSet);
    }

    public void enterKey(Keys keys) {
        LogInfo.log_Status("Entering " + keys.toString() + " into WebElement " + _friendlyName);

        _element.sendKeys("");
        _element.sendKeys(keys);
    }

    public void selectValueByPartialMatch(String valueToSet) {
        if (valueToSet == null) return; //Don't attempt anything if valueToSet is null
        LogInfo.log_Status("Selecting " + valueToSet + " from WebElement " + _friendlyName);

        WebElement option =
                _element.findElement(By.xpath(".//option[contains(normalize-space(.), " + Quotes.escape(valueToSet) + ")]"));

        option.click();
    }

    //End Textbox methods
    //
    //
}
