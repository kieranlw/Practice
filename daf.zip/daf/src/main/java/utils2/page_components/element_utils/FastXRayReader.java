package utils2.page_components.element_utils;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

public final class FastXRayReader {
    private static final String TAG_WIDGET = "ttbWidget";
    private static final String TAG_CELL = "ttbBrowseRowDetail";

    private Deque<String> elements = new LinkedList<>();
    private String widgetType = "";
    private String widgetName = "";
    private String widgetLabel = "";
    private String widgetValue = "";
    private int rowIndex = 0;
    private final List<FastXRayWidget> widgets = new ArrayList<>();
    private final List<Map<String, String>> rows = new ArrayList<>();

    public FastXRay load(String filePath) throws IOException, XMLStreamException {
        try (InputStream stream = new FileInputStream(filePath)) {
            XMLEventReader reader = XMLInputFactory.newInstance().createXMLEventReader(stream);
            while (reader.hasNext()) {
                XMLEvent event = reader.nextEvent();
                switch (event.getEventType()) {
                    case XMLStreamConstants.START_ELEMENT:
                        handleStartElement(event.asStartElement());
                        break;
                    case XMLStreamConstants.CHARACTERS:
                        handleCharacters(event.asCharacters());
                        break;
                    case XMLStreamConstants.END_ELEMENT:
                        handleEndElement(event.asEndElement());
                        break;
                }
            }
        }

        return new FastXRay(widgets, rows);
    }

    private void handleStartElement(StartElement startElement) {
        String tag = startElement.getName().getLocalPart();
        elements.push(tag);

        switch (tag) {
            case TAG_WIDGET:
            case TAG_CELL:
                widgetType = "";
                widgetName = "";
                widgetLabel = "";
                widgetValue = "";
                rowIndex = 0;
                break;
        }
    }

    private void handleCharacters(Characters asCharacters) {
        String parentTag = elements.peek();
        if (parentTag == null) {
            return;
        }

        String text = asCharacters.getData();
        if (text == null || text.isEmpty()) {
            return;
        }

        switch (parentTag) {
            case "WidgetType":
                widgetType = text;
                break;
            case "WidgetName":
                widgetName = text;
                break;
            case "WidgetLabel":
                widgetLabel = text;
                break;
            case "WidgetValue":
                widgetValue = text;
                break;
            case "BrowseRow":
                rowIndex = Integer.parseInt(text) - 1;
                break;
        }
    }

    private void handleEndElement(EndElement endElement) {
        String tag = endElement.getName().getLocalPart();
        elements.pop();

        switch (tag) {
            case TAG_WIDGET:
                widgets.add(new FastXRayWidget(widgetType, widgetName, widgetLabel, widgetValue));
                break;
            case TAG_CELL:
                Map<String, String> row = getOrAddRow(rowIndex);
                row.put(XRayColumnLocator.byLabel(widgetLabel).toString(), widgetValue);
                row.put(XRayColumnLocator.byName(widgetName).toString(), widgetValue);
                break;
        }
    }

    private Map<String, String> getOrAddRow(int rowIndex) {
        while (rows.size() <= rowIndex) {
            rows.add(new HashMap<>());
        }
        return rows.get(rowIndex);
    }
}
