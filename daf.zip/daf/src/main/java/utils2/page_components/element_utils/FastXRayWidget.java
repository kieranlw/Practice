package utils2.page_components.element_utils;

public class FastXRayWidget {
    public final String type;
    public final String name;
    public final String label;
    public final String value;

    public FastXRayWidget(String type, String name, String label, String value) {
        this.type = type;
        this.name = name;
        this.label = label;
        this.value = value;
    }
}
