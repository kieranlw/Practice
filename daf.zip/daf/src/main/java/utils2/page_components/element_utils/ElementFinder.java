package utils2.page_components.element_utils;

import io.appium.java_client.windows.WindowsDriver;
import org.openqa.selenium.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import utils.BaseUI;
import utils.XmlData;
import utils2.AppiumDesktop;
import utils2.LogInfo;
import utils2.SimpleNoSuchElementException;
import utils2.page_components.*;

import java.text.MessageFormat;
import java.util.List;

public class ElementFinder {

    private WebDriver _driver;
    private ElementInfo _elementInfo;

    public ElementFinder(WebDriver driver, ElementInfo elementInfo) {
        _driver = driver;
        _elementInfo = elementInfo;
    }

    //Only use with validations.
    public WebElement findNullableElement() {
        if (_elementInfo.getElementLocator_Type().equals("partialLinkText") && AppiumDesktop.isWindowsPlatform(_driver)) {
            return findByPartialValueMatch(false);
        } else {
            try {
                return findElement();
            } catch (NoSuchElementException e) {
                BaseUI.log_Status("Did not find element " + _elementInfo.getFriendlyName() + " Seeing exception: " + e.getMessage());
            }
        }

        return null;
    }

    public WebElement findElement() {
        String locatorType = _elementInfo.getElementLocator_Type();
        String locatorValue = _elementInfo.getElementLocator_String();
        if (locatorType.equals("partialLinkText") && AppiumDesktop.isWindowsPlatform(_driver)) {
            return findByPartialValueMatch(true);
        } else if (locatorType.equals("id") && AppiumDesktop.isWindowsPlatform(_driver)) {
            return ((WindowsDriver<?>) _driver).findElementByAccessibilityId(locatorValue);
        }

        if (locatorValue.startsWith("xr:")) {
            String identifier = locatorValue;
            if (locatorType.equals("name")) {
                identifier = get_XR_XPath(locatorType, locatorValue);
            }
            return findBy_XrXpath(identifier);
        }

        final List<WebElement> elements = _driver.findElements(_elementInfo.getElementLocator());
        if (elements.size() > 0) {
            return elements.get(0);
        } else {
            // Throw an exception without Selenium's usual debug information appended
            throw new SimpleNoSuchElementException(
                    "Could not find component \"" + _elementInfo.getFriendlyName() + "\" on the page");
        }
    }

    private static String get_XR_XPath(String locatorType, String identifier) {
        String simplifiedIdentifier = identifier.split(":")[1];

        String xpath = "//*[./{0}[./text()='{1}']]";
        xpath = xpath.replace("'", "''");

        switch (locatorType) {
            case "name":
                return MessageFormat.format(xpath, "WidgetName", simplifiedIdentifier);
            case "type":
                return MessageFormat.format(xpath, "WidgetType", simplifiedIdentifier);
            case "label":
                return MessageFormat.format(xpath, "WidgetLabel", simplifiedIdentifier);
            case "value":
                return MessageFormat.format(xpath, "WidgetValue", simplifiedIdentifier);
            default:
                throw new RuntimeException("Unknown identifier type of " + locatorType);
        }
    }

    //Windows Appium workaround
    private WebElement findByPartialValueMatch(boolean errorIfNotFound) {
        List<WebElement> potentialMatches = _driver.findElements(By.xpath("//*"));
        for (WebElement element : potentialMatches) {
            if (element.getText().contains(_elementInfo.getElementLocator_String())) {
                return element;
            }
        }

        if (errorIfNotFound) {
            BaseUI.log_AndFail("Did not find element " + _elementInfo.getFriendlyName());
            return null;
        }
        return null;
    }

    private WebElement findBy_XrXpath(String xpath) {
        if (xpath.startsWith("xrxpath")) {
            xpath = xpath.split(":")[1];
        }

        try {
            XRayUtils xrayUtil = new XRayUtils(_driver);
            Document xrayXML = xrayUtil.getData();

            long windowHandle = 0;
            XmlData xml = new XmlData(xrayXML);
            Node matchingNode = xml.findNode(xpath);
            if (matchingNode == null) {
                return null;
            }
            NodeList nodes = matchingNode.getChildNodes();
            for (int i = 0; i < nodes.getLength(); i++) {
                if (nodes.item(i).getNodeType() == Node.ELEMENT_NODE) {
                    Element el = (Element) nodes.item(i);
                    if (el.getTagName().equals("WindowsHandle")) {
                        String text = el.getTextContent();
                        if (text != null && !text.isEmpty()) {
                            windowHandle = Long.parseLong(text);
                        }
                        break;
                    }
                }
            }

            return _driver.findElement(AppiumBy.windowHandle(windowHandle));
        } catch (Exception e) {
            LogInfo.log_AndFail("Encountered exception while trying to locate element using xrxpath: " + e.getMessage());
        }

        return null;
    }
}
