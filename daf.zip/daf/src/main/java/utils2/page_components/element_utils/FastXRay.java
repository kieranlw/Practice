package utils2.page_components.element_utils;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class FastXRay {
    public final List<FastXRayWidget> widgets;
    public final List<Map<String, String>> rows;

    public FastXRay(List<FastXRayWidget> widgets, List<Map<String, String>> rows) {
        this.widgets = Collections.unmodifiableList(widgets);
        this.rows = Collections.unmodifiableList(rows);
    }
}
