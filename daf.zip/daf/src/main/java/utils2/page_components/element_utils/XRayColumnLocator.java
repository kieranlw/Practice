package utils2.page_components.element_utils;

public class XRayColumnLocator {
    public final String type;
    public final String value;

    private XRayColumnLocator(String type, String value) {
        this.type = type;
        this.value = value;
    }

    public static XRayColumnLocator byLabel(String label) {
        return new XRayColumnLocator("WidgetLabel", label);
    }

    public static XRayColumnLocator byName(String name) {
        return new XRayColumnLocator("WidgetName", name);
    }

    @Override
    public String toString() {
        return type + ":" + value;
    }
}
