package utils2.page_components;

import common.ListUtils;
import common.StringUtils;
import org.immutables.value.Value;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import utils2.LogInfo;
import utils2.pageControls.annotations.ControlFindBy;
import utils2.pageControls.annotations.WaitFor;

import java.lang.annotation.Annotation;
import java.lang.reflect.*;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.stream.Collectors;

public class ComponentFactory {

    //This class needs to be refactored.  Would like to have initElements in here and then move the rest of the code to an instanced class so we can inherit and override portions of the code.

    public static void initElements(WebDriver driver, Object page) {
        initElements(driver, page, null);
    }

    public static void initElements(WebDriver driver, Object page, String[] identifierArguments) {
        Class<?> proxyIn = page.getClass();
        while (proxyIn != Object.class) {
            proxyFields(driver, page, proxyIn, identifierArguments);
            proxyIn = proxyIn.getSuperclass();
        }
    }

    private static void proxyFields(WebDriver driver, Object page, Class<?> proxyIn, String[] identifierArguments) {
        Field[] fields = proxyIn.getDeclaredFields();
        for (Field field : fields) {
            Object value = decorate(driver, field, identifierArguments, page);
            if (value != null) {
                try {
                    field.setAccessible(true);
                    field.set(page, value);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    private static boolean isDecorative(Class<?> type) {
        return isMobilePlatform(type) || Component.class.isAssignableFrom(type);
    }

    private static boolean isMobilePlatform(Class<?> type) {
        MobilePlatformSelector mobilePlatform = type.getAnnotation(MobilePlatformSelector.class);
        return mobilePlatform != null;
    }

    @NotNull
    private static Class<?> getConcreteComponentType(WebDriver driver, Class<?> requestedType) {
        if (isMobilePlatform(requestedType)) {
            MobilePlatformSelector mobilePlatform = requestedType.getAnnotation(MobilePlatformSelector.class);
            try {
                String browserType = (String) ((RemoteWebDriver) driver).getCapabilities().asMap().get("BROWSER_NAME");
                return (browserType != null && browserType.equals("Android")) ? mobilePlatform.android() : mobilePlatform.ios();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        return requestedType;
    }

    private static Object decorate(WebDriver driver, Field field, String[] identifierArguments, Object page) {
        if (!isDecorative(field.getType())) {
            return null;
        }

        ComponentLocators locators = getComponentLocators(field);
        Tableizer tableizer = field.getAnnotation(Tableizer.class);
        final ComponentWaitInfo afterClickWait = getAfterClickWait(field);
        final Duration afterClickSleep = getAfterClickSleep(field);
        DateFormat dateFormat = field.getAnnotation(DateFormat.class);

        if (locators != null) {
            String friendlyName = locators.friendlyName();

            if (friendlyName.isEmpty()) {
                friendlyName = StringUtils.camelCaseToHumanReadable(field.getName());
            }
            try {
                ElementInfo elementInfo = ElementInfo.createElementInfo_WithWaitLogic(
                        friendlyName, getByLocator(locators, identifierArguments, driver),
                        getWaitLogic(afterClickWait.getWaitMethodName(), page),
                        afterClickWait.getTimeout(),
                        afterClickSleep);

                TableInfo tableInfo = null;
                if (tableizer != null) {
                    tableInfo = TableInfo.createTableInfo(elementInfo, tableizer.headers(), tableizer.headerCellsXpath(),
                            tableizer.tableCellsXpath(), tableizer.firstCellXpath());
                }

                final DateFormatInfo dateFormatInfo = dateFormat != null
                        ? new DateFormatInfo(dateFormat.value())
                        : null;

                Class<?> genericTypeParameter = getGenericTypeParameter(field);
                return createChildComponent(field.getType(), genericTypeParameter, driver, elementInfo, tableInfo, dateFormatInfo);
            } catch (java.lang.ClassNotFoundException e) {
                LogInfo.log_Warning("Unable to get Class " + field.getType() + " for field " + field.getName());
            } catch (ComponentCreationException e) {
                LogInfo.log_Warning(e.getMessage());
            }
        }

        return null;
    }

    @Nullable
    private static ComponentLocators getComponentLocators(Field field) {
        ComponentFindBy componentFindBy = field.getAnnotation(ComponentFindBy.class);
        if (componentFindBy != null) {
            return wrap(componentFindBy, ComponentLocators.class);
        }

        ControlFindBy controlFindBy = field.getAnnotation(ControlFindBy.class);
        if (controlFindBy != null) {
            return wrap(controlFindBy, ComponentLocators.class);
        }

        return null;
    }

    private static ComponentWaitInfo getAfterClickWait(Field field) {
        final AfterClick_Wait afterClickWait = field.getAnnotation(AfterClick_Wait.class);
        if (afterClickWait != null) {
            return ImmutableComponentWaitInfo.builder()
                    .waitMethodName(afterClickWait.waitMethodName())
                    .timeout(Duration.ofMillis(afterClickWait.timeoutInMilliseconds()))
                    .build();
        }

        final WaitFor waitFor = field.getAnnotation(WaitFor.class);
        if (waitFor != null && !waitFor.waitMethodName().isEmpty()) {
            return ImmutableComponentWaitInfo.builder()
                    .waitMethodName(waitFor.waitMethodName())
                    .timeout(Duration.ofMillis(waitFor.waitForDurationInMilliseconds()))
                    .build();
        }

        return ImmutableComponentWaitInfo.builder()
                .waitMethodName("")
                .timeout(Duration.ZERO)
                .build();
    }

    private static Duration getAfterClickSleep(Field field) {
        final AfterClick_HardCodedSleep afterClickSleep = field.getAnnotation(AfterClick_HardCodedSleep.class);
        if (afterClickSleep != null) {
            if (afterClickSleep.why().trim().isEmpty()) {
                LogInfo.log_AndFail("Field " + field.getDeclaringClass().getName() + "." +
                        field.getName() + ":\n" +
                        "Error: 'why' is required for hard-coded sleeps.\n" +
                        "Hard-coded sleeps should always be a last resort. If you need to add one, " +
                        "you need to also add an explanation of why explicit waits " +
                        "(e.g. AfterClick_Wait) were inadequate.");
            }

            return Duration.ofMillis(afterClickSleep.milliseconds());
        }

        final WaitFor waitFor = field.getAnnotation(WaitFor.class);
        if (waitFor != null && waitFor.sleepForGivenMilliseconds() > 0) {
            return Duration.ofMillis(waitFor.sleepForGivenMilliseconds());
        }

        return Duration.ZERO;
    }

    private static BooleanSupplier getWaitLogic(String methodName, Object page) {
        if (methodName.isEmpty()) {
            return null;
        }

        Method waitMethod;
        try {
            waitMethod = page.getClass().getDeclaredMethod(methodName);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException("Error finding wait method '" + methodName +
                    "' on page '" + page.getClass().getName() +
                    "': " + e.getClass().getSimpleName() +
                    ": " + e.getMessage());
        }

        waitMethod.setAccessible(true);
        BooleanSupplier waitSupplier = () -> {
            try {
                return (boolean) waitMethod.invoke(page);
            } catch (IllegalAccessException | InvocationTargetException e) {
                LogInfo.log_AndFail("Encountered error: " + e.getMessage());
                return false;
            }
        };
        return waitSupplier;
    }

    @NotNull
    private static List<Argument> getComponentArguments(Class<?> genericTypeParameter, WebDriver driver,
                                                        ElementInfo elementInfo, TableInfo tableInfo,
                                                        DateFormatInfo dateFormatInfo) {
        final List<Argument> arguments = new ArrayList<>();

        // Generics get a Class<T> as their first argument
        if (genericTypeParameter != null) {
            arguments.add(new Argument(Class.class, genericTypeParameter));
        }

        // Then everyone gets a WebDriver argument
        arguments.add(new Argument(WebDriver.class, driver));

        // Then either an ElementInfo or a Table Info
        if (tableInfo != null) {
            arguments.add(new Argument(TableInfo.class, tableInfo));
        } else {
            arguments.add(new Argument(ElementInfo.class, elementInfo));
        }

        // If there's a date format, that's next
        if (dateFormatInfo != null) {
            arguments.add(new Argument(DateFormatInfo.class, dateFormatInfo));
        }

        return arguments;
    }

    public static Object createChildComponent(Class<?> requestedComponentType, Class<?> genericTypeParameter,
                                              WebDriver driver, ElementInfo elementInfo, TableInfo tableInfo,
                                              DateFormatInfo dateFormatInfo) throws ComponentCreationException {
        final List<Argument> arguments = getComponentArguments(genericTypeParameter, driver, elementInfo, tableInfo, dateFormatInfo);
        final Class<?>[] argumentTypes = ListUtils.map(arguments, Argument::getArgumentType).toArray(new Class<?>[0]);
        final Object[] argumentValues = ListUtils.map(arguments, Argument::getArgumentValue).toArray(new Object[0]);

        Class<?> concreteComponentType = getConcreteComponentType(driver, requestedComponentType);
        try {
            // Call the constructor. If the constructor is private/protected,
            // call it anyway - leaving it non-public was probably an accident. (To really prevent
            // a class from being instantiated as a component, make it abstract.)
            Constructor<?> constructor = concreteComponentType.getDeclaredConstructor(argumentTypes);
            constructor.setAccessible(true);
            return constructor.newInstance(argumentValues);
        } catch (NoSuchMethodException e) {
            final String argumentTypesAsString = Arrays.stream(argumentTypes)
                    .map(Class::getSimpleName)
                    .collect(Collectors.joining(", "));
            throw new ComponentCreationException("Error creating component " + concreteComponentType.getName() +
                    " with argument types " + argumentTypesAsString +
                    ": " + e.getMessage(), e);
        } catch (IllegalAccessException | InvocationTargetException | InstantiationException e) {
            throw new ComponentCreationException("Error creating component " + concreteComponentType.getName() + ": " + e.getMessage(), e);
        }
    }

    @Nullable
    private static Class<?> getGenericTypeParameter(Field field) throws ClassNotFoundException {
        String genericName = field.getGenericType().getTypeName();

        if (genericName.contains("<")) {
            genericName = genericName.substring(genericName.indexOf("<") + 1, genericName.indexOf(">"));
            return Class.forName(genericName);
        }

        return null;
    }

    private static By getByLocator(ComponentLocators linkElement, String[] arguments, WebDriver driver) {

        if (!linkElement.xpath().equals("")) {
            String identifier = StringUtils.expandXPathPlaceholders(linkElement.xpath(), arguments);
            return By.xpath(identifier);
        } else if (!linkElement.className().equals("")) {
            String identifier = StringUtils.expandXPathPlaceholders(linkElement.className(), arguments);
            return By.className(identifier);
        } else if (!linkElement.id().equals("")) {
            String identifier = StringUtils.expandXPathPlaceholders(linkElement.id(), arguments);

            String browserType = (String) ((RemoteWebDriver) driver).getCapabilities().asMap().get("BROWSER_NAME");
            if (browserType != null && browserType.equals("Android") && !identifier.contains("id/")) {
                return By.xpath("//*[contains(@resource-id,'id/" + identifier + "')]");
            }
            return By.id(identifier);
        } else if (!linkElement.linkText().equals("")) {
            String identifier = StringUtils.expandXPathPlaceholders(linkElement.linkText(), arguments);
            return By.linkText(identifier);
        } else if (!linkElement.name().equals("")) {
            String identifier = StringUtils.expandXPathPlaceholders(linkElement.name(), arguments);
            return By.name(identifier);
        } else if (!linkElement.partialLinkText().equals("")) {
            String identifier = StringUtils.expandXPathPlaceholders(linkElement.partialLinkText(), arguments);
            return By.partialLinkText(identifier);
        }

        return null;
    }

    /**
     * Wraps an annotation in an interface, which then passes calls on to the
     * annotation. The interface is assumed to have methods identical to those
     * on the annotation. This gives us a way to pass around ordinary data
     * objects instead of annotations.
     *
     * @param annotation  The annotation to wrap
     * @param targetClass The interface class to return
     * @param <T>         Type of the interface to return
     * @return An instance of T that forwards calls to annotation
     */
    @Contract(pure = true)
    private static <T> T wrap(Annotation annotation, Class<T> targetClass) {
        final Object proxy = Proxy.newProxyInstance(
                ComponentFactory.class.getClassLoader(),
                new Class<?>[]{targetClass},
                new AnnotationWrapperInvocationHandler(annotation));
        return targetClass.cast(proxy);
    }

    @Value.Immutable
    public interface ComponentWaitInfo {
        String getWaitMethodName();
        Duration getTimeout();
    }

    public static class ComponentCreationException extends Exception {
        public ComponentCreationException(String s, Throwable throwable) {
            super(s, throwable);
        }
    }

    private static class Argument {
        private final Class<?> argumentType;
        private final Object argumentValue;

        private Argument(Class<?> argumentType, Object argumentValue) {
            this.argumentType = argumentType;
            this.argumentValue = argumentValue;
        }

        public Class<?> getArgumentType() {
            return argumentType;
        }

        public Object getArgumentValue() {
            return argumentValue;
        }
    }

    private static class AnnotationWrapperInvocationHandler implements InvocationHandler {
        private final Annotation annotation;

        private AnnotationWrapperInvocationHandler(Annotation annotation) {
            this.annotation = annotation;
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            // Assume that annotation methods are parameterless
            Method targetMethod = annotation.getClass().getMethod(method.getName());
            return targetMethod.invoke(annotation);
        }
    }
}