package utils2.page_components;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.element_utils.ElementUtils;

import java.time.Duration;

public class GenericComponent extends Component {

    public GenericComponent(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
    }

    public void click() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).click();
        waitForComponent();

    }

    public void clickAndWait(Duration duration) {
        click();
        ThreadUtils.sleep(duration);
    }

    public void injectTextNode(String textToInject) {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).injectTextNode(textToInject);
    }


    public void click_JS() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).click_JS();
        waitForComponent();
    }

    public BaseValidations verify() {
        return new BaseValidations(_elementInfo.getFriendlyName(), findNullableElement());
    }

    public String getText() {
        return new ElementUtils(_elementInfo.getFriendlyName(), findElement()).getText();
    }

    public String getAttribute(String attributeToGet) {
        return new ElementUtils(_elementInfo.getFriendlyName(), findElement()).getAttribute(attributeToGet);
    }

    public String getCSSValue(String attributeToGet) {
        return new ElementUtils(_elementInfo.getFriendlyName(), findElement()).getCSSValue(attributeToGet);
    }

    public void hover() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).hover();
    }

    @Override
    public String toString() {
        return _elementInfo.getFriendlyName();
    }
}
