package utils2.page_components;

import utils2.page_components.*;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface MobilePlatformSelector {
    Class<? extends Component> android();
    Class<? extends Component> ios();
}
