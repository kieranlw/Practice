package utils2.page_components;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Quotes;
import utils2.Index;
import utils2.page_components.element_utils.ElementUtils;

import java.time.Duration;
import java.util.List;

public class DropDown extends Component {

    public DropDown(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
    }

    public DropdownValidations verify() {
        return new DropdownValidations(_elementInfo.getFriendlyName(), findNullableElement());
    }

    public String getSelectedOption() {
        return new ElementUtils(_elementInfo.getFriendlyName(), findElement()).getSelectedOption();
    }

    public void selectValue(String valueToSelect) {
        if(valueToSelect == null) return; //Don't attempt anything if valueToSet is null
        WaitUtils waitUtils = new WaitUtils(_driver, _elementInfo, Duration.ofSeconds(5));
        waitUtils.secondaryElementExists(By.xpath(".//option[normalize-space(.) = " + Quotes.escape(valueToSelect) + "]"));
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).selectValue(valueToSelect);
    }

    public void selectValuePartialMatch(String valueToSelect) {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).selectValueByPartialMatch(valueToSelect);
    }

    public void selectValueByIndex(Index indexToSelect) {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).selectValueByIndex(indexToSelect);
    }

    public List<String> getAllOptions(){
        return new ElementUtils(_elementInfo.getFriendlyName(), findElement()).getOptions();
    }

    public void click() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).click();
    }

    public void click_JS() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).click_JS();
    }

    private Label option_ByText(String text){
        ElementInfo optionElementInfo = ElementInfo.createElementInfo("Option Element for " + text,
                By.xpath(_elementInfo.getElementXpath() + "//option[normalize-space(.) = " + Quotes.escape(text) + "]"));
        return new Label(_driver, optionElementInfo);
    }

    public String getOptionValue(String textOfOption){
       Label optionElement = option_ByText(textOfOption);
       return optionElement.getAttribute("value");
    }

}
