package utils2.page_components;

import common.ListUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.openqa.selenium.WebDriver;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class DateDropdown extends DropDown {
    private final DateFormatInfo dateFormat;

    /**
     * Called by {@link ComponentFactory} if the
     * page object doesn't have a @DateFormat annotation.
     *
     * @param driver      The WebDriver
     * @param elementInfo Element information from the @FindBy annotation
     */
    @SuppressWarnings("unused")
    public DateDropdown(WebDriver driver, ElementInfo elementInfo) {
        this(driver, elementInfo, null);
    }

    /**
     * Called by {@link ComponentFactory} if the
     * page object has a @DateFormat annotation.
     *
     * @param driver      The WebDriver
     * @param elementInfo Element information from the @FindBy annotation
     * @param dateFormat  Describes the date format to use, or null for the default M/d/yyyy
     */
    @SuppressWarnings("WeakerAccess")
    public DateDropdown(WebDriver driver, ElementInfo elementInfo, @Nullable DateFormatInfo dateFormat) {
        super(driver, elementInfo);
        this.dateFormat = dateFormat != null ? dateFormat : new DateFormatInfo("M/d/yyyy");
    }

    private DateTimeFormatter getFormat() {
        return DateTimeFormatter.ofPattern(dateFormat.getFormat());
    }

    @NotNull
    public LocalDate getSelectedDate() {
        final String text = getSelectedOption();
        return LocalDate.parse(text, getFormat());
    }

    public void selectDate(LocalDate valueToSelect) {
        selectValue(valueToSelect.format(getFormat()));
    }

    public List<LocalDate> getAllDates() {
        return ListUtils.map(getAllOptions(), d -> LocalDate.parse(d, getFormat()));
    }
}
