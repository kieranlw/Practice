package utils2.page_components;

import org.openqa.selenium.WebDriver;
import utils2.page_components.element_utils.ElementUtils;

/**
 * Check/uncheck methods are done via JavaScript. Used for weird cases where the checkbox is covered
 * by another element, but if the user clicked that element, it would check/uncheck the checkbox anyway
 * (e.g. if the checkbox is covered by a label whose for= attribute references the checkbox).
 */
public class CheckBox_CheckViaJS extends CheckBox {
    public CheckBox_CheckViaJS(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
    }

    @Override
    public void check() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).check_JS();
    }

    @Override
    public void uncheck() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).uncheck_JS();
    }
}
