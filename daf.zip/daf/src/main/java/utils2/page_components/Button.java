package utils2.page_components;

import org.openqa.selenium.WebDriver;
import utils2.page_components.element_utils.ElementUtils;

public class Button extends GenericComponent {

    public Button(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
    }

    @Override
    public void injectTextNode(String textToInject) {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).injectTextNode(textToInject);
    }

    public boolean isEnabled() {
        return new ElementUtils(_elementInfo.getFriendlyName(), findElement()).isEnabled();
    }
}
