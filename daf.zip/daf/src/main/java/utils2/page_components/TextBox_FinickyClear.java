package utils2.page_components;

import org.openqa.selenium.WebDriver;
import utils2.page_components.element_utils.ElementUtils;

public class TextBox_FinickyClear extends TextBox {

    public TextBox_FinickyClear(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
    }

    @Override
    public TextBox_FinickyClear enterText(String valueToSet) {
        ElementUtils elementUtils = new ElementUtils(_elementInfo.getFriendlyName(), findElement());
        elementUtils.enterText_Finicky(valueToSet);

        return this;
    }
}

