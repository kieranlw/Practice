package utils2.page_components;

import common.ThreadUtils;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.*;
import utils2.AppiumDesktop;
import utils2.AppiumUtils;
import utils2.DriverUtils;
import utils2.page_components.element_utils.ElementFinder;
import utils2.page_components.element_utils.ElementUtils;

import java.time.Duration;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public class Component {

    protected WebDriver _driver;
    protected ElementInfo _elementInfo;
    private ElementFinder _elementFinder;

    protected Component(WebDriver driver, ElementInfo elementInfo) {
        _driver = driver;
        _elementInfo = elementInfo;
        _elementFinder = new ElementFinder(_driver, _elementInfo);
    }

    public void scrollTo() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).scrollToElement();
    }

    //Scrolls to element and then scrolls a certain y offset
    public void scrollToWithYOffset(int yOffset) {
        scrollTo();
        new DriverUtils(_driver).scrollByYOffset(yOffset);
    }

    public boolean exists() {
        return findNullableElement() != null;
    }

    protected void waitForComponent() {
        if (_elementInfo.getWaitSupplier() != null) {
            WaitUtils.conditionMet(
                    _elementInfo.getWaitSupplier(),
                    "wait logic for component \"" + _elementInfo.getFriendlyName() + "\"",
                    _elementInfo.getDurationToWait());
        }
        if (_elementInfo.getDurationToSleep().toMillis() > 0) {
            ThreadUtils.sleep(_elementInfo.getDurationToSleep().toMillis());
        }
    }

    public Rectangle getBoundingRectangle() {
        WebElement element = findElement();

        if (AppiumDesktop.isWindowsPlatform(_driver)) {
            // WinAppDriver returns non-useful values when you call getLocation/getSize on a
            // top-level window - they don't line up with the actual window size or position.
            // Use the "BoundingRectangle" attribute instead; it matches up with Inspect.exe.
            String boundingRectangle = element.getAttribute("BoundingRectangle");
            // boundingRectangle will be a string of the form: "Left:5 Top:10 Width:99 Height:99"
            Map<String, Integer> rectangleProperties = Arrays.stream(boundingRectangle.split(" "))
                    .map(term -> term.split(":", 2))
                    .collect(Collectors.toMap(pair -> pair[0], pair -> Integer.parseInt(pair[1])));
            // Yes, Rectangle's constructor really puts the height parameter before width
            return new Rectangle(
                    rectangleProperties.get("Left"), rectangleProperties.get("Top"),
                    rectangleProperties.get("Height"), rectangleProperties.get("Width"));
        } else {
            Point location = element.getLocation();
            Dimension size = element.getSize();
            return new Rectangle(location, size);
        }
    }

    public int getXCoordinate() {
        return findElement().getLocation().x;
    }

    public int getYCoordinate() {
        return findElement().getLocation().y;
    }

    public void scrollDownUntilVisible(Component elementToScrollTo) {
        new AppiumUtils((AppiumDriver<?>) _driver).scrollDownUntilVisible(this, elementToScrollTo);
    }

    public void swipeTo(Component elementToSwipeTo) {
        new AppiumUtils((AppiumDriver<?>) _driver).swipe(this, elementToSwipeTo);
    }

    public WaitUtils waitUntil(Duration timeToWait) {
        return new WaitUtils(_driver, _elementInfo, timeToWait);
    }

    public boolean isDisplayed() {
        WebElement element = findNullableElement();
        return (element == null) ? false : element.isDisplayed();
    }

    public ElementInfo getElementInfo() {
        return _elementInfo;
    }

    public WebElement findElement() {
        return _elementFinder.findElement();
    }

    public WebElement getWebElement() {
        return _elementFinder.findElement();
    }

    public WebElement findNullableElement() {
        return _elementFinder.findNullableElement();
    }

    @Override
    public String toString() {
        return "[ Element: " + _elementInfo.getFriendlyName() + " ]";
    }
}
