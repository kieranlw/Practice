package utils2;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import java.io.File;
import java.net.URL;

public class AppiumSetup {



    private DesiredCapabilities addIphoneCapabilities(DesiredCapabilities capabilities){

        //Needs to be updated. Point to a generic folder where any user can access and put the file there.
        //capabilities.setCapability("app", "/Users/t449381/Downloads/Eleanor.iOS.ipa");
        capabilities.setCapability("bundleId", "com.deluxe.eleanor");
        capabilities.setCapability("automationName", "XCUITest");
        capabilities.setCapability("xcodeOrgId", "LX87U2J64W");
        capabilities.setCapability("showXcodeLog", true);
        capabilities.setCapability("xcodeSigningId", "iOS Developer");
        capabilities.setCapability("BROWSER_NAME", "iPhone");
        String deviceType = capabilities.getCapability("device_Type").toString();

        if(!deviceType.isEmpty() && deviceType.equals("fake")) {
            capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
            capabilities.setCapability("appPackage", "com.deluxe.eleanor");
        }
        return capabilities;
    }

    private DesiredCapabilities addAndroidCapabilities(DesiredCapabilities capabilities){

        capabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, "*.LoginActivity");
        //Needs to be updated. Point to a generic folder where any user can access and put the file there.
        capabilities.setCapability("app", "/Users/t449381/Downloads/com.deluxe.eleanor-Signed.apk");
        capabilities.setCapability("newCommandTimeout", 0);
        capabilities.setCapability("forceMjsonwp", true);
        capabilities.setCapability("BROWSER_NAME", "Android");
        String deviceType = capabilities.getCapability("device_Type").toString();

        if(!deviceType.isEmpty() && deviceType.equals("fake")){
            capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "com.deluxe.eleanor");
            capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, "com.deluxe.eleanor");
            capabilities.setCapability("appPackage", "com.deluxe.eleanor");
            capabilities.setCapability("appActivity", "crc64e770ed657aa05117.StartupActivity");
        }
        return capabilities;
    }

    public AppiumDriver<MobileElement> startDriver(File appFile, DesiredCapabilities capabilities) throws Exception {
        AppiumDriver<MobileElement> driver;

        capabilities.setCapability("newCommandTimeout", 0);

        if(capabilities.getCapability("platformName").equals("iOS")){
            addIphoneCapabilities(capabilities);
        }else{
            addAndroidCapabilities(capabilities);
        }
        driver = new AppiumDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        return driver;
    }
}
