package utils2;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverUtils {

    private WebDriver _driver;

    public WebDriverUtils(WebDriver driver){
        _driver = driver;
    }

    public Alert waitForAlert(){
        WebDriverWait wait = new WebDriverWait(_driver, 10);
        wait.until(ExpectedConditions.alertIsPresent());
        return _driver.switchTo().alert();
    }

    public void switchToAlert_Accept() {
        String alertText = null;
        Alert alert = waitForAlert();
        alertText = alert.getText();
        LogInfo.log_Status("Alert message in pop-up window " + alertText);
        alert.accept();
    }

}
