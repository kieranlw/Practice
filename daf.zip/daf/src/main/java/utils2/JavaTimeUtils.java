package utils2;

import org.jetbrains.annotations.NotNull;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class JavaTimeUtils {

    public static LocalDate getLocalDate(String dateString, String format) {
        LocalDate date = null;
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
            date = LocalDate.parse(dateString, formatter);
        } catch (Exception e) {
            LogInfo.log_AndFail("Failed to parse String, error " + e.getMessage());
        }
        return date;
    }

    public static String getTodaysDate(String format) {
        LocalDate date = LocalDate.now();

        return getLocalDateString(date, format);
    }

    public static boolean dateFormatAcceptable(String dateStr, String format) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);

        try {
            LocalDate.parse(dateStr, formatter);
        } catch (DateTimeParseException e) {
            return false;
        }
        return true;
    }

    public static void verifyDateFormatAcceptable(String dateStr, String format) {
        LogInfo.verify_ConditionTrue(dateFormatAcceptable(dateStr, format), "Check that Date String of '" + dateStr + "' is of date format '" + format + "'");
    }

    public static void verify_LocalDateTime_InAcceptableMinuteRange(LocalDateTime expectedDateTime, LocalDateTime actualDateTime, int minutesDifference) {
        LocalDateTime minimumDateTime = expectedDateTime.minusMinutes(minutesDifference);
        LocalDateTime maximumDateTime = expectedDateTime.plusMinutes(minutesDifference);
        boolean timeWithinRange = (minimumDateTime.isBefore(actualDateTime) && maximumDateTime.isAfter(actualDateTime));
        LogInfo.verify_ConditionTrue(timeWithinRange, "Expecting " + getLocalDateTimeString(expectedDateTime, "MM/dd/yyy HH:mm:ss")
                + " to be between " + minimumDateTime + " and " + maximumDateTime + ", Seeing " + actualDateTime);
    }

    public static LocalDateTime getLocalDateTime(String dateString, String format) {
        LocalDateTime date = null;
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
            date = LocalDateTime.parse(dateString, formatter);
        } catch (Exception e) {
            LogInfo.log_AndFail("Failed to parse String, error " + e.getMessage());
        }
        return date;
    }

    public static String getLocalDateString(LocalDate date, String format) {

        String dateString = null;

        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
            dateString = date.format(formatter);
        } catch (Exception e) {
            LogInfo.log_AndFail("Failed to parse String, error " + e.getMessage());
        }
        return dateString;
    }

    public static String getLocalDateTimeString(LocalDateTime date, String format) {

        String dateString = null;

        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
            dateString = date.format(formatter);
        } catch (Exception e) {
            LogInfo.log_AndFail("Failed to parse String, error " + e.getMessage());
        }
        return dateString;
    }

    @NotNull
    public static LocalDate max(List<LocalDate> list) {
        return list.stream()
                .max(LocalDate::compareTo)
                .orElseThrow(() -> new RuntimeException("List contains no values"));
    }
}
