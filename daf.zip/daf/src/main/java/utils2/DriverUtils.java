package utils2;

import common.ThreadUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils2.page_components.*;

import java.text.MessageFormat;
import java.time.Duration;

public class DriverUtils {

    private WebDriver _driver;

    public void scrollByYOffset(int yOffset) {
        JavascriptExecutor jse = (JavascriptExecutor) _driver;
        jse.executeScript("window.scrollBy(0,arguments[0])", yOffset);
    }

    public DriverUtils(WebDriver driver) {
        _driver = driver;
    }

    public void scrollTo(int x, int y) {
        ((JavascriptExecutor) _driver).executeScript("window.scrollTo(arguments[0], arguments[1])", x, y);
    }

    //You will need to do something to determine page is in a state where it is loading before calling this.
    //If the next page has not started loading prior to calling this method, the script will look at prior page and think it's done intermittently.
    public void waitForReadyStateComplete(Duration timeToWait) {
        WebDriverWait wait = new WebDriverWait(_driver, timeToWait.getSeconds());

        LogInfo.log_Status("Waiting for page to finish loading.");
        {
            ExpectedCondition<Boolean> expectation = driver ->
                    ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
                            .equals("complete");

            try {
                wait.until(expectation);
            } catch (Exception e) {
                LogInfo.log_Status("Encountered error waiting for page to finish loading.");
            }
        }
    }

    public void send_KeyWithActionBuilder(String keyToEnter) {
        Actions builder = new Actions(_driver);
        builder.sendKeys(keyToEnter);
        builder.build().perform();
    }

    public void send_KeyWithActionBuilder(Keys key) {
        Actions builder = new Actions(_driver);
        builder.sendKeys(key);
        builder.build().perform();
    }

    public void refreshPage() {
        LogInfo.log_Status("Refreshing Driver");
        _driver.navigate().refresh();
    }

    public void close_ExtraWindows(String primaryWindowHandle) throws Exception {
        if (_driver == null) {
            return;
        }
        // Checks for extra windows and close any that are not the main window.
        if (_driver.getWindowHandles().size() > 1) {
            for (String s : _driver.getWindowHandles()) {
                switch_ToWindow(s);
                if (!s.equals(primaryWindowHandle)) {
                    _driver.close();
                }
            }
            // Switch back to primary window handle after we've closed other windows.
            switch_ToWindow(primaryWindowHandle);
        }
    }

    private void switch_ToWindow(String windowHandle) {
        try {
            _driver.switchTo().window(windowHandle);
            LogInfo.log_AndPass(MessageFormat.format("Successfully switched to window {0}", windowHandle));
        } catch (Exception e) {
            LogInfo.log_AndFail(MessageFormat.format("Unable to switch to window {0}", windowHandle) + "/n"
                    + MessageFormat.format("Encountered error: {0}", e.toString()));
        }
        ThreadUtils.sleep(100);
    }

    public void switch_ToDefaultContent() {
        try {
            _driver.switchTo().defaultContent();
        } catch (Exception e) {
            throw new RuntimeException("Error while trying to switch to default content: " + e.getMessage(), e);
        }
        ThreadUtils.sleep(100);
    }

    public void switch_ToIFrame_ByID(String id) {
        try {
            _driver.switchTo().frame(id);
        } catch (Exception e) {
            throw new RuntimeException("Error while trying to switch to iframe '" + id + "': " + e.getMessage(), e);
        }
        ThreadUtils.sleep(100);
    }

    public <P extends BasePageObject> P clickBrowserBackButton(BasePageObject.PageConstructor<WebDriver, P> pageConstructor) {
        _driver.navigate().back();
        return BasePageObject.createAndLoad(pageConstructor, _driver);
    }

    public void switch_ToIFrame_ByWebElement(WebElement element) {
        try {
            _driver.switchTo().frame(element);
        } catch (Exception e) {
            LogInfo.log_Warning("Encountered error attempting to switch frames " + e.getMessage());
        }
        ThreadUtils.sleep(100);
    }

    public <P extends BasePageObject> P refreshPage(BasePageObject.PageConstructor<WebDriver, P> pageConstructor) {
        _driver.navigate().refresh();
        ThreadUtils.sleep(Duration.ofSeconds(2));
        return BasePageObject.createAndLoad(pageConstructor, _driver);
    }

    public void waitForUrlContains(String partialUrl, Duration timeToWait) {
        WebDriverWait wait = new WebDriverWait(_driver, timeToWait.getSeconds());
        LogInfo.log_Status("Waiting for page URL to contain: " + partialUrl);
        wait.until(ExpectedConditions.urlContains(partialUrl));
    }
}
