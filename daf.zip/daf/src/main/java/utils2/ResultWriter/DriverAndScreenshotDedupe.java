package utils2.ResultWriter;

public class DriverAndScreenshotDedupe {
    
    public String get_DriverString() {
        return _driverString;
    }

    public void set_DriverString(String _driverString) {
        this._driverString = _driverString;
    }

    public String get_ScreenshotInfo() {
        return _screenshotInfo;
    }

    public void set_ScreenshotInfo(String _screenshotInfo) {
        this._screenshotInfo = _screenshotInfo;
    }

    //Create Records of what we've screenshoted to prevent duplicate screenshots
    private String _driverString;
    private String _screenshotInfo;

    public DriverAndScreenshotDedupe(String driverString, String screenshotInfo){
        _driverString = driverString;
        _screenshotInfo = screenshotInfo;
    }

}
