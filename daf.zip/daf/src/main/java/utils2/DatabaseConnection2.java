//// LET 12/14/15: Browser.java
//// Purpose: Contains actions for dealing with opening/closing browsers. The open action specifies a default browser to use
//// but can be overridden by setting a value in testng or ant files.
//// The warning messages in this file can be ignored.
package utils2;

import common.ResourceFile;
import net.sourceforge.jtds.jdbc.ClobImpl;
import org.postgresql.util.PGobject;
import utils.TableData;
import utils2.tableData.Row;

import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class DatabaseConnection2 {
    // CMP database connection string
    // "jdbc:sqlserver://DOMUWD04\\DT01;databaseName=POMSCMP;integratedSecurity=true;";
    // to use jtds driver will need jtds jar. Connection string will look like
    // below. Allows for Windows Credentials
    // jdbc:jtds:sqlserver://[servername]:[port]/[DBName];domain=[DomainName];user=[username];password=[password]

    private String _connectionString;

    private static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss:SSS";

    public DatabaseConnection2(String connectionString) {
        _connectionString = connectionString;
    }

    @FunctionalInterface
    public interface FunctionWithSQLException<T, R> {
        R apply(T t) throws SQLException;
    }

    // TODO Discuss with QEs about adding logging here. We have it on other query executions.
    public void executeUpdate(String query) {
        RuntimeSqlException.withRuntimeSqlExceptions(() -> {
            try (Connection con = DriverManager.getConnection(_connectionString);
                 Statement stmt = con.createStatement()) {
                stmt.executeUpdate(query);
            }
        });
    }

    // Function to connect to SQL Server - and run a query
    public TableData2 runSQLServerQuery(String query) {
        return RuntimeSqlException.withRuntimeSqlExceptions(() -> {
            try (Connection con = DriverManager.getConnection(_connectionString);
                 Statement stmt = con.createStatement()) {

                ResultSet rs = stmt.executeQuery(query);

                List<Row> rowList = new ArrayList<>();

                int count = 0;
                while (rs.next()) {

                    Map<String, String> dataRow = new HashMap<String, String>();
                    // Used to get Column Header
                    ResultSetMetaData rsmd = rs.getMetaData();
                    int columnCount = rsmd.getColumnCount();

                    // The column count starts from 1
                    for (int i = 1; i <= columnCount; i++) {
                        // Column header
                        String key = rsmd.getColumnName(i);

                        Object cell = rs.getObject(i);
                        String value = returnValue(cell);

                        dataRow.put(key, value);
                    }

                    rowList.add(new Row(dataRow));
                    count++;
                }

                LogInfo.log_Status("Successfully ran query.  Returning Data.");

                return new TableData2(rowList);
            }
        });
    }

    public static String getDBOffsetHoursSql() {
        return new ResourceFile("utils2/DBOffset.sql").readAllText();
    }

    public int getDBOffsetHours() {

        String query = getDBOffsetHoursSql();

        TableData2 creationTableLastResult = runSQLServerQuery(query);
        String[] resultSplit = creationTableLastResult.data.get(0).get("Result").split("\\s");
        String timeOffSet = resultSplit[resultSplit.length - 1];
        timeOffSet = timeOffSet.split("\\:")[0];
        return Integer.parseInt(timeOffSet);
    }

    public static String getDateTimeFormat() {
        return DATE_TIME_FORMAT;
    }

    // Function to connect to SQL Server - and run a query
    public TableData2 runSQLServerQuery(String query, Object... queryVariables) {
        return executeQuery(query, queryVariables, rs -> {
            List<Row> rowList = new ArrayList<>();

            int count = 0;
            while (rs.next()) {

                Map<String, String> dataRow = new HashMap<String, String>();
                // Used to get Column Header
                ResultSetMetaData rsmd = rs.getMetaData();
                int columnCount = rsmd.getColumnCount();

                // The column count starts from 1
                for (int i = 1; i <= columnCount; i++) {
                    // Column header
                    String key = rsmd.getColumnName(i);

                    Object cell = rs.getObject(i);
                    String value = returnValue(cell);

                    dataRow.put(key, value);
                }

                rowList.add(new Row(dataRow));
                count++;
            }

            LogInfo.log_Status("Successfully ran query.  Returning Data.");

            return new TableData2(rowList);
        });
    }

    private <T> T executeQuery(String query, Object[] queryVariables, FunctionWithSQLException<ResultSet, T> extractValue) {
        return RuntimeSqlException.withRuntimeSqlExceptions(() -> {
            try (Connection con = DriverManager.getConnection(_connectionString);
                 PreparedStatement stmt = con.prepareStatement(query)) {

                for (int i = 0; i < queryVariables.length; i++) {
                    stmt.setString(i + 1, queryVariables[i].toString());
                }
                return extractValue.apply(stmt.executeQuery());
            }
        });
    }

    public int runSQLServerScalarQueryInt(String query, Object... queryVariables) {
        return executeQuery(query, queryVariables, resultSet -> extractScalar(resultSet, rs -> rs.getInt(1)));
    }

    /**
     * Runs a query and returns a single value.
     *
     * @param query SQL query
     * @param type  Type to return, e.g. LocalDate.class
     * @param <T>   Type to return
     * @return The single value from the single row of the query results
     * @throws RuntimeSqlException There was an error running the query, or the query didn't return a single row and column
     */
    public <T> T queryValue(String query, Class<T> type) {
        return queryValue(query, new Object[]{}, type);
    }

    /**
     * Runs a parameterized query and returns a single value.
     *
     * @param query          SQL query
     * @param queryVariables Values for "?" placeholders in the SQL
     * @param type           Type to return, e.g. LocalDate.class
     * @param <T>            Type to return
     * @return The single value from the single row of the query results
     * @throws RuntimeSqlException There was an error running the query, or the query didn't return a single row and column
     */
    public <T> T queryValue(String query, Object[] queryVariables, Class<T> type) {
        return executeQuery(query, queryVariables, resultSet -> extractScalar(resultSet, rs -> rs.getObject(1, type)));
    }

    // Function to connect to SQL Server - and run a query as a command without
    // returning any datasets
    public void runSQLServerCommand(String query) {
        RuntimeSqlException.withRuntimeSqlExceptions(() -> {
            try (Connection con = DriverManager.getConnection(_connectionString);
                 Statement stmt = con.createStatement()) {
                stmt.execute(query);
            }
        });
    }

    /**
     * Use this function to connect to SQL Server - and run a parameterized query as a command without
     * returning any dataset
     *
     * @param query
     * @param queryVariables
     */
    public void runSQLServerUpdateWithParameters(String query, Object... queryVariables) {
        RuntimeSqlException.withRuntimeSqlExceptions(() -> {
            try (Connection con = DriverManager.getConnection(_connectionString);
                 PreparedStatement stmt = con.prepareStatement(query)) {

                for (int i = 0; i < queryVariables.length; i++) {
                    stmt.setString(i + 1, queryVariables[i].toString());
                }
                stmt.executeUpdate();
            }
        });
    }

    // Function to connect to SQL Server - and run a query as a command without
    // returning any datasets
    public void runSQLServerUpdate(String query) {
        RuntimeSqlException.withRuntimeSqlExceptions(() -> {
            try (Connection con = DriverManager.getConnection(_connectionString);
                 Statement stmt = con.createStatement()) {
                stmt.executeUpdate(query);
            }
        });
    }

    // Function to connect to SQL Server - and run a query
    public TableData runSQLServerCommand_AndThenQuery(String command, String query) {
        return RuntimeSqlException.withRuntimeSqlExceptions(() -> {
            try (Connection con = DriverManager.getConnection(_connectionString);
                 Statement cmnd = con.createStatement()) {

                cmnd.executeUpdate(command);

                try (Statement stmt = con.createStatement()) {
                    ResultSet rs = stmt.executeQuery(query);

                    TableData tableData = new TableData();
                    // ArrayList<Object> dataList = new ArrayList<Object>();
                    // This gets tricky - we need to know the return type of each field that we're
                    // pulling back. Yikes.
                    while (rs.next()) {

                        HashMap<String, String> dataRow = new HashMap<String, String>();
                        // Used to get Column Header
                        ResultSetMetaData rsmd = rs.getMetaData();
                        int columnCount = rsmd.getColumnCount();

                        // The column count starts from 1
                        for (int i = 1; i <= columnCount; i++) {
                            // Column header
                            String key = rsmd.getColumnName(i);

                            Object cell = rs.getObject(i);
                            String value = returnValue(cell);

                            dataRow.put(key, value);
                        }

                        tableData.data.add(dataRow);
                    }

                    LogInfo.log_Status("Successfully ran query.  Returning Data.");

                    return tableData;
                }
            }
        });
    }

    public String returnValue(Object cell) {
        String str = null;

        if (cell instanceof String) {
            // do you work here for string like below
            str = (String) cell;
        } else if (cell instanceof Integer) {
            str = Integer.toString((Integer) cell);
            // do cell work for Integer
        } else if (cell instanceof Double) {
            str = Double.toString((Double) cell);
        } else if (cell instanceof BigDecimal) {
            str = ((BigDecimal) cell).toString();
        } else if (cell instanceof Long) {
            str = Long.toString((Long) cell);
        } else if (cell instanceof Short) {
            str = Short.toString((Short) cell);
        } else if (cell instanceof Timestamp) {
            str = new SimpleDateFormat(DATE_TIME_FORMAT).format((Timestamp) cell);
        } else if (cell instanceof Boolean) {
            str = (Boolean) cell == true ? "1" : "0";
        } else if (cell instanceof ClobImpl) {
            str = RuntimeSqlException.withRuntimeSqlExceptions(() -> {
                ClobImpl newClob = (ClobImpl) cell;
                if (newClob.length() >= 1) {
                    return newClob.getSubString(1, (int) newClob.length());
                } else {
                    return null;
                }
            });
        } else if (cell instanceof UUID) {
            str = ((UUID) cell).toString();
        } else if (cell instanceof PGobject) {
            str = ((PGobject) cell).getValue();
        }

        return str;
    }

    private <T> T extractScalar(ResultSet rs, FunctionWithSQLException<ResultSet, T> extractValue) {
        return RuntimeSqlException.withRuntimeSqlExceptions(() -> {
            ResultSetMetaData rsmd = rs.getMetaData();

            int columnCount = rsmd.getColumnCount();
            if (columnCount != 1) {
                throw new RuntimeSqlException("Scalar query should return a resultset of a single column; This one resulted in " + columnCount + " columns.");
            }

            if (rs.next()) {
                T result = extractValue.apply(rs);
                if (rs.next()) {
                    throw new RuntimeSqlException("Scalar query should return a resultset of a single row; This one resulted returned more than one row.");
                }
                return result;
            } else {
                throw new RuntimeSqlException("Scalar query should return a resultset of a single row; This one resulted returned no rows.");
            }
        });
    }
}
