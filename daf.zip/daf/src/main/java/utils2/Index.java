package utils2;

import java.util.Objects;

public final class Index {
    private final int _zeroBasedIndex;

    public static Index createIndex_FromZeroBasedInt(int zeroBasedIndex) {
        return zeroBased(zeroBasedIndex);
    }

    public static Index zeroBased(int zeroBasedIndex) {
        return new Index(zeroBasedIndex);
    }

    public static Index oneBased(int oneBasedIndex) {
        return new Index(oneBasedIndex - 1);
    }

    private Index(int zeroBasedIndex) {
        _zeroBasedIndex = zeroBasedIndex;
    }

    public Index getIndexPlusOrMinusInt(int indexOffSet) {
        return plus(indexOffSet);
    }

    public Index plus(int indexOffSet) {
        return zeroBased(_zeroBasedIndex + indexOffSet);
    }

    public int get_ZeroBasedIndex() {
        return asZeroBased();
    }

    public int asZeroBased() {
        return _zeroBasedIndex;
    }

    public int get_OneBasedIndex() {
        return asOneBased();
    }

    public int asOneBased() {
        return _zeroBasedIndex + 1;
    }

    public Index increment() {
        return zeroBased(_zeroBasedIndex + 1);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Index index = (Index) o;
        return _zeroBasedIndex == index._zeroBasedIndex;
    }

    @Override
    public int hashCode() {
        return Objects.hash(_zeroBasedIndex);
    }

    @Override
    public String toString() {
        return "Index{" +
                "zeroBasedIndex=" + _zeroBasedIndex +
                '}';
    }
}
