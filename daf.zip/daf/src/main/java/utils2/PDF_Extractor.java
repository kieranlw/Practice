package utils2;

import common.*;
import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.io.RandomAccessFile;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.testng.asserts.SoftAssert;

import java.io.File;
import java.io.IOException;

public class PDF_Extractor {
    /**
     * <p>
     * Loads a PDF as a list of rows and cells.
     * </p><p>
     * This method correctly handles PDFs whose columns were written out of order (such
     * as Payroll's "Payroll Summary" report), unlike PdfBox's default PDFTextStripper.
     * So if you have that kind of out-of-order PDF, you're better off with this than
     * with the String[] method below.
     * </p>
     *
     * @param file File to load
     * @return PDF content
     */
    public static PdfContent loadPdfContent(ReadableFile file) {
        try (PDDocument doc = PDDocument.load(file.toFile())) {
            final PdfContentExtractor extractor = new PdfContentExtractor();
            extractor.getText(doc);
            return new PdfContent(extractor.getRows());
        } catch (IOException e) {
            throw new RuntimeException("Error loading PDF file '" + file.getAbsolutePath() + ": " + e.getMessage(), e);
        }
    }

    public static String[] getPDF_Extract(String fileLocation) throws IOException {
        RandomAccessFile randomAccessRead = new RandomAccessFile(new File(fileLocation), "rw");
        PDFParser parser = new PDFParser(randomAccessRead);
        parser.parse();
        COSDocument cosDoc = parser.getDocument();
        PDFTextStripper pdfStripper = new PDFTextStripper();
        PDDocument pdDoc = new PDDocument(cosDoc);
        String text = pdfStripper.getText(pdDoc);
        String[] docxLines = text.split(System.lineSeparator());

        return docxLines;
    }

    public static void verify_PDF_TextMatch(File testFile, File actualFile) throws Exception {
        LogInfo.log_Status("Comparing " + actualFile + " to " + testFile);

        String[] testFileExtract = getPDF_Extract(testFile.getAbsolutePath());
        String[] actualFileExtract = getPDF_Extract(actualFile.getAbsolutePath());

        Verify.that(actualFileExtract.length, Is.equalTo(testFileExtract.length), "PDF lengths in lines");

        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < testFileExtract.length; i++) {
            softAssert.assertTrue(testFileExtract[i].equals(actualFileExtract[i]), "Expected line '" + i + "' to match '" + testFileExtract[i] + "', but seeing '" + actualFileExtract[i] + "'");
        }

        softAssert.assertAll();
    }

    public static void verify_PDF_OmitLinesWith(File testFile, File actualFile, String omit_lines_with) throws Exception {
        LogInfo.log_Status("Comparing " + actualFile + " to " + testFile);

        String[] testFileExtract = getPDF_Extract(testFile.getAbsolutePath());
        String[] actualFileExtract = getPDF_Extract(actualFile.getAbsolutePath());

        Verify.that(actualFileExtract.length, Is.equalTo(testFileExtract.length), "PDF lengths in lines");

        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < testFileExtract.length; i++) {
            if (testFileExtract[i].contains(omit_lines_with)) continue;
            softAssert.assertTrue(testFileExtract[i].equals(actualFileExtract[i]), "Expected line '" + i + "' to match '" + testFileExtract[i] + "', but seeing '" + actualFileExtract[i] + "'");
        }
        softAssert.assertAll();
    }

    public static void verify_PDF_OmitLinesWith_LogsWithEmployeeNumber(File testFile, File actualFile, String omit_lines_with) throws Exception {
        LogInfo.log_Status("Comparing " + actualFile + " to " + testFile);

        String[] testFileExtract = getPDF_Extract(testFile.getAbsolutePath());
        String[] actualFileExtract = getPDF_Extract(actualFile.getAbsolutePath());

        Verify.that(actualFileExtract.length, Is.equalTo(testFileExtract.length), "PDF lengths in lines");

        String regex = "\\d{1,15}";
        String empNumber = "";

        SoftAssert softAssert = new SoftAssert();
        for (int i = 0; i < testFileExtract.length; i++) {
            boolean result = testFileExtract[i].matches(regex);
            if (result) {
                empNumber = testFileExtract[i];
            }
            if (testFileExtract[i].contains(omit_lines_with)) continue;
            softAssert.assertTrue(testFileExtract[i].equals(actualFileExtract[i]), (!empNumber.equals("") ? ("Failed for employee: '" + empNumber + "' ") : "") + "Expected line '" + i + "' to match '" + testFileExtract[i] + "', but seeing '" + actualFileExtract[i] + "'");
        }
        softAssert.assertAll();
    }
}

