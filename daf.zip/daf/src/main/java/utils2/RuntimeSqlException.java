package utils2;

import java.sql.SQLException;

public class RuntimeSqlException extends RuntimeException {

    public RuntimeSqlException(String s) {
        super(s);
    }

    public RuntimeSqlException(String s, SQLException sqlException) {
        super(s, sqlException);
    }

    /**
     * Calls the given code, and turns IOExceptions to RuntimeSqlExceptions
     * so that they don't have to be declared as checked exceptions.
     *
     * @param action Code to run
     */
    public static void withRuntimeSqlExceptions(RunnableWithSqlException action) {
        try {
            action.run();
        } catch (SQLException e) {
            throw new RuntimeSqlException(e.getMessage(), e);
        }
    }

    /**
     * Calls the given code and returns its result, and turns IOExceptions to
     * RuntimeSqlExceptions so that they don't have to be declared as checked exceptions.
     *
     * @param producer Code to run
     */
    public static <T> T withRuntimeSqlExceptions(ProducerWithSqlException<T> producer) {
        try {
            return producer.produce();
        } catch (SQLException e) {
            throw new RuntimeSqlException(e.getMessage(), e);
        }
    }

    public interface ProducerWithSqlException<ReturnType> {
        ReturnType produce() throws SQLException;
    }

    public interface RunnableWithSqlException {
        void run() throws SQLException;
    }
}
