package utils2.pageControls.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface ControlFindBy {
    String friendlyName() default "";
    String id() default "";
    String name() default "";
    String className() default "";
    String linkText() default "";
    String partialLinkText() default "";
    String xpath() default "";
}
