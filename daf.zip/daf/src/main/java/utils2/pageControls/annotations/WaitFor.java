package utils2.pageControls.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface WaitFor {

    String waitMethodName() default "";
    int waitForDurationInMilliseconds() default 5000;
    int sleepForGivenMilliseconds() default 0;

}
