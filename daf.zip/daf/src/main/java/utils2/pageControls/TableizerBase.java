package utils2.pageControls;

import org.openqa.selenium.WebDriver;
import utils2.page_components.TableInfo;

public class TableizerBase extends utils2.page_components.TableizerBase {
    public TableizerBase(WebDriver driver, TableInfo tableInfo) {
        super(driver, tableInfo);
    }
}
