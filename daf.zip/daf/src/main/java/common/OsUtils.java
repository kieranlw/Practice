package common;

public class OsUtils {

    public static boolean isMac(){

        return System.getProperty("os.name").toLowerCase().contains("mac");

    }

}
