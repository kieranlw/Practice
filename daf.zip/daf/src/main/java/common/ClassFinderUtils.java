package common;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.*;

public class ClassFinderUtils {

    /**
     * Scans all classes accessible from the context class loader with belong to the given package and subpackages
     * that can be assigned to the passed in class
     *
     * @param packageName The packageName to scan
     * @param assignableClass Assignable class to filter on
     * @return Class[] for the classes for use in a dataprovider
     * @throws ClassNotFoundException
     * @throws IOException
     */
    public static <C> Class<?>[] getAssignableClasses(String packageName, Class<C> assignableClass) throws ClassNotFoundException, IOException {
        return Arrays.stream(ClassFinderUtils.getClasses(packageName))
                .filter(clz -> assignableClass.isAssignableFrom(clz) )
                .toArray(Class[]::new);
    }

    /**
     * Scans all classes accessible from the context class loader which belong to the given package and subpackages.
     *
     * @param packageName The base package
     * @return The classes
     * @throws ClassNotFoundException
     * @throws IOException
     */
    public static Class<?>[] getClasses(String packageName) throws ClassNotFoundException, IOException {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        assert classLoader != null;
        String path = packageName.replace('.', '/');
        Enumeration<URL> resources = classLoader.getResources(path);
        ArrayList<Class<?>> classes = new ArrayList<>();
        while (resources.hasMoreElements()) {
            URL resource = resources.nextElement();
            File file = new File(resource.getFile());
            if (file.exists() && file.isDirectory()) {
                classes.addAll(findClasses(file, packageName));
            }
        }
        return classes.toArray(new Class<?>[0]);
    }

    /**
     * Recursive method used to find all classes in a given directory and subdirs.
     *
     * @param directory   The base directory
     * @param packageName The package name for classes found inside the base directory
     * @return The classes
     * @throws ClassNotFoundException
     */
    public static List<Class<?>> findClasses(File directory, String packageName) throws ClassNotFoundException {
        List<Class<?>> classes = new ArrayList<>();
        if (!directory.exists()) { return classes; }
        File[] files = directory.listFiles();
        for (File file : files) {
            if (file.isDirectory()) {
                assert !file.getName().contains(".");
                classes.addAll(findClasses(file, packageName + "." + file.getName()));
            } else if (file.getName().endsWith(".class")) {
                classes.add(Class.forName(packageName + '.' + file.getName().substring(0, file.getName().length() - 6)));
            }
        }
        return classes;
    }

}

