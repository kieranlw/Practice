package common;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

public class Cache<K, V> {
    private final Function<K, V> supplier;
    private final Map<K, V> cache = new HashMap<>();

    public Cache(Function<K, V> supplier) {
        this.supplier = supplier;
    }

    public V get(K key) {
        if (cache.containsKey(key)) {
            return cache.get(key);
        } else {
            V value = supplier.apply(key);
            cache.put(key, value);
            return value;
        }
    }

    public Set<Map.Entry<K, V>> entrySet() {
        return cache.entrySet();
    }

    public Collection<V> values() {
        return cache.values();
    }

    public boolean isEmpty() {
        return cache.isEmpty();
    }
}
