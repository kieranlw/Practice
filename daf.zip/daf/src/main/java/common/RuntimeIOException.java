package common;

import java.io.IOException;

/**
 * Unchecked-exception version of IOException. For when you mostly just want
 * to do something, and if it fails, you're OK with failing the test rather
 * than adding "throws IOException" everywhere - but still catchable if you
 * need to handle it a few places.
 */
public class RuntimeIOException extends RuntimeException {
    public RuntimeIOException(String s) {
        super(s);
    }

    public RuntimeIOException(String s, Throwable throwable) {
        super(s, throwable);
    }

    /**
     * Calls the given code, and turns IOExceptions to RuntimeIOExceptions
     * so that they don't have to be declared as checked exceptions.
     *
     * @param action Code to run
     */
    public static void withRuntimeIOExceptions(RunnableWithIOException action) {
        try {
            action.run();
        } catch (IOException e) {
            throw new RuntimeIOException(e.getMessage(), e);
        }
    }

    /**
     * Calls the given code and returns its result, and turns IOExceptions to
     * RuntimeIOExceptions so that they don't have to be declared as checked exceptions.
     *
     * @param producer Code to run
     */
    public static <T> T withRuntimeIOExceptions(ProducerWithIOException<T> producer) {
        try {
            return producer.produce();
        } catch (IOException e) {
            throw new RuntimeIOException(e.getMessage(), e);
        }
    }

    public interface ProducerWithIOException<ReturnType> {
        ReturnType produce() throws IOException;
    }

    public interface RunnableWithIOException {
        void run() throws IOException;
    }
}
