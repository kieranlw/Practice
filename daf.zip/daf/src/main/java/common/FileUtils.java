package common;

import com.sun.jna.platform.win32.W32FileUtils;
import utils2.LogInfo;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public final class FileUtils {
    /**
     * Deletes files and/or directories. Works for non-empty directories.
     *
     * @param paths Path objects representing the items to delete
     * @throws RuntimeIOException if an error occurs
     */
    public static void delete(List<Path> paths) throws RuntimeIOException {
        RuntimeIOException.withRuntimeIOExceptions(() -> {
            for (Path path : paths) {
                LogInfo.log_Status("Deleting \"" + path + "\"");
                if (Files.isDirectory(path)) {
                    org.apache.commons.io.FileUtils.deleteDirectory(path.toFile());
                } else {
                    Files.delete(path);
                }
            }
        });
    }

    /**
     * Deletes files and/or directories. Works for non-empty directories.
     *
     * @param paths Path objects representing the items to delete
     * @throws RuntimeIOException if an error occurs
     */
    public static void delete(Path... paths) throws RuntimeIOException {
        delete(Arrays.asList(paths));
    }

    /**
     * Deletes files and/or directories, ignoring any that don't exist.
     * Works for non-empty directories.
     *
     * @param paths Path objects representing the items to delete
     * @throws RuntimeIOException if an error occurs
     */
    public static void deleteIfExists(List<Path> paths) throws RuntimeIOException {
        for (Path path : paths) {
            if (Files.exists(path)) {
                // delete() will write its own log message
                delete(path);
            } else {
                LogInfo.log_Status("Not deleting \"" + path + "\" because it did not exist");
            }
        }
    }

    /**
     * Deletes files and/or directories, ignoring any that don't exist.
     * Works for non-empty directories.
     *
     * @param paths Path objects representing the items to delete
     * @throws RuntimeIOException if an error occurs
     */
    public static void deleteIfExists(Path... paths) throws RuntimeIOException {
        deleteIfExists(Arrays.asList(paths));
    }

    /**
     * Returns true if the file contains a line matches to 'starts' + 'separator' + 'ends'.
     * <p>
     * Spaces before/after separator are ignored. Case Sensitive
     * Use this in looking for "useToken = true" or "ABCD , 1234" in a file.
     * </p>
     *
     * @return boolean
     */
    public static boolean fileContainsTextLine(ReadableFile file, String starts, String separator, String ends) {
        return file.containsLine(s -> {
            String line = s.trim();
            return line.startsWith(starts) &&
                    line.endsWith(ends) &&
                    line.substring(starts.length(), line.length() - ends.length()).trim().equals(separator);
        });
    }

    /**
     * Sends files and/or directories to the Recycle Bin.
     * Works for non-empty directories.
     *
     * @param paths Path objects representing the items to recycle
     * @throws RuntimeIOException if an error occurs
     */
    public static void recycle(List<Path> paths) throws RuntimeIOException {
        if (paths.isEmpty()) {
            return;
        }

        LogInfo.log_Status("Recycling " + paths.stream()
                .map(p -> "\"" + p + "\"")
                .collect(Collectors.joining(", ")));
        final File[] files = ListUtils.map(paths, p -> p.toFile()).toArray(new File[0]);
        RuntimeIOException.withRuntimeIOExceptions(() -> {
            W32FileUtils.getInstance().moveToTrash(files);
        });
    }

    /**
     * Sends files and/or directories to the Recycle Bin.
     * Works for non-empty directories.
     *
     * @param paths Path objects representing the items to recycle
     * @throws RuntimeIOException if an error occurs
     */
    public static void recycle(Path... paths) throws RuntimeIOException {
        recycle(Arrays.asList(paths));
    }

    /**
     * Sends files and/or directories to the Recycle Bin, ignoring any that
     * don't exist. Works for non-empty directories.
     *
     * @param paths Path objects representing the items to recycle
     * @throws RuntimeIOException if an error occurs
     */
    public static void recycleIfExists(List<Path> paths) throws RuntimeIOException {
        for (Path path : paths) {
            if (Files.exists(path)) {
                // recycle() will write its own log message
                recycle(path);
            } else {
                LogInfo.log_Status("Not recycling \"" + path + "\" because it did not exist");
            }
        }
    }

    /**
     * Sends files and/or directories to the Recycle Bin, ignoring any that
     * don't exist. Works for non-empty directories.
     *
     * @param paths Path objects representing the items to recycle
     * @throws RuntimeIOException if an error occurs
     */
    public static void recycleIfExists(Path... paths) throws RuntimeIOException {
        recycleIfExists(Arrays.asList(paths));
    }
}
