package common;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.List;

// Adapted from https://jcalcote.wordpress.com/2010/06/22/managing-a-dynamic-java-trust-store/
public class TrustedServerCertificates {
    private TrustedServerCertificates() {
    }

    /**
     * <p>
     * Loads all certificates from the /daf/src/main/resources/trusted_server_certificates directory, and
     * makes Java trust them like any other root certificate authority. You only need to call this once at
     * app startup (but calling it again is harmless).
     * </p><p>
     * These certificates will only be trusted in Java code. So they'll work for Report Portal and probably
     * for REST Assured, but not for Selenium (since there it's the browser making the HTTPS requests).
     * </p>
     */
    public static void load() {
        try {
            KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
            keyStore.load(null, null);

            CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
            for (String filepath : getCertificateFiles()) {
                try (InputStream inputStream = TrustedServerCertificates.class.getResourceAsStream(filepath)) {
                    X509Certificate certificate = (X509Certificate) certificateFactory.generateCertificate(inputStream);
                    keyStore.setCertificateEntry(certificate.getSubjectX500Principal().getName(), certificate);
                }
            }

            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            trustManagerFactory.init(keyStore);

            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, trustManagerFactory.getTrustManagers(), null);
            SSLContext.setDefault(sslContext);
        } catch (Exception e) {
            throw new RuntimeException("Error reading the trusted_server_certificates directory: " + e.getMessage(), e);
        }
    }

    private static List<String> getCertificateFiles() throws IOException {
        //TODO: This is a temporary hack. The code below was failing in some cases because ResourceDirectory
        // returned a jar:// URL. Need to investigate, but in the meantime this should get things working.
        // Story to fix this and remove hard-coding is in the backlog as https://deluxe.atlassian.net/browse/DAFCON-6373.
        return Arrays.asList(
                "/trusted_server_certificates/DigiCert Global Root CA.cer",
                "/trusted_server_certificates/Deluxe Enterprise CA.cer",
                "/trusted_server_certificates/Deluxe Root CA.cer",
                "/trusted_server_certificates/GlobalSign RSA OV SSL CA 2018.cer"
        );

//        return ListUtils.filter(
//                new ResourceDirectory("trusted_server_certificates").getFiles(),
//                TrustedServerCertificates::isCertificateFile);
    }

    private static boolean isCertificateFile(ReadableFile file) {
        String lowerCaseFileName = file.getFileName().toLowerCase();
        return lowerCaseFileName.endsWith(".cer") || lowerCaseFileName.endsWith(".pem");
    }
}
