package common;

import utils.Parameter;

import java.io.File;

/**
 * <p>
 * Represents a file, not stored in version control, that needs to be accessed by tests.
 * (For files that are stored in version control, use ResourceFile instead.)
 * </p><p>
 * Useful methods for working with the file are provided by default interface methods.
 * See implemented interfaces for details.
 * </p>
 */
public class DataFile implements ReadableFile, WritableFile {
    private final String absolutePath;

    public DataFile(String absolutePath) {
        Parameter.named("absolutePath").withValue(absolutePath).mustBeNonNull();
        this.absolutePath = absolutePath;
    }

    @Override
    public boolean exists() {
        return new File(absolutePath).exists();
    }

    @Override
    public String getAbsolutePath() {
        return absolutePath;
    }

    @Override
    public String toString() {
        return "[" + absolutePath + "]";
    }

    @Override
    public ReadableFile withFileNameSuffix(String suffix) {
        return new DataFile(absolutePath + suffix);
    }
}
