package common;

import org.jetbrains.annotations.NotNull;
import utils2.Index;
import utils2.TableData2;
import utils2.tableData.Row;

import java.util.*;

public final class PdfContent {
    // Store the cells as a SortedSet, so that if someone adds a new row,
    // it will automatically go to the correct spot based on its page and Y
    private final SortedSet<PdfRow> rows;

    public PdfContent(List<PdfRow> rows) {
        Comparator<PdfRow> comparator = Comparator.comparing((PdfRow r) -> r.getPage().asZeroBased())
                .thenComparingDouble(PdfRow::getY);
        this.rows = new TreeSet<>(comparator);
        this.rows.addAll(rows);
    }

    public SortedSet<PdfRow> getRows() {
        return rows;
    }

    /**
     * Combines rows whose Y values are nearly equal. Makes up for
     * sloppy report layout and/or different font sizes.
     *
     * @param yTolerance If the Y values are less than this value,
     *                   rows are considered to be the same row.
     */
    public void fixRowAlignment(double yTolerance) {
        PdfRow lastRowKept = null;
        final Iterator<PdfRow> iterator = rows.iterator();
        while (iterator.hasNext()) {
            final PdfRow row = iterator.next();
            if (lastRowKept != null &&
                    row.getPage().equals(lastRowKept.getPage()) &&
                    row.getY() - lastRowKept.getY() < yTolerance) {
                lastRowKept.getCells().addAll(row.getCells());
                iterator.remove();
            } else {
                lastRowKept = row;
            }
        }
    }

    public TableData2 getTable(String topLeftCellLabel, String topRightCellLabel,
                               String bottomLeftCellLabel, Endpoint includeLastRow) {
        final PdfRow headerRow = rowWithText(new String[]{topLeftCellLabel, topRightCellLabel}, null);
        final PdfRow lastRow = rowWithText(new String[]{bottomLeftCellLabel}, headerRow);

        return getTable(headerRow, topLeftCellLabel, topRightCellLabel, lastRow, includeLastRow);
    }

    private TableData2 getTable(PdfRow headerRow,
                                String firstColumnHeaderText, String lastColumnHeaderText,
                                PdfRow lastRow, Endpoint includeLastRow) {
        final List<Row> tableRows = new ArrayList<>();
        final List<PdfCell> headerCells = new ArrayList<>(headerRow.getCells());
        final List<ColumnArea> columnAreas = getColumnAreas(firstColumnHeaderText, lastColumnHeaderText, headerCells);

        final List<PdfRow> relevantRows = ListUtils.subList(rows, headerRow, Endpoint.EXCLUDE, lastRow, includeLastRow);
        for (PdfRow row : relevantRows) {
            // Use a LinkedHashMap to preserve insertion order, as a testing/debugging aid
            Map<String, String> tableRowValues = new LinkedHashMap<>();
            for (PdfCell cell : row.getCells()) {
                final Optional<ColumnArea> columnArea = findMatchingColumnArea(columnAreas, cell);
                columnArea.ifPresent(area -> tableRowValues.put(area.columnName(), cell.getText()));
            }

            // Create a Row from our Map (not a clone), so the Row preserves insertion order
            tableRows.add(new Row(tableRowValues));
        }
        return new TableData2(tableRows);
    }

    private List<ColumnArea> getColumnAreas(String firstColumnHeaderText, String lastColumnHeaderText, List<PdfCell> headerCells) {
        final List<ColumnArea> columnAreas = new ArrayList<>();
        boolean reachedFirstHeader = false;
        boolean pastLastHeader = false;
        for (int i = 0; i < headerCells.size(); i++) {
            final boolean isFirstColumn = i == 0;
            final double areaMinX = isFirstColumn ? Double.MIN_VALUE : headerCells.get(i - 1).getEndX();
            final boolean isLastColumn = i == headerCells.size() - 1;
            final double areaMaxX = isLastColumn ? Double.MAX_VALUE : headerCells.get(i + 1).getX();

            final PdfCell cell = headerCells.get(i);
            final String cellText = cell.getText();
            if (cellText.equals(firstColumnHeaderText) && !pastLastHeader) {
                reachedFirstHeader = true;
            }

            if (reachedFirstHeader && !pastLastHeader) {
                columnAreas.add(new ColumnArea(cell, areaMinX, areaMaxX));
            }

            if (cellText.equals(lastColumnHeaderText) && reachedFirstHeader) {
                pastLastHeader = true;
            }
        }

        return columnAreas;
    }

    @NotNull
    private Optional<ColumnArea> findMatchingColumnArea(List<ColumnArea> columnAreas, PdfCell cell) {
        // Iterate columnAreas right-to-left, so that this...
        //
        // Column1                   Column2
        // Left-justified    Right-justified
        // |                 |
        // --- columnArea 1 --------]
        //        [-- columnArea 2 ---------
        //
        // ...can correctly put "Right-justified" into Column2.

        // First we need to see if the cell is past the rightmost column header
        // that we're currently scraping. If it is, then it's part of the next
        // column, outside the area we're scraping, and we should ignore it.
        if (columnAreas.size() > 0) {
            final ColumnArea lastArea = columnAreas.get(columnAreas.size() - 1);
            if (cell.getX() > lastArea.getHeaderEndX()) {
                return Optional.empty();
            }
        }

        for (int i = columnAreas.size() - 1; i >= 0; i--) {
            final ColumnArea area = columnAreas.get(i);
            if (area.contains(cell)) {
                return Optional.of(area);
            }
        }

        return Optional.empty();
    }

    public PdfRow rowWithText(String[] lookForCellValues, PdfRow startAfter) {
        return PdfContentUtils.rowWithText(rows, lookForCellValues, startAfter);
    }

    @Override
    public String toString() {
        return String.join("\n", ListUtils.map(rows, PdfRow::toString));
    }

    public void trimPageHeaders(String... cellsFromLastHeaderRow) {
        final double headerEndY = rowWithText(cellsFromLastHeaderRow, null).getY();
        rows.removeIf(r -> r.getY() <= headerEndY);
    }

    public void trimPageFooters(String... cellsFromFirstFooterRow) {
        final double footerStartY = rowWithText(cellsFromFirstFooterRow, null).getY();
        rows.removeIf(r -> r.getY() >= footerStartY);
    }

    /**
     * <p>
     * Represents the space between the previous column header's right edge
     * and the next column header's left edge. If a data cell's left edge falls
     * in that range, we'll consider it to be part of this column.
     * For example:
     * </p><pre>
     * Column1 (left-justified)         Column2 (right-justified)   Column3 (left-justified)
     * Data goes here                                       $0.00   Data goes here
     * Data goes here                                       $0.00   Data goes here
     * Data goes here             Value can be longer than header   Data goes here
     * Long string that spans across multiple columns
     *
     * -- Column1 -------------------]
     *                         [-- Column2 ------------------------]
     *                                                           [-- Column3 --------------
     * </pre>
     */
    private static class ColumnArea {
        private final PdfCell headerCell;
        private final double areaMinX;
        private final double areaMaxX;

        public ColumnArea(PdfCell headerCell, double areaMinX, double areaMaxX) {
            this.headerCell = headerCell;
            this.areaMinX = areaMinX;
            this.areaMaxX = areaMaxX;
        }

        public String columnName() {
            return headerCell.getText();
        }

        public boolean contains(PdfCell cell) {
            return (cell.getX() >= areaMinX) && (cell.getX() <= areaMaxX);
        }

        public double getHeaderEndX() {
            return headerCell.getEndX();
        }

        @Override
        public String toString() {
            return "'" + columnName() + "' (" +
                    (areaMinX == Double.MIN_VALUE ? "min" : areaMinX) +
                    " - " +
                    (areaMaxX == Double.MAX_VALUE ? "max" : areaMaxX) +
                    ")";
        }
    }
}
