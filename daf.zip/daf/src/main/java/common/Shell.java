package common;

import org.apache.commons.lang3.ArrayUtils;

public enum Shell {
    NONE(),
    POWERSHELL("powershell.exe", "-ExecutionPolicy", "Unrestricted"),
    CMD("cmd.exe", "/c");

    private final String[] shellArguments;

    Shell(String... shellArguments) {
        this.shellArguments = shellArguments;
    }

    public String[] buildCommandLine(String... arguments) {
        return ArrayUtils.addAll(this.shellArguments, arguments);
    }
}
