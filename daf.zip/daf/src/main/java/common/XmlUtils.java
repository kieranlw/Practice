package common;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

public final class XmlUtils {

    private XmlUtils() {

    }

    public static Document parseDocument(String xml) {
        try {
            InputSource xmlInputSource = new InputSource(new StringReader(xml));
            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            return db.parse(xmlInputSource);
        } catch (ParserConfigurationException | SAXException | IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static NodeList evaluateXpath(Document document, String xPath) {
        try {
            XPathExpression expression = XPathFactory.newInstance().newXPath().compile(xPath);
            return (NodeList) expression.evaluate(document.getDocumentElement(), XPathConstants.NODESET);
        } catch (XPathExpressionException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static Map<String, Node> namedNodeMapToMap(NamedNodeMap namedNodeMap) {
        Map<String, Node> temp = new HashMap<>();

        for (int i = 0; i < namedNodeMap.getLength(); i++)
            temp.put(namedNodeMap.item(i).getNodeName(), namedNodeMap.item(i));

        return temp;
    }

    private static String nodeToString(Node node) {
        try {
            StringWriter stringWriter = new StringWriter();
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            transformer.transform(new DOMSource(node), new StreamResult(stringWriter));
            return (stringWriter.toString());
        } catch (TransformerException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    @SuppressWarnings("unused") //Used for debugging.
    public static String nodeListToString(NodeList nodeList) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < nodeList.getLength(); ++i) {
            result.append(nodeToString(nodeList.item(i)));
        }
        return result.toString();
    }

    /**
     * Prints a Document or Node into a pretty, easy to read, human-friendly format.
     * Targeted for debugging
     *
     * @param nodeOrDoc XML Node or Document
     * @return A single XML string without the <?xml></?xml> tags
     * @throws RuntimeException There was an error transforming the Node into an XML string
     */
    @SuppressWarnings("unused") //Used for debugging.
    public static String prettyPrint(Node nodeOrDoc) {
        try {
            StringWriter stringWriter = new StringWriter();
            StreamResult xmlOutput = new StreamResult(stringWriter);
            TransformerFactory tf = TransformerFactory.newInstance();

            Transformer transformer = tf.newTransformer();
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            transformer.transform(new DOMSource(nodeOrDoc), xmlOutput);
            return xmlOutput.getWriter().toString();
        } catch (TransformerException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }
}