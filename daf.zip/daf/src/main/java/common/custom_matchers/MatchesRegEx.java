package common.custom_matchers;

import org.hamcrest.Description;
import org.hamcrest.text.MatchesPattern;

import java.util.regex.Pattern;

public class MatchesRegEx extends MatchesPattern {

    private final String customDescription;

    public MatchesRegEx(Pattern pattern, String description) {
        super(pattern);
        this.customDescription = description;
    }

    @Override
    public void describeTo(Description description) {
        description.appendText(customDescription);
    }

}
