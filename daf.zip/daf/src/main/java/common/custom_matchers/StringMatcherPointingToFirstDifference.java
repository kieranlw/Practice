package common.custom_matchers;

import com.google.common.base.Strings;
import common.StringUtils;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.StringDescription;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

// Ideally this class wouldn't need to be generic, but because of the way we use it (Is.equalTo
// automatically decides whether to return this, based on the runtime type of the parameter, and
// Is.equalTo needs to return Matcher<T>) this was the easiest way to make the compiler happy.
public class StringMatcherPointingToFirstDifference<T> extends BaseMatcher<T> {
    @Nullable
    private final T expected;

    public StringMatcherPointingToFirstDifference(@Nullable T expected) {
        this.expected = expected;
    }

    @Override
    public boolean matches(@Nullable Object actual) {
        if (expected == actual)
            return true;
        if (expected == null || actual == null)
            return false;
        return valuesMatch(expected.toString(), actual.toString());
    }

    @Override
    public void describeTo(@NotNull Description description) {
        description.appendText(getValuePrefix()).appendValue(expected);
    }

    @Override
    public void describeMismatch(@Nullable Object actual, @NotNull Description mismatchDescription) {
        // If describeTo is showing a prefix, add space to match
        String indentForValuePrefix = Strings.repeat(" ", getValuePrefix().length());

        mismatchDescription.appendText(indentForValuePrefix);

        if (expected != null && actual != null) {
            // "but: <actual> differs: starting at index <i>"
            mismatchDescription.appendValue(actual);
            mismatchDescription.appendText("\n differs:");

            String leadingSubstring = StringUtils.leadingSubstring(expected.toString(), actual.toString(), this::valuesMatch);
            StringDescription leadingSubstringDescription = new StringDescription();
            leadingSubstringDescription.appendValue(leadingSubstring);
            mismatchDescription
                    .appendText(indentForValuePrefix)
                    .appendText(Strings.repeat(" ", leadingSubstringDescription.toString().length()))
                    .appendText("^ starting at index " + leadingSubstring.length());
        } else {
            // One or both values is null, so there's no sense showing the location of the
            // first difference. Rephrase the message from "but: <actual> differs starting..."
            // to "but: was <actual>" so it's still got a verb.
            mismatchDescription.appendText("was ").appendValue(actual);
        }
    }

    protected boolean valuesMatch(@NotNull String a, @NotNull String b) {
        return Objects.equals(a, b);
    }

    protected String getValuePrefix() {
        return "";
    }

    public static class CaseInsensitive extends StringMatcherPointingToFirstDifference<String> {
        public CaseInsensitive(String expected) {
            super(expected);
        }

        @Override
        protected boolean valuesMatch(@NotNull String a, @NotNull String b) {
            return a.equalsIgnoreCase(b);
        }

        @Override
        protected String getValuePrefix() {
            return "(ignoring case) ";
        }
    }
}
