package common;

public class CommandLineException extends RuntimeException {
    public CommandLineException(String message, Throwable cause) {
        super(message, cause);
    }
}
