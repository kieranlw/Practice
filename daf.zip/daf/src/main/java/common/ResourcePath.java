package common;

import org.jetbrains.annotations.Nullable;
import utils.Parameter;

import java.io.File;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

public abstract class ResourcePath {
    protected final String mavenRelativePath;

    protected ResourcePath(String mavenRelativePath) {
        Parameter.named("mavenRelativePath").withValue(mavenRelativePath).mustBeNonNull();
        validatePath(mavenRelativePath);
        this.mavenRelativePath = mavenRelativePath;
    }

    private static void failPath(String path, String should) {
        throw new RuntimeException("Resource path '" + path + "' " + should);
    }

    private static void validatePath(String path) {
        // Simplify later logic by making sure we know whether there's a leading slash
        if (path.startsWith("/") || path.startsWith("\\")) {
            failPath(path, "should be relative (no leading '/')");
        }

        // We may not strictly need to avoid backslashes, but this way I don't have to test all
        // this logic twice. Prefer forward slashes since they don't require doubling.
        if (path.contains("\\")) {
            failPath(path, "should use forward slashes ('/', not '\\')");
        }

        if (path.contains("//")) {
            failPath(path, "should not contain duplicate consecutive slashes ('//')");
        }

        // Catch mistakes early and with a good error message
        if (path.startsWith("src/")) {
            failPath(path, "should be relative to the package name, not to 'src'");
        }
    }

    protected abstract boolean exists(Path candidateAbsolutePath);

    public final boolean exists() {
        return getAbsolutePathIfExists() != null;
    }

    public final String getAbsolutePath() {
        String path = getAbsolutePathIfExists();
        if (path == null) {
            throw new RuntimeException("Resource path not found: " + mavenRelativePath);
        }
        return path;
    }

    @Nullable
    private String getAbsolutePathIfExists() {
        String resourcePath = ("/" + mavenRelativePath);
        URL resource = ResourceFile.class.getResource(resourcePath);
        if (resource != null) {
            String mavenPath = urlToAbsolutePath(resource);
            if (exists(Paths.get(mavenPath))) {
                return mavenPath;
            }
        }

        return null;
    }

    @Override
    public String toString() {
        return "[" + mavenRelativePath + "]";
    }

    private String urlToAbsolutePath(URL url) {
        try {
            return new File(url.toURI()).getAbsolutePath();
        } catch (Exception e) {
            // We're required to catch URISyntaxException, but the above code may also throw runtime exceptions (e.g.
            // IllegalArgumentException), and we want to add diagnostic info to those too. Hence, catching Exception.
            throw new RuntimeException("Error converting URL " + url + " to absolute path: " + e.getMessage(), e);
        }
    }
}
