package common;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import utils2.DriverInfo;
import utils2.LogInfo;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.logging.Level;

public final class BrowserOptions {
    private BrowserOptions() {
    }

    public static FirefoxOptions forFirefox(String url, String downloadLocation) {
        System.setProperty("webdriver.gecko.driver", "c:\\Selenium\\geckodriver.exe");
        FirefoxOptions options = new FirefoxOptions();
        if (url.contains("rpsqaaut3.qalabs.nwk") || url.contains("nextgenblack3.qalabs.nwk")
                || url.contains("rps602auto1web.qalabs.nwk/Framework")) {
            options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
            options.setCapability("marionette", false);

            FirefoxProfile firefoxProfile = new FirefoxProfile();
            firefoxProfile.setPreference("browser.download.folderList", 2);
            firefoxProfile.setPreference("browser.download.manager.showWhenStarting", false);
            firefoxProfile.setPreference("browser.download.dir", downloadLocation);
            firefoxProfile.setPreference("browser.helperApps.neverAsk.saveToDisk", "text/csv");
            firefoxProfile.setAcceptUntrustedCertificates(true);
            firefoxProfile.setAssumeUntrustedCertificateIssuer(true);

            options.setCapability(FirefoxDriver.PROFILE, firefoxProfile);
        }

        return options;
    }

    private static void initializeWebDriverManager() {
        String chromeDriverPath = OsUtils.isMac() ? System.getProperty("user.home") + "/Selenium/" : "C:/Selenium/";
        WebDriverManager.chromedriver().cachePath(chromeDriverPath).setup();
    }

    @NotNull
    private static ChromeOptions createDefaultChromeOptions() {
        ChromeOptions options = new ChromeOptions();

        options.setAcceptInsecureCerts(true);

        options.addArguments("--disable-plugins");
        options.addArguments("--disable-bundled-ppapi-flash");
        options.addArguments("--disable-internal-flash");
        options.addArguments("--disable-plugins-discovery");
        options.addArguments("--start-maximized");

        return options;
    }

    public static ChromeOptions forChromeRemote(DriverInfo driverInfo) {
        // Selenium Server will use the driver in its own directory -
        // no need to set a ChromeDriver path
        return forChrome(driverInfo);
    }

    public static ChromeOptions forChromeLocal(DriverInfo driverInfo) {
        LogInfo.log_Status("Initializing WebDriverManager");
        initializeWebDriverManager();
        return forChrome(driverInfo);
    }

    private static ChromeOptions forChrome(DriverInfo driverInfo) {
        ChromeOptions options = createDefaultChromeOptions();
        Map<String, Object> preferences = new Hashtable<>();
        // disable flash and the PDF viewer
        preferences.put("plugins.plugins_disabled", new String[]{"Adobe Flash Player"});
        if (driverInfo.getDownloadLocation() != null) {
            preferences.put("profile.default_content_settings.popups", 0);
            if (!driverInfo.isLogPerformanceInfo()) {
                preferences.put("download.default_directory", driverInfo.getDownloadLocation());
            }
            // suppressing "This type of file can harm your computer." popup
            preferences.put("safebrowsing.enabled", "true");
        }

        if (driverInfo.isStartMaximized()) {
            options.addArguments("--start-maximized");
        }
        options.addArguments("--disable-backgrounding-occluded-windows");
        if (driverInfo.isLogPerformanceInfo()) {
            LoggingPreferences loggingPreferences = new LoggingPreferences();
            loggingPreferences.enable(LogType.PERFORMANCE, Level.ALL);
            options.setCapability(CapabilityType.LOGGING_PREFS, loggingPreferences);
            options.setCapability("goog:loggingPrefs", loggingPreferences);
        }

        options.setExperimentalOption("prefs", preferences);
        if (driverInfo.getPageLoadStrategy() != null) {
            options.setPageLoadStrategy(driverInfo.getPageLoadStrategy());
        }

        if (driverInfo.isHeadlessMode()) {
            options.addArguments("window-size=1920,1080");
            options.addArguments("headless");
        }

        options.addArguments("--disable-gpu");

        String extraArguments = System.getenv("DAF_ChromeDriverArguments");
        if (extraArguments != null && !extraArguments.isEmpty()) {
            options.addArguments(extraArguments.split(" "));
        }

        return options;
    }

    public static InternetExplorerOptions forInternetExplorer(String url) {
        System.setProperty("webdriver.ie.driver", "c:\\Selenium\\IEDriverServer.exe");
        InternetExplorerOptions options = new InternetExplorerOptions();
        if (url.contains("rpsqaaut3.qalabs.nwk") || url.contains("rechubqaweb02.qalabs.nwk") || url.contains("nextgenblack3.qalabs.nwk")) {
            options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
            options.setCapability("enablePersistentHover", false);

            // This will hopefully fix issue where typing doesn't work.
            options.setCapability("requireWindowFocus", false);

            // Setting to false fixed issue where browser would get stuck on
            // starting page.
            options.setCapability("ie.ensureCleanSession", true);
            options.setCapability("browserstack.ie.noFlash", "true");
            options.setCapability("browserstack.bfcache", "0");
        } else if (url.contains("bankersdashboard.com")) {
            options.setCapability("ignoreZoomSetting", true);
            options.setCapability("browserstack.ie.noFlash", true);
            options.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
            options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
        } else {
            options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
            options.setCapability("enablePersistentHover", false);
            options.setCapability("requireWindowFocus", false);
            options.setCapability("ie.ensureCleanSession", true);
            options.setCapability("browserstack.ie.noFlash", true);
            options.setCapability("browserstack.bfcache", "0");
        }

        return options;
    }

    public static ChromeOptions forAndroid() {
        // Android uses the chrome driver but is really a chrome package
        // with a different option
        System.setProperty("webdriver.chrome.driver", "c:\\Selenium\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        Map<String, String> mobileEmulation = new HashMap<>();
        //TODO: add support for different devices
        mobileEmulation.put("deviceName", "Pixel 2 XL");
        options.addArguments("start-maximized");

        options.setExperimentalOption("mobileEmulation", mobileEmulation);

        return options;
    }

    public static ChromeOptions forIPhoneSimulated() {
        System.setProperty("webdriver.chrome.driver", "c:\\Selenium\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        Map<String, String> mobileEmulation = new HashMap<>();
        //TODO: add support for different devices
        mobileEmulation.put("deviceName", "iPhone X");
        options.addArguments("start-maximized");

        options.setExperimentalOption("mobileEmulation", mobileEmulation);

        return options;
    }

    public static ChromeOptions forChromeHeadlessWithProxyBypass() {
        initializeWebDriverManager();

        ChromeOptions options = createDefaultChromeOptions();

        options.addArguments("--headless");
        options.addArguments("window-size=1920,1080");

        options.addArguments("--proxy-server='direct://'");
        options.addArguments("--proxy-bypass-list=*");

        return options;
    }
}
