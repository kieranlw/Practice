package common;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public final class ListUtils {
    private ListUtils() {}

    public static <E> List<E> filter(List<E> list, Predicate<? super E> predicate) {
        return list.stream().filter(predicate).collect(Collectors.toList());
    }

    public static <E> Optional<E> nextAfter(List<E> list, Predicate<? super E> matcher) {
        AtomicBoolean hasMatched = new AtomicBoolean(false);
        return list.stream()
                .filter(element -> {
                    if (hasMatched.get()) {
                        return true;
                    } else if (matcher.test(element)) {
                        hasMatched.set(true);
                    }
                    return false;
                })
                .findFirst();
    }

    public static <E, R> List<R> map(E[] values, Function<? super E, ? extends R> mapper) {
        return map(Arrays.asList(values), mapper);
    }

    public static <E, R> List<R> map(Collection<E> list, Function<? super E, ? extends R> mapper) {
        return list.stream().map(mapper).collect(Collectors.toList());
    }

    public static <E> E single(List<E> list, Predicate<? super E> matcher) {
        List<E> matches = list.stream().filter(matcher).collect(Collectors.toList());
        if (matches.size() > 1) {
            throw new RuntimeException("Expected one match but found " + matches.size());
        } else if (matches.isEmpty()) {
            throw new RuntimeException("No matches found");
        }
        return matches.get(0);
    }

    public static <T> List<T> subList(Collection<T> input,
                                      T first, Endpoint includeFirst,
                                      T last, Endpoint includeLast) {
        List<T> results = new ArrayList<>();
        boolean reachedFirst = false;
        boolean reachedLast = false;
        for (T value : input) {
            boolean include;
            if (!reachedFirst && Objects.equals(value, first)) {
                reachedFirst = true;
                include = (includeFirst == Endpoint.INCLUDE);
            } else if (reachedFirst && !reachedLast && Objects.equals(value, last)) {
                reachedLast = true;
                include = (includeLast == Endpoint.INCLUDE);
            } else {
                include = reachedFirst && !reachedLast;
            }

            if (include) {
                results.add(value);
            }
        }
        return results;
    }

    public static List<String> trimTrailingBlanks(List<String> input) {
        List<String> output = new ArrayList<>(input);
        while (output.size() > 0 && StringUtils.isNullOrEmpty(output.get(output.size() - 1))) {
            output.remove(output.size() - 1);
        }
        return output;
    }

    /**
     * Similar to Collections.reverse(), but accepts Collection&lt;T&gt; instead of
     * only List&lt;T&gt;.
     *
     * @param values The list to reverse
     * @param <T>    The type of elements in the list
     * @return The reversed list
     */
    public static <T> List<T> reverse(Collection<T> values) {
        final LinkedList<T> results = new LinkedList<>();
        for (T value : values) {
            results.addFirst(value);
        }
        return results;
    }

    public static <T> List<T> concat(Collection<T> first, T newItem) {
        return concat(first, Collections.singletonList(newItem));
    }

    public static <T> List<T> concat(Collection<T> first, Collection<T> second) {
        final ArrayList<T> results = new ArrayList<>(first);
        results.addAll(second);
        return results;
    }
}
