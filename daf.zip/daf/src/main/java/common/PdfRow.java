package common;

import org.jetbrains.annotations.NotNull;
import utils2.Index;

import java.util.*;

public final class PdfRow {
    private final Index page;
    private final double y;
    // Store the cells as a SortedSet, so that if someone adds a new cell,
    // it will automatically go to the correct spot based on its X value
    private final SortedSet<PdfCell> cells;

    public PdfRow(Index page, double y, List<PdfCell> cells) {
        this.page = page;
        this.y = y;

        this.cells = new TreeSet<>(Comparator.comparingDouble(PdfCell::getX));
        this.cells.addAll(cells);
    }

    /**
     * The page index / page number
     *
     * @return The page index / page number
     */
    public Index getPage() {
        return page;
    }

    /**
     * The Y coordinate of the row
     *
     * @return The Y coordinate of the row
     */
    public double getY() {
        return y;
    }

    /**
     * The cells in the row, sorted by X coordinate
     *
     * @return The cells in the row, sorted by X coordinate
     */
    public SortedSet<PdfCell> getCells() {
        return cells;
    }

    @NotNull
    public PdfCell getCellByText(String text) {
        return getOptionalCellByText(text)
                .orElseThrow(() -> new RuntimeException("Could not find cell with text '" + text + "'. " +
                        "Actual row contents: " + this));
    }

    @NotNull
    public Optional<PdfCell> getOptionalCellByText(String text) {
        return cells.stream()
                .filter(c -> Objects.equals(c.getText(), text))
                .findFirst();
    }

    @Override
    public String toString() {
        return "[Page=" + page.asZeroBased() + " Y=" + String.format("%.2f", y) + "] " +
                String.join(" | ", ListUtils.map(cells, PdfCell::getText));
    }
}
