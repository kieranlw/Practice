package common;

import net.engio.mbassy.listener.Synchronized;

import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Lazily computes a value the first time it's requested, then caches the value.
 */
public class Lazy<T> implements Supplier<T> {
    private final Supplier<T> supplier;
    private volatile T value;

    public Lazy(Supplier<T> supplier) {
        this.supplier = supplier;
    }

    @Override
    @Synchronized
    public T get() {
        if (value == null) {
            value = supplier.get();
        }
        return value;
    }

    @Synchronized
    public boolean hasValue() {
        return value != null;
    }

    @Synchronized
    public void ifPresent(Consumer<T> consumer) {
        if (value != null) {
            consumer.accept(value);
        }
    }
}
