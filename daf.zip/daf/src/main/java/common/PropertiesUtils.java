package common;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public final class PropertiesUtils {
    private PropertiesUtils() {
    }

    public static Properties load(ReadableFile file) throws IOException {
        Properties properties = new Properties();
        try (InputStream input = new FileInputStream(file.getAbsolutePath())) {
            properties.load(input);
        }
        return properties;
    }

    public static Map<String, String> loadAsMap(ReadableFile file) throws IOException {
        Properties properties = load(file);
        ImmutableMap<String, String> immutableMap = Maps.fromProperties(properties);
        return new HashMap<>(immutableMap);
    }
}
