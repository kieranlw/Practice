# common package

This package is for code shared between DAF 1.0 (/utils) and DAF 2.0 (/utils2).
