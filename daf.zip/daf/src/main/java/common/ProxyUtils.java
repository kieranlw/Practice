package common;

import com.sun.jna.platform.win32.Advapi32Util;
import com.sun.jna.platform.win32.WinReg;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.Optional;

public final class ProxyUtils {
    private static final WinReg.HKEY ROOT = WinReg.HKEY_CURRENT_USER;
    private static final String KEY = "Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings";
    private static final String VALUE_NAME = "ProxyServer";

    private ProxyUtils() {
    }

    /**
     * <p>
     * Returns the URL of the HTTPS proxy that's configured for the computer.
     * </p><p>
     * To make REST Assured honor the system proxy settings (and therefore to enable debugging tools like
     * <a href="https://www.telerik.com/fiddler">Fiddler</a>), do this:
     * </p><pre>
     * ProxyUtils.getProxyUrl(baseUri.getScheme()).ifPresent(builder::setProxy);
     * </pre>
     *
     * @param scheme URL scheme ("http" or "https").
     * @return The URL of the system proxy, or empty if no system proxy is configured for the given scheme.
     */
    @NotNull
    public static Optional<String> getProxyUrl(@SuppressWarnings("SameParameterValue") String scheme) {
        // If no proxy is set up (e.g. if Fiddler isn't running or isn't capturing), return empty
        if (!Advapi32Util.registryValueExists(ROOT, KEY, VALUE_NAME)) {
            return Optional.empty();
        }

        String proxyDescription = Advapi32Util.registryGetStringValue(ROOT, KEY, VALUE_NAME);
        // proxyDescription will be something like "http=127.0.0.1:8888;https=127.0.0.1:8888"

        String[] schemes = proxyDescription.split(";");
        return Arrays.stream(schemes)
                .filter(entry -> entry.startsWith(scheme))
                .map(entry -> entry.split("=")[1])
                .findFirst()
                // At this point, we may have empty (e.g. if Fiddler isn't capturing HTTPS), or we may have a value.
                // If we have a value, it will be something like "127.0.0.1:8888". Convert that to a URL.
                .map(value -> "http://" + value);
    }
}
