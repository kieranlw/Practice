package common;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

public final class PdfContentUtils {
    private PdfContentUtils() {
    }

    public static PdfRow rowWithText(Collection<PdfRow> rows, String[] lookForCellValues, PdfRow startAfter) {
        boolean reachedStart = startAfter == null;
        for (PdfRow row : rows) {
            if (reachedStart) {
                final List<String> rowValues = ListUtils.map(row.getCells(), PdfCell::getText);
                if (Arrays.stream(lookForCellValues).allMatch(rowValues::contains)) {
                    return row;
                }
            } else if (Objects.equals(row, startAfter)) {
                reachedStart = true;
            }
        }

        throw new RuntimeException("Could not find row with cell(s) '" + String.join("', '", lookForCellValues) + "'");
    }
}
