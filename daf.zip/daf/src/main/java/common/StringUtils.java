package common;

import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.support.ui.Quotes;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import utils.Parameter;
import utils2.LogInfo;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.BiPredicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class StringUtils {

    private static final String LEFT_ANGLE_QUOTE = "\u00AB";
    private static final String RIGHT_ANGLE_QUOTE = "\u00BB";

    private StringUtils() {
    }

    /**
     * Convert the given value to a string surrounded by angle quotes. Can be handy when the string
     * might contain single quotes, double quotes, angle brackets, or any of the other things we
     * often use to surround values in log messages.
     *
     * @param value The value to quote. Can be null.
     * @return The value in angle quotes, or the word "null" if the input was null.
     */
    public static String angleQuote(String value) {
        if (value == null)
            return "null";

        return LEFT_ANGLE_QUOTE + value + RIGHT_ANGLE_QUOTE;
    }

    /**
     * Given a comma-delimited string, return only the first N parts of it.
     *
     * @param valueToSplit          The input value (a comma-delimited string)
     * @param numberOfIndexesToKeep Number of parts to keep
     * @return A comma-delimited string with at most numberOfIndexesToKeep parts
     */
    public static String getOptions(String valueToSplit, int numberOfIndexesToKeep) {
        String[] originalParts = valueToSplit.split(",");
        if (numberOfIndexesToKeep < originalParts.length) {
            String[] partsToKeep = Arrays.copyOfRange(originalParts, 0, numberOfIndexesToKeep);
            return String.join(",", partsToKeep);
        } else {
            return valueToSplit;
        }
    }

    /**
     * <p>
     * Replace {0}, {1}, etc. placeholders in an XPath.
     * </p><p>
     * If any placeholders in the input XPath are surrounded by single or double quotes, e.g. '{0}' or "{0}",
     * then this intelligently quotes the replacement value. So you can have '{0}' in the input, but if the
     * replacement value contains an apostrophe, then the returned XPath will be smart enough to use
     * double quotes instead.
     * </p>
     *
     * @param inputXPath        The XPath that potentially contains {0}-style placeholders
     * @param replacementValues The replacement values
     * @return The XPath string with the placeholders replaced
     */
    @NotNull
    public static String expandXPathPlaceholders(String inputXPath, String... replacementValues) {
        StringBuffer result = new StringBuffer();
        Pattern regex = Pattern.compile("(['\"]?)\\{(\\d+)}\\1");
        Matcher regexMatcher = regex.matcher(inputXPath);
        while (regexMatcher.find()) {
            final boolean quoted = !regexMatcher.group(1).isEmpty();
            final int index = Integer.parseInt(regexMatcher.group(2));

            // Due to inheritance a parent class might not have the values,
            // still need to be able to add replacement values later on without nuking our factory.
            String alternativeReplacementValue = "";
            if (index >= replacementValues.length || replacementValues[index] == null) {
                alternativeReplacementValue = "IF YOU SEE THIS FIX YOUR ComponentFactory.init TO PASS IN APPROPRIATE VALUE FOR INDEX " + index;
            }

            final String replacementValue = alternativeReplacementValue.equals("") ? replacementValues[index] : alternativeReplacementValue;
            final String finalReplacement = quoted ? Quotes.escape(replacementValue) : replacementValue;
            regexMatcher.appendReplacement(result, Matcher.quoteReplacement(finalReplacement));
        }
        regexMatcher.appendTail(result);
        return result.toString();
    }

    /**
     * Converts an int into a String with comma separations
     * (i.e. 123456789 => "123,456,789")
     *
     * @param number int
     * @return String
     */
    public static String intAsCommaSeparatedNumber(int number) {
        return String.format("%,d", number);
    }

    public static boolean isNullOrEmpty(String s) {
        return s == null || s.isEmpty();
    }

    public static boolean isValidEmailAddress(String emailAddress) {
        Pattern pattern = Pattern.compile("^(.+)@(.+)$");
        Matcher matcher = pattern.matcher(emailAddress);
        return matcher.matches();
    }

    /**
     * Trims off the leading Unicode byte-order mark, if any.
     *
     * @param value Input value that may start with a byte-order mark
     * @return The value without the byte-order mark
     */
    public static String trimByteOrderMark(String value) {
        return value.startsWith("\uFEFF") ? value.substring(1) : value;
    }

    public static String camelCaseToHumanReadable(String value) {
        return org.apache.commons.lang3.StringUtils.capitalize(
                org.apache.commons.lang3.StringUtils.join(
                        org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(value), " "));
    }

    /**
     * Returns the longest substring, starting at the beginning of the input strings, that both inputs have in common.
     *
     * @param a        The first input
     * @param b        The second input
     * @param comparer Function to compare two strings; typically Objects::equals or String::equalsIgnoreCase
     * @return The leading substring. For example, given "abc" and "abx", the return value will be "ab".
     */
    public static String leadingSubstring(String a, String b, BiPredicate<String, String> comparer) {
        Parameter.named("a").withValue(a).mustBeNonNull();
        Parameter.named("b").withValue(b).mustBeNonNull();

        int index = 0;
        while (index < a.length() && index < b.length() && comparer.test(a.substring(index, index + 1), b.substring(index, index + 1)))
            ++index;
        return a.substring(0, index);
    }

    public static String urlEncode(String value) {
        try {
            return URLEncoder.encode(value, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("Error encoding URL: " + e.getMessage(), e);
        }
    }

    public static boolean string_IsAlphaNumeric(String stringToCheck) {
        Pattern p = Pattern.compile("^[a-zA-Z0-9]*$");
        boolean isAlphaNumeric = p.matcher(stringToCheck).find();
        LogInfo.log_Status("String " + stringToCheck + " was a alphanumeric? " + isAlphaNumeric);

        return isAlphaNumeric;
    }

    /**
     * Strips leading and trailing whitespace, and replaces sequences of whitespace characters
     * with a single space. Matches the behavior of XPath's normalize-whitespace() function.
     *
     * @param input The string to normalize
     * @return The normalized string
     */
    public static String normalizeWhitespace(String input) {
        Parameter.named("input").withValue(input).mustBeNonNull();

        // Take the easy (?) way out: use XPath's normalize-space() as both spec and implementation.
        try {
            Document xmlDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            Element rootElement = xmlDocument.createElement("root");
            xmlDocument.appendChild(rootElement);
            rootElement.appendChild(xmlDocument.createTextNode(input));

            XPath xPath = XPathFactory.newInstance().newXPath();
            return (String) xPath.compile("normalize-space(/root/text())").evaluate(xmlDocument, XPathConstants.STRING);
        } catch (ParserConfigurationException | XPathExpressionException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    /**
     * Returns the input values formatted as an ASCII table.
     * Cells with leading spaces are right-justified in the output.
     *
     * @param rows The rows to display, each containing a string for each cell
     * @return A string with the ASCII-table-formatted cell data.
     */
    public static String formatTable(String[]... rows) {
        // Calculate column widths
        List<Integer> columnWidths = new ArrayList<>();
        for (String[] row : rows) {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                if (columnWidths.size() <= columnIndex) {
                    columnWidths.add(0);
                }
                int length = row[columnIndex] != null ? row[columnIndex].trim().length() : 0;
                if (columnWidths.get(columnIndex) < length) {
                    columnWidths.set(columnIndex, length);
                }
            }
        }

        List<String> lines = new ArrayList<>();
        for (String[] row : rows) {
            List<String> values = new ArrayList<>();
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                String inputValue = row[columnIndex] != null ? row[columnIndex] : "";
                String displayValue = inputValue.trim();
                final int width = columnWidths.get(columnIndex);
                if (inputValue.startsWith(" ")) {
                    values.add(leftPad(displayValue, width));
                } else {
                    values.add(rightPad(displayValue, width));
                }
            }
            lines.add(String.join("  ", values));
        }
        return String.join("\n", lines);
    }

    /**
     * Same as Apache leftPad, jut added to our StringUtils class for convenience.
     *
     * @param str  String to pad
     * @param size Length to pad it to
     * @return str padded to length size, using leading spaces
     */
    private static String leftPad(String str, int size) {
        return org.apache.commons.lang3.StringUtils.leftPad(str, size);
    }

    /**
     * Same as Apache rightPad, jut added to our StringUtils class for convenience.
     *
     * @param str  String to pad
     * @param size Length to pad it to
     * @return str padded to length size, using trailing spaces
     */
    private static String rightPad(String str, int size) {
        return org.apache.commons.lang3.StringUtils.rightPad(str, size);
    }
}
