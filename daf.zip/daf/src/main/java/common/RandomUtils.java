package common;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class RandomUtils {

    public static <T> T randomElement(List<T> list) {
       return list.get(ThreadLocalRandom.current().nextInt(list.size()));
    }

    public static <T> T randomElement(T[] array) {
        return randomElement(Arrays.asList(array));
    }

}
