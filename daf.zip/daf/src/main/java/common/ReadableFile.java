package common;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.function.Predicate;

/**
 * Interface for reading from text files. Implemented by:
 * <ul>
 *     <li>ResourceFile, for files we keep in Git</li>
 *     <li>DataFile, for files outside Git (absolute paths)</li>
 * </ul>
 */
public interface ReadableFile {

    /**
     * Appends the given suffix to the path, and returns a new ReadableFile for that combined path.
     * For example, if the current instance represents path foo/bar.txt, and suffix is ".example",
     * the returned ReadableFile will represent path foo/bar.txt.example.
     *
     * @param suffix String to append to the file path
     * @return A new ReadableFile instance for the modified path
     */
    ReadableFile withFileNameSuffix(String suffix);

    default boolean containsLine(Predicate<String> test) throws RuntimeIOException {
        return readAllLines().stream().anyMatch(test);
    }

    boolean exists();

    String getAbsolutePath();

    /**
     * Returns the filename portion of the path, with directories stripped off.
     *
     * @return The filename portion of the path
     */
    default String getFileName() {
        return toPath().getFileName().toString();
    }

    default byte[] readAllBytes() throws RuntimeIOException {
        return RuntimeIOException.withRuntimeIOExceptions(() ->
                Files.readAllBytes(toPath())
        );
    }

    default List<String> readAllLines() throws RuntimeIOException {
        List<String> lines = RuntimeIOException.withRuntimeIOExceptions(() ->
                Files.readAllLines(Paths.get(getAbsolutePath()), StandardCharsets.UTF_8)
        );

        // Strip off the byte order mark, if any
        if (lines.size() > 0) {
            lines.set(0, StringUtils.trimByteOrderMark(lines.get(0)));
        }

        return lines;
    }

    default String readAllText() throws RuntimeIOException {
        return RuntimeIOException.withRuntimeIOExceptions(() -> {
            String text = FileUtils.readFileToString(new File(getAbsolutePath()), StandardCharsets.UTF_8);
            // Strip off the byte order mark, if any
            return StringUtils.trimByteOrderMark(text);
        });
    }

    /**
     * Reads the contents of a file as JSON, and converts it to the given type.
     * The file may contain comments (both "//" and "/*" style).
     *
     * @param returnType The Java type to return
     * @param <T>        The Java type to return
     * @return The JSON data loaded into the given type
     */
    default <T> T readJsonAs(Class<T> returnType) {
        String json = readAllText();
        try {
            final ObjectMapper mapper = new ObjectMapper();
            mapper.enable(JsonParser.Feature.ALLOW_COMMENTS);
            return mapper.readValue(json, returnType);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    default void copyTo(WritableFile target) throws RuntimeIOException {
        RuntimeIOException.withRuntimeIOExceptions(() ->
                FileUtils.copyFile(toFile(), target.toFile())
        );
    }

    /**
     * Returns the path as a java.io.File (old-style file I/O) object.
     *
     * @return The path as a java.io.File
     */
    default File toFile() {
        return new File(getAbsolutePath());
    }

    /**
     * Returns the path as a java.nio.file.Path (new-style file I/O) object.
     *
     * @return The path as a java.nio.file.Path
     */
    default Path toPath() {
        return Paths.get(getAbsolutePath());
    }
}
