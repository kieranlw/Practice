package common;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * <p>
 * Represents a file, stored in version control, that needs to be accessed by tests.
 * (For files outside of version control, use DataFile instead.)
 * </p><p>
 * Useful methods for working with the file are provided by default interface methods.
 * See implemented interfaces for details.
 * </p>
 */
public class ResourceFile extends ResourcePath implements ReadableFile {
    /**
     * <p>
     * Creates a new ResourceFile for the given relative path.
     * </p><p>
     * For consistency and to keep things DRY, the path should use forward slashes, and
     * should not start with a slash. Paths should start with the package name, not with "src".
     * </p>
     *
     * @param packageAndFilename Package-qualified filename, e.g. "utils2/DBOffset.sql".
     */
    public ResourceFile(String packageAndFilename) {
        super(packageAndFilename);
    }

    @Override
    protected boolean exists(Path candidateAbsolutePath) {
        return Files.isRegularFile(candidateAbsolutePath);
    }

    @Override
    public ReadableFile withFileNameSuffix(String suffix) {
        return new ResourceFile(mavenRelativePath + suffix);
    }
}
