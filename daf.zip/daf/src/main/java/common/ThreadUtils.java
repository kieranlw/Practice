package common;

import java.time.Duration;

public class ThreadUtils {

    /**
     * Track total amount of time test class spends sleeping, in milliseconds.
     * Not intended or accurate for multithreading applications.
     * A temporary property to be removed once metrics are collected from project run iterations.
     */
    public static long totalTimeSpentSleeping = 0;

    private ThreadUtils() {
    }

    /**
     * Equivalent to Thread.sleep, but without checked exceptions
     *
     * @param milliseconds How many milliseconds to sleep
     */
    public static void sleep(long milliseconds) {
        try {
            //noinspection SSBasedInspection
            Thread.sleep(milliseconds);
            totalTimeSpentSleeping += milliseconds;
        } catch (InterruptedException ex) {
            throw new RuntimeException(ex.getMessage(), ex);
        }
    }

    public static void sleep(Duration duration) {
        sleep(duration.toMillis());
    }
}