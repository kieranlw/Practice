package common;

import common.custom_matchers.MatchesRegEx;
import common.custom_matchers.StringMatcherPointingToFirstDifference;
import org.hamcrest.Matcher;
import org.hamcrest.Matchers;
import org.hamcrest.text.CharSequenceLength;

import java.util.Collection;
import java.util.regex.Pattern;

public final class Is {
    private Is() {
    }

    public static <T> Matcher<T> equalTo(T expected) {
        return expected instanceof String
                ? new StringMatcherPointingToFirstDifference<>(expected)
                : Matchers.equalTo(expected);
    }

    public static <T> Matcher<T> notEqualTo(T expected) {
        return Matchers.not(Matchers.equalTo(expected));
    }

    public static Matcher<String> equalToIgnoringCase(String expected) {
        return new StringMatcherPointingToFirstDifference.CaseInsensitive(expected);
    }

    public static <T extends Comparable<T>> Matcher<T> lessThan(T expected) {
        return Matchers.lessThan(expected);
    }

    public static <T extends Comparable<T>> Matcher<T> lessThanOrEqualTo(T expected) {
        return Matchers.lessThanOrEqualTo(expected);
    }

    public static <T extends Comparable<T>> Matcher<T> greaterThan(T expected) {
        return Matchers.greaterThan(expected);
    }

    public static <T extends Comparable<T>> Matcher<T> greaterThanOrEqualTo(T expected) {
        return Matchers.greaterThanOrEqualTo(expected);
    }

    public static <T> Matcher<T> not(Matcher<T> matcher) {
        return Matchers.not(matcher);
    }

    public static Matcher<Collection<?>> emptyCollection() {
        return Matchers.empty();
    }

    public static Matcher<Collection<?>> nonEmptyCollection() {
        return Matchers.not(Matchers.empty());
    }

    public static <T> Matcher<Iterable<? extends T>> collectionContaining(T value) { return Matchers.contains(value); }

    public static <T> Matcher<T> sameInstanceAs(T value) {
        return Matchers.sameInstance(value);
    }

    public static <T> Matcher<T> differentInstanceThan(T value) {
        return Matchers.not(sameInstanceAs(value));
    }

    public static Matcher<String> stringContaining(String value) {
        return Matchers.containsString(value);
    }

    public static Matcher<String> stringNotContaining(String value) {
        return Matchers.not(Matchers.containsString(value));
    }

    public static Matcher<String> stringContainingWithIgnoreCase(String value) {
        return Matchers.containsStringIgnoringCase(value);
    }

    public static Matcher<String> stringStartsWithIgnoreCase(String value) {
        return Matchers.startsWithIgnoringCase(value);
    }

    public static Matcher<String> stringEndsWithIgnoreCase(String value) {
        return Matchers.endsWithIgnoringCase(value);
    }

    // Here we have a return type of Matcher<CharSequence>, just because that's what Hamcrest
    // already provides. If you want to declare a variable or parameter that can accept either a
    // Matcher<String> or a Matcher<CharSequence>, declare it as "Matcher<? super String>".

    public static Matcher<CharSequence> stringWhoseLength(Matcher<Integer> condition) {
        return CharSequenceLength.hasLength(condition);
    }

    public static Matcher<String> nullOrEmptyString() {
        return oneOf(null, "");
    }

    public static Matcher<String> notNullOrEmptyString() {
        return not(nullOrEmptyString());
    }

    public static Matcher<String> oneOf(String... values) { return Matchers.oneOf(values); }

    public static Matcher<String> alphanumeric() {
        return new MatchesRegEx(Pattern.compile("^[a-zA-Z0-9]+$"), "an alphanumeric string");
    }

    public static Matcher<String> alphanumericOrEmpty() {
        return new MatchesRegEx(Pattern.compile("^[a-zA-Z0-9]*$"), "an alphanumeric or empty string");
    }

    /**
     * <p>
     * Is the floating-point value within acceptableError of expected?
     * </p><p>
     * Beware: acceptableError isn't exact because of the way floating-point works.
     * If you're checking for, say, "within a penny", don't pass exactly 0.01 for
     * acceptableError, because that will lead to unexpected errors:
     * </p>
     * <pre>
     * Verify.that(1.01, Is.closeTo(1.02, 0.01)); // fails
     * Verify.that(1.01, Is.closeTo(1.02, 0.01 + 1e-10)); // passes
     * </pre>
     * <p>
     * For details, see https://stackoverflow.com/questions/588004/is-floating-point-math-broken.
     * </p>
     *
     * @param expected        The expected value to compare to
     * @param acceptableError The range of +/- acceptable error
     * @return Matcher
     */
    public static Matcher<Double> closeTo(double expected, double acceptableError) {
        return Matchers.closeTo(expected, acceptableError);
    }
}
