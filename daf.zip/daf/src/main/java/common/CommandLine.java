package common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CommandLine {

    // We log from multiple threads, so LogInfo's "show nearest non-core-DAF-library caller"
    // feature would actually make our logs harder to follow. Use a plain slf4j logger instead.
    private static final Logger LOGGER = LoggerFactory.getLogger(CommandLine.class);

    private final Shell shell;
    private boolean displayOutput = true;
    private String workingDirectory = ".";

    public CommandLine(Shell shell) {
        this.shell = shell;
    }

    public CommandLine displayOutput(boolean value) {
        this.displayOutput = value;
        return this;
    }

    public CommandLine workingDirectory(String value) {
        workingDirectory = value;
        return this;
    }

    private void log(String message) {
        // We route all our logging through this one method, so that we show the same immediate-caller
        // name in all of our log entries ("starting", "output", and "exit code")
        LOGGER.debug(message);
    }

    /**
     * @throws CommandLineException if there was an error starting the command
     * @throws RuntimeException     if Process.waitFor throws an exception
     */
    public CommandOutput execute(String... arguments) {
        String[] commandLine = shell.buildCommandLine(arguments);
        log("Starting: " + String.join(" ", commandLine));
        ProcessBuilder builder = new ProcessBuilder(commandLine);
        builder.directory(new File(workingDirectory));
        Process process;
        try {
            process = builder.start();
        } catch (IOException e) {
            throw new CommandLineException("Error starting process: " + e.getMessage(), e);
        }

        List<String> standardErrorLines = new ArrayList<>();
        List<String> standardOutputLines = new ArrayList<>();
        StreamGobbler errorGobbler = new StreamGobbler(process.getErrorStream(), line -> {
            if (displayOutput) {
                log("Error: " + line);
            }
            standardErrorLines.add(line);
        });
        StreamGobbler standardGobbler = new StreamGobbler(process.getInputStream(), line -> {
            if (displayOutput) {
                log(line);
            }
            standardOutputLines.add(line);
        });
        errorGobbler.start();
        standardGobbler.start();
        try {
            process.waitFor();
        } catch (InterruptedException e) {
            throw new RuntimeException("process.waitFor threw exception: " + e.getMessage(), e);
        }

        log("Exit code: " + process.exitValue());

        return ImmutableCommandOutput.builder()
                .exitCode(process.exitValue())
                .standardErrorLines(standardErrorLines)
                .standardOutputLines(standardOutputLines)
                .build();
    }
}
