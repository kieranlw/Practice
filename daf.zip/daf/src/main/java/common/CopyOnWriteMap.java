package common;

import com.google.common.collect.ImmutableMap;

import java.util.Collection;
import java.util.Map;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

/**
 * Like a Map, but instead of mutators, has methods that returns new immutable copies of the map.
 * Inspired by .NET's ImmutableDictionary, though this version is not optimized for large collections.
 *
 * @param <K> Key type
 * @param <V> Value type
 */
public class CopyOnWriteMap<K, V> {
    private final ImmutableMap<K, V> map;

    public CopyOnWriteMap() {
        this(builder -> builder);
    }

    public CopyOnWriteMap(Map<K, V> map) {
        this(builder -> builder.putAll(map));
    }

    private CopyOnWriteMap(UnaryOperator<ImmutableMap.Builder<K, V>> build) {
        this.map = build.apply(ImmutableMap.builder()).build();
    }

    /**
     * Convenience factory method, to create a CopyOnWriteMap from a flat list.
     *
     * @param collection The input collection
     * @param getKey     A lambda to get the Map key for an input value
     * @param <K>        Key type
     * @param <V>        Value type
     * @return The new CopyOnWriteMap
     */
    public static <K, V> CopyOnWriteMap<K, V> fromCollection(Collection<V> collection, Function<V, K> getKey) {
        return fromCollection(collection, getKey, v -> v);
    }

    /**
     * Convenience factory method, to create a CopyOnWriteMap from a flat list.
     *
     * @param collection The input collection
     * @param getKey     A lambda to get the Map key for an input value
     * @param getValue   A lambda to get the Map value for an input value
     * @param <S>        Input value type
     * @param <K>        Key type
     * @param <V>        Value type
     * @return The new CopyOnWriteMap
     */
    public static <S, K, V> CopyOnWriteMap<K, V> fromCollection(Collection<S> collection, Function<S, K> getKey, Function<S, V> getValue) {
        Map<K, V> map = collection.stream().collect(Collectors.toMap(getKey, getValue));
        return new CopyOnWriteMap<>(builder -> builder.putAll(map));
    }

    /**
     * Escape hatch in case we need Map methods.
     *
     * @return The contents as an immutable Map. Mutator methods will throw.
     */
    public Map<K, V> asMap() {
        return map;
    }

    public V get(K key) {
        return map.get(key);
    }

    public CopyOnWriteMap<K, V> with(K key, V value) {
        return new CopyOnWriteMap<>(builder -> {
            for (Map.Entry<K, V> entry : map.entrySet()) {
                if (!entry.getKey().equals(key)) {
                    builder.put(entry);
                }
            }
            builder.put(key, value);
            return builder;
        });
    }
}
