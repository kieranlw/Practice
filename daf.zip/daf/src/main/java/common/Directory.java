package common;

import org.jetbrains.annotations.NotNull;
import org.springframework.util.AntPathMatcher;
import utils2.LogInfo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Directory {
    private final Path path;

    public Directory(String path) {
        this(Paths.get(path));
    }

    public Directory(Path path) {
        this.path = path;
    }

    /**
     * Creates a new subdirectory under the system temp directory.
     * If the directory already exists, its previous contents are left unchanged.
     *
     * @param subdirectoryName Name of the subdirectory to create under the temp directory
     * @return A new Directory instance for working with the new directory
     */
    public static Directory createTempDirectory(String subdirectoryName) {
        return new Directory(System.getProperty("java.io.tmpdir"))
                .createDirectory("DAF")
                .createDirectory(subdirectoryName);
    }

    public Directory createDirectory(String subdirectoryName) {
        final Directory newDirectory = directory(subdirectoryName);
        newDirectory.create();
        return newDirectory;
    }

    public void create() {
        try {
            Files.createDirectories(path);
        } catch (IOException e) {
            throw new RuntimeException("Error creating directory '" + path + "': " + e.getMessage(), e);
        }
    }

    /**
     * <p>
     * Creates one or more items in the directory. If an item ends with a slash
     * or backslash, it's created as a directory, otherwise it's created as an
     * empty file.
     * </p><p>
     * Intervening directories are created automatically (both when creating
     * directories and when creating files).
     * </p><p>
     * Each string can be its own comma-delimited list, e.g. "abc,def/xyz".
     * This is to help with places where a single string is more convenient,
     * e.g. parameterized tests.
     * </p>
     *
     * @param items List of relative paths to create. Each value may itself
     *              be a comma-delimited list. Items ending with a slash are
     *              created as directories; others are created as empty files.
     */
    public void createItems(@NotNull String... items) {
        for (String item : items) {
            final String[] chunks = item.split(",");
            // Filter out empty values (covers the case where the caller does
            // pass a string, but it's empty - e.g. from a parameterized test)
            final List<String> paths = Arrays.stream(chunks)
                    .map(s -> s.trim())
                    .filter(s -> !s.isEmpty())
                    .collect(Collectors.toList());

            for (String path : paths) {
                if (path.endsWith("/") || path.endsWith("\\")) {
                    createDirectory(path);
                } else {
                    final WritableFile file = file(path);
                    file.directory().create();
                    file.writeAllText("");
                }
            }
        }
    }

    public Directory directory(String subdirectoryName) {
        return new Directory(path.resolve(subdirectoryName));
    }

    public boolean exists() {
        return Files.isDirectory(path);
    }

    public String getAbsolutePath() {
        return path.toString();
    }

    /**
     * <p>
     * Returns a string representing the items' paths relative to this
     * Directory. The result is suitable for comparison to an expected value.
     * </p><p>
     * The paths are returned with forward slashes as path delimiters.
     * If an item is a directory, it's returned with a slash appended to the end.
     * If multiple items are provided, the result is a comma-separated list,
     * with items alphabetized based on their relative paths.
     * </p>
     *
     * @return A string representing the items' paths relative to this
     * Directory.
     */
    @SuppressWarnings("WeakerAccess")
    public String stringifyPaths(List<Path> items) {
        return items.stream()
                .map(item -> {
                            final String itemPath = path.relativize(item)
                                    .toString()
                                    .replace("\\", "/");
                            if (Files.isDirectory(item)) {
                                return itemPath + "/";
                            } else {
                                return itemPath;
                            }
                        }
                )
                .sorted(Comparator.comparing(s -> s, String::compareToIgnoreCase))
                .collect(Collectors.joining(","));
    }

    /**
     * @see #stringifyPaths(List)
     */
    @SuppressWarnings("unused")
    public String stringifyPaths(Path... items) {
        return stringifyPaths(Arrays.asList(items));
    }

    /**
     * @see #stringifyPaths(List)
     */
    public String stringifyFiles(List<WritableFile> items) {
        return stringifyPaths(ListUtils.map(items, i -> i.toPath()));
    }

    /**
     * @see #stringifyPaths(List)
     */
    @SuppressWarnings("unused")
    public String stringifyFiles(WritableFile... items) {
        return stringifyFiles(Arrays.asList(items));
    }

    /**
     * Returns a string representation of all the directories and files in the
     * directory.
     *
     * @see #stringifyPaths(List)
     */
    public String stringifyContents() {
        return stringifyPaths(findMatchingPaths("**"));
    }

    /**
     * Returns an object representing the given file within the directory.
     * Does not check whether the file exists on disk.
     *
     * @param relativePath Relative path to the file
     * @return WritableFile object representing the file
     */
    @NotNull
    public WritableFile file(String relativePath) {
        return new DataFile(Paths.get(path.toString(), relativePath).toString());
    }

    /**
     * <p>
     * Finds all files in the directory matching a given Ant-style wildcard.
     * </p><p>
     * For details on the syntax, see https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/util/AntPathMatcher.html.
     * </p>
     *
     * @param matchPattern The wildcard to search for. Can include either
     *                     forward slashes or backslashes if desired.
     * @return List of matching files.
     */
    public List<WritableFile> findFiles(String matchPattern) {
        return findMatchingPaths(matchPattern).stream()
                .filter(p -> Files.isRegularFile(p))
                .map(p -> new DataFile(p.toString()))
                .collect(Collectors.toList());
    }

    private List<Path> findMatchingPaths(String matchPattern) {
        final int depth = Integer.MAX_VALUE;
        final String pattern = (path + "\\" + matchPattern).replace('/', '\\');

        final AntPathMatcher pathMatcher = new AntPathMatcher("\\");
        pathMatcher.setCaseSensitive(false);

        final BiPredicate<Path, BasicFileAttributes> isMatch =
                (p, a) -> {
                    // Never match the Directory itself
                    if (p.equals(path)) {
                        return false;
                    }

                    final String path = p.toString().replace('/', '\\');
                    return pathMatcher.match(pattern, path);
                };

        try (final Stream<Path> paths = Files.find(path, depth, isMatch)) {
            return paths.collect(Collectors.toList());
        } catch (IOException ex) {
            throw new RuntimeException("Error finding '" + matchPattern + "' in directory '" + path + "': " + ex.getMessage(), ex);
        }
    }

    private void forEachFile(String matchPattern, Consumer<WritableFile> consumer,
                             String verbWithIng, String verbWithEd) {
        LogInfo.log_Status(verbWithIng + " '" + path + "\\" + matchPattern + "':");
        final List<WritableFile> files = findFiles(matchPattern);

        final List<String> errors = new ArrayList<>();
        final AtomicInteger numberAffected = new AtomicInteger();
        for (WritableFile file : files) {
            try {
                consumer.accept(file);
                LogInfo.log_Status("  " + verbWithEd + " '" + file.getAbsolutePath() + "'");
                numberAffected.incrementAndGet();
            } catch (RuntimeIOException e) {
                errors.add(e.getMessage());
            }
        }

        if (errors.size() == 0) {
            LogInfo.log_Status(numberAffected.get() + " file(s) " + verbWithEd.toLowerCase());
        } else {
            throw new RuntimeException(numberAffected.get() + " file(s) " + verbWithEd.toLowerCase() + ", " +
                    errors.size() + " error(s):\n" +
                    String.join("\n", ListUtils.map(errors, e -> "  " + e)));
        }
    }

    /**
     * <p>
     * Deletes all files in the directory matching a given Ant-style wildcard.
     * </p><p>
     * For details on the syntax, see https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/util/AntPathMatcher.html.
     * </p>
     *
     * @param matchPattern The wildcard to search for. Can include either
     *                     forward slashes or backslashes if desired.
     */
    public void deleteFiles(String matchPattern) {
        forEachFile(matchPattern, WritableFile::delete, "Deleting", "Deleted");
    }

    /**
     * <p>
     * Recycles (i.e., sends to the Recycle Bin) all files in the directory
     * matching a given Ant-style wildcard.
     * </p><p>
     * For details on the syntax, see https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/util/AntPathMatcher.html.
     * </p>
     *
     * @param matchPattern The wildcard to search for. Can include either
     *                     forward slashes or backslashes if desired.
     */
    public void recycleFiles(String matchPattern) {
        forEachFile(matchPattern, WritableFile::recycle, "Recycling", "Recycled");
    }

    /**
     * Deletes the directory. Works for non-empty directories.
     */
    public void delete() {
        FileUtils.delete(path);
    }

    /**
     * If the directory exists, deletes it. Works for non-empty directories.
     */
    public void deleteIfExists() {
        FileUtils.deleteIfExists(path);
    }

    /**
     * Sends the directory to the Recycle Bin. Works for non-empty directories.
     */
    public void recycle() {
        FileUtils.recycle(path);
    }

    /**
     * If the directory exists, sends it to the Recycle Bin.
     * Works for non-empty directories.
     */
    public void recycleIfExists() {
        FileUtils.recycleIfExists(path);
    }

    /**
     * Cleans out the directory's contents. Items are sent to the Recycle Bin,
     * rather than being deleted outright, just in case.
     */
    public void clean() {
        // Find items directly in the directory - both files and directories.
        // When we recycle the directories, that'll catch their contents too.
        final List<Path> topLevelItems = findMatchingPaths("*");

        // Recycle them all
        LogInfo.log_Status("Cleaning directory \"" + path + "\" " +
                "(recycling " + topLevelItems.size() + " item" + (topLevelItems.size() == 1 ? "" : "s") + ")");
        FileUtils.recycle(topLevelItems);
    }

    public Path toPath() {
        return path;
    }

    @Override
    public String toString() {
        return "Directory(" + path + ')';
    }
}
