package common;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;

public interface WritableFile extends ReadableFile {
    /**
     * Returns an object representing the containing directory.
     *
     * @return A Directory object for the containing directory
     */
    default Directory directory() {
        return new Directory(toPath().getParent());
    }

    /**
     * Deletes the file. Throws on failure.
     *
     * @throws RuntimeIOException if an error occurs
     */
    default void delete() throws RuntimeIOException {
        FileUtils.delete(toPath());
    }

    /**
     * If the file exists, deletes it. Throws on failure.
     *
     * @throws RuntimeIOException if an error occurs
     */
    default void deleteIfExists() throws RuntimeIOException {
        FileUtils.deleteIfExists(toPath());
    }

    /**
     * Sends the file to the Recycle Bin. Throws on failure.
     *
     * @throws RuntimeIOException if an error occurs
     */
    default void recycle() throws RuntimeIOException {
        FileUtils.recycle(toPath());
    }

    /**
     * If the file exists, sends it to the Recycle Bin. Throws on failure.
     *
     * @throws RuntimeIOException if an error occurs
     */
    default void recycleIfExists() throws RuntimeIOException {
        FileUtils.recycleIfExists(toPath());
    }

    default void writeAllBytes(byte[] bytes) throws IOException {
        Files.write(toPath(), bytes);
    }

    /**
     * Writes the given lines to the file, using UTF-8 encoding. Each line
     * (including the last) is followed by the platform's line separator.
     *
     * @param lines The lines to write to the file
     * @throws IOException if an error occurs
     */
    default void writeAllLines(List<String> lines) throws IOException {
        Files.write(toPath(), lines, StandardCharsets.UTF_8);
    }

    /**
     * Writes the given string to the file, using UTF-8 encoding.
     *
     * @param text The text to write to the file
     * @throws RuntimeIOException if an error occurs
     */
    default void writeAllText(String text) throws RuntimeIOException {
        RuntimeIOException.withRuntimeIOExceptions(() -> {
            writeAllBytes(text.getBytes(StandardCharsets.UTF_8));
        });
    }
}
