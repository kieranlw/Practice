package common;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.StringDescription;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import utils.Parameter;
import utils.RunnableWithException;
import utils2.LogInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

public final class Verify {
    private static final ThreadLocal<VerifyContext> context = new InheritableThreadLocal<VerifyContext>() {
        @Override
        protected VerifyContext initialValue() {
            // Create a new instance for every thread
            return new VerifyContext();
        }
    };

    private Verify() {}

    /**
     * Runs the given code block in a soft-assert context: all Verify failures inside this block
     * are added to a list rather than throwing immediately, then one exception is thrown at the
     * end of the block.
     *
     * @param block Code block to execute in a soft-assert context
     */
    public static void allOf(Runnable block) {
        context.get().withSoftAssertionScope(block);
    }

    /**
     * Transitional version of <code>allOf</code> for migrating from SoftAssert. Usage:
     * <ol>
     *     <li>Change <pre>SoftAssert softAssert = new SoftAssert();</pre> to <pre>Verify.allOf(softAssert -> {</pre></li>
     *     <li>Change <pre>softAssert.assertAll();</pre> to <pre>});</pre> and then reformat (Ctrl+Alt+L)</li>
     *     <li>
     *         For each usage of <code>softAssert</code> inside the block, click on the method name, perform an
     *         Inline Method refactoring (Ctrl+Alt+N), and select "Inline this only and keep the method".
     *         <i>(If you're running in Parallels, you may need to press Ctrl+Alt+N twice)</i>
     *     </li>
     *     <li>Change <pre>Verify.allOf(softAssert -> {</pre> to <pre>Verify.allOf(() -> {</pre></li>
     * </ol>
     *
     * @param block Code block to execute in a soft-assert context
     */
    public static void allOf(Consumer<SoftAssertAdapter> block) {
        allOf(() -> block.accept(new SoftAssertAdapter()));
    }

    /**
     * Verifies that the value matches the given condition. Throws on failure, logs on success.
     *
     * @param actual      The value to check
     * @param matcher     The condition that must be satisfied
     * @param description Description of the value or of the check being performed
     * @param <T>         Type of the value
     */
    public static <T> void that(@Nullable T actual, @NotNull Matcher<T> matcher, @NotNull String description) {
        Parameter.named("description").withValue(description).mustBeNonNull();
        Parameter.named("matcher").withValue(matcher).mustBeNonNull();

        if (matcher.matches(actual)) {
            logPass(description, actual, matcher);
        } else {
            Description failureDescription = new StringDescription();
            if (!description.isEmpty()) {
                failureDescription.appendText(description);
            }
            failureDescription.appendText("\nExpected: ")
                    .appendDescriptionOf(matcher)
                    .appendText("\n     but: ");
            matcher.describeMismatch(actual, failureDescription);

            context.get().fail(failureDescription.toString());
        }
    }

    /**
     * Verifies that the value matches the given condition. Throws on failure, logs on success.
     *
     * @param actual  The value to check
     * @param matcher The condition that must be satisfied
     * @param <T>     Type of the value
     */
    public static <T> void that(@Nullable T actual, @NotNull Matcher<T> matcher) {
        Parameter.named("matcher").withValue(matcher).mustBeNonNull();

        that(actual, matcher, "");
    }

    /**
     * Verifies that the given condition is true. Throws on failure, logs on success.
     * Use this overload sparingly, when no better comparison is available.
     *
     * @param actual The condition to check
     */
    public static void that(boolean actual) {
        that(actual, Is.equalTo(true));
    }

    /**
     * Verifies that the given condition is true. Throws on failure, logs on success.
     * Use this overload sparingly, when no better comparison is available.
     *
     * @param actual      The condition to check
     * @param description Description of the value or of the check being performed
     */
    public static void that(boolean actual, String description) {
        that(actual, Is.equalTo(true), description);
    }

    /**
     * <p>Verifies the behavior of a given piece of code. For example,</p>
     * <pre>Verify.that(() -> divide(1, 0)).throwsException(ArithmeticException.class);</pre>
     *
     * @param lambda Code to verify
     * @return A fluent interface with verification methods
     */
    @Contract(pure = true)
    public static LambdaVerifications that(RunnableWithException lambda) {
        return that(lambda, "");
    }

    /**
     * <p>Verifies the behavior of a given piece of code. For example,</p>
     * <pre>Verify.that(() -> divide(1, 0), "Denominator is zero").throwsException(ArithmeticException.class);</pre>
     *
     * @param lambda Code to verify
     * @return A fluent interface with verification methods
     */
    @Contract(pure = true)
    public static LambdaVerifications that(RunnableWithException lambda, String description) {
        return that(() -> {
            lambda.run();
            return null;
        }, description);
    }

    /**
     * <p>Verifies the behavior of a given piece of code. For example,</p>
     * <pre>Verify.that(() -> divide(1, 0)).throwsException(ArithmeticException.class);</pre>
     *
     * @param lambda Code to verify
     * @return A fluent interface with verification methods
     */
    @Contract(pure = true)
    public static LambdaVerifications that(Callable<?> lambda) {
        return that(lambda, "");
    }

    /**
     * <p>Verifies the behavior of a given piece of code. For example,</p>
     * <pre>Verify.that(() -> divide(1, 0), "Denominator is zero").throwsException(ArithmeticException.class);</pre>
     *
     * @param lambda Code to verify
     * @return A fluent interface with verification methods
     */
    @Contract(pure = true)
    public static LambdaVerifications that(Callable<?> lambda, String description) {
        Exception exception = null;
        try {
            lambda.call();
        } catch (Exception e) {
            exception = e;
        }
        return new LambdaVerifications(exception, description);
    }

    private static <T> void logPass(@NotNull String reason, @Nullable T value, @NotNull Matcher<T> matcher) {
        Parameter.named("reason").withValue(reason).mustBeNonNull();
        Parameter.named("matcher").withValue(matcher).mustBeNonNull();

        Description description = new StringDescription();
        if (!reason.isEmpty()) {
            description.appendText(reason)
                    .appendText(": ");
        }
        description.appendText("Value ")
                .appendValue(value)
                .appendText(" is ")
                .appendDescriptionOf(matcher);

        LogInfo.log_AndPass(description.toString());
    }

    public static void fail(String description) {
        context.get().fail(description);
    }

    private static class VerifyContext {
        private int softAssertionScopeCount;
        private List<String> failures = new ArrayList<>();

        public void withSoftAssertionScope(Runnable block) {
            if (softAssertionScopeCount == 0) {
                failures.clear();
            }

            ++softAssertionScopeCount;
            try {
                block.run();
            } finally {
                --softAssertionScopeCount;
            }

            if (softAssertionScopeCount == 0 && !failures.isEmpty()) {
                throw new AssertionError("The following assertions failed:\n\n" + String.join("\n\n", failures));
            }
        }

        void fail(String message) {
            if (softAssertionScopeCount == 0) {
                throw new AssertionError(message);
            } else {
                // If the message starts with newline(s), remove them, so our output
                // has only one blank line between each failure
                failures.add(message.replaceAll("^[\\r\\n]+", ""));
            }
        }
    }

    public static class SoftAssertAdapter {
        public void assertEquals(boolean actual, boolean expected, String description) {
            Verify.that(actual, Is.equalTo(expected), description);
        }

        public void assertEquals(int actual, int expected) {
            Verify.that(actual, Is.equalTo(expected));
        }

        public void assertEquals(int actual, int expected, String description) {
            Verify.that(actual, Is.equalTo(expected), description);
        }

        public void assertEquals(long actual, long expected, String description) {
            Verify.that(actual, Is.equalTo(expected), description);
        }

        public void assertEquals(String actual, String expected) {
            Verify.that(actual, Is.equalTo(expected));
        }

        public void assertEquals(String actual, String expected, String description) {
            Verify.that(actual, Is.equalTo(expected), description);
        }

        public <T> void assertEquals(T actual, T expected, String description) {
            Verify.that(actual, Is.equalTo(expected), description);
        }

        public void assertFalse(boolean condition, String description) {
            Verify.that(condition, Is.equalTo(false), description);
        }

        public void assertNotEquals(String actual, String expected) {
            Verify.that(actual, Is.notEqualTo(expected));
        }

        public void assertNotEquals(String actual, String expected, String description) {
            Verify.that(actual, Is.notEqualTo(expected), description);
        }

        public void assertNotNull(Object value) {
            Verify.that(value, Is.notEqualTo(null));
        }

        public void assertTrue(boolean condition) {
            Verify.that(condition);
        }

        public void assertTrue(boolean condition, String description) {
            Verify.that(condition, description);
        }

        public void fail(String description) {
            Verify.fail(description);
        }
    }

    public static class LambdaVerifications {
        private final Exception exception;
        private final String descriptionPrefix;

        public LambdaVerifications(Exception exception, String description) {
            this.exception = exception;
            this.descriptionPrefix = description.isEmpty() ? "" : description + ": ";
        }

        /**
         * <p>
         * Verifies that the lambda does not throw exceptions.
         * </p><p>
         * The test could just run the line of code directly, but this allows
         * you to make the intent clear (this line of code is here for a reason -
         * it's here because we're making sure it doesn't throw).
         * </p>
         */
        public void doesNotThrow() {
            if (exception != null) {
                throw new AssertionError("Expected no exception, but got: " + exception, exception);
            }
        }

        public void throwsException(Class<? extends Exception> exceptionClass) {
            throwsException(exceptionClass, "");
        }

        public void throwsException(Class<? extends Exception> exceptionClass, String expectedMessage) {
            if (exceptionClass == null) {
                doesNotThrow();
                return;
            }

            if (exception == null) {
                Verify.fail(descriptionPrefix + "Expected exception of type " + exceptionClass.getName() + ", but none was thrown");
            } else {
                Verify.allOf(() -> {
                    Verify.that(exception.getClass(), Is.equalTo(exceptionClass),
                            descriptionPrefix + "Exception type");

                    if (!expectedMessage.isEmpty()) {
                        Verify.that(exception.getMessage(), Is.equalTo(expectedMessage),
                                descriptionPrefix + "Exception message");
                    }
                });
            }
        }
    }
}
