package common.networkFileUtils;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.utils.SmbFiles;
import common.Is;
import common.Verify;
import org.openqa.selenium.support.ui.Quotes;
import utils2.page_components.*;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.time.Duration;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;

//TODO: refactor and cleanup
public class NetworkFileUtils {
    private NetworkUser networkUser;
    private SMBClient client;

    public NetworkFileUtils(NetworkUser networkUser) {
        this.networkUser = networkUser;
        client = new SMBClient();
    }

    public void deleteFile(INetworkFilePath filePath) {
        try (Connection connection = client.connect(filePath.getServer())) {
            AuthenticationContext ac = new AuthenticationContext(networkUser.getUser(), networkUser.getPassword().toCharArray(), networkUser.getDomain());
            Session session = connection.authenticate(ac);

            // Connect to Share
            try (DiskShare share = (DiskShare) session.connectShare(filePath.getShare())) {
                if (share.fileExists(filePath.getPathWithFile())) {
                    share.rm(filePath.getPathWithFile());
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public void deleteFilesForFolder(INetworkFilePath filePath) {
        try (Connection connection = client.connect(filePath.getServer())) {
            AuthenticationContext ac = new AuthenticationContext(networkUser.getUser(), networkUser.getPassword().toCharArray(), networkUser.getDomain());
            Session session = connection.authenticate(ac);

            // Connect to Share
            try (DiskShare share = (DiskShare) session.connectShare(filePath.getShare())) {
                List<FileIdBothDirectoryInformation> fileList = getFiles(share, filePath);
                for (FileIdBothDirectoryInformation file : fileList) {
                    share.rm(filePath.getPathRemainder() + "\\" + file.getFileName());
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public void waitForFileCount(INetworkFilePath filePath, int numberOfFiles, Duration durationToWait) {
        WaitUtils.conditionMet(
                () -> getListOfFiles(filePath).size() == numberOfFiles,
                "file count in " + filePath.getAbsolutePath() + " to be " + numberOfFiles,
                durationToWait);
    }

    public void waitForFile(INetworkFilePath filePath, Duration durationToWait)  {
        WaitUtils.conditionMet(
                () -> listOfFilesContainsFile(getListOfFiles(filePath), filePath.getFile()),
                "existence of file \"" + filePath.getAbsolutePath() + "\"",
                durationToWait);
    }

    private boolean listOfFilesContainsFile(List<FileIdBothDirectoryInformation> fileList, String fileName){
        for(FileIdBothDirectoryInformation file : fileList){
            if(file.getFileName().equals(fileName)){
                return true;
            }
        }
        return false;
    }

    public ServerFilePath getLatestFile(INetworkFilePath filePath) {
        try (Connection connection = client.connect(filePath.getServer())) {
            AuthenticationContext ac = new AuthenticationContext(networkUser.getUser(), networkUser.getPassword().toCharArray(), networkUser.getDomain());
            Session session = connection.authenticate(ac);

            // Connect to Share
            try (DiskShare share = (DiskShare) session.connectShare(filePath.getShare())) {
                List<FileIdBothDirectoryInformation> files = getFiles(share, filePath);
                files.sort(new SortFilesLatest());
                return new ServerFilePath(filePath.getAbsolutePath() + "\\" + files.get(0).getFileName());
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    private class SortFilesLatest implements  Comparator<FileIdBothDirectoryInformation>{
        @Override
        public int compare(FileIdBothDirectoryInformation a, FileIdBothDirectoryInformation b)
        {
            return (int)( b.getCreationTime().toEpochMillis() - a.getCreationTime().toEpochMillis());
        }
    }

    private List<FileIdBothDirectoryInformation> getListOfFiles(INetworkFilePath filePath) {
        try (Connection connection = client.connect(filePath.getServer())) {
            AuthenticationContext ac = new AuthenticationContext(networkUser.getUser(), networkUser.getPassword().toCharArray(), networkUser.getDomain());
            Session session = connection.authenticate(ac);

            // Connect to Share
            try (DiskShare share = (DiskShare) session.connectShare(filePath.getShare())) {
                return getFiles(share, filePath);
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public void verifyFileFound(INetworkFilePath filePath){
        List<FileIdBothDirectoryInformation> files = getListOfFiles(filePath);
        FileIdBothDirectoryInformation fileWeWant = files.stream().filter(a -> a.getFileName().equals(filePath.getFile())).findFirst().orElse(null);
        Verify.that(fileWeWant != null, "Checking that file " + Quotes.escape(filePath.getFile()) + " exists.");
    }

    public void verifyFileNOTFound(INetworkFilePath filePath){
        List<FileIdBothDirectoryInformation> files = getListOfFiles(filePath);
        FileIdBothDirectoryInformation fileWeWant = files.stream().filter(a -> a.getFileName().equals(filePath.getFile())).findFirst().orElse(null);
        Verify.that(fileWeWant == null, "Checking that file " + Quotes.escape(filePath.getFile()) + " does NOT exist.");
    }

    public void verifyFileCountCorrect(INetworkFilePath filePath, int expectedCount){
        List<FileIdBothDirectoryInformation> files = getListOfFiles(filePath);
        Verify.that(files.size(), Is.equalTo(expectedCount));
    }

    private List<FileIdBothDirectoryInformation> getFiles(DiskShare share, INetworkFilePath filePath) {
        final String pathRemainder = filePath.getPathRemainder();
        return share.list(pathRemainder).stream()
                .filter(a -> !a.getFileName().equals(".") &&
                        !a.getFileName().equals("..") &&
                        share.fileExists(pathRemainder + "\\" + a.getFileName()) // skip folders
                ).collect(Collectors.toList());
    }

    //Include file name with the destination.  Copies from Remote to Local
    public void copyRemoteFileToLocalLocation(INetworkFilePath filePath, File destination) {
        try (Connection connection = client.connect(filePath.getServer())) {
            AuthenticationContext ac = new AuthenticationContext(networkUser.getUser(), networkUser.getPassword().toCharArray(), networkUser.getDomain());
            Session session = connection.authenticate(ac);

            // Connect to Share
            try (DiskShare share = (DiskShare) session.connectShare(filePath.getShare())) {
                try (FileOutputStream fos = new FileOutputStream(destination);
                     BufferedOutputStream bos = new BufferedOutputStream(fos)) {

                    com.hierynomus.smbj.share.File smbFileRead = share.openFile(filePath.getPathWithFile(), EnumSet.of(AccessMask.GENERIC_READ), null, SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null);
                    InputStream in = smbFileRead.getInputStream();
                    byte[] buffer = new byte[4096];
                    int len = 0;
                    while ((len = in.read(buffer, 0, buffer.length)) != -1) {
                        bos.write(buffer, 0, len);
                    }
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public void copyLocalFileToRemoteLocation(File fileToCopy, INetworkFilePath filePath) {
        try (Connection connection = client.connect(filePath.getServer())) {
            AuthenticationContext ac = new AuthenticationContext(networkUser.getUser(), networkUser.getPassword().toCharArray(), networkUser.getDomain());
            Session session = connection.authenticate(ac);
            // Connect to Share
            try (DiskShare share = (DiskShare) session.connectShare(filePath.getShare())) {
                SmbFiles.copy(fileToCopy, share, filePath.getPathWithFile(), true);
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }
}
