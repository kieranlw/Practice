package common.networkFileUtils;

public class NetworkUser {

    private String user;
    private String password;
    private String domain;

    public NetworkUser(String user, String password, String domain) {
        this.user = user;
        this.password = password;
        this.domain = domain;
    }

    public String getUser() {
        return user;
    }


    public String getPassword() {
        return password;
    }

    public String getDomain() {
        return domain;
    }
}
