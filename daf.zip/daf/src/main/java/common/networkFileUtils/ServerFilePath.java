package common.networkFileUtils;

import utils2.LogInfo;

public class ServerFilePath implements INetworkFilePath {
    //Anatomy of this mess
    // absolutePath: \\AWB02099\netdrv\ptxmit\out\ASCENSUS\STAGE\a2c8d68e-8888-ea11-8151-00155d001935\TESTAT11_111111_ASCENSUS_20200620.DAT
    private String absolutePath;
    //server: AWB02099
    private String server;
    //file: TESTAT11_111111_ASCENSUS_20200620.DAT
    private String file;
    //share: netdrv
    private String share;
    //pathWithFile: ptxmit\out\ASCENSUS\STAGE\a2c8d68e-8888-ea11-8151-00155d001935\TESTAT11_111111_ASCENSUS_20200620.DAT
    private String pathWithFile;
    //pathRemainder: ptxmit\out\ASCENSUS\STAGE\a2c8d68e-8888-ea11-8151-00155d001935\
    private String pathRemainder;

    public ServerFilePath(String absolutePath) {
        if (!absolutePath.startsWith("\\\\")) {
            LogInfo.log_AndFail("Path should start with \\\\");
        }

        populateFields(absolutePath);
    }

    private void populateFields(String absolutePath){
        this.absolutePath = absolutePath;
        String[] split = absolutePath.split("\\\\");
        boolean containsFile = split[split.length - 1].contains(".");

        this.server = split[2];
        this.share = split[3];
        this.file = containsFile ? split[split.length - 1] : null;
        this.pathWithFile = containsFile ? absolutePath.split("\\\\", 5)[4] : null;
        this.pathRemainder = containsFile ? pathWithFile.substring(0, pathWithFile.lastIndexOf("\\")) : absolutePath.split("\\\\", 5)[4];
    }

    @Override
    public String getFile(){
        return file;
    }

    @Override
    public String getAbsolutePath() {
        return absolutePath;
    }

    @Override
    public String getServer() {
        return server;
    }

    @Override
    public String getShare() {
        return share;
    }

    @Override
    public String getPathWithFile() {
        return pathWithFile;
    }

    @Override
    public String getPathRemainder() {
       return pathRemainder;
    }
}
