package common.networkFileUtils;

public interface INetworkFilePath {

    String getFile();

    String getAbsolutePath();

    String getServer();

    String getShare();

    String getPathRemainder();

    String getPathWithFile();
}
