package common;

import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;

import java.nio.file.Paths;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <p>
 * Provides a way to interact with the QALabs (*.qalabs.nwk) domain, e.g. by connecting to
 * file shares, or remotely running commands on QALabs servers via PowerShell Remoting. If the
 * tests are running on a computer outside the QALabs domain, this class does what's needed to
 * log into QALabs resources.
 * </p><p>
 * Note: if you need to disconnect a file share (e.g. to test changes to this class), run
 * <code>net use \\vm1.qalabs.nwk\share /del</code> from the command line.
 * </p><p>
 * Ideally we would call this from any test that uses QALabs file shares. Feel free to add calls
 * wherever they're missing, so that any test can be run locally regardless of which other tests
 * were run before it.
 * </p>
 */
public final class QaLabs {

    public static final String USERNAME = "QALABS\\DAFTestUser";
    public static final String PASSWORD = "DAFWausau#1";

    /**
     * PowerShell source code that returns the QALabs credentials as a PSCredential object.
     * Suitable for, e.g., the "-Credential" parameter for Invoke-Command -ComputerName.
     */
    public static final String POWERSHELL_CREDENTIAL_EXPRESSION = "(New-Object PSCredential ('" + USERNAME + "', " +
            "(ConvertTo-SecureString '" + PASSWORD + "' -AsPlainText -Force)))";

    private static final Strategy STRATEGY = isRunningInQaLabsDomain()
            ? new InsideQaLabsStrategy()
            : new OutsideQaLabsStrategy();

    private interface Strategy {
        void connectRoot(String shareRoot);
    }

    private static class InsideQaLabsStrategy implements Strategy {
        @Override
        public void connectRoot(String shareRoot) {
            // We're running from a VM inside QALabs, so we already have access to all QALabs
            // file shares. No need to do anything more.
        }
    }

    private static class OutsideQaLabsStrategy implements Strategy {
        private final Set<String> existingShares = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);

        public OutsideQaLabsStrategy() {
            CommandOutput output = new CommandLine(Shell.CMD)
                    .execute("net", "use");
            // The output of "net use" looks like this:
            //
            //   Status       Local     Remote                    Network
            //
            //   -------------------------------------------------------------------------------
            //   OK                     \\qaautotest_10j1.qalabs.nwk\c$
            //                                                   Microsoft Windows Network
            //   Disconnected           \\qaautotest_10j1.qalabs.nwk\d$
            //                                                   Microsoft Windows Network
            //
            // Shares can get marked "Disconnected" if not used for a while, but Windows will
            // automatically reconnect them when you access them, so we can treat them the same as
            // "OK" shares.
            //
            // Extract all the UNC paths from the output. Match two backslashes (each one doubled
            // for Java strings, then doubled again to mean literal backslashes in regex) followed
            // by one or more non-space characters.
            Pattern uncPathPattern = Pattern.compile("\\\\\\\\[^ ]+");

            for (String line : output.standardOutputLines()) {
                Matcher matcher = uncPathPattern.matcher(line);
                if (matcher.find()) {
                    existingShares.add(matcher.group());
                }
            }
        }

        @Override
        public void connectRoot(String shareRoot) {
            if (existingShares.contains(shareRoot)) {
                // Already connected, our work here is done
                return;
            }

            CommandOutput commandOutput = new CommandLine(Shell.CMD)
                    .execute("net", "use", shareRoot, "/USER:" + USERNAME, PASSWORD);
            if (commandOutput.exitCode() != 0) {
                throw new RuntimeException("Unable to connect network share '" + shareRoot + "': " +
                        String.join(" ", commandOutput.standardErrorLines()));
            }

            existingShares.add(shareRoot);
        }
    }

    private QaLabs() {
    }

    private static boolean isRunningInQaLabsDomain() {
        String domain = System.getenv().get("USERDOMAIN");
        return StringUtils.equalsIgnoreCase(domain, "QALABS.NWK");
    }

    @NotNull
    private static String getShareRoot(String sharePath) {
        String root = Paths.get(sharePath).getRoot().toString();
        // Remove any trailing '\' or '/'
        return root.replaceAll("[\\\\/]+$", "");
    }

    /**
     * <p>
     * Connects to the file share referenced by sharePath, if we're not already connected.
     * </p><p>
     * sharePath doesn't need to be the root of the file share (\\vm1.qalabs.nwk\share);
     * it can be any path on that share.
     * </p>
     *
     * @param sharePath Any path on the file share, e.g. \\vm1.qalabs.nwk\share or
     *                  \\vm1.qalabs.nwk\share\path\to\file.
     */
    public static void connect(String sharePath) {
        String shareRoot = getShareRoot(sharePath);

        // If we happened to get something that isn't a network path, like "C:\Temp", ignore it.
        // It'll be accessible after we return, and that's the whole point, after all.
        if (shareRoot.startsWith("\\\\")) {
            STRATEGY.connectRoot(shareRoot);
        }
    }

    /**
     * Executes the given PowerShell command on a remote QALabs computer.
     *
     * @param computerName Name of the computer to run the command on
     * @param command      The PowerShell command to execute remotely
     * @return The command's output
     */
    public static CommandOutput executeRemotePowerShell(String computerName, String command) {
        CommandOutput output = new CommandLine(Shell.POWERSHELL)
                .execute(
                        "Invoke-Command -ComputerName", computerName,
                        "-ScriptBlock {" + command + "}",
                        "-Credential", POWERSHELL_CREDENTIAL_EXPRESSION);
        return output;
    }

    public static CommandOutput executeRemotePowerShellEchoOff(String computerName, String command) {
        CommandOutput output = new CommandLine(Shell.POWERSHELL)
                .displayOutput(false)
                .execute(
                        "Invoke-Command -ComputerName", computerName,
                        "-ScriptBlock {" + command + "}",
                        "-Credential", POWERSHELL_CREDENTIAL_EXPRESSION);
        return output;
    }
}
