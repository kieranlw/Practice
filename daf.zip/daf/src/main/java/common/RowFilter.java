package common;

import org.hamcrest.Matcher;
import org.jetbrains.annotations.NotNull;
import utils2.tableData.Row;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public class RowFilter {
    private final List<ColumnFilter> filters;

    private RowFilter(List<ColumnFilter> filters) {
        this.filters = Collections.unmodifiableList(filters);
    }

    /**
     * <p>
     * Creates a RowFilter using the given values as alternating column names
     * and matchers. For example, <code>RowFilter.of("a", "1",
     * "b", Is.stringContaining("2"))</code> would return a RowFilter with
     * two filters: column "a" is equal to "1" and column "b" contains "2".
     * </p><p>
     * Keys must be strings. Matchers may be either Hamcrest {@link Matcher}&lt;String&gt;,
     * or strings (which will be treated as {@link Is#equalTo(Object)}).
     * </p>
     *
     * @param columnNamesAndMatchers String&nbsp;columnName1,&nbsp;String|Matcher&lt;String&gt;&nbsp;matcher1,
     *                               String&nbsp;columnName2,&nbsp;String|Matcher&lt;String&gt;&nbsp;matcher2, ...
     * @return The new RowFilter object
     */
    @NotNull
    public static RowFilter of(Object... columnNamesAndMatchers) {
        List<ColumnFilter> columnFilters = new ArrayList<>();
        for (int i = 0; i < columnNamesAndMatchers.length; i += 2) {
            final String key = (String) columnNamesAndMatchers[i];
            final Object matcher = columnNamesAndMatchers[i + 1];
            columnFilters.add(ColumnFilter.of(key, matcher, Is::equalTo));
        }

        return new RowFilter(columnFilters);
    }

    @NotNull
    public static RowFilter of(Map<String, ?> matchers) {
        return of(matchers, Is::equalTo);
    }

    @NotNull
    public static RowFilter of(Map<String, ?> matchers,
                               Function<String, Matcher<String>> matcherFactory) {
        List<ColumnFilter> columnFilters = new ArrayList<>();
        matchers.forEach((column, matcher) -> columnFilters.add(ColumnFilter.of(column, matcher, matcherFactory)));
        return new RowFilter(columnFilters);
    }

    public boolean matches(Row row) {
        return filters.stream()
                .allMatch(c -> c.matcher.matches(row.get(c.column)));
    }

    public RowFilter with(String column, String value) {
        return with(column, Is.equalTo(value));
    }

    public RowFilter with(String column, Matcher<String> matcher) {
        return new RowFilter(ListUtils.concat(filters, new ColumnFilter(column, matcher)));
    }

    private static class ColumnFilter {
        private final String column;
        private final Matcher<String> matcher;

        private ColumnFilter(String column, Matcher<String> matcher) {
            this.column = column;
            this.matcher = matcher;
        }

        @SuppressWarnings("unchecked")
        private static ColumnFilter of(String column, Object value,
                                       Function<String, Matcher<String>> matcherFactory) {
            final Matcher<String> matcher;
            if (value instanceof String || value == null) {
                matcher = matcherFactory.apply((String) value);
            } else {
                // value might be something like a Matcher<Integer>; due to
                // type erasure, we can't tell at runtime. But that won't actually
                // hurt anything - RowFilter only specifies Matcher<String> to
                // provide a better API. It can in fact take any Matcher (though
                // there wouldn't be much point).
                matcher = (Matcher<String>) value;
            }
            return new ColumnFilter(column, matcher);
        }
    }
}
