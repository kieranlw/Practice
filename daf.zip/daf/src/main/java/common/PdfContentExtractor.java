package common;

import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;
import org.jetbrains.annotations.NotNull;
import utils2.Index;

import java.io.IOException;
import java.util.*;

/**
 * Used to load PDF files and break them into rows and columns. This class is an
 * implementation detail; to use it, call PDF_Extractor.loadPdfCells().
 */
public class PdfContentExtractor extends PDFTextStripper {
    private final SortedMap<RowKey, List<PdfCell>> cellsByRowKey = new TreeMap<>();
    private Index pageIndex = Index.zeroBased(0);

    public PdfContentExtractor() throws IOException {
    }

    @Override
    protected void endPage(PDPage page) throws IOException {
        super.endPage(page);
        pageIndex = pageIndex.increment();
    }

    public List<PdfRow> getRows() {
        // No need to return rows in order - PdfContent will sort them and keep them sorted
        return ListUtils.map(cellsByRowKey.entrySet(), entry -> {
            final RowKey key = entry.getKey();
            final List<PdfCell> rowCells = entry.getValue();
            return new PdfRow(Index.zeroBased(key.pageIndex), key.y, rowCells);
        });
    }

    @Override
    protected void writeString(String text, List<TextPosition> textPositions) throws IOException {
        MutablePdfCell currentCell = null;

        for (TextPosition chunk : textPositions) {
            if (currentCell == null || chunk.getY() != currentCell.getY() || chunk.getX() < currentCell.getX()) {
                currentCell = new MutablePdfCell(pageIndex, chunk.getX(), chunk.getY());
                addCell(currentCell);
            }

            currentCell.appendText(chunk.getUnicode(), chunk.getEndX());
        }

        super.writeString(text, textPositions);
    }

    private void addCell(PdfCell cell) {
        final RowKey rowKey = new RowKey(cell.getPageIndex().asZeroBased(), cell.getY());

        // Add a List for the row, if not already present
        cellsByRowKey.computeIfAbsent(rowKey, k -> new ArrayList<>());

        cellsByRowKey.get(rowKey).add(cell);
    }

    private static final class RowKey implements Comparable<RowKey> {
        private final int pageIndex;
        private final double y;

        private RowKey(int pageIndex, double y) {
            this.pageIndex = pageIndex;
            this.y = y;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            RowKey rowKey = (RowKey) o;
            return pageIndex == rowKey.pageIndex && Double.compare(rowKey.y, y) == 0;
        }

        @Override
        public int hashCode() {
            return Objects.hash(pageIndex, y);
        }

        @Override
        public int compareTo(@NotNull PdfContentExtractor.RowKey rowKey) {
            final int pageIndexCompare = Integer.compare(pageIndex, rowKey.pageIndex);
            if (pageIndexCompare != 0)
                return pageIndexCompare;

            final int yCompare = Double.compare(y, rowKey.y);
            return yCompare;
        }
    }

    private static class MutablePdfCell implements PdfCell {
        private final Index pageIndex;
        private final float x;
        private final float y;
        private final StringBuilder text = new StringBuilder();
        private float endX;

        public MutablePdfCell(Index pageIndex, float x, float y) {
            this.pageIndex = pageIndex;
            this.x = x;
            this.endX = x;
            this.y = y;
        }

        public void appendText(String text, float endX) {
            this.text.append(text);
            this.endX = endX;
        }

        @Override
        public Index getPageIndex() {
            return pageIndex;
        }

        @Override
        public double getX() {
            return x;
        }

        @Override
        public double getEndX() {
            return endX;
        }

        @Override
        public double getY() {
            return y;
        }

        @Override
        public String getText() {
            return text.toString();
        }
    }
}
