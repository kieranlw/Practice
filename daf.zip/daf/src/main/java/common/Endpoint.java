package common;

public enum Endpoint {
    /**
     * Include the endpoint in the results.
     */
    INCLUDE,

    /**
     * Do not include the endpoint in the results. Only include the middle of the range.
     */
    EXCLUDE
}
