package common;

import org.immutables.value.Value;

import java.util.List;

@Value.Immutable
public interface CommandOutput {
    int exitCode();
    List<String> standardOutputLines();
    List<String> standardErrorLines();
}
