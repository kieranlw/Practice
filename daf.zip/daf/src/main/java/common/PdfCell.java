package common;

import utils2.Index;

public interface PdfCell {
    Index getPageIndex();
    double getX();
    double getEndX();
    double getY();
    String getText();
}
