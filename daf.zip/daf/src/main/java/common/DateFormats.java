package common;

import java.time.format.DateTimeFormatter;

@SuppressWarnings("SpellCheckingInspection")
public class DateFormats {
    /**
     * M/D/YYYY date format, for both formatting and parsing.
     */
    public static final DateTimeFormatter M_D_YYYY = DateTimeFormatter.ofPattern("M/d/yyyy");

    /**
     * <p>
     * MM/DD/YYYY date format. Should be mainly used for formatting.
     * </p><p>
     * For parsing, you should generally prefer M_D_YYYY, because MM_DD_YYYY will
     * throw DateTimeParseException if the string <em>doesn't</em> happen to have
     * leading zeroes in the month and year.
     * </p>
     */
    public static final DateTimeFormatter MM_DD_YYYY = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    /**
     * YYYY-MM-DD date format, for both formatting and parsing.
     */
    public static final DateTimeFormatter YYYY_MM_DD = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    /**
     * YYYYMMDD date format.
     */
    public static final DateTimeFormatter YYYYMMDD = DateTimeFormatter.ofPattern("yyyyMMdd");

    protected DateFormats() {}
}