package common;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ResourceDirectory extends ResourcePath {
    /**
     * <p>
     * Creates a new ResourceDirectory for the given relative path.
     * </p><p>
     * For consistency and to keep things DRY, the path should use forward slashes, and
     * should not start with a slash. Paths should start with the package name, not with "src".
     * </p>
     *
     * @param packageRelativePath Package-qualified path, e.g. "utils2/data".
     */
    public ResourceDirectory(String packageRelativePath) {
        super(packageRelativePath);
    }

    @Override
    protected boolean exists(Path candidateAbsolutePath) {
        return Files.isDirectory(candidateAbsolutePath);
    }

    /**
     * Returns all files in the directory. Does not recurse into subdirectories.
     *
     * @return List of files in the directory
     * @throws RuntimeIOException if an I/O error occurred
     */
    public List<ReadableFile> getFiles() throws RuntimeIOException {
        return RuntimeIOException.withRuntimeIOExceptions(() -> {
            try (Stream<Path> list = Files.list(toPath())) {
                return list.map(path -> new DataFile(path.toString()))
                        .collect(Collectors.toList());
            }
        });
    }

    private Path toPath() {
        return Paths.get(getAbsolutePath());
    }
}
