package utils;

import common.ThreadUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public enum BeforeTyping {
    /**
     * <p>Clear the text box, and click to focus it. This is our historical default, although the
     * click probably isn't necessary since sendKeys will focus the text box before typing.</p>
     *
     * <p>The clear can sometimes fail silently due to Selenium driver-version issues, or
     * due to JavaScript on the page. If this happens, you'll see the test appending to the
     * existing text, rather than replacing it.</p>
     *
     * <p>The click can fail (and throw) if the element is covered by another element.</p>
     */
    CLEAR_AND_CLICK {
        @Override
        public void execute(WebElement element) {
            element.clear();
            element.click();
        }
    },

    /**
     * <p>Clear the text box using Selenium's clear() method.</p>
     *
     * <p>The clear can sometimes fail silently due to Selenium driver-version issues, or
     * due to JavaScript on the page. If this happens, you'll see the test appending to the
     * existing text, rather than replacing it.</p>
     */
    CLEAR {
        @Override
        public void execute(WebElement element) {
            String elementText = element.getAttribute("value");
            if (elementText != null && !elementText.equals("")) {
                element.clear();
            }
        }
    },

    /**
     * <p>Don't do anything prior to entering the new text.</p>
     *
     * <p>If the text box isn't empty, the new text will typically be appended.</p>
     */
    DO_NOTHING {
        @Override
        public void execute(WebElement element) {
            // do nothing
        }
    },

    /**
     * <p>Double-click the text box to select its existing text, so that the new text replaces the old.</p>
     *
     * <p>The double-click can fail (and throw) if the element is covered by another element.</p>
     *
     * <p>This can fail its intended purpose if there's more than one word of text in the text box,
     * or if the new text is the empty string.</p>
     */
    DOUBLE_CLICK {
        @Override
        public void execute(WebElement element) {
            Actions actions = new Actions(Browser.getDriver());
            actions.doubleClick(element).build().perform();
            ThreadUtils.sleep(200);
        }
    },

    /**
     * <p>Send Ctrl+A to select all text in the text box, then Delete to delete the old text.
     * Fails loudly if this doesn't successfully clear the text box.</p>
     */
    DELETE {
        @Override
        public void execute(WebElement element) {
            element.sendKeys(Keys.chord(Keys.CONTROL, "a"));
            element.sendKeys(Keys.DELETE);

            String elementText = element.getAttribute("value");
            if (elementText != null && !elementText.isEmpty()) {
                BaseUI.log_AndFail("Failed to delete text - remaining text is '" + elementText + "' in element " + element);
            }
        }
    };

    public abstract void execute(WebElement element);
}
