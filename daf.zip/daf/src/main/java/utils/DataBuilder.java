package utils;

import common.*;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.function.Consumer;
import java.util.regex.Pattern;

public class DataBuilder {
    /**
     * <p>
     * Reads configuration from a pipe-delimited, "name|value" file into a Map. If the file
     * doesn't exist, create it from [filename].example.
     * </p><p>
     * For example, given this file:
     * </p><pre>
     * Name|Someone'sName
     * ID|42
     * DOB|01/08/1990
     * </pre><p>
     * this will return a map with three keys: "Name" with the value "Someone'sName", "ID" with
     * the value "42", and "DOB" with the value "01/08/1990".
     * </p>
     *
     * @param file The file to read
     * @return A Map with the key/value pairs from the file
     */
    public static HashMap<String, String> readConfigFile(ReadableFile file) {
        final String delimiter = "|";

        // If txt_path doesn't exist but txt_path.example does, create txt_path from the
        // example file.
        if (!file.exists()) {
            ReadableFile exampleFile = file.withFileNameSuffix(".example");
            if (exampleFile.exists()) {
                String exampleFilePath = exampleFile.getAbsolutePath();
                // We can't use file.getAbsolutePath here - it throws if the file doesn't exist.
                // Strip the ".example" back off of exampleFilePath instead.
                String targetFilePath = exampleFilePath.replaceAll("\\.example$", "");
                RuntimeIOException.withRuntimeIOExceptions(() ->
                        FileUtils.copyFile(new File(exampleFilePath), new File(targetFilePath))
                );
            }
        }

        List<String> lines = file.readAllLines();

        String splitRegex = Pattern.quote(delimiter);

        HashMap<String, String> confData = new HashMap<>();
        int lineNumber = 0;
        for (String line : lines) {
            ++lineNumber;

            // Skip blank lines
            if (line.trim().isEmpty()) {
                continue;
            }

            final String[] columns = line.split(splitRegex);
            if (columns.length < 2) {
                throw new RuntimeException("Error reading " + file + ": " +
                        "Expected a line of the form \"name|value\", but line " + lineNumber + " was \"" + line + "\"");
            }

            confData.put(columns[0], columns[1]);
        }
        return confData;
    }

    public static String Get_FileData_AsString(File file) throws FileNotFoundException {
        Scanner readDocument = new Scanner(file);
        String text = readDocument.useDelimiter("\\A").next();
        readDocument.close();

        return text;
    }

    public static String Get_FileData_AsString(File file, String charSet) throws FileNotFoundException {
        Scanner readDocument = new Scanner(file, charSet);
        String text = readDocument.useDelimiter("\\A").next();
        readDocument.close();

        return text;
    }

    public static Object[][] getTableData_FromFile(ReadableFile file) {
        List<String> lines = file.readAllLines();

        String[] headerRow = lines.get(0).split("\\s*\\|\\s*");

        Object[][] tableData = new Object[lines.size()][headerRow.length];

        for (int i = 0; i < lines.size(); i++) {
            String[] lineArray = lines.get(i).split("\\s*\\|\\s*");
            for (int j = 0; j < headerRow.length; j++) {
                tableData[i][j] = j < lineArray.length ? lineArray[j] : "";
            }
        }

        return tableData;
    }

    @NotNull
    public static TableData returnTableData_ForComparison(ReadableFile file, String delimiter) {
        return parseTableData(ListUtils.trimTrailingBlanks(file.readAllLines()), delimiter);
    }

    @NotNull
    private static TableData parseTableData(List<String> lines, String delimiter) {
        TableData tabledata = new TableData();
        if (lines.isEmpty()) {
            return tabledata;
        }

        String[] headerRow;
        if (delimiter.startsWith("\\")) {
            headerRow = lines.get(0).split(MessageFormat.format("{0}", delimiter));
        } else {
            headerRow = lines.get(0).split(MessageFormat.format("\\{0}", delimiter));
        }

        lines.stream().skip(1).forEach(line -> {
            String[] lineArray;
            lineArray = line.split(MessageFormat.format("{0}(?=([^\"]*\"[^\"]*\")*[^\"]*$)", delimiter), -1);

            HashMap<String, String> tableRow = new HashMap<String, String>();
            for (int headerCount = 0; headerCount < headerRow.length; headerCount++) {
                String key = headerRow[headerCount].replaceAll("[\\s\\u00A0]+$", " ").trim();
                String value = null;
                try {
                    value = lineArray[headerCount];
                } catch (Exception e) {

                }
                tableRow.put(key, value);
            }
            tabledata.data.add(tableRow);
        });
        return tabledata;
    }

    public static String return_Downloads_Folder() {
        String home = System.getProperty("user.home");
        String downloads_Location = home + "\\Downloads\\";

        return downloads_Location;
    }

    public static void delete_Files_FromDownloads_withExtension(String extension) {

        delete_Files_WithExtention_FromLocation(extension, return_Downloads_Folder());
    }

    public static void delete_Files_WithExtention_FromLocation(String extension, String folderLocation) {
        extension = extension.startsWith(".") ? extension.substring(1, extension.length()) : extension;
        File folder = new File(folderLocation);
        File folderList[] = folder.listFiles();
        // Searchs .lck
        if (folderList != null) {
            for (int i = 0; i < folderList.length; i++) {
                // String pes = folderList[i].toString();
                // if (pes.endsWith(extension)) {
                // // and deletes
                // boolean success = (new File(folderList[i].toString()).delete());
                // }
                if (folderList[i].isFile()) {
                    String fileExtension = FilenameUtils.getExtension(folderList[i].toString());
                    if (fileExtension.equals(extension)) {
                        boolean success = (new File(folderList[i].toString()).delete());
                    }
                }
            }
        }
    }

    public static ReadableFile return_File_WithExtension(String extension, String folderLocation) {
        File folder = new File(folderLocation);
        File[] folderList = folder.listFiles();
        for (File file : folderList) {
            String pes = file.toString();
            if (pes.endsWith(extension)) {
                return new DataFile(pes);
            }
        }
        return null;
    }

    // Note: will not preserve original column order.
    public static void update_CSVFile(WritableFile file, String delimiter,
                                      Consumer<HashMap<String, String>> lambdaToUse) throws IOException {

        ArrayList<String> finalLines = new ArrayList<String>();

        TableData csvData = returnTableData_ForComparison(file, delimiter);

        //apply formatting from lambda
        csvData.forEach_Row(lambdaToUse);

        if (delimiter.startsWith("\\")) {
            delimiter = delimiter.substring(1);
        }

        // Assemble the first line and then add to finalLines
        ArrayList<String> keys = new ArrayList<String>(csvData.data.get(0).keySet());
        String firstLine = keys.get(0) + delimiter;
        for (int i = 1; i < keys.size() - 1; i++) {
            firstLine += keys.get(i) + delimiter;
        }
        firstLine += keys.get(keys.size() - 1);
        finalLines.add(firstLine);

        //Reassemble the lines
        for (int i = 0; i < csvData.data.size(); i++) {
            String lineToAdd = "";

            for (String key : keys) {
                lineToAdd += csvData.data.get(i).get(key) + delimiter;
            }
            lineToAdd = lineToAdd.substring(0, lineToAdd.lastIndexOf(delimiter));
            finalLines.add(lineToAdd);
        }

        file.writeAllLines(finalLines);
    }

    private static boolean rowMatchesCriteria(HashMap<String, String> actualRow, HashMap<String, String> matchingCriteria) {
        for (String key : matchingCriteria.keySet()) {
            if (!actualRow.get(key).equals(matchingCriteria.get(key))) {
                return false;
            }
        }

        return true;
    }

    public static void wait_ForFile_WithExtension_ToExist(String extension, String folderLocation, int timeToWaitInSeconds) {
        String newExtension = extension.startsWith(".") ? extension.substring(1, extension.length()) : extension;
        BaseUI.wait_ForCondition_ToBeMet(() -> {
            File folder = new File(folderLocation);
            File[] listOfExpectedFiles = folder.listFiles();
            boolean fileHasExtension = false;
            for (File file : listOfExpectedFiles) {
                if (file.isFile()) {
                    String fileExtension = FilenameUtils.getExtension(file.toString());
                    if (fileExtension.equals(newExtension)) {
                        fileHasExtension = true;
                        break;
                    }
                }
            }
            return fileHasExtension;
        }, timeToWaitInSeconds);
    }
}
