package utils;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;

public class XmlEditor extends XmlData {
    private final String filePath;

    public XmlEditor(String filePathAndName) throws Exception {
        super(filePathAndName);
        this.filePath = filePathAndName;
    }

    public XmlEditor(String filePathAndName, Document xml) {
        super(xml);
        this.filePath = filePathAndName;
    }

    public void applyUpdates_ToXML() throws Exception {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(xml);
        StreamResult result = new StreamResult(new File(filePath));
        transformer.transform(source, result);
    }

    public void createNode(Node nodeToAppendTo, String nodeType) {
        Element newNode = xml.createElement(nodeType);
        nodeToAppendTo.appendChild(newNode);
    }

    public void setAttribute(Node nodeToUpdate, String attributeToUpdate, String valueToSet) {
        Element elementToSet = (Element) nodeToUpdate;
        elementToSet.setAttribute(attributeToUpdate, valueToSet);
    }

    public void append_CDataNode(Node nodeToAppendTo, String textToAppend) {
        Node cdata = xml.createCDATASection(textToAppend);
        nodeToAppendTo.appendChild(cdata);
    }
}
