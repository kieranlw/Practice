package utils;

public class BustedTestException extends RuntimeException {
    public BustedTestException(String message) {
        super(message);
    }
}
