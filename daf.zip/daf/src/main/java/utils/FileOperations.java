package utils;

import com.sun.jna.Memory;
import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.VerRsrc.VS_FIXEDFILEINFO;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.PointerByReference;
import common.Is;
import common.ReadableFile;
import common.RuntimeIOException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.openqa.selenium.io.Zip;
import org.openqa.selenium.support.ui.Quotes;
import utils2.LogInfo;
import utils2.page_components.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class FileOperations {
    public static void copyFiles(String sourceDirectory, String destinationDirectory) {

        BaseUI.log_Status("Copying files from " + sourceDirectory + " to " + destinationDirectory);

        File source = new File(sourceDirectory);
        File dest = new File(destinationDirectory);
        try {
            FileUtils.copyDirectory(source, dest);
        } catch (IOException e) {
            BaseUI.log_Warning(e.getMessage());
        }
    }

    public static void copyFile(String sourceDirectory, String destinationDirectory) {

        BaseUI.log_Status("Copying file from " + sourceDirectory + " to " + destinationDirectory);

        File source = new File(sourceDirectory);
        File dest = new File(destinationDirectory);
        try {
            FileUtils.copyFile(source, dest);
        } catch (IOException e) {
            BaseUI.log_Warning(e.getMessage());
        }
    }

    // fileName_Prefix will be the start of the file name that we'll
    // search for.
    public static String[] getLatestFileExtract_FromFolder(String folderLocation, String fileName_Prefix)
            throws Exception {
        File folder = new File(folderLocation);
        File[] listOfFilesAndFolders = return_NonHiddenFiles(folder);

        // ArrayList<File> filesThatMatch = new ArrayList<File>();
        File fileToPick = null;
        long lastModified_ClosestToCurrent = 0;

        for (File file : listOfFilesAndFolders) {
            if (file.isFile() && file.getName().startsWith(fileName_Prefix)) {
                // filesThatMatch.add(file);
                long lastModified = file.lastModified();
                if (lastModified > lastModified_ClosestToCurrent) {
                    lastModified_ClosestToCurrent = lastModified;
                    fileToPick = file;
                }
            }
        }

        String fileExtract = DataBuilder.Get_FileData_AsString(fileToPick);

        return fileExtract.split("\\r");
    }

    // Verifies that there are no files remaining. If there are folders it will
    // still pass. Ignores Hidden files.
    public static void verify_NoFiles_Remaining(String folderLocation) {
        File folder = new File(folderLocation);
        File[] listOfFilesAndFolders = return_NonHiddenFiles(folder);

        String output = "";
        for (File file : listOfFilesAndFolders) {
            if (file.isFile()) {
                output += "\n" + "Seeing file " + file.getName();
            }
        }

        BaseUI.verify_true_AndLog(output.equals(""), "No Files Found.", output);
    }

    public static File getLatestFileWithExtension(String filePath, String ext) {
        return getLatestFileWithByWildcard(filePath, new WildcardFileFilter("*." + ext));
    }

    public static File getLatestFileWithByWildcard(String filePath, WildcardFileFilter wildcardFileFilter) {
        File theNewestFile = null;
        File dir = new File(filePath);
        File[] files = dir.listFiles((FileFilter) wildcardFileFilter);

        if (files != null && files.length > 0) {
            /** The newest file comes first **/
            Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
            theNewestFile = files[0];
        }

        return theNewestFile;
    }

    public static void wait_For_File_To_Exist(String fileString, Duration duration) {
        WaitUtils.conditionMet(
                () -> {
                    File file = new File(fileString);
                    return file.exists();
                },
                "existence of file \"" + fileString + "\"",
                duration);
    }

    public static void wait_For_File_To_Exist(String filePath, WildcardFileFilter wildcardFileFilter, Duration duration) {
        WaitUtils.conditionMet(
                () -> {
                    File file = getLatestFileWithByWildcard(filePath, wildcardFileFilter);
                    return file != null && file.exists();
                },
                "Existence of file matching \"" + wildcardFileFilter + "\" in \"" + filePath + "\"",
                duration);
    }

    public static void wait_For_File_To_Exist(String fileString) {

        wait_For_File_To_Exist(fileString, Duration.ofSeconds(60));
    }

    // Returns non-hidden files. Doesn't include folders.
    public static File[] return_NonHiddenFiles(File directory) {
        File[] files = directory.listFiles(file -> {
            boolean notHiddenAndIsFile = true;
            if (file.isHidden() || !file.isFile()) {
                notHiddenAndIsFile = false;
            }

            return notHiddenAndIsFile;
        });

        return files;
    }

    // Pass in the extension minus the period. So blue.dat would be "dat"
    public static File[] return_Files_ThatEndInExtension(String directoryPath, String extension) {
        File[] initialArray = return_NonHidden_Files_AndSubFiles(directoryPath);
        ArrayList<File> newList = new ArrayList<File>();

        for (File file : initialArray) {
            if (file.getName().endsWith("." + extension)) {
                newList.add(file);
            }
        }

        return newList.toArray(new File[newList.size()]);
    }

    public static File[] return_NonHidden_Files_AndSubFiles(String directoryPath) {
        ArrayList<File> completeList = new ArrayList<File>();
        find_SubFiles(directoryPath, completeList);
        // get all the files from a directory
        return completeList.toArray(new File[completeList.size()]);
    }

    public static File[] return_NonHidden_Files_AndSubFiles_excludeDirectories(String directoryPath) {
        ArrayList<File> completeList = new ArrayList<File>();
        find_SubFiles(directoryPath, completeList);

        Iterator<File> fileIterator = completeList.iterator();
        while (fileIterator.hasNext()) {
            File nextFile = fileIterator.next();
            if (nextFile.isDirectory())
                fileIterator.remove();
        }

        // get all the files from a directory
        return completeList.toArray(new File[completeList.size()]);
    }

    // Updates the ArrayList we pass in with files found in subdirectories.
    // Ignore Thumbs.db as that was throwing off my tests.
    private static void find_SubFiles(String directoryPath, ArrayList<File> completeList) {
        File directory = new File(directoryPath);
        File[] fileList = directory.listFiles();
        for (File file : fileList) {
            if (!file.isHidden() && !file.getName().contains("Thumbs.db")) {
                completeList.add(file);
                if (file.isDirectory()) {

                    find_SubFiles(file.getAbsolutePath(), completeList);
                }
                // else {
                // completeList.add(file);
                // }
            }
        }
    }

    public static void verify_FileNames_EndsWithExtension(String folderName, String extensionFilesShouldHave) {
        File[] availableFiles = return_NonHidden_Files_AndSubFiles(folderName);

        BaseUI.verify_true_AndLog(availableFiles.length > 0, "Found Files.", "Did NOT find files.");
        for (File file : availableFiles) {
            String actualExtension = FilenameUtils.getExtension(file.getName());
            BaseUI.baseStringCompare("File Extension", extensionFilesShouldHave, actualExtension);
        }
    }

    public static void wait_ForFileCount_ToMatch(String folderToGet, Integer expectedCount, Integer timeToWaitInSeconds) {

        BaseUI.log_Status(
                "Attempting to wait for file count for directory " + folderToGet + " to reach " + expectedCount);

        try {
            BaseUI.wait_ForCondition_ToBeMet(
                    () -> return_NonHidden_Files_AndSubFiles(folderToGet).length == expectedCount,
                    timeToWaitInSeconds);
        } finally {

            File[] allFiles = return_NonHidden_Files_AndSubFiles(folderToGet);
            String output = "";
            if (allFiles.length > 0) {
                for (File file : allFiles) {
                    output += "\nFound File " + file.getAbsolutePath();
                }
                BaseUI.log_Status(output);
            }
            BaseUI.log_Status("File count was " + allFiles.length);
        }
    }

    public static void wait_ForDirectoryCount_ToMatch(File directory, int expectedCount, Duration timeToWait) {
        BaseUI.log_Status(
                "Attempting to wait for file count for directory " + directory.getAbsolutePath()
                        + " to reach " + expectedCount);
        try {
            BaseUI.wait_ForCondition_ToBeMet(
                    () -> getDirectories(directory).size() == expectedCount,
                    Math.toIntExact(timeToWait.getSeconds()));
        } finally {
            List<File> directories = getDirectories(directory);
            BaseUI.log_Status("File count was " + directories.size());
        }
    }

    public static List<File> getDirectories(File directory) {
        File[] fileList = directory.listFiles();

        List<File> files = new ArrayList<>();
        for (File file : fileList) {
            if (file.isDirectory()) {
                files.add(file);
            }
        }

        return files;
    }

    public static String getVersionInfo(String path) throws IOException {
        try {
            IntByReference dwDummy = new IntByReference();
            dwDummy.setValue(0);

            int versionlength = com.sun.jna.platform.win32.Version.INSTANCE.GetFileVersionInfoSize(path, dwDummy);

            byte[] bufferarray = new byte[versionlength];
            Pointer lpData = new Memory(bufferarray.length);
            PointerByReference lplpBuffer = new PointerByReference();
            IntByReference puLen = new IntByReference();
            boolean fileInfoResult = com.sun.jna.platform.win32.Version.INSTANCE.GetFileVersionInfo(path, 0,
                    versionlength, lpData);
            boolean verQueryVal = com.sun.jna.platform.win32.Version.INSTANCE.VerQueryValue(lpData, "\\", lplpBuffer,
                    puLen);

            VS_FIXEDFILEINFO lplpBufStructure = new VS_FIXEDFILEINFO(lplpBuffer.getValue());
            lplpBufStructure.read();

            int v1 = (lplpBufStructure.dwFileVersionMS).intValue() >> 16;
            int v2 = (lplpBufStructure.dwFileVersionMS).intValue() & 0xffff;
            int v3 = (lplpBufStructure.dwFileVersionLS).intValue() >> 16;
            int v4 = (lplpBufStructure.dwFileVersionLS).intValue() & 0xffff;
            System.out.println("Version: " + v1 + "." + v2 + "." + v3 + "." + v4);
            return String.valueOf(v1) + "." + String.valueOf(v2) + "." + String.valueOf(v3) + "." + String.valueOf(v4);
        } catch (Exception ex) {
            String errorMessage = "Error reading version info for path '" + path + "': " + ex.getMessage();
            throw new IOException(errorMessage, ex);
        }
    }

    public static void wait_ForFile_WithExtension_ToExist(String extension, String folderLocation,
                                                          Integer timeToWaitInSeconds) {
        String newExtension = extension.startsWith(".") ? extension.substring(1, extension.length()) : extension;
        BaseUI.wait_ForCondition_ToBeMet(() -> {
            File[] listOfExpectedFiles = return_NonHiddenFiles(new File(folderLocation));
            Boolean fileHasExtension = false;
            for (File file : listOfExpectedFiles) {
                if (file.isFile()) {
                    String fileExtension = FilenameUtils.getExtension(file.toString());
                    if (fileExtension.equals(newExtension)) {
                        fileHasExtension = true;
                        break;
                    }
                }
            }
            return fileHasExtension;
        }, timeToWaitInSeconds);
    }

    public static void wait_ForFile_WithExtension_ToNOTExist(String extension, String folderlocation,
                                                             Integer timeToWaitInSeconds) {
        String newextension = extension.startsWith(".") ? extension.substring(1, extension.length()) : extension;
        BaseUI.wait_ForCondition_ToBeMet(() -> {
            File[] listOfExpectedFiles = return_NonHiddenFiles(new File(folderlocation));
            File fileWithExtension = null;
            for (File file : listOfExpectedFiles) {
                if (file.isFile()) {
                    String fileExtension = FilenameUtils.getExtension(file.toString());
                    if (fileExtension.equals(newextension)) {
                        fileWithExtension = file;
                        break;
                    }
                }
            }
            return fileWithExtension == null;
        }, timeToWaitInSeconds);
    }

    public static File getNewFileFromFolder(String folderLocation, long modifiedAfter) {
        File folder = new File(folderLocation);
        File[] listOfFilesAndFolders = return_NonHiddenFiles(folder);

        for (File file : listOfFilesAndFolders) {
            if (file.isFile() && file.lastModified() >= modifiedAfter) {
                return file;
            }
        }
        return null;
    }

    // Wait for a new file created in the folder
    public static File wait_For_New_File_To_Exist(String folderLocation, long modifiedAfter, Duration duration) {
        WaitUtils.conditionMet(
                () -> getNewFileFromFolder(folderLocation, modifiedAfter) != null,
                "existence of new file in \"" + folderLocation + "\"",
                duration);
        return getNewFileFromFolder(folderLocation, modifiedAfter);
    }

    public static void verify_AllFiles_FromFoldersMatch(String expectedFolderLocation, String actualFolderLocation)
            throws Exception {
        File[] listOfExpectedFiles = return_NonHidden_Files_AndSubFiles(expectedFolderLocation);
        File[] listOfActualFiles = return_NonHidden_Files_AndSubFiles(actualFolderLocation);

        BaseUI.verify_true_AndLog(listOfExpectedFiles.length > 0, "Found files.", "Did NOT find files.");
        BaseUI.verify_true_AndLog(listOfExpectedFiles.length == listOfActualFiles.length,
                "Number of Files matched between expected and actual file arrays.  Count was "
                        + String.valueOf(listOfExpectedFiles.length),
                "Expected " + String.valueOf(listOfExpectedFiles.length) + " files, but seeing "
                        + String.valueOf(listOfActualFiles.length) + " files.");

        String output = "";

        for (int i = 0; i < listOfExpectedFiles.length; i++) {
            Boolean filesMatched = FileUtils.contentEquals(listOfExpectedFiles[i], listOfActualFiles[i]);
            if (!filesMatched) {
                output += "\n" + "File " + listOfExpectedFiles[i].getPath() + " did not match "
                        + listOfActualFiles[i].getPath();
            }
        }

        BaseUI.verify_true_AndLog(output.equals(""),
                "Files from " + expectedFolderLocation + " matched files from " + actualFolderLocation, output);
    }

    public static void verify_AllFiles_FromFolder_MatchesExpectedFilesAndFileName_WithoutExtension(File[] expectedFiles,
                                                                                                   String actualFolderLocation) throws Exception {
        // File actualFolder = new File(actualFolderLocation);

        File[] listOfActualFiles = return_NonHidden_Files_AndSubFiles(actualFolderLocation);

        BaseUI.verify_true_AndLog(expectedFiles.length > 0, "Found files.", "Did NOT find files.");
        BaseUI.verify_true_AndLog(expectedFiles.length == listOfActualFiles.length,
                "Number of Files matched between expected and actual file arrays.  Count was "
                        + String.valueOf(expectedFiles.length),
                "Expected " + String.valueOf(expectedFiles.length) + " files, but seeing "
                        + String.valueOf(listOfActualFiles.length) + " files.");

        String output = "";

        for (int i = 0; i < expectedFiles.length; i++) {
            Boolean filesMatched = FileUtils.contentEquals(expectedFiles[i], listOfActualFiles[i]);
            if (!filesMatched) {
                output += "\n" + "File " + expectedFiles[i].getPath() + " did not match "
                        + listOfActualFiles[i].getPath();
            } else {
                // don't need pass condition here, is handled later on.
            }
            String expected_FileNameWithoutExtension = expectedFiles[i].getName();
            expected_FileNameWithoutExtension = expected_FileNameWithoutExtension.split("\\.")[0];
            String actual_FileNameWithoutExtension = listOfActualFiles[i].getName();
            ;
            actual_FileNameWithoutExtension = actual_FileNameWithoutExtension.split("\\.")[0];
            if (!expected_FileNameWithoutExtension.equals(actual_FileNameWithoutExtension)) {
                output += "\n" + "File name expected was " + expected_FileNameWithoutExtension + " did not match "
                        + actual_FileNameWithoutExtension;
            } else {
                // pass condition handled later on.
            }
        }

        BaseUI.verify_true_AndLog(output.equals(""), "Files matched files from " + actualFolderLocation, output);
    }

    // Checks folder and subfolders to make sure that the passed in file name cannot
    // be found.
    public static void verify_FileName_NotFound_InFolderOrSubFolders(String folderToCheck, String fileName) {
        File[] listOfFiles = return_NonHidden_Files_AndSubFiles(folderToCheck);

        Boolean testPass = true;
        for (File file : listOfFiles) {
            // If we find the file we'll fail the test.
            if (file.getName().equals(fileName)) {
                testPass = false;
                BaseUI.verify_true_AndLog(testPass, "",
                        "Found file " + fileName + " and file should not have been there.");
            }
        }
        // Above we check if the file does not exist. So if we get to this point that
        // means the file did not exist (if it did this method would have thrown an
        // error and not continued)
        BaseUI.verify_true_AndLog(testPass, "Did Not find file " + fileName, "Found the file " + fileName);
    }

    // Checks folder and subfolders to make sure that the passed in file name cannot
    // be found.
    public static void verify_FileName_NotFound(String folderToCheck, String fileName) {
        File[] listOfFiles = return_NonHiddenFiles(new File(folderToCheck));

        Boolean testPass = true;
        for (File file : listOfFiles) {
            // If we find the file we'll fail the test.
            if (file.getName().equals(fileName)) {
                testPass = false;
                BaseUI.verify_true_AndLog(testPass, "",
                        "Found file " + fileName + " and file should not have been there.");
            }
        }
        // Above we check if the file does not exist. So if we get to this point that
        // means the file did not exist (if it did this method would have thrown an
        // error and not continued)
        BaseUI.verify_true_AndLog(testPass, "Did Not find file " + fileName, "Found the file " + fileName);
    }

    public static void verify_FileFound(File file) {
        BaseUI.verify_true_AndLog(file.exists(), "Found the file " + file.getName(), "Did NOT find the file " + file.getName());
    }

    // Checks folder top level folder for the specified file.
    public static void verify_FileFound(String folderToCheck, String fileName) {
        File directory = new File(folderToCheck);

        File[] listOfFiles = FileOperations.return_NonHiddenFiles(directory);

        Boolean foundFile = false;
        for (File file : listOfFiles) {
            // If we find the file we'll fail the test.
            if (file.getName().equals(fileName)) {
                foundFile = true;
            }
        }

        // If we find the file we'll pass the test.
        BaseUI.verify_true_AndLog(foundFile, "Found the file " + fileName, "Did NOT find the file " + fileName);
    }

    public static void verify_FileCount_Correct(String fileLocation, Integer expectedCount) {
        File[] listOfExpectedFiles = return_NonHidden_Files_AndSubFiles(fileLocation);

        BaseUI.verify_true_AndLog(listOfExpectedFiles.length == expectedCount,
                "Number of Files matched between expected and actual file arrays.",
                "Expected " + expectedCount.toString() + " files, but seeing "
                        + String.valueOf(listOfExpectedFiles.length) + " files.");
    }

    public static void verify_Files_Match(String expectedFilePath, String actualFilePath) throws Exception {
        LogInfo.log_Status("Comparing " + actualFilePath + " to " + expectedFilePath);

        File expectedFile = new File(expectedFilePath);
        File actualFile = new File(actualFilePath);

        BaseUI.verify_true_AndLog(FileUtils.contentEquals(expectedFile, actualFile),
                "File " + expectedFile + " matched " + actualFile,
                "File " + expectedFile + " did NOT match " + actualFile);
    }

    // Validates Files, sub directories, and sub files to verify that they matched
    // after copy. Does not perform copy.
    public static void verify_Files_CopiedCorrectly(String source_Directory, String end_Directory,
                                                    Integer expectedCountOfFilesAndDirectories) throws Exception {
        // File expectedFile = new File(source_Directory);
        File[] expectedFilesAndDirectories = return_NonHidden_Files_AndSubFiles(source_Directory);

        // File actualFile = new File(end_Directory);
        File[] actualFilesAndDirectories = return_NonHidden_Files_AndSubFiles(end_Directory);

        BaseUI.verify_true_AndLog(expectedFilesAndDirectories.length == expectedCountOfFilesAndDirectories,
                "File and Directory count matched " + expectedCountOfFilesAndDirectories.toString(),
                "Actual File and Directory count was " + String.valueOf(expectedFilesAndDirectories.length)
                        + " but was expecting " + expectedCountOfFilesAndDirectories.toString());
        BaseUI.verify_true_AndLog(expectedFilesAndDirectories.length == actualFilesAndDirectories.length,
                "Expected and actual files matched in size of " + String.valueOf(expectedFilesAndDirectories.length),
                "Expected file size of " + String.valueOf(expectedFilesAndDirectories.length) + " but seeing "
                        + String.valueOf(actualFilesAndDirectories.length));

        String output = "";
        for (int i = 0; i < expectedFilesAndDirectories.length; i++) {
            if (expectedFilesAndDirectories[i].isFile()) {

                if (!FileUtils.contentEquals(expectedFilesAndDirectories[i], actualFilesAndDirectories[i])) {
                    output += "\n File " + expectedFilesAndDirectories[i].toString() + " Did not match "
                            + actualFilesAndDirectories[i].toString();
                } else {
                    // Don't need anything in here as if they do equal that's our pass condition.
                }
            } // Directory Validation section. Empty since Directory and Files will have same
            // validation below.
            else {
            }

            // removes source directories from name so that we can compare the rest of the
            // file name.
            String expected_directoryShortened = expectedFilesAndDirectories[i].toString().replace(source_Directory,
                    "");
            String actual_directoryShortened = actualFilesAndDirectories[i].toString().replace(end_Directory, "");
            if (!expected_directoryShortened.equals(actual_directoryShortened)) {
                output += "\n File " + expectedFilesAndDirectories[i].toString() + " Did not match "
                        + actualFilesAndDirectories[i].toString();
            } else {
                // don't need anything here as pass condition is handled outside of for loop.
            }
        }
        BaseUI.verify_true_AndLog(output.equals(""), "Files and Directories from " + source_Directory
                + " matched Files and Directories from " + end_Directory, output);
    }

    public static void verify_File_Matches(ReadableFile sourceFile, ReadableFile endFile) {
        List<String> sourceExtract = sourceFile.readAllLines();
        List<String> endFileExtract = endFile.readAllLines();
        String output = "";
        BaseUI.verify_true_AndLog(sourceExtract.size() == endFileExtract.size(), "Files matched in line count.",
                "Files did NOT match in line count.");
        for (int i = 0; i < sourceExtract.size(); i++) {
            if (!sourceExtract.get(i)
                    .equals(endFileExtract.get(i))) {
                output += "\n" + "Source File had line:\n" + sourceExtract.get(i) + "\n" + "But End file had line:\n"
                        + endFileExtract.get(i);
            }
        }
        BaseUI.verify_true_AndLog(output.equals(""),
                "File " + sourceFile + " matched file " + endFile, output);
    }

    public static void cleanup_TempFolder() throws Exception {
        String tempDirectory = System.getProperty("java.io.tmpdir");
        cleanup_PriorFiles(tempDirectory);
    }

    public static void cleanup_dafTestUser() throws Exception {
        String tempDirectory = "C:\\Users\\daftestuser\\AppData\\Local\\Temp\\";
        cleanup_PriorFiles(tempDirectory);
    }

    // Clean up prior files based on passed in folder.
    // will delete files that are in folders nested in that folder.
    // also delete folders
    public static void cleanup_PriorFiles(String folderLocation) {

        File path = new File(folderLocation);
        BaseUI.log_Status("Cleaning up directory " + folderLocation);

        if (path.exists()) {
            File[] files = path.listFiles();
            for (int i = 0; i < files.length; i++) {
                if (files[i].isDirectory()) {
                    String fileLocation = files[i].toString();
                    cleanup_PriorFiles(fileLocation);

                    // Check if there are any remaining files (might be some if they were locked).
                    // Delete if empty.
                    File[] listOfFilesAndFolders = files[i].listFiles();
                    if (listOfFilesAndFolders.length == 0) {
                        files[i].delete();
                    }
                } else {
                    boolean fileIsNotLocked = files[i].canWrite();

                    if (fileIsNotLocked) {
                        // BaseUI.log_Status(files[i].toString());
                        files[i].delete();
                    }
                }
            }
        }
    }

    public static void deleteFolder(String folder) throws IOException {
        FileUtils.deleteDirectory(new File(folder));
    }

    // Will only delete the files in the folder that we pass in. Will not delete
    // directories
    public static void deleteFiles_TopFolder(String folderToClear) {
        File folder = new File(folderToClear);
        File[] listOfFilesAndFolders = folder.listFiles();
        if (listOfFilesAndFolders == null) {
            return;
        }

        BaseUI.log_Status("Deleting files in " + folderToClear);

        for (File file : listOfFilesAndFolders) {
            if (file.isFile()) {
                file.delete();
            }
        }
    }

    public static void create_Folder(String folderLocation) {
        BaseUI.log_Status("Creating folder in " + folderLocation);
        Path path = Paths.get(folderLocation);
        if (!Files.exists(path)) {
            RuntimeIOException.withRuntimeIOExceptions(() -> {
                Files.createDirectories(path);
            });
        }
    }

    public static void verify_FolderNotFound(String folderLocation) {

        BaseUI.log_Status("Verifying Folder does not exist " + folderLocation);
        Path path = Paths.get(folderLocation);

        boolean directoryDoesNotExist = Files.notExists(path);
        BaseUI.verify_true_AndLog(directoryDoesNotExist, "Did Not Find the folder ", "Found the folder");
    }

    public static void delete_SpecificFile(String fullNameWithPath) {
        BaseUI.log_Status("Deleting file " + fullNameWithPath);

        File fileToDelete = new File(fullNameWithPath);

        fileToDelete.delete();
    }

    /**
     * Try to delete the given file. If it's already deleted, do nothing; for other errors
     * (e.g. network drive not mapped), throw a RuntimeException.
     *
     * @param fullNameWithPath Path to the file to delete.
     */
    public static void delete_SpecificFile_AndThrowOnError(String fullNameWithPath) {
        BaseUI.log_Status("Deleting file " + fullNameWithPath);

        try {
            Files.delete(Paths.get(fullNameWithPath));
        } catch (NoSuchFileException e) {
            // Do nothing.
        } catch (IOException e) {
            throw new RuntimeException("Error deleting file '" + fullNameWithPath + "': " + e.getMessage(), e);
        }
    }

    // Clean up a single prior file
    public static void cleanup_PriorFile(String folderLocation) {

        File path = new File(folderLocation);

        if (path.exists()) {

            boolean fileIsNotLocked = path.canWrite();

            if (fileIsNotLocked) {
                // BaseUI.log_Status(files[i].toString());
                path.delete();
            }
        }
    }

    public static void verify_FileMetadata_BitSize(String[] fileName, int imageBitSize) throws Exception {

        int length = fileName.length;
        for (int i = 0; i < length; i++) {
            File file = new File(fileName[i]);
            BaseUI.verify_true_AndLog(file.exists(), "File existed", "File " + file.getName() + " does NOT exist.");
            final BufferedImage bufferImage = ImageIO.read(file);

            BaseUI.verify_true_AndLog(bufferImage.getColorModel().getPixelSize() == imageBitSize,
                    "File Bit size " + bufferImage.getColorModel().getPixelSize() + " matches expected Bit size " + imageBitSize,
                    "File Bit size " + bufferImage.getColorModel().getPixelSize() + " did Not match expected Bit size " + imageBitSize);
        }
    }

    /**
     * Unzips the given zip file to the target directory (creating the target directory if needed).
     *
     * @param zipFileWithPath Fully-qualified path to the .zip file
     * @param unZipFilePath   Directory to unzip to
     * @throws IOException if there's an error reading or writing
     */
    public static void unZipFiles(String zipFileWithPath, String unZipFilePath) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(zipFileWithPath);
        Zip.unzip(fileInputStream, new File(unZipFilePath));
    }

    //This method change any text in file with new text.
    public static void editContentsOfFile(String filepath, String originalValue, String newValue) {
        File oldFile = new File(filepath);

        RuntimeIOException.withRuntimeIOExceptions(() -> {
            String oldContent = "";
            BufferedReader reader = new BufferedReader(new FileReader(oldFile));

            String line = reader.readLine();

            while (line != null) {
                oldContent = oldContent + line + System.lineSeparator();
                line = reader.readLine();
            }

            String newContent = oldContent.replace(originalValue, newValue);

            FileWriter writer = new FileWriter(filepath);
            writer.write(newContent);
            reader.close();
            writer.close();
        });
    }

    public static String return_Nth_Line_FromFile(String folderLocation, int lineNumber) throws IOException {
        FileReader file = new FileReader(folderLocation);
        String returnLine = "";
        BufferedReader bufferedReader = new BufferedReader(file);
        String lines;

        int i = 1;
        while ((lines = bufferedReader.readLine()) != null) {
            if (i == lineNumber) {
                returnLine = lines;
            }
            i++;
        }
        bufferedReader.close();
        return returnLine;
    }

    public static void verifyLogFile_ContainsText(String filePath, String todaysDate, String expectedText) {
        try {
            BufferedReader in = new BufferedReader(new FileReader(filePath));
            String line = in.readLine();
            int numberOfStrings = 0;

            while (line != null) {
                if (line.startsWith(todaysDate) && line.contains(expectedText)) {
                    BaseUI.log_Status("Text file displays expected text: " + line);
                    numberOfStrings++;
                }
                line = in.readLine();
            }
            BaseUI.verify_true_AndLog(numberOfStrings != 0, "The total number of lines containing the string is NOT equal to zero: " + numberOfStrings,
                    "The total number of lines containing the string " + Quotes.escape(expectedText) + " is equal to zero: " + numberOfStrings);
            in.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static String return_NthLine_FromFile_ByDateAndLineText(String folderLocation, String todaysDate, String lineText) {

        String returnLine = "";
        try {
            FileReader file = new FileReader(folderLocation);
            BufferedReader bufferedReader = new BufferedReader(file);
            String line;

            while ((line = bufferedReader.readLine()) != null) {
                if (line.startsWith(todaysDate) && line.contains(lineText)) {
                    returnLine = line;
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        return returnLine;
    }

    public static void verify_FileName_Exists_InFolderOrSubFolders(String fileName) {
        File file = new File(fileName);

        BaseUI.verify_true_AndLog(file.exists(), "Did find file " + fileName, "Dis not find the file " + fileName);
    }

    public static void renameFolder(String oldFolderName, String newFolderName) {
        File oldName = new File(oldFolderName);
        File newName = new File(newFolderName);

        // Retry the rename for a few seconds. This is often needed for network folders,
        // especially if we were just copying files to/from the folder.
        Wait.atMost(Duration.ofSeconds(10)).until(
                "Folder-rename success",
                () -> oldName.renameTo(newName),
                Is.equalTo(true));
    }

    /**
     * Use this method when you have to find file in directory by partial file name.
     * For example: BadFields.dat.14134a25-4eff-430a-9cc5-f29aa34630ea.inprocess.14134a25-4eff-430a-9cc5-f29aa34630ea.error where
     * BadFields.dat is same but "14134a25-4eff-430a-9cc5-f29aa34630ea.inprocess.14134a25-4eff-430a-9cc5-f29aa34630ea.error" is generated value
     * and is not same everytime.
     *
     * @param fileLocation
     * @param partialFileName
     */
    public static void verifyFileFoundByPartialFileName(String fileLocation, String partialFileName) {
        File dir = new File(fileLocation);
        FilenameFilter filter = (dir1, name) -> name.contains(partialFileName);

        String[] files = dir.list(filter);
        if (files == null) {
            LogInfo.log_AndFail("File contains " + partialFileName + " does not exist in " + fileLocation);
        } else {
            LogInfo.verify_ConditionTrue(files.length > 0, "Filtered file list returned matching files");
            for (int i = 0; i < files.length; i++) {
                String filename = files[i];
                System.out.println("Files: " + filename);
                LogInfo.verify_ConditionTrue(filename.contains(partialFileName), "FileName exists in folder/directory: " + filename);
            }
        }
    }

    /**
     * Use this function if you have to delete specific files from a folder
     * Example 9022_1_INI_F, 9022_2_ITI_C, so pass partially file name value and it find if file exists
     * and delete them.
     *
     * @param folderLocation
     * @param fileName
     */
    public static void deleteFileWithPartialName_FromFolder(String folderLocation, String fileName) {
        File folder = new File(folderLocation);
        if (folder.exists()) {

            for (File f : folder.listFiles()) {
                if (f.getName().startsWith(fileName)) {
                    f.delete();
                    LogInfo.log_Status("'" + f.getName() + "' deleted successfully");
                } else {
                    LogInfo.log_Status("File does not exists '" + f.getName() + "'");
                }
            }
        } else {
            LogInfo.log_AndFail("Folder does not exists" + folder);
        }
    }

    /**
     * Use this file function to verify file with partial filename
     * does not exists in specified folder
     *
     * @param fileLocation
     * @param partialFileName
     */
    public static void verifyFileDoesNotExistsByPartialFileName(String fileLocation, String partialFileName) {
        File dir = new File(fileLocation);
        if (dir.exists()) {
            for (File file : dir.listFiles()) {
                if (file.getName().startsWith(partialFileName)) {
                    LogInfo.log_AndFail(partialFileName + " file does exist in folder " + fileLocation);
                }
            }
            LogInfo.log_Status(partialFileName + " File does not exist in folder " + fileLocation);
        }
    }

    /**
     * Use to rename filename to provided new filename
     *
     * @param oldFileName
     * @param newFileName
     * @return
     */
    public static void renameFileName(String oldFileName, String newFileName) {
        File oldFile = new File(oldFileName);
        File newFile = new File(newFileName);

        if (oldFile.renameTo(newFile)) {
            LogInfo.log_AndPass("Rename filename successful");
        } else {
            LogInfo.log_AndFail("Rename failed");
        }
    }

    //This method reads the file and verify if the file has matching text
    public static void verifyFile_ContainsText(String filePath, String expectedText) throws Exception {
        String fileContent = new String(Files.readAllBytes(Paths.get(filePath)));
        LogInfo.verify_ConditionTrue(fileContent.contains(expectedText), "The file " + filePath
                + " contains the string " + expectedText);
    }

    //This method returns true if the matching text found.
    public static boolean returnFileContainsText(String filePath, String expectedText) throws Exception {
        boolean matchFound = false;
        String fileContent = new String(Files.readAllBytes(Paths.get(filePath)));
        if (fileContent.contains(expectedText)) {
            LogInfo.log_Status("Text file displays expected text: " + fileContent.contains(expectedText));
            matchFound = true;
        }
        return matchFound;
    }

    //This method returns the expectedText from the file.
    public static String getTextFromFile(String filePath, String expectedText) throws Exception {
        String matchText = null;
        try {
            BufferedReader in = new BufferedReader(new FileReader(filePath));
            String line = in.readLine();

            while (line != null) {
                if (line.contains(expectedText)) {
                    LogInfo.log_Status("Text file displays expected text: " + line);
                    matchText = line;
                }
                line = in.readLine();
            }
            in.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return matchText;
    }

    //This method validates if the folder exists
    public static void verify_FolderFound(String folderLocation) {
        LogInfo.log_Status("Verifying Folder does exist " + folderLocation);
        Path path = Paths.get(folderLocation);

        boolean directoryDoesExist = Files.exists(path);
        LogInfo.verify_ConditionTrue(directoryDoesExist, "Found the folder");
    }

    //This method copies all the folders from the sourceFolder to destinationFolder without copying the contents/files of sub-folders.
    public static void copyOnlyDirectoryWithoutContents(String sourceFolder, String destinationFolder) throws Exception {
        File srcDir = new File(sourceFolder);
        File destDir = new File(destinationFolder);

        FileUtils.copyDirectory(srcDir, destDir, DirectoryFileFilter.DIRECTORY, false);
    }

    public static int calculateDirectoryInfo(String dirPath) {
        long[] result = new long[]{0, 0, 0};
        int totalFiles = 0;
        int totalDirs = 0;
        long totalSize = 0;
        int totalNumberOfDirectories = 0;

        File dir = new File(dirPath);

        File[] subFiles = dir.listFiles();

        if (subFiles != null && subFiles.length > 0) {
            for (File aFile : subFiles) {
                if (aFile.isFile()) {
                    totalFiles++;
                    totalSize += aFile.length();
                } else {
                    totalDirs++;
                    int info = calculateDirectoryInfo(aFile.getAbsolutePath());
                    totalDirs += info;
                    //totalFiles += info[1];
                    //totalSize += info[2];
                }
            }

            totalNumberOfDirectories = totalDirs;
            //result[0] = totalDirs;
            //result[1] = totalFiles;
            //result[2] = totalSize;
        }

        return totalNumberOfDirectories;
    }
}// End of Class
