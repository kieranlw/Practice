package utils;

import org.immutables.value.Value;
import org.jetbrains.annotations.Nullable;

@Value.Immutable
@Value.Style(stagedBuilder = true)
public interface EmailMessage {

    String getSubject();
    String getCreationDate();
    String getTextBody();
    String getHtmlBody();

    @Nullable
    String getFirstLink();

    String getId();

    @Nullable
    String getFirstToAddress();
}
