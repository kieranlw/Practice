package utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SystemVariables {

    public static String testStartTime = new SimpleDateFormat("dd.MM.yyyy_HH.mm.ss").format(new Date());

    // System variables. These shouldn't ever really need to be touched
}
