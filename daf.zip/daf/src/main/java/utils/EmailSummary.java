package utils;

import org.immutables.value.Value;
import org.jetbrains.annotations.Nullable;

@Value.Immutable
@Value.Style(stagedBuilder = true)
public interface EmailSummary {
    String getSubject();
    String getCreationDate();
    String getId();

    @Nullable
    String getFirstToAddress();
}
