// LET 12/14/15: Locator.java
// Purpose: Builds the object repository based on values stored in a text file containing objectLookupKey, objectValue

package utils;

import common.ReadableFile;
import common.ResourceFile;
import common.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import utils.winiumXRay.XRayUtils;

import java.text.MessageFormat;
import java.util.*;

import static common.StringUtils.angleQuote;

public class Locator {

    private static Map<String, String> map = new HashMap<>();

    // Need to read text file and build up hash map then create the element
    // based on the hashed value
    public static void loadObjectRepository(ResourceFile... files) {
        StackTrace.verifyHasCallerWithAnnotation(Arrays.asList(BeforeTest.class, BeforeSuite.class, BeforeClass.class),
                "The object repository may only be initialized from a {0} method");

        Map<String, String> newMap = new HashMap<>();
        for (ReadableFile file : files) {
            for (String line : file.readAllLines()) {
                String[] arr = line.split("\\s", 2);
                if (arr.length == 1) {
                    // Ignore blank lines and lines starting with "***" (comments)
                    if (arr[0].length() != 0 && !arr[0].contains("***")) {
                        BaseUI.log_Warning("The line of -" + arr[0]
                                + "- does not have a key and a value. Please update this object before continuing");
                    }
                } else if (arr.length >= 2 && arr[1].contains("id=Close")) {
                    BaseUI.log_AndFail("id=Close is a bad locator, needs to be updated.");
                } else {
                    if (!arr[0].contains("***")) {
                        newMap.put(arr[0].trim(), arr[1].trim());
                    }
                }
            }
        }
        map = newMap;
    }

    @NotNull
    public static WebElement lookupRequiredElement(String objectLookupKey) {
        return lookupRequiredElement(objectLookupKey, null, null);
    }

    @NotNull
    public static WebElement lookupRequiredElement(String objectLookupKey, String variable1, String variable2) {
        By byLocator = lookupBy(objectLookupKey, variable1, variable2);
        return findRequiredElement(byLocator);
    }

    @NotNull
    public static WebElement findRequiredElement(By by) {
        WebDriver driver = Browser.getDriver();
        if (driver == null) {
            throw new BustedTestException("Cannot look up elements when WebDriver is null");
        }
        return driver.findElement(by);
    }

    // Main lookup action - Based on the value found by the key, we set the By
    // locator value
    @Nullable
    public static WebElement lookupOptionalElement(String objectLookupKey) {
        return lookupOptionalElement(objectLookupKey, null, null);
    }

    // Main lookup action - Based on the value found by the key, we set the By
    // locator value. Overload accepts up to 2 variables as Strings.
    @Nullable
    public static WebElement lookupOptionalElement(String objectLookupKey, String variable1, String variable2) {
        By byLocator = lookupBy(objectLookupKey, variable1, variable2);
        return findOptionalElement(byLocator);
    }

    @NotNull
    public static By lookupBy(String objectLookupKey, String variable1, String variable2) {
        String myPath = map.get(objectLookupKey);

        if (myPath == null) {
            throw new BustedTestException("Could not find '" + objectLookupKey + "' in repository.");
        }
        // Use double angle quotes for clarity, instead of ' or ", because XPath will often contain ' or ".
        BaseUI.log_Status("Path for locator " + angleQuote(objectLookupKey)
                + " is " + angleQuote(myPath)
                + (variable1 != null ? " - {0}=" + angleQuote(variable1) : "")
                + (variable2 != null ? " - {1}=" + angleQuote(variable2) : ""));

        By byLocator;

        if (myPath.startsWith("xr")) {
            byLocator = new ByXray(get_XR_XPath(objectLookupKey, variable1, variable2));
        } else if (myPath.startsWith("//") || myPath.startsWith("(")) {
            myPath = StringUtils.expandXPathPlaceholders(myPath, variable1, variable2);
            byLocator = By.xpath(myPath);
        } else if (myPath.startsWith("id=")) {
            byLocator = By.id(myPath.split("id=")[1]);
        } else if (myPath.startsWith("css=")) {
            byLocator = By.cssSelector(myPath.split("css=")[1]);
        } else if (myPath.startsWith("className=")) {
            byLocator = By.className(myPath.split("className=")[1]);
        } else if (myPath.startsWith("name=")) {
            byLocator = By.name(myPath.split("name=")[1]);
        } else if (myPath.startsWith("partialLinkText=")) {
            byLocator = By.partialLinkText(myPath.split("partialLinkText=")[1]);
        } else {
            BaseUI.log_Warning("Identifier " + objectLookupKey + " has a value of " + myPath
                    + " that doesn't match any known format. Attempting to continue as an id.");
            byLocator = By.id(myPath);
        }
        return byLocator;
    }

    // Main lookup action - Based on the value found by the key, we set the By
    // locator value
    @NotNull
    public static ArrayList<WebElement> lookup_multipleElements(String objectLookupKey, String variable1, String variable2) {
        By byLocator = lookupBy(objectLookupKey, variable1, variable2);
        return new ArrayList<>(Browser.getDriver().findElements(byLocator));
    }

    @Nullable
    public static WebElement findOptionalElement(By by) {
        WebDriver driver = Browser.getDriver();
        if (driver == null) {
            throw new BustedTestException("Cannot look up elements when WebDriver is null");
        }

        try {
            List<WebElement> elements = driver.findElements(by);
            if (elements.size() != 0) {
                return elements.get(0);
            } else {
                BaseUI.log_Warning("Object does not appear to exist. Attempting to continue");
                return null;
            }
        } catch (Exception e) {
            BaseUI.log_Warning("Element could not be found by " + by.toString());
            return null;
        }
    }

    public static String get_XR_XPath(String objectLookupKey, String variable1, String variable2) {
        String objectType = map.get(objectLookupKey).split("=", 2)[0];
        String identifier = map.get(objectLookupKey).split("=", 2)[1];

        if (objectType.equals("xrxpath")) {
            return StringUtils.expandXPathPlaceholders(identifier, variable1, variable2);
        } else {
            String xpath = "//*[./{0}[./text()='{1}']]";
            xpath = xpath.replace("'", "''");

            switch (objectType) {
                case "xrname":
                    return MessageFormat.format(xpath, "WidgetName", identifier);
                case "xrtype":
                    return MessageFormat.format(xpath, "WidgetType", identifier);
                case "xrlabel":
                    return MessageFormat.format(xpath, "WidgetLabel", identifier);
                case "xrvalue":
                    return MessageFormat.format(xpath, "WidgetValue", identifier);
                default:
                    throw new RuntimeException("Unknown identifier type of " + objectType);
            }
        }
    }

    public static class ByXray extends By {
        private String _xpath;

        public ByXray(String xpath) {
            _xpath = xpath;
        }

        @Nullable
        private static WebElement findBy_XrXpath(String xpath) {

            try {
                Document xrayXML = XRayUtils.getXML();

                String tempWinHandle = "";
                XmlData xml = new XmlData(xrayXML);
                Node matchingNode = xml.findNode(xpath);
                if (matchingNode == null) {
                    return null;
                }
                NodeList nodes = matchingNode.getChildNodes();
                for (int i = 0; i < nodes.getLength(); i++) {
                    if (nodes.item(i).getNodeType() == Node.ELEMENT_NODE) {
                        Element el = (Element) nodes.item(i);
                        if (el.getTagName().equals("WindowsHandle")) {
                            tempWinHandle = el.getTextContent();
                            //byLocator = By.xpath("//*[contains(@NativeWindowHandle,'" + tempWinHandle + "')]");
                            break;
                        }
                    }
                }

                Browser.getDriver().switchTo().window(tempWinHandle);
                return Browser.getDriver().switchTo().activeElement();
            } catch (Exception e) {
                BaseUI.log_AndFail("Encountered exception while trying to locate element using xrxpath: " + e.getMessage());
            }

            return null;
        }

        @Override
        public List<WebElement> findElements(SearchContext context) {
            List<WebElement> results = new ArrayList<>();
            WebElement foundElement = findBy_XrXpath(_xpath);
            if (foundElement != null) {
                results.add(foundElement);
            }
            return results;
        }

        @Override
        public String toString() {
            return "ByXray: " + _xpath;
        }
    }
}
