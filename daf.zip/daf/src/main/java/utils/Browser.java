//// LET 12/14/15: Browser.java
//// Purpose: Contains actions for dealing with opening/closing browsers. The open action specifies a default browser to use
//// but can be overridden by setting a value in testng or ant files.
//// The warning messages in this file can be ignored. 
package utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import common.BrowserOptions;
import common.DesktopApplicationStartupSettings;
import common.RuntimeIOException;
import common.ThreadUtils;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;
import utils2.AppiumDesktop;
import utils2.DriverInfo;
import utils2.DriverSetup;
import utils2.page_components.*;

import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;

public class Browser {

    private static final InheritableThreadLocal<WebDriver> driver = new InheritableThreadLocal<WebDriver>() {
        @Override
        public WebDriver initialValue() {
            return null;
        }
    };

    private static final InheritableThreadLocal<WebDriverWait> wait = new InheritableThreadLocal<WebDriverWait>() {
        @Override
        public WebDriverWait initialValue() {
            return null;
        }
    };

    public static int defaultWaitTime = 10;
    public static String typeOfBrowser = "desktop";
    //public static String defaultBrowser = "internetexplorer";
    private static final InheritableThreadLocal<String> defaultBrowser = new InheritableThreadLocal<String>() {
        @Override
        public String initialValue() {
            return "chrome";
        }
    };

    private static final InheritableThreadLocal<String> currentBrowser = new InheritableThreadLocal<String>();


    private static final InheritableThreadLocal<String> downloadLocation = new InheritableThreadLocal<String>() {
        @Override
        public String initialValue() {
            return System.getProperty("user.home") + "\\downloads";
        }
    };

    public static String getDefaultBrowser(){
        return defaultBrowser.get();
    }

    public static void setDefaultBrowser(String newDefault){
        defaultBrowser.set(newDefault);
    }

    public static WebDriverWait getWebDriverWait(){
        return wait.get();
    }

    public static void setWebDriverWait(WebDriverWait wait1){
        wait.set(wait1);
    }

    public static WebDriver openWiniumDriver(DesktopApplicationStartupSettings startupSettings) throws Exception {
        setCurrentBrowser("winium");

        DesktopOptions deskOption = new DesktopOptions();
        deskOption.setApplicationPath(startupSettings.get_applicationPath());
        String arguments = startupSettings.get_applicationArguments();
        if (arguments != null) {
            deskOption.setArguments(arguments);
        }
        deskOption.setDebugConnectToRunningApp(false);
        deskOption.setLaunchDelay(2);
        setDriver(new WiniumDriver(new URL(startupSettings.getWiniumServerString()), deskOption));
        return getDriver();
    }

    public static String getDownloadLocation(){
        return downloadLocation.get();
    }

    public static void setDownloadLocation(String newLocation){
        downloadLocation.set(newLocation);
    }

    public static WebDriver getDriver() {
        return driver.get();
    }

    public static void setDriver(WebDriver newDriver) {
        driver.set(newDriver);
    }

    public static String getCurrentBrowser() {
        return currentBrowser.get();
    }

    public static void setCurrentBrowser(String browserStr) {
        currentBrowser.set(browserStr);
    }

    /**
     * Returns true if the current driver is a desktop driver (Appium or Winium). Returns false if
     * the current driver is a web or mobile-app driver, or if there is no current driver.
     *
     * @return true if we're automating a desktop application
     */
    public static boolean isDesktop() {
        boolean isAppium = AppiumDesktop.isWindowsPlatform(getDriver());
        boolean isWinium = Objects.equals(getCurrentBrowser(), "winium");
        return isAppium || isWinium;
    }

    // Open a browser to a particular URL. Defaults to the value set in the
    // string above unless overridden.
    // Note that this uses RemoteWebDriver and depends on Selenium-Standalone
    // being up and running.
    // The value here can also be passed in as a variable via Ant/Jenkins
    public static WebDriver openBrowser(String url, String browserToUse) {
        setCurrentBrowser(browserToUse);

        BaseUI.log_Status("Launching " + browserToUse + " browser.");
        DesiredCapabilities capa = new DesiredCapabilities();
        switch (browserToUse) {
            case "firefox":
                capa = DesiredCapabilities.firefox();

                FirefoxOptions option = BrowserOptions.forFirefox(url, getDownloadLocation());

                break;
            case "chrome":
                capa = DesiredCapabilities.chrome();
                DriverInfo driverInfo = new DriverInfo(DriverSetup.DriverType.CHROME);
                driverInfo.setDownloadLocation(getDownloadLocation());

                ChromeOptions options = BrowserOptions.forChromeRemote(driverInfo);

                capa.setCapability(ChromeOptions.CAPABILITY, options);

                break;
            case "internetexplorer":
                capa = DesiredCapabilities.internetExplorer();

                InternetExplorerOptions options1 = BrowserOptions.forInternetExplorer(url);

                break;
            case "android":
                capa = DesiredCapabilities.chrome();

                ChromeOptions chromeOptions = BrowserOptions.forAndroid();

                capa.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
                // Set the mobile type flag. We use this in tests to determine which
                // version of an object to use
                typeOfBrowser = "mobile";
                break;
            case "iphonesimulated":
                capa = DesiredCapabilities.chrome();

                ChromeOptions optionsSimulated = BrowserOptions.forIPhoneSimulated();

                capa.setCapability(ChromeOptions.CAPABILITY, optionsSimulated);
                typeOfBrowser = "mobile";
                break;
            case "chromeHeadless":
                options = BrowserOptions.forChromeHeadlessWithProxyBypass();

                ChromeDriverService driverService = ChromeDriverService.createDefaultService();
                RemoteWebDriver chromeDriver = new ChromeDriver(driverService, options);

                setDriver(chromeDriver);

                Map<String, Object> commandParams = new HashMap<>();
                commandParams.put("cmd", "Page.setDownloadBehavior");
                Map<String, String> params = new HashMap<>();
                params.put("behavior", "allow");
                params.put("downloadPath", getDownloadLocation());
                commandParams.put("params", params);
                ObjectMapper objectMapper = new ObjectMapper();
                HttpClient httpClient = HttpClientBuilder.create().build();
                RuntimeIOException.withRuntimeIOExceptions(() -> {
                    String command = objectMapper.writeValueAsString(commandParams);
                    String u = driverService.getUrl().toString() + "/session/" + chromeDriver.getSessionId() + "/chromium/send_command";
                    HttpPost request = new HttpPost(u);
                    request.addHeader("content-type", "application/json");
                    request.setEntity(new StringEntity(command));
                    httpClient.execute(request);
                });
                break;
            default:
                capa = DesiredCapabilities.firefox();
        }
        if (getCurrentBrowser().equals("chromeHeadless")
            //         || url.contains("datamyx") || url.contains("ie-dev.deluxe.com")
        ) {
            //Setting this in Chrome section under these conditions to not use RemoteWebDriver.
        } else {
            setDriver(new RemoteWebDriver(capa));
        }

        setWebDriverWait(new WebDriverWait(getDriver(), defaultWaitTime));

        getDriver().get(url);
        getDriver().manage().window().maximize();
        ThreadUtils.sleep(6000);
        setDefaultBrowser(browserToUse);

        getDriver().switchTo().window(getDriver().getWindowHandle());

        ThreadUtils.sleep(500);
        BaseUI.log_Status("Opened " + url + " with " + defaultBrowser);

        return getDriver();
    }

    public static void changeDriver(WebDriver newDriver, String browser) {
        setDriver(newDriver);
        setCurrentBrowser(browser);
    }

    public static String selectProperBrowser() {
        String browserToUse = getDefaultBrowser();
        try {
            browserToUse = System.getProperty("browser");
            if (browserToUse == null) {
                browserToUse = getDefaultBrowser();
            }
        } catch (NullPointerException e) {
            BaseUI.log_Status("Browser not set, using default");
        }
        return browserToUse;
    }

    public static WebDriver openBrowser(String url) {
        return openBrowser(url, selectProperBrowser());
    }

    //Overload that also calls wait logic on PageObject via reflection.
    //Assumptions: Page Object has constructor that takes WebDriver
    public static <T extends BasePageObject> WebDriver openBrowser(String url, Class<T> classToWaitFor) {
        WebDriver driver = openBrowser(url, selectProperBrowser());
        try {
            Constructor<T> cons = classToWaitFor.getConstructor(WebDriver.class);
            T pageObject = cons.newInstance(driver);
            pageObject.waitForPageToLoad();
            return driver;
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static void closeBrowser() {
        if (getDriver() != null) {
            getDriver().quit();
            setDriver(null);
            BaseUI.log_Status("Closed browser");
        }
    }

    public static void close_CurrentBrowserWindow() {
        getDriver().close();
        BaseUI.log_Status("Closed current browser window");
    }

    // Clicks the back button on every browser type.
    public static void clickBrowserBackButton() {
        getDriver().navigate().back();
        BaseUI.log_Status("Clicking back button on browser");
    }

    // Navigate to a new page in the current session.
    public static void navigateTo(String urlValue) {
        getDriver().navigate().to(urlValue);
        BaseUI.log_Status("Navigating to " + urlValue);
    }

    //Do NOT use this method if you plan to run multiple jobs on the same vm via Jenkins using multiple executors/nodes.
    public static void kill_ExcessProcesses() throws Exception {

        Process process = Runtime.getRuntime().exec("tasklist.exe");
        Scanner scanner = new Scanner(new InputStreamReader(process.getInputStream()));
        while (scanner.hasNext()) {
            String scannerText = scanner.nextLine();
            System.out.println(scannerText);

            if (scannerText != null) {

                if (scannerText.startsWith("chrome.exe")) {
                    Runtime.getRuntime().exec("taskkill /F /T /IM chrome.exe");
                }
                if (scannerText.startsWith("chromedriver.exe")) {
                    Runtime.getRuntime().exec("taskkill /F /T /IM chromedriver.exe");
                }
                if (scannerText.startsWith("iexplore.exe")) {
                    Runtime.getRuntime().exec("taskkill /F /T /IM iexplore.exe");
                }
                if (scannerText.startsWith("IEDriverServer.exe")) {
                    Runtime.getRuntime().exec("taskkill /F /T /IM IEDriverServer.exe");
                }

                if (scannerText.startsWith("firefox.exe")) {
                    Runtime.getRuntime().exec("taskkill /F /T /IM firefox.exe");
                }

                // taskkill /IM "process_name" /T /F
            }
        }
        scanner.close();
    }
}// End of Class
