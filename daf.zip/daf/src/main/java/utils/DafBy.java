package utils;

import org.jetbrains.annotations.Nullable;
import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class DafBy {

    public static By key(String key) {
        return key(key, null, null);
    }

    public static By key(String key, String argument) {
        return key(key, argument, null);
    }

    public static By key(String key, String argument1, String argument2) {
        By by = Locator.lookupBy(key, argument1, argument2);
        String stringValue = stringify(key, argument1, argument2);
        return new NamedBy(by, stringValue);
    }

    private static String stringify(String key, String... arguments) {
        List<String> argumentList = new ArrayList<>(Arrays.asList(arguments));

        Collections.reverse(argumentList);
        while (!argumentList.isEmpty() && argumentList.get(0) == null)
            argumentList.remove(0);
        Collections.reverse(argumentList);

        return argumentList.isEmpty()
                ? "[Repository Key: " + key + "]"
                : "[Repository Key: " + key + "(" + argumentList.stream().map(DafBy::stringifyArgument).collect(Collectors.joining(", ")) + ")]";
    }

    private static String stringifyArgument(@Nullable String argument) {
        return argument == null ? "null" : '"' + argument + '"';
    }

    /**
     * Decorator for another By instance, but changes the string representation to something closer to what
     * the test code is working with, i.e. the repository key and arguments.
     */
    private static class NamedBy extends By {
        private final By inner;
        private final String stringValue;

        private NamedBy(By inner, String stringValue) {
            this.inner = inner;
            this.stringValue = stringValue;
        }

        @Override
        public WebElement findElement(SearchContext context) {
            return inner.findElement(context);
        }

        @Override
        public List<WebElement> findElements(SearchContext context) {
            return inner.findElements(context);
        }

        @Override
        public String toString() {
            return stringValue;
        }
    }
}
