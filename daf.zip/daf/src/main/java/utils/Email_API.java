package utils;

import com.mailosaur.MailosaurClient;
import com.mailosaur.MailosaurException;
import com.mailosaur.models.Message;
import com.mailosaur.models.MessageSummary;
import com.mailosaur.models.SearchCriteria;
import common.ListUtils;
import utils2.LogInfo;

import java.io.IOException;
import java.util.List;

public class Email_API {

    static String apiKey = "v87IhGSmN3ohRJy";
    static String mailosaurbox = "j4pxicxw";
    public static String email_Ending = ".j4pxicxw@mailosaur.io";

    private static MailosaurClient mailosaur = new MailosaurClient(apiKey);

    public static void Wait_ForEmail_ToExist(String recipient, Integer secondsToWait) throws IOException {
        BaseUI.log_Status("Waiting up to " + secondsToWait.toString() + " seconds for email to appear in inbox.");
        SearchCriteria criteria = new SearchCriteria().withSentTo(recipient);
        final int millisecondsToWait = secondsToWait * 1000;
        try {
            mailosaur.messages().get(mailosaurbox, criteria, millisecondsToWait);
            LogInfo.log_Status("Message(s) found");
        } catch (MailosaurException e) {
            // If timeout is exceeded, just return
            LogInfo.log_Status("Timeout exceeded with no messages found");
        }
    }

    private static ImmutableEmailMessage createEmailMessage(Message email) {
        return ImmutableEmailMessage.builder()
                .subject(email.subject())
                .creationDate(email.received().toString())
                .textBody(email.text().body())
                .htmlBody(email.html().body())
                .id(email.id())
                .firstLink(email.html().links().size() > 0 ? email.html().links().get(0).href() : null)
                .firstToAddress(email.to().size() > 0 ? email.to().get(0).email() : null)
                .build();
    }

    private static ImmutableEmailSummary createEmailSummary(MessageSummary email) {
        return ImmutableEmailSummary.builder()
                .subject(email.subject())
                .creationDate(email.received().toString())
                .id(email.id())
                .firstToAddress(email.to().size() > 0 ? email.to().get(0).email() : null)
                .build();
    }

    public static EmailMessage return_FirstEmail_ByRecipient(String recipient) {
        try {
            BaseUI.log_Status("Returning email for recipient " + recipient);

            SearchCriteria criteria = new SearchCriteria().withSentTo(recipient);

            // Throws MailosaurException if no messages exist
            Message email = mailosaur.messages().get(mailosaurbox, criteria);

            return createEmailMessage(email);
        } catch (MailosaurException e) {
            BaseUI.log_Status("No emails were found.");
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Error getting emails for '" + recipient + "': " + e.getMessage(), e);
        }
    }

    public static EmailSummary[] return_AllEmailsByRecipient(String recipient) throws Exception {
        SearchCriteria criteria = new SearchCriteria().withSentTo(recipient);
        final List<MessageSummary> emails = mailosaur.messages().search(mailosaurbox, criteria).items();
        BaseUI.log_Status("Returning all emails for " + recipient);

        if (emails.size() == 0) {
            BaseUI.log_Status("No emails were found.");
        }

        return ListUtils.map(emails, Email_API::createEmailSummary).toArray(new EmailSummary[0]);
    }

    //Might have multiple pages of emails, R360 was flooding our inbox, needed to make more robust.
    public static void delete_Emails_ByRecipient(String recipient) throws Exception {
        EmailSummary[] emails = return_AllEmailsByRecipient(recipient);

        BaseUI.log_Status("Deleting all emails for " + recipient);

        int maxCount = 0;
        while (emails.length > 0 && maxCount < 50) {
            for (EmailSummary email : emails) {
                String emailID = email.getId();
                if (email.getFirstToAddress().equalsIgnoreCase(recipient)) {
                    try {
                        mailosaur.messages().delete(emailID);
                    } catch (Exception e) {
                        BaseUI.log_Warning("Encountered error while attempting to delete email: " + e.getMessage());
                    }
                }
            }
            emails = return_AllEmailsByRecipient(recipient);
            maxCount++;
        }
    }

    public static void delete_Email_ByEmailID(String id) throws Exception {
        mailosaur.messages().delete(id);
    }

    public static String return_FirstLink_FromEmail(EmailMessage email) {
        BaseUI.log_Status("Attempting to return first link from email.");
        return email.getFirstLink();
    }

    public static String return_EmailSubject_FromEmail(EmailMessage email) {
        BaseUI.log_Status("Attempting to return Subject from email.");
        return email.getSubject();
    }

    public static String return_EmailCreationDate_FromEmail(EmailMessage email) {
        BaseUI.log_Status("Attempting to return email creation date from email.");
        return email.getCreationDate();
    }

    public static String return_EmailData_FromEmailBody(EmailMessage email) {
        BaseUI.log_Status("Attempting to return email content from email.");
        return email.getTextBody();
    }

    public static String return_EmailHtmlBody_FromEmail(EmailMessage email) {
        BaseUI.log_Status("Attempting to return email content as html from email.");
        return email.getHtmlBody();
    }

    public static EmailMessage getFullMessage(EmailSummary summary) throws Exception {
        BaseUI.log_Status("Getting email with ID " + summary.getId());
        final Message email = mailosaur.messages().getById(summary.getId());
        return createEmailMessage(email);
    }
}
