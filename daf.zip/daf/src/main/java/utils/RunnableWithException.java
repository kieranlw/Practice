package utils;

/**
 * Functional interface that can throw. Like Runnable but with exceptions, or Callable with no return value.
 */
@FunctionalInterface
public interface RunnableWithException {
    void run() throws Exception;
}
