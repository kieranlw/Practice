package utils;

import common.ReadableFile;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.File;

/**
 * Read-only wrapper to make XML data easier to work with. If you need to modify the XML,
 * use this class's descendant, XmlEditor.
 */
public class XmlData {

    protected final Document xml;

    public XmlData(String filePathAndName) throws Exception {
        xml = createXML(filePathAndName);
    }

    public XmlData(ReadableFile file) throws Exception {
        this(file.getAbsolutePath());
    }

    public XmlData(Document xml) {
        this.xml = xml;
    }

    private Document createXML(String xmlFileName) throws Exception {

        File xmlFile = new File(xmlFileName);
        Document xmlDoc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(xmlFile);
        xmlDoc.getDocumentElement().normalize();

        return xmlDoc;
    }

    public NodeList findNodes(String xpathToEvaluate) {
        XPath newXpath = XPathFactory.newInstance().newXPath();
        try {
            NodeList nodes = (NodeList) newXpath.evaluate(xpathToEvaluate, xml.getDocumentElement(),
                    XPathConstants.NODESET);
            return nodes;
        } catch (XPathExpressionException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public Node findNode(String xpathToEvaluate) throws Exception {
        XPath newXpath = XPathFactory.newInstance().newXPath();
        Node node = (Node) newXpath.evaluate(xpathToEvaluate, xml.getDocumentElement(), XPathConstants.NODE);
        return node;
    }

    public String getAttribute(Node nodeToCheck, String attributeToGet) {
        Element elementToSet = (Element) nodeToCheck;
        String attribute = elementToSet.getAttribute(attributeToGet);

        return attribute;
    }

    public NodeList getElementsByTagName(String tagName) {

        return xml.getElementsByTagName(tagName);
    }
}
