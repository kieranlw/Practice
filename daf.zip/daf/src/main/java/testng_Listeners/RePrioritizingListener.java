package testng_Listeners;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;
import utils2.classGroup.GroupBy;

//Listener to fix TestNG Interleaving issue.  I had to re-write this as the original example I had did not allow for priority to be manually set on a test level.
public class RePrioritizingListener implements IAnnotationTransformer {

    private HashMap<Object, Integer> priorityMap = new HashMap<Object, Integer>();
    private Integer class_priorityCounter = 1000;
    // The length of the final priority assigned to each method.
    private Integer max_testpriorityLength = 4;

    private HashMap<Object, String[]> classGroupingMap = new HashMap<>();

    // The parameters would be better as the generic Class<...> and Constructor<...>, but the
    // interface we're implementing uses the raw types, so we're stuck. Tell the compiler not to
    // give the raw-types warning.
    // IntelliJ is smart enough to know we have no alternative, so it doesn't show the raw-types
    // warning in the first place - so we also need to tell IntelliJ not to warn us of (what it
    // thinks is) the unneeded suppression annotation!
    @Override
    @SuppressWarnings({"rawtypes", "RedundantSuppression"})
    public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod) {

        // class of the test method.
        Class<?> declaringClass = testMethod.getDeclaringClass();

        setPriority(declaringClass, annotation);
        setGroupings(declaringClass, annotation);
    }

    private void setPriority(Class<?> declaringClass, ITestAnnotation annotation) {
        // Current priority of the test assigned at the test method.
        Integer test_priority = annotation.getPriority();
        // Current class priority.
        if (test_priority.toString().length() < max_testpriorityLength) {
            Integer current_ClassPriority = priorityMap.get(declaringClass);

            if (current_ClassPriority == null) {
                current_ClassPriority = class_priorityCounter++;
                priorityMap.put(declaringClass, current_ClassPriority);
            }

            // Adds 0's to start of this number.
            String concatenatedPriority = String.format("%0" + max_testpriorityLength + "d", test_priority);

            // Concatenates our class counter to the test level priority (example
            // for test with a priority of 1: 1000100001; same test class with a
            // priority of 2: 1000100002; next class with a priority of 1. 1000200001)
            concatenatedPriority = current_ClassPriority.toString() + concatenatedPriority;

            //Sets the new priority to the test method.
            annotation.setPriority(Integer.parseInt(concatenatedPriority));
        }
    }

    private void setGroupings(Class<?> declaringClass, ITestAnnotation annotation) {
        if (classGroupingMap.get(declaringClass) == null) {
            GroupBy groupBy = declaringClass.getAnnotation(GroupBy.class);
            if (groupBy == null) {
                classGroupingMap.put(declaringClass, new String[]{});
            } else {
                classGroupingMap.put(declaringClass, groupBy.groups());
            }
        }

        Set<String> classGroupings = new HashSet<>(
                Arrays.asList(classGroupingMap.get(declaringClass)));
        String[] testLocalGroupings = annotation.getGroups();
        for (String localGrouping : testLocalGroupings) {
            classGroupings.add(localGrouping);
        }

        annotation.setGroups(classGroupings.toArray(new String[classGroupings.size()]));
    }
}
