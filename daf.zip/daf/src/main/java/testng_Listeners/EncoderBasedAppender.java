package testng_Listeners;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.AppenderBase;
import ch.qos.logback.core.encoder.Encoder;
import ch.qos.logback.core.status.ErrorStatus;

import java.nio.charset.StandardCharsets;

public abstract class EncoderBasedAppender extends AppenderBase<ILoggingEvent> {
    private Encoder<ILoggingEvent> encoder;

    public Encoder<ILoggingEvent> getEncoder() {
        return encoder;
    }

    public void setEncoder(Encoder<ILoggingEvent> encoder) {
        this.encoder = encoder;
    }

    @Override
    public void start() {
        if (this.encoder == null) {
            addStatus(new ErrorStatus("No encoder set for the appender named \"" + name + "\".", this));
        } else {
            super.start();
        }
    }

    protected String encode(ILoggingEvent event) {
        if (encoder == null) {
            return "";
        }

        byte[] bytes = encoder.encode(event);
        return new String(bytes, StandardCharsets.UTF_8);
    }
}
