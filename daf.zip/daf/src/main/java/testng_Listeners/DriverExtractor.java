package testng_Listeners;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.openqa.selenium.WebDriver;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class DriverExtractor {
    private DriverExtractor() {
    }

    private static WebDriver getDriverFromWebDriverField(Field field, Object instance) {
        try {
            return (WebDriver) FieldUtils.readField(field, instance, true);
        } catch (Exception e) {
            return null;
        }
    }

    private static WebDriver getDriverFromThreadLocalField(Field field, Object instance) {
        try {
            ThreadLocal<?> threadLocal = (ThreadLocal<?>) FieldUtils.readField(field, instance, true);
            if (threadLocal == null) {
                return null;
            }

            Object value = threadLocal.get();
            if (value instanceof WebDriver) {
                return (WebDriver) value;
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    private static WebDriver getDriverFromField(Field field, Object instance) {
        if (field.getType().equals(WebDriver.class)) {
            return getDriverFromWebDriverField(field, instance);
        } else if (ThreadLocal.class.isAssignableFrom(field.getType())) {
            return getDriverFromThreadLocalField(field, instance);
        } else {
            return null;
        }
    }

    private static List<Field> getAllFields(Class<?> testClass) {
        // Get all fields, including private, from this class and all ancestors
        List<Field> results = new ArrayList<>();
        for (Class<?> current = testClass; current != null; current = current.getSuperclass()) {
            results.addAll(Arrays.asList(current.getDeclaredFields()));
        }
        return results;
    }

    public static List<WebDriver> getDriversFromFields(Object instance) {
        return getAllFields(instance.getClass()).stream()
                .map(field -> getDriverFromField(field, instance))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }
}
