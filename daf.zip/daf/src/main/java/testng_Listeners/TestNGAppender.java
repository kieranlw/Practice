package testng_Listeners;

import ch.qos.logback.classic.spi.ILoggingEvent;
import org.testng.Reporter;

public class TestNGAppender extends EncoderBasedAppender {
    @Override
    protected void append(ILoggingEvent eventObject) {
        Reporter.log(encode(eventObject));
    }
}
