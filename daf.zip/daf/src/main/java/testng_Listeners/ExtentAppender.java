package testng_Listeners;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import com.aventstack.extentreports.Status;

public class ExtentAppender extends EncoderBasedAppender {
    @Override
    protected void append(ILoggingEvent eventObject) {
        Status status = levelToStatus(eventObject.getLevel());
        String message = encode(eventObject);

        if (ExtentReportListener2.reporterRunning.get()) {
            ExtentReportListener2.testReporter.get().log(status, message);
        }
        if (ExtentReportListenerV3.reporterRunning.get()) {
            ExtentReportListenerV3.testReporter.get().log(status, message);
        }
    }

    private static Status levelToStatus(Level level) {
        switch (level.toInt()) {
            case Level.ERROR_INT:
                return Status.FAIL;
            case Level.WARN_INT:
                return Status.WARNING;
            case Level.DEBUG_INT:
                return Status.PASS;
            default:
                return Status.INFO;
        }
    }
}
