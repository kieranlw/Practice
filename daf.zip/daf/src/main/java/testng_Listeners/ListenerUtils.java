package testng_Listeners;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.slf4j.Logger;
import org.testng.ITestResult;
import org.testng.Reporter;

public class ListenerUtils {
    private ListenerUtils() {
    }

    /**
     * Handle logging of a failure (either a test or a configuration method).
     *
     * @param result     The ITestResult object for the failing test/configuration method
     * @param extentTest The ExtentTest object for the current test, if this is a test-method failure; or null, if this is a configuration-method failure.
     */
    public static void logFailure(ITestResult result, ExtentTest extentTest) {
        if (result.getThrowable() != null) {
            String message = result.getThrowable().getMessage();
            if (message != null) {
                System.out.println(message);
                // No need to write to Reporter.log. TestNG logs the exception automatically.
            }

            if (extentTest != null) {
                extentTest.log(Status.FAIL, result.getThrowable());
            }
        }
    }

    /**
     * Sends a screenshot (identified by a file on disk) to Report Portal.
     * See https://github.com/reportportal/logger-java-logback#screenshots.
     *
     * @param logger  A logger that's able to write to the Logback Report Portal appender
     * @param path    Path of the screenshot image
     * @param message Text to log along with the screenshot
     */
    public static void logScreenshot(Logger logger, String path, String message) {
        logger.warn("RP_MESSAGE#FILE#" + path + "#" + message);

        // Log the screenshot path for DafAggregator to pick up. This only needs to go to the TestNG log,
        // not the Jenkins console or Report Portal. The line needs to start with "ScreenshotPath: ".
        Reporter.log("ScreenshotPath: " + path);
    }
}
