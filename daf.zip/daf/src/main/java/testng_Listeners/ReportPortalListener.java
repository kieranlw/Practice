package testng_Listeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.epam.reportportal.listeners.Statuses;
import com.epam.reportportal.testng.ITestNGService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.*;
import org.testng.internal.IResultListener;
import utils.FileOperations;
import utils2.LogInfo;

import java.io.File;

/**
 * <p>Base TestNG listener that knows how to log events to Report Portal. Descendant classes can
 * add other outputs (e.g. Extent Reports). Screenshots currently happen in descendants as well,
 * since screenshot logic is currently intertwined with Extent Reports logic.</p>
 */
public class ReportPortalListener implements IExecutionListener, ISuiteListener, IResultListener, IConfigurationListener {
    protected final Logger LOGGER = LoggerFactory.getLogger(getClass());
    private final ITestNGService testNGService = new DafTestNGService();
    protected ExtentReports report;
    protected String path = "";
    private ExtentHtmlReporter htmlReporter;
    protected String folderName = "";
    private Boolean firstTestClass = true;
    private String suiteName;

    @Override
    public final void onExecutionStart() {
        testNGService.startLaunch();
    }

    @Override
    public final void onExecutionFinish() {
        testNGService.finishLaunch();
    }

    @Override
    public final void onStart(ISuite suite) {
        testNGService.startTestSuite(suite);
    }

    @Override
    public final void onFinish(ISuite suite) {
        testNGService.finishTestSuite(suite);
    }

    @Override
    public final void beforeConfiguration(ITestResult testResult) {
        testNGService.startConfiguration(testResult);
    }

    @Override
    public final void onConfigurationSuccess(ITestResult testResult) {
        try {
            configurationSucceeded(testResult);
        } finally {
            testNGService.finishTestMethod(Statuses.PASSED, testResult);
        }
    }

    @Override
    public final void onConfigurationFailure(ITestResult testResult) {
        try {
            configurationFailed(testResult);
        } finally {
            testNGService.sendReportPortalMsg(testResult);
            testNGService.finishTestMethod(Statuses.FAILED, testResult);
        }
    }

    @Override
    public final void onConfigurationSkip(ITestResult testResult) {
        testNGService.startConfiguration(testResult);
        testNGService.finishTestMethod(Statuses.SKIPPED, testResult);
    }

    @Override
    public final void onTestStart(ITestResult testResult) {
        testNGService.startTestMethod(testResult);
        testStarted(testResult);
    }

    @Override
    public final void onTestSuccess(ITestResult testResult) {
        try {
            testSucceeded(testResult);
        } finally {
            testNGService.finishTestMethod(Statuses.PASSED, testResult);
        }
    }

    @Override
    public final void onTestFailure(ITestResult testResult) {
        try {
            testFailed(testResult);
        } finally {
            testNGService.sendReportPortalMsg(testResult);
            testNGService.finishTestMethod(Statuses.FAILED, testResult);
        }
    }

    @Override
    public final void onTestSkipped(ITestResult testResult) {
        try {
            testSkipped(testResult);
        } finally {
            testNGService.finishTestMethod(Statuses.SKIPPED, testResult);
        }
    }

    @Override
    public final void onTestFailedButWithinSuccessPercentage(ITestResult testResult) {
        testNGService.finishTestMethod(Statuses.FAILED, testResult);
    }

    @Override
    public final void onStart(ITestContext testContext) {
        testNGService.startTest(testContext);
        testContextStarted(testContext);
    }

    @Override
    public final void onFinish(ITestContext testContext) {
        try {
            testContextFinished(testContext);
        } finally {
            testNGService.finishTest(testContext);
        }
    }

    protected void configurationSucceeded(ITestResult testResult) {
    }

    protected void configurationFailed(ITestResult testResult) {
    }

    protected void testStarted(ITestResult testResult) {
    }

    protected void testSucceeded(ITestResult testResult) {
    }

    protected void testFailed(ITestResult testResult) {
    }

    protected void testSkipped(ITestResult testResult) {
    }

    protected void testContextStarted(ITestContext testContext) {
        // If we're running in Jenkins, write Extent reports and screenshots to
        // "C:\DAF\<jobname>" (now that we're using pre-built XML files instead
        // of dynamically-generated ones, and the suite name may not be the same
        // as the job name)
        if (suiteName == null) {
            suiteName = System.getenv("JOB_BASE_NAME");
        }
        // Otherwise use the suite name from the TestNG.xml
        if (suiteName == null) {
            suiteName = testContext.getSuite().getName();
        }

        if (firstTestClass) {
            folderName = "c:/DAF/" + suiteName + "/";

            path = folderName.replace("/", "\\");
            File file = new File(path);
            file.mkdir();
            try {
                FileOperations.cleanup_PriorFiles(path);
            } catch (Exception e) {
                LogInfo.log_Warning("Error cleaning up files before test run: " + e);
            }

            htmlReporter = new ExtentHtmlReporter(folderName + "SimpleReport.html");
            htmlReporter.setAppendExisting(true);

            report = new ExtentReports();
            report.attachReporter(htmlReporter);
            String environment = System.getProperty("environment");
            if (environment != null) {
                report.setSystemInfo("Environment", environment);
            }
        }

        firstTestClass = false;
    }

    protected void testContextFinished(ITestContext testContext) {
    }
}
