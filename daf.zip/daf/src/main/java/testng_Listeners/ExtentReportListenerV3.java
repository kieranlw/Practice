package testng_Listeners;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import utils.Browser;
import utils.FileOperations;
import utils2.LogInfo;
import utils2.ResultWriter2;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by andrey.smirnov on 14.06.2016.
 */
public class ExtentReportListenerV3 extends ReportPortalListener {
    public static ThreadLocal<ExtentTest> testReporter = new ThreadLocal<>();

    public static ThreadLocal<Boolean> reporterRunning = new ThreadLocal<Boolean>() {
        @Override
        public Boolean initialValue() {
            return false;
        }
    };

    private Boolean bool_ClearTempFiles = return_TempFilesBool();

    private Boolean return_TempFilesBool() {
        String cleanTemp = System.getProperty("cleanTemp");

        if (cleanTemp != null && cleanTemp.equals("true")) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void testSucceeded(ITestResult result) {
        testReporter.get().log(Status.PASS, "Test PASSED");
        report.flush();
        reporterRunning.set(false);
    }

    @Override
    public void testContextFinished(ITestContext context) {
        if (bool_ClearTempFiles) {
            try {
                FileOperations.cleanup_dafTestUser();
                FileOperations.cleanup_TempFolder();
            } catch (Exception e) {
                LogInfo.log_Warning("Error cleaning up after test run: " + e);
            }
        }

        reporterRunning.set(false);
    }

    @Override
    public void testContextStarted(ITestContext arg0) {
        reporterRunning.set(false);
        super.testContextStarted(arg0);
    }

    @Override
    public void testStarted(ITestResult result) {
        String testName = returnTestName(result);

        testReporter.set(report.createTest(testName, result.getMethod().getDescription()));
        String[] groups = result.getMethod().getGroups();
        for (String group : groups) {
            testReporter.get().assignCategory(group);
        }
        testReporter.get().log(Status.INFO, "Starting test " + result.getMethod().getMethodName());
        reporterRunning.set(true);
    }

    @Override
    public void testFailed(ITestResult result) {
        ListenerUtils.logFailure(result, testReporter.get());

        takeScreenshots(result, Status.FAIL);

        report.flush();
        reporterRunning.set(false);
    }

    private void takeScreenshots(ITestResult result, Status logStatus) {
        // Look for WebDriver fields on the test class, for DAFv2 tests.
        List<WebDriver> driversFromFields = DriverExtractor.getDriversFromFields(result.getInstance());

        // Also make this work for DAFv1 tests. Use a Set<T> to prevent duplicates, since many
        // tests call Browser.openBrowser and then store the result in a field on the test class.
        Set<WebDriver> allDrivers = new HashSet<>(driversFromFields);
        if (Browser.getDriver() != null) {
            allDrivers.add(Browser.getDriver());
        }

        for (WebDriver driver : allDrivers) {
            if (driver != null) {
                try {
                    ResultWriter2.checkForFailureAndScreenshot(result, driver);
                } catch (Exception e) {
                }
            }
        }

        Object screenObject = result.getAttribute("Screenshots");
        List<File> fileList = ResultWriter2.convertObjectToArrayListOfFiles(screenObject);

        for (File screenshot : fileList) {
            // Copy the file to the Extent-report directory
            String destination = folderName + screenshot.getName();
            FileOperations.copyFile(screenshot.getAbsolutePath(), destination);

            // Pass the message to the Extent report
            if (testReporter.get() != null) {
                String screenShotPath = ".\\" + screenshot.getName();
                try {
                    testReporter.get().log(logStatus, "Snapshot below: " + testReporter.get().addScreenCaptureFromPath(screenShotPath));
                } catch (IOException e) {
                    LogInfo.log_Warning("Error logging screenshot: " + e);
                }
            }
        }
    }

    private String returnTestName(ITestResult result) {
        Object[] testParameters = result.getParameters();
        String testName = result.getMethod().getMethodName();
        String testClass = result.getTestClass().getName();

        for (Object param : testParameters) {
            testName = testName + "," + param;
        }

        testName = testClass + "." + testName;

        return testName;
    }

    @Override
    public void testSkipped(ITestResult result) {
        String testName = returnTestName(result);

        if (!reporterRunning.get()) {
            testReporter.set(report.createTest(testName, "Test was Skipped"));
            testReporter.get().log(Status.INFO, "Test Skipped Name: " + result.getMethod().getMethodName());
            reporterRunning.set(true);
        }

        takeScreenshots(result, Status.SKIP);

        testReporter.get().log(Status.SKIP, "Test SKIPPED");

        report.flush();
        reporterRunning.set(false);
    }

    @Override
    public void configurationFailed(ITestResult testResult) {
        ListenerUtils.logFailure(testResult, null);
        takeScreenshots(testResult, Status.FAIL);
    }
}
