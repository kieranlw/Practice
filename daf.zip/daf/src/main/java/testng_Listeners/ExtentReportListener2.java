package testng_Listeners;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.testng.ITestContext;
import org.testng.ITestResult;
import utils.*;
import utils2.LogInfo;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.zip.CRC32;

/**
 * Created by andrey.smirnov on 14.06.2016.
 */
public class ExtentReportListener2 extends ReportPortalListener {

    public static ThreadLocal<ExtentTest> testReporter = new ThreadLocal<>();

    public static ThreadLocal<Boolean> reporterRunning = new ThreadLocal<Boolean>() {
        @Override
        public Boolean initialValue() {
            return false;
        }
    };
    private ArrayList<String> testList = new ArrayList<String>();
    private ArrayList<String> testList_Skipped = new ArrayList<String>();
    private ArrayList<String> failed_testList = new ArrayList<String>();

    private Boolean bool_ClearTempFiles = return_TempFilesBool();

    private Boolean return_TempFilesBool() {
        String cleanTemp = System.getProperty("cleanTemp");

        if (cleanTemp != null && cleanTemp.equals("true")) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    protected void testSucceeded(ITestResult result) {
        testReporter.get().log(Status.PASS, "Test PASSED");
        report.flush();
        reporterRunning.set(false);
    }

    @Override
    protected void testContextFinished(ITestContext testContext) {
        if (bool_ClearTempFiles) {
            try {
                FileOperations.cleanup_dafTestUser();
                FileOperations.cleanup_TempFolder();
            }
            catch (Exception e) {
                LogInfo.log_Warning("Error cleaning up after test run: " + e);
            }
        }

        reporterRunning.set(false);
    }

    @Override
    protected void testStarted(ITestResult result) {
        String testName = returnTestName(result);

        if (!testList.contains(testName)) {
            testList.add(testName);
            testReporter.set(report.createTest(testName, result.getMethod().getDescription()));
            testReporter.get().log(Status.INFO, "Starting test " + result.getMethod().getMethodName());
            String[] groups = result.getMethod().getGroups();
            for (String group : groups) {
                testReporter.get().assignCategory(group);
            }
            reporterRunning.set(true);
        }
    }

    @Override
    protected void testFailed(ITestResult result) {
        ListenerUtils.logFailure(result, testReporter.get());

        String testName = returnTestName(result);
        if (!failed_testList.contains(testName)) {

            failed_testList.add(testName);
            takeScreenshot(Status.FAIL, testName);

            testReporter.get().log(Status.FAIL, "Test FAILED");

            report.flush();
            reporterRunning.set(false);
        }
    }

    /**
     * Generates a shortened-but-likely-unique version of a possibly-long string.
     *
     * @param string    Input string to be possibly shortened
     * @param maxLength Maximum length of the returned string. This is assumed to be at least 10 or so.
     * @return The input string, if it's already less than maxLength; otherwise, a substring plus a hash.
     */
    private String shortenString(String string, int maxLength) {
        if (string.length() <= maxLength) {
            return string;
        }

        CRC32 crc = new CRC32();
        crc.update(string.getBytes(StandardCharsets.UTF_8));
        String suffix = Long.toHexString(crc.getValue());

        String prefix = string.substring(0, maxLength - suffix.length() - 1);
        return prefix + "~" + suffix;
    }

    private String returnTestName(ITestResult result) {
        Object[] testParameters = result.getParameters();

        String testName = shortenString(result.getMethod().getMethodName(), 64);
        String testClass = shortenString(result.getTestClass().getName(), 64);

        for (Object param : testParameters) {
            String paramString = param == null ? "null" : param.toString();
            testName = testName + "," + shortenString(paramString, 32);
        }

        testName = testClass + "." + testName;

        return testName;
    }

    private void takeScreenshot(Status logStatus, String testName) {
        if (Browser.getDriver() != null) {
            String screenShotPath = "";
            try {
                if (!Browser.isDesktop()) {
                    BaseUI.log_Warning("Current URL: " + Browser.getDriver().getCurrentUrl());
                }

                if (testName == null) {
                    BaseUI.log_Warning("Test Name was: null");
                } else {
                    BaseUI.log_Status("Test Name was: " + testName);
                }

                if (path == null) {
                    BaseUI.log_Warning("Screenshot path was: null");
                }
                screenShotPath = ResultWriter.saveScreenshot(testName, path);

                ListenerUtils.logScreenshot(LOGGER, screenShotPath, "Screenshot");

                screenShotPath = ".\\"
                        + screenShotPath.substring(screenShotPath.lastIndexOf("\\"), screenShotPath.length());
                testReporter.get().log(logStatus, "Snapshot below: " + testReporter.get().addScreenCaptureFromPath(screenShotPath));
            } catch (Exception e) {
                BaseUI.log_Warning("Unexpected error trying to save screenshot: " + ExceptionUtils.getStackTrace(e));
            }
        }
    }

    @Override
    protected void testSkipped(ITestResult result) {
        String testName = returnTestName(result);

        if (!testList_Skipped.contains(testName)) {
            testList_Skipped.add(testName);

            if (!reporterRunning.get()) {
                testReporter.set(report.createTest(testName, "Test was Skipped"));
                testReporter.get().log(Status.INFO, "Test Skipped Name: " + result.getMethod().getMethodName());
                reporterRunning.set(true);
            }

            takeScreenshot(Status.SKIP, testName);

            testReporter.get().log(Status.SKIP, "Test SKIPPED");

            report.flush();
            reporterRunning.set(false);
        }
    }

    @Override
    protected void configurationFailed(ITestResult testResult) {
        ListenerUtils.logFailure(testResult, null);

        takeScreenshot(Status.FAIL, returnTestName(testResult));
    }

    @Override
    public void configurationSucceeded(ITestResult testResult) {
    }
}
