package testng_Listeners;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.turbo.TurboFilter;
import ch.qos.logback.core.spi.FilterReply;
import org.slf4j.Marker;

public class DafFilter extends TurboFilter {
    @Override
    public FilterReply decide(Marker marker, Logger logger, Level level, String format, Object[] params, Throwable t) {

        // Ignore debug logging from Report Portal (it logs all its REST traffic,
        // which is more than we care about)
        if (level.equals(Level.DEBUG) && logger.getName().startsWith("com.epam")) {
            return FilterReply.DENY;
        }

        return FilterReply.NEUTRAL;
    }
}
