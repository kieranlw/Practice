package payroll.pageComponents;

import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

public class CookieBanner extends payroll.page_components.CookieBanner {
    public CookieBanner(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
    }
}
