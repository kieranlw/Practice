package payroll.data_prep;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import payroll.data.BaseTest;
import payroll.data.Payroll_Logins;
import payroll.pages.workflow.DashboardPage_Workflow;
import payroll.pages.workflow.LoginPage_Workflow;
import payroll.pages.workflow.StateTaxCodeDetailsPage_Workflow;
import payroll.pages.workflow.TaxTableDetailPage_Workflow;
import utils2.DriverSetup;
import utils2.Index;
import utils2.page_components.*;

public class PrepareStateTaxTables extends BaseTest {

    private DashboardPage_Workflow dashboardPage;
    private static final Index FIRST_ROW = Index.zeroBased(0);
    private static final Index SECOND_ROW = Index.zeroBased(1);
    private static final Index THIRD_ROW = Index.zeroBased(2);
    private static final Index FOURTH_ROW = Index.zeroBased(3);
    private static final Index FIFTH_ROW = Index.zeroBased(4);
    private static final Index SIXTH_ROW = Index.zeroBased(5);
    private static final Index SEVENTH_ROW = Index.zeroBased(6);
    private static final Index EIGHTH_ROW = Index.zeroBased(7);
    private static final Index NINTH_ROW = Index.zeroBased(8);
    private static final Index TWELFTH_ROW = Index.zeroBased(11);

    @BeforeClass(alwaysRun = true)
    protected void secondarySetup() throws Exception {
        driver = new DriverSetup(defaultDriverInfo).startDriver(url_Workflow);
        dashboardPage = BasePageObject.createAndLoad(LoginPage_Workflow::new, driver)
                .login(Payroll_Logins.WORKFLOW_DEFAULT.getLoginInfo());
    }

    private StateTaxCodeDetailsPage_Workflow editState(String stateAbbreviation) {
        return dashboardPage
                .taxLink.clickToNavigate()
                .stateLink.clickToNavigate().stateTaxCodesTable
                .getStateLinkByText(stateAbbreviation).clickToNavigate();
    }

    @Test
    public void alaska() {
        StateTaxCodeDetailsPage_Workflow ak = editState("AK");
        ak.suiSdiFmlaSection_401kIsPreTaxCheckBox.check();
        ak.suiSdiFmlaSection_S125IsPreTaxCheckBox.check();
        ak.sitTransitSection_DependentCarePretax_CheckBox.check();
        ak.saveButton.clickToNavigate();
    }

    @Test
    public void alabama() {
        StateTaxCodeDetailsPage_Workflow al = editState("AL");
        al.sitTransitSection_DependentCarePretax_CheckBox.check();
        al.saveButton.clickToNavigate();
    }

    @Test
    public void california() {
        StateTaxCodeDetailsPage_Workflow ca = editState("CA");
        TaxTableDetailPage_Workflow taxTableDetailsPage = ca.getSitTableSetupLink("Annually","Single").clickToNavigate();
        taxTableDetailsPage.currentTaxTable_AllowanceMin.enterText("4601.00");
        taxTableDetailsPage.currentTaxTable_AllowanceMax.enterText("4601.00");
        taxTableDetailsPage.currentTaxTable_MiscAmt2.enterText("136.40");
        ca = taxTableDetailsPage.saveButton.clickToNavigate();
        taxTableDetailsPage = ca.getSitTableSetupLink("Annually", "Married").clickToNavigate();
        taxTableDetailsPage.currentTaxTable_MiscAmt2.enterText("136.40");
        ca = taxTableDetailsPage.saveButton.clickToNavigate();
        taxTableDetailsPage = ca.getSitTableSetupLink("Annually","Head of Household").clickToNavigate();
        taxTableDetailsPage.currentTaxTable_MiscAmt2.enterText("136.40");
        ca = taxTableDetailsPage.saveButton.clickToNavigate();
        ca.saveButton.clickToNavigate();
    }

    @Test
    public void dc() {
        StateTaxCodeDetailsPage_Workflow dc = editState("DC");
        TaxTableDetailPage_Workflow taxTableDetailsPage = dc.getSitTableSetupLink("Annually","Married").clickToNavigate();
        taxTableDetailsPage.getCell(Index.zeroBased(5),"FixedConstant" ).enterText("85025");
        dc = taxTableDetailsPage.saveButton.clickToNavigate();
        dc.saveButton.clickToNavigate();
    }

    @Test
    public void louisiana() {
        StateTaxCodeDetailsPage_Workflow la = editState("LA");
        la.sitTransitSection_RequiresRounding_Checkbox.uncheck();
        TaxTableDetailPage_Workflow taxTableDetailsPage = la.getSitTableSetupLink("Annually", "Zero Exempt").clickToNavigate();
        taxTableDetailsPage.getCell(THIRD_ROW, "FixedConstant").enterText("1.65");
        taxTableDetailsPage.getCell(FIRST_ROW, "FromPct").enterText("1.8");
        taxTableDetailsPage.getCell(SECOND_ROW, "FromPct").enterText("1.8");
        taxTableDetailsPage.getCell(THIRD_ROW, "FromPct").enterText("1.8");
        la = taxTableDetailsPage.saveButton.clickToNavigate();
        taxTableDetailsPage = la.getSitTableSetupLink("Annually", "One Exempt").clickToNavigate();
        taxTableDetailsPage.getCell(THIRD_ROW, "FixedConstant").enterText("1.65");
        taxTableDetailsPage.getCell(FIRST_ROW, "FromPct").enterText("1.8");
        taxTableDetailsPage.getCell(SECOND_ROW, "FromPct").enterText("1.8");
        taxTableDetailsPage.getCell(THIRD_ROW, "FromPct").enterText("1.8");
        la = taxTableDetailsPage.saveButton.clickToNavigate();
        la.saveButton.clickToNavigate();
    }

    @Test
    public void massachusetts() {
        StateTaxCodeDetailsPage_Workflow ma = editState("MA");
        TaxTableDetailPage_Workflow taxTableDetailsPage = ma.getSitTableSetupLink("Annually", "Single").clickToNavigate();
        taxTableDetailsPage.getCell(FIRST_ROW, "FromPct").enterText("5.0");
        ma = taxTableDetailsPage.saveButton.clickToNavigate();
        taxTableDetailsPage = ma.getSitTableSetupLink("Annually", "Married").clickToNavigate();
        taxTableDetailsPage.getCell(FIRST_ROW, "FromPct").enterText("5.00");
        ma = taxTableDetailsPage.saveButton.clickToNavigate();
        ma.saveButton.clickToNavigate();
    }
    @Test
    public void maryland() {
        StateTaxCodeDetailsPage_Workflow md = editState("MD");
        TaxTableDetailPage_Workflow taxTableDetailsPage = md.getSitTableSetupLink("Annually", "Single").clickToNavigate();
        taxTableDetailsPage.currentTaxTable_AllowanceMin.enterText("1550.00");
        taxTableDetailsPage.currentTaxTable_AllowanceMax.enterText("2350.00");
        md = taxTableDetailsPage.saveButton.clickToNavigate();
        taxTableDetailsPage = md.getSitTableSetupLink("Annually", "Married").clickToNavigate();
        taxTableDetailsPage.currentTaxTable_AllowanceMin.enterText("1550.00");
        taxTableDetailsPage.currentTaxTable_AllowanceMax.enterText("2350.00");
        md = taxTableDetailsPage.saveButton.clickToNavigate();
        md.saveButton.clickToNavigate();
    }

    @Test
    public void newYork() {
        StateTaxCodeDetailsPage_Workflow ny = editState("NY");
        TaxTableDetailPage_Workflow taxTableDetailsPage = ny.getSitTableSetupLink("Annually","Single").clickToNavigate();
        taxTableDetailsPage.getCell(Index.zeroBased(11),"FromPct" ).enterText("52.08");
        ny = taxTableDetailsPage.saveButton.clickToNavigate();
        ny.getSitTableSetupLink("Annually", "Married").clickToNavigate();
        taxTableDetailsPage.getCell(TWELFTH_ROW,"FromPct" ).enterText("94.54");
        ny = taxTableDetailsPage.saveButton.clickToNavigate();
        ny.saveButton.clickToNavigate();
    }

    @Test
    public void newJersey() {
        StateTaxCodeDetailsPage_Workflow nj = editState("NJ");
        TaxTableDetailPage_Workflow taxTableDetailsPage = nj.getSitTableSetupLink("Annually","Rate A").clickToNavigate();
        taxTableDetailsPage.getCell(SEVENTH_ROW, "FromPct").enterText("21.30");
        taxTableDetailsPage.addRow();
        taxTableDetailsPage.getCell(EIGHTH_ROW, "FromPct").enterText("11.80");
        taxTableDetailsPage.getCell(EIGHTH_ROW, "FixedConstant").enterText("934180");
        taxTableDetailsPage.getCell(EIGHTH_ROW, "FromAmt").enterText("5000000");
        nj = taxTableDetailsPage.saveButton.clickToNavigate();
        taxTableDetailsPage = nj.getSitTableSetupLink("Annually","Rate B").clickToNavigate();
        taxTableDetailsPage.getCell(EIGHTH_ROW, "FromPct").enterText("21.30");
        taxTableDetailsPage.addRow();
        taxTableDetailsPage.getCell(NINTH_ROW, "FromPct").enterText("11.80");
        taxTableDetailsPage.getCell(NINTH_ROW, "FixedConstant").enterText("932100");
        taxTableDetailsPage.getCell(NINTH_ROW, "FromAmt").enterText("5000000");
        nj = taxTableDetailsPage.saveButton.clickToNavigate();
        taxTableDetailsPage = nj.getSitTableSetupLink("Annually","Rate C").clickToNavigate();
        taxTableDetailsPage.getCell(EIGHTH_ROW, "FromPct").enterText("21.30");
        taxTableDetailsPage.addRow();
        taxTableDetailsPage.getCell(NINTH_ROW, "FromPct").enterText("11.80");
        taxTableDetailsPage.getCell(NINTH_ROW, "FixedConstant").enterText("931030");
        taxTableDetailsPage.getCell(NINTH_ROW, "FromAmt").enterText("5000000");
        nj = taxTableDetailsPage.saveButton.clickToNavigate();
        taxTableDetailsPage = nj.getSitTableSetupLink("Annually","Rate D").clickToNavigate();
        taxTableDetailsPage.addRow();
        taxTableDetailsPage.addRow();
        taxTableDetailsPage.addRow();
        taxTableDetailsPage.getCell(SECOND_ROW, "FromPct").enterText("2.7");
        taxTableDetailsPage.getCell(THIRD_ROW, "FromAmt").enterText("40000");
        taxTableDetailsPage.getCell(THIRD_ROW, "FromPct").enterText("3.4");
        taxTableDetailsPage.getCell(THIRD_ROW, "FixedConstant").enterText("840");
        taxTableDetailsPage.getCell(FOURTH_ROW, "FromAmt").enterText("50000");
        taxTableDetailsPage.getCell(FOURTH_ROW, "FromPct").enterText("4.3");
        taxTableDetailsPage.getCell(FOURTH_ROW, "FixedConstant").enterText("1180");
        taxTableDetailsPage.getCell(FIFTH_ROW, "FromAmt").enterText("60000");
        taxTableDetailsPage.getCell(FIFTH_ROW, "FromPct").enterText("5.6");
        taxTableDetailsPage.getCell(FIFTH_ROW, "FixedConstant").enterText("1610");
        taxTableDetailsPage.getCell(SIXTH_ROW, "FromAmt").enterText("150000");
        taxTableDetailsPage.getCell(SIXTH_ROW, "FromPct").enterText("6.5");
        taxTableDetailsPage.getCell(SIXTH_ROW, "FixedConstant").enterText("6650");
        taxTableDetailsPage.getCell(SEVENTH_ROW, "FromAmt").enterText("500000");
        taxTableDetailsPage.getCell(SEVENTH_ROW, "FromPct").enterText("9.9");
        taxTableDetailsPage.getCell(SEVENTH_ROW, "FixedConstant").enterText("29400");
        taxTableDetailsPage.getCell(EIGHTH_ROW, "FromAmt").enterText("1000000");
        taxTableDetailsPage.getCell(EIGHTH_ROW, "FromPct").enterText("21.3");
        taxTableDetailsPage.getCell(EIGHTH_ROW, "FixedConstant").enterText("78900");
        taxTableDetailsPage.getCell(NINTH_ROW, "FromAmt").enterText("5000000");
        taxTableDetailsPage.getCell(NINTH_ROW, "FromPct").enterText("11.8");
        taxTableDetailsPage.getCell(NINTH_ROW, "FixedConstant").enterText("930900");
        nj = taxTableDetailsPage.saveButton.clickToNavigate();
        taxTableDetailsPage = nj.getSitTableSetupLink("Annually","Rate E").clickToNavigate();
        taxTableDetailsPage.getCell(SIXTH_ROW, "FixedConstant").enterText("79870");
        taxTableDetailsPage.addRow();
        taxTableDetailsPage.getCell(SEVENTH_ROW, "FromPct").enterText("11.80");
        taxTableDetailsPage.getCell(SEVENTH_ROW, "FixedConstant").enterText("931870");
        taxTableDetailsPage.getCell(SEVENTH_ROW, "FromAmt").enterText("500000");
        nj = taxTableDetailsPage.saveButton.clickToNavigate();
        nj.saveButton.clickToNavigate();
    }


    @Test
    public void oklahoma() {
        StateTaxCodeDetailsPage_Workflow ok = editState("OK");
        ok.sitTransitSection_RequiresRounding_Checkbox.check();
        ok.suiSdiFmlaSection_401kIsPreTaxCheckBox.uncheck();
        ok.saveButton.clickToNavigate();
    }

    @Test
    public void rhodeIsland() {
        StateTaxCodeDetailsPage_Workflow ri = editState("RI");
        TaxTableDetailPage_Workflow taxTableDetailsPage = ri.getSitTableSetupLink("Annually", "Single").clickToNavigate();
        taxTableDetailsPage.getCell(SECOND_ROW, "FromAmt").enterText("66200.00");
        taxTableDetailsPage.getCell(THIRD_ROW, "FromAmt").enterText("145600");
        taxTableDetailsPage.getCell(SECOND_ROW, "FixedConstant").enterText("2482.50");
        taxTableDetailsPage.getCell(THIRD_ROW, "FixedConstant").enterText("6489.13");
        ri = taxTableDetailsPage.saveButton.clickToNavigate();
        taxTableDetailsPage = ri.getSitTableSetupLink("Annually", "Married").clickToNavigate();
        taxTableDetailsPage.getCell(SECOND_ROW, "FromAmt").enterText("66200.00");
        taxTableDetailsPage.getCell(THIRD_ROW, "FromAmt").enterText("150550");
        taxTableDetailsPage.getCell(SECOND_ROW, "FixedConstant").enterText("2482.50");
        taxTableDetailsPage.getCell(THIRD_ROW, "FixedConstant").enterText("6489.13");
        ri = taxTableDetailsPage.saveButton.clickToNavigate();
        ri.saveButton.clickToNavigate();
    }

    @Test
    public void southCarolina() {
        StateTaxCodeDetailsPage_Workflow sc = editState("SC");
        TaxTableDetailPage_Workflow taxTableDetailsPage = sc.getSitTableSetupLink("Annually", "Single").clickToNavigate();
        taxTableDetailsPage.exemptionAmount.enterText("2670");
        taxTableDetailsPage.currentTaxTable_AllowanceMax.enterText("4200.00");
        taxTableDetailsPage.getCell(SECOND_ROW, "FromAmt").enterText("2800.00");
        taxTableDetailsPage.getCell(THIRD_ROW, "FromAmt").enterText("5610.00");
        taxTableDetailsPage.getCell(FOURTH_ROW, "FromAmt").enterText("8410.00");
        taxTableDetailsPage.getCell(FIFTH_ROW, "FromAmt").enterText("11220.00");
        taxTableDetailsPage.getCell(SIXTH_ROW, "FromAmt").enterText("14030.00");
        taxTableDetailsPage.getCell(FIRST_ROW, "FromPct").enterText(".5");
        taxTableDetailsPage.getCell(SECOND_ROW, "FixedConstant").enterText("14");
        taxTableDetailsPage.getCell(THIRD_ROW, "FixedConstant").enterText("98.30");
        taxTableDetailsPage.getCell(FOURTH_ROW, "FixedConstant").enterText("210.30");
        taxTableDetailsPage.getCell(FIFTH_ROW, "FixedConstant").enterText("350.80");
        taxTableDetailsPage.getCell(SIXTH_ROW, "FixedConstant").enterText("519.40");
        sc = taxTableDetailsPage.saveButton.clickToNavigate();
        taxTableDetailsPage = sc.getSitTableSetupLink("Annually", "Married").clickToNavigate();
        taxTableDetailsPage.exemptionAmount.enterText("2670.00");
        taxTableDetailsPage.currentTaxTable_AllowanceMax.enterText("2670.00");
        taxTableDetailsPage.getCell(SECOND_ROW, "FromAmt").enterText("2800.00");
        taxTableDetailsPage.getCell(THIRD_ROW, "FromAmt").enterText("5610.00");
        taxTableDetailsPage.getCell(FOURTH_ROW, "FromAmt").enterText("8410.00");
        taxTableDetailsPage.getCell(FIFTH_ROW, "FromAmt").enterText("11220.00");
        taxTableDetailsPage.getCell(SIXTH_ROW, "FromAmt").enterText("14030.00");
        taxTableDetailsPage.getCell(FIRST_ROW, "FromPct").enterText(".5");
        taxTableDetailsPage.getCell(SECOND_ROW, "FixedConstant").enterText("14");
        taxTableDetailsPage.getCell(THIRD_ROW, "FixedConstant").enterText("98.30");
        taxTableDetailsPage.getCell(FOURTH_ROW, "FixedConstant").enterText("210.30");
        taxTableDetailsPage.getCell(FIFTH_ROW, "FixedConstant").enterText("350.80");
        taxTableDetailsPage.getCell(SIXTH_ROW, "FixedConstant").enterText("519.40");
        sc = taxTableDetailsPage.saveButton.clickToNavigate();
        sc.saveButton.clickToNavigate();
    }

    @Test
    public void vermont() {
        StateTaxCodeDetailsPage_Workflow vt = editState("VT");
        TaxTableDetailPage_Workflow taxTableDetailsPage = vt.getSitTableSetupLink("Annually", "Single").clickToNavigate();
        taxTableDetailsPage.exemptionAmount.enterText("4400");
        taxTableDetailsPage.getCell(SECOND_ROW, "FromAmt").enterText("3175.00");
        taxTableDetailsPage.getCell(THIRD_ROW, "FromAmt").enterText("44125");
        taxTableDetailsPage.getCell(FOURTH_ROW, "FromAmt").enterText("102375.00");
        taxTableDetailsPage.getCell(FIFTH_ROW, "FromAmt").enterText("210125");
        taxTableDetailsPage.getCell(THIRD_ROW, "FixedConstant").enterText("1371.83");
        taxTableDetailsPage.getCell(FOURTH_ROW, "FixedConstant").enterText("5216.33");
        taxTableDetailsPage.getCell(FIFTH_ROW, "FixedConstant").enterText("13405.33");
        vt = taxTableDetailsPage.saveButton.clickToNavigate();
        taxTableDetailsPage = vt.getSitTableSetupLink("Annually", "Married").clickToNavigate();
        taxTableDetailsPage.exemptionAmount.enterText("4400");
        taxTableDetailsPage.getCell(SECOND_ROW, "FromAmt").enterText("9525.00");
        taxTableDetailsPage.getCell(THIRD_ROW, "FromAmt").enterText("77925");
        taxTableDetailsPage.getCell(FOURTH_ROW, "FromAmt").enterText("174875");
        taxTableDetailsPage.getCell(FIFTH_ROW, "FromAmt").enterText("15271.70");
        taxTableDetailsPage.getCell(THIRD_ROW, "FixedConstant").enterText("2291.40");
        taxTableDetailsPage.getCell(FOURTH_ROW, "FixedConstant").enterText("8690.10");
        taxTableDetailsPage.getCell(FIFTH_ROW, "FixedConstant").enterText("15271.70");
        vt = taxTableDetailsPage.saveButton.clickToNavigate();
        vt.saveButton.clickToNavigate();
    }

    @Test
    public void virginia() {
        StateTaxCodeDetailsPage_Workflow va = editState("VA");
        TaxTableDetailPage_Workflow taxTableDetailsPage = va.getSitTableSetupLink("Annually", "Single").clickToNavigate();
        taxTableDetailsPage.currentTaxTable_AllowanceMin.enterText("4500.00");
        taxTableDetailsPage.currentTaxTable_AllowanceMax.enterText("4500.00");
        va = taxTableDetailsPage.saveButton.clickToNavigate();
        taxTableDetailsPage = va.getSitTableSetupLink("Annually", "Married").clickToNavigate();
        taxTableDetailsPage.currentTaxTable_AllowanceMin.enterText("4500.00");
        taxTableDetailsPage.currentTaxTable_AllowanceMax.enterText("4500.00");
        va = taxTableDetailsPage.saveButton.clickToNavigate();
        va.saveButton.clickToNavigate();
    }

    @Test
    public void westVirginia() {
        StateTaxCodeDetailsPage_Workflow wv = editState("WV");
        wv.sitTransitSection_DependentCarePretax_CheckBox.check();
        wv.saveButton.clickToNavigate();
    }

    @Test
    public void wyoming() {
        StateTaxCodeDetailsPage_Workflow wy = editState("WY");
        wy.suiSdiFmlaSection_401kIsPreTaxCheckBox.uncheck();
        wy.suiSdiFmlaSection_S125IsPreTaxCheckBox.check();
        wy.saveButton.clickToNavigate();
    }
}
