package payroll.framework;

import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import org.apache.commons.lang3.ArrayUtils;
import payroll.api.template.*;

import java.util.ArrayList;
import java.util.List;

public class TemplateParser {

    public static TemplateUpdated parseTemplate(ReadableFile fileToParse) {

        if (fileToParse.getFileName().endsWith("txt")) {
            return getTemplateByTxtFile(fileToParse);
        } else {
            return getTemplateByJsonFile(fileToParse);
        }
    }

    private static TemplateUpdated getTemplateByJsonFile(ReadableFile fileToParse) {
        return fileToParse.readJsonAs(TemplateUpdated.class);
    }

    private static TemplateUpdated getTemplateByTxtFile(ReadableFile fileToParse) {
        TemplateUpdated template = new TemplateUpdated();
        List<Step> templateSteps = new ArrayList<>();
        List<String> fileOutput = fileToParse.readAllLines();
        List<StepField> fields = new ArrayList<>();

        List<Dependent> dependents = new ArrayList<>();
        List<EmergencyContact> emergencyContacts = new ArrayList<>();

        Step latestStep = new Step();
        String[] lineHeaders = fileOutput.get(0).split("\\|");
        for (int i = 1; i < fileOutput.size(); i++) {
            if (fileOutput.get(i).contains("{Page")) {

                if (templateSteps.size() > 0) {
                    latestStep.fields = fields.toArray(new StepField[0]);
                }

                latestStep = new Step();
                fields = new ArrayList<>();
                templateSteps.add(latestStep);
                String name = fileOutput.get(i).split("=")[1];
                name = name.replace("}", "").trim();
                latestStep.name = name;
            } else {
                StepField newField = new StepField();

                String[] lineValues = fileOutput.get(i).split("\\|", -1);
                newField.label = lineValues[ArrayUtils.indexOf(lineHeaders, "label")];
                newField.value = lineValues[ArrayUtils.indexOf(lineHeaders, "value")];
                newField.type = lineValues[ArrayUtils.indexOf(lineHeaders, "type")];
                //handle dependents
                if (newField.type.equals("dependent")) {
                    String[] subFields = fileOutput.get(i).split("\\|", -1);
                    dependents.add(getDependent(subFields[ArrayUtils.indexOf(lineHeaders, "value")]));
                    if (fileOutput.get(i + 1).contains("{Page")) {
                        newField.value = "";
                        newField.dependents = dependents.toArray(new Dependent[0]);
                        fields.add(newField);
                    }
                //handle emergency contacts
                } else if (newField.type.equals("emergencyContact")) {
                    String[] subFields = fileOutput.get(i).split("\\|", -1);
                    emergencyContacts.add(getEmergencyContact(subFields[ArrayUtils.indexOf(lineHeaders, "value")]));
                    if (fileOutput.get(i + 1).contains("{Page")) {
                        newField.value = "";
                        newField.emergencyContacts = emergencyContacts.toArray(new EmergencyContact[0]);
                        fields.add(newField);
                    }

                } else {
                    fields.add(newField);
                }
                if (i == fileOutput.size() - 1) {
                    latestStep.fields = fields.toArray(new StepField[0]);
                }
            }
        }
        template.steps = templateSteps.toArray(new Step[0]);
        return template;
    }

    private static EmergencyContact getEmergencyContact(String valueToParse) {
        EmergencyContact emergencyContact = new EmergencyContact();
        String[] lineValues = valueToParse.split("\\;", -1);
        emergencyContact.setContactName(getValue("contactName", lineValues));
        emergencyContact.setPhone(getValue("phone", lineValues));
        emergencyContact.setWorkPhone(getValue("workPhone", lineValues));
        emergencyContact.setCellPhone(getValue("cellPhone", lineValues));
        emergencyContact.setEmail(getValue("email", lineValues));
        emergencyContact.setPriority(Integer.parseInt(getValue("priority", lineValues)));
        emergencyContact.setNotes(getValue("notes", lineValues));

        return emergencyContact;
    }

    private static Dependent getDependent(String valueToParse) {
        Dependent dependent = new Dependent();
        String[] lineValues = valueToParse.split("\\;", -1);
        dependent.firstName = getValue("firstName", lineValues);
        dependent.middleName = getValue("middleName", lineValues);
        dependent.lastName = getValue("lastName", lineValues);
        dependent.birthDate = getValue("birthDate", lineValues);
        dependent.ssn = getValue("ssn", lineValues);
        dependent.suffix = getValue("suffix", lineValues);

        return dependent;
    }

    private static String getValue(String key, String[] lineValues) {
        for (String keyValueCombo : lineValues) {
            String[] keyValue = keyValueCombo.split("\\=");
            if (keyValue.length == 2 && keyValue[0].equals(key)) {
                return keyValue[1];
            }
        }
        return null;
    }
}
