package payroll.framework;

import common.ResourceFile;
import org.openqa.selenium.WebDriver;
import payroll.api.template.TemplateUpdated;
import payroll.pages.onboarding.GenericField_Page;
import payroll.pages.onboarding.ReviewInformation_Page;
import utils2.page_components.*;

public class GenericPageDriver {

    private WebDriver driver;

    public ReviewInformation_Page fillInFields(ResourceFile file) {

        TemplateUpdated template = TemplateParser.parseTemplate(file);
        GenericField_Page genericFieldPage = new GenericField_Page(driver);
        for (int i = 0; i < template.steps.length; i++) {
            genericFieldPage.fillInFields(template.steps[i]);
            if (i < template.steps.length - 1) {
                String textToWaitFor = template.steps[i + 1].fields[0].label;
                if (template.steps[i + 1].fields[0].type.equals("photo") || textToWaitFor.equals("")) {
                    textToWaitFor = template.steps[i + 1].name;
                }

                //If we came from a signature page and the next page already present skip clicking next.
                if(!(i >0 && template.steps[i].fields[0].type.equals("signature") && genericFieldPage.getGenericElement(textToWaitFor).exists() && genericFieldPage.getGenericElement(textToWaitFor).isDisplayed())) {
                    genericFieldPage.clickNext_GetPastUseInvalidAddress_IfVisible(textToWaitFor);
                }
            }
            else {
                ReviewInformation_Page reviewInformationPage = new ReviewInformation_Page(driver);
                if(!reviewInformationPage.processCompleteBanner.exists()) {
                    genericFieldPage.nextButton.click();
                }
            }
        }

        ReviewInformation_Page reviewInformationPage = BasePageObject.createAndLoad(ReviewInformation_Page::new, driver);

        return reviewInformationPage;
    }

    public TemplateUpdated fillInFields_ViaAPI(String user) {
        //Need to add logic to call API and get template fields to drive the tests.

        return new TemplateUpdated();
    }

    public void validateData(TemplateUpdated initialUserData, String userWeFilledIn) {
        //Would add validations to loop through the fields of our template user and compare to the user we just Onboarded.
    }

    public GenericPageDriver(WebDriver driver) {
        this.driver = driver;
    }
}
