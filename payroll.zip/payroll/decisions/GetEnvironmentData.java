package payroll.decisions;

import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import common.ResourceFile;

public class GetEnvironmentData {

    private static final ReadableFile ENVIRONMENT_DATA =  new ResourceFile("payroll/data/decisions/environmentConfig.json");

    private static Environments getEnvironments() {
        return ENVIRONMENT_DATA.readJsonAs(Environments.class);
    }

    public static Environment getCurrentEnvironment() {
        return getEnvironments().getCurrentEnvironment();
    }





}
