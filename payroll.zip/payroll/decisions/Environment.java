package payroll.decisions;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import payroll.api.DeluxeUnifiedOnboarding.Account;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Environment {

    private String name;

    private String DO_Base_URL;

    private String DO_AccountRegistration_URL;

    private String DO_UserInvitation_URL;

    private String DO_ResetPassword_URL;

    private String DO_ForgotPassword_URL;

    private String DO_Login_URL;

    private String DO_AccountHome_URL;

    private String DO_Packages_URL;

    private String DO_ExpandedFeatures_URL;

    private String DO_BusinessInformation_URL;

    private String DO_CompanyAddresses_URL;

    private String DO_FederalTaxInfo_URL;

    private String DO_AuthorizationForms_URL;

    private String DO_StateTaxInfo_URL;

    private String DO_CompanyBankAccounts_URL;

    private String DO_Summary_URL;

    private String DO_UserAgreement_URL;

    private String DO_Success_URL;

    private String DO_IdentityServer_URL;

    private String email;

    private String tokenURL;

    private String tokenRequestURL;

    private String herokuLoginURL;

    private String redirectURL;

    private String checkURL;

    private String swaggerPOSTURL;

    public void addTokenToResetPasswordURL(String token){
        DO_ResetPassword_URL += token;
    }
    public void addTokenToRegistrationURL(String token){
        DO_AccountRegistration_URL += token;
    }
    public void addTokenToEmailVerificationURL(Account account){
        DO_Base_URL += "email-verification/" + account.getEmailAddress() + "/" + account.getVerificationToken();
    }

    public void addTokenToEmailVerificationURL(Account account, String badToken){
        DO_Base_URL += "email-verification/" + account.getEmailAddress() + "/" + badToken;
    }
    public void addTokenToUserInvitationURL(String token){
        DO_UserInvitation_URL += token;
    }

    /*private String doSPABaseURL;

    @JsonProperty("companyBankAccountURL_Heroku")
    private String companyBankAccountURL_Heroku;

    @JsonProperty("federalTaxInfoURL_Heroku")
    private String federalTaxInfoURL_Heroku;

    @JsonProperty("onboardingAuthorizationFormsURL")
    private String onboardingAuthorizationFormsURL;

    @JsonProperty("onboardingStateTaxesURL")
    private String onboardingStateTaxesURL;

    @JsonProperty("onboardingBankAccountsURL")
    private String onboardingBankAccountsURL;

    @JsonProperty("onboardingSummaryURL")
    private String onboardingSummaryURL;

    @JsonProperty("onboardingSuccessURL")
    private String onboardingSuccessURL;

    @JsonProperty("herokuLoginURL")
    private String herokuLoginURL;

    @JsonProperty("onboardingStartURL")
    private String onboardingStartURL;

    @JsonProperty("companyAddressURL")
    private String companyAddressURL;

    @JsonProperty("companyIdURL_Heroku")
    private String companyIdURL_Heroku;

    @JsonProperty("companyResetPasswordURL")
    private String companyResetPasswordURL;

    @JsonProperty("accountRegistrationURL_Heroku")
    private String accountRegistrationURL_Heroku;

    @JsonProperty("accountHomeURL")
    private String accountHomeURL;

    @JsonProperty("forgotPassword")
    private String forgotPassword;

    @JsonProperty("name")
    private String name;

    @JsonProperty("email")
    private String email;

    @JsonProperty("identity_server")
    private String identityServer;

    @JsonProperty("digitalOnboardingLoginURL")
    private String digitalOnboardingLoginURL;

    @JsonProperty("userAgreementURL")
    private String userAgreementURL;

    @JsonProperty("packageSelectionURL_Heroku")
    private String packageSelectionURL_Heroku;

    @JsonProperty("onboardinPricingAddonURL")
    private String onboardinPricingAddonURL;

    @JsonProperty("herokuRegisterURL")
    private String herokuRegisterURL;

    @JsonProperty("tokenRequestURL")
    private String tokenRequestURL;

    @JsonProperty("swaggerPOSTURL")
    private String swaggerPOSTURL;

    @JsonProperty("tokenURL")
    private String tokenURL;

    @JsonProperty("redirectURL")
    private String redirectURL;

    @JsonProperty("checkURL")
    private String checkURL;

    @JsonProperty("userInvitationLink")
    private String userInvitationLink;

    public void addTokenToPasswordURL(String token){
        companyResetPasswordURL+=token;
    }*/
}
