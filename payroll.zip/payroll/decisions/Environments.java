package payroll.decisions;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import utils2.ModelUtils;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Environments {

    @JsonProperty("currentEnvironment")
    private String currentEnvironment;

    @JsonProperty("environments")
    private Environment[] environments;

    public Environment getCurrentEnvironment(){
        Optional<Environment> environment1 = Arrays.stream(environments).filter(environment -> environment.getName().equals(currentEnvironment)).findFirst();

        return environment1.get();
    }

}

