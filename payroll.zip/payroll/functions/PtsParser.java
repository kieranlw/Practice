package payroll.functions;

import common.ReadableFile;

import java.math.BigDecimal;
import java.util.Map;

public final class PtsParser extends BasePtsRtsParser {
    private PtsParser() {
    }

    public static Map<String, BigDecimal> parse(ReadableFile file) {
        return new PtsParser().execute(file);
    }

    @Override
    protected void processRow() {
        if (getRecordType().equals("500")) {
            final String taxCode = getField(16, 35);
            addValue(67, 80, taxCode, "Tax");
            addValue(81, 94, taxCode, "TaxableWages");
        }
    }
}
