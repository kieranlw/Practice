package payroll.functions;

import common.*;
import utils2.PDF_Extractor;
import utils2.TableData2;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * <p>
 * Parses a PDF of the Payroll Summary report.
 * Returns a Map&lt;String, BigDecimal&gt; with "TableHeader/ColumnHeader/RowHeader" keys.
 * </p><p>
 * For example, if one of the tables in the report is:
 * </p><pre>
 * Unemployment     Rate        Taxable
 *    FUTA         0.60%    $100,000.00
 * </pre>
 * <p>
 * then the returned Map would have "Unemployment/FUTA/Rate" = 0.60, and
 * "Unemployment/FUTA/Taxable" = 100,000.00.
 * </p>
 */
public final class PayrollSummaryParser {
    public static Map<String, BigDecimal> parse(ReadableFile file) {
        // Use a LinkedHashMap to preserve insertion order, for convenience in testing/debugging
        final Map<String, BigDecimal> results = new LinkedHashMap<>();

        final PdfContent content = PDF_Extractor.loadPdfContent(file);
        content.fixRowAlignment(1.0);
        content.trimPageHeaders("Payroll Summary");
        content.trimPageFooters("Payroll by Deluxe Payroll");

        fixTotalCashRequirementHeader(content);

        addValues(content, results, "Federal 941", "Cash Req", "Total 941");
        addValues(content, results, "Unemployment", "Cash Req", "Total Unemployment");
        addValues(content, results, "State", "Cash Req", "Total State");

        return results;
    }

    private static void fixTotalCashRequirementHeader(PdfContent content) {
        // The "Total Cash Requirement" section is a bit of a mess. It looks like this:
        //
        // Total Cash Requirement  (excludes invoices)                                 Amount  Notes
        //   Deluxe Payroll will collect and pay (electronic debits included below)  9,999.99
        //   - Tax Collection                               1,111.11
        //   Physical Checks                                                         9,999.99
        //
        // "(excludes invoices)" is a separate text block, so by default we would parse it as another
        // column header - for that middle column with the tax amount in it. Not what we want.
        //
        // We can clean this up by removing that extra header. This causes the tax amount to go
        // into the "Amount" column, which is actually pretty reasonable.

        final PdfRow totalCashRequirementRow = content
                .rowWithText(new String[]{"Total Cash Requirement", "Amount"}, null);

        // Remove the "(excludes invoices)" cell, if present.
        final Optional<PdfCell> excludesInvoicesCell = totalCashRequirementRow.getOptionalCellByText(" (excludes invoices)");
        excludesInvoicesCell.ifPresent(cell -> totalCashRequirementRow.getCells().remove(cell));
    }

    private static void addValues(PdfContent content, Map<String, BigDecimal> results,
                                  String topLeftCellLabel, String topRightCellLabel,
                                  String bottomLeftCellLabel) {
        // Skip all the total rows for now. We can change this if/when we need to.
        final TableData2 tableData = content.getTable(topLeftCellLabel, topRightCellLabel,
                bottomLeftCellLabel, Endpoint.EXCLUDE);

        tableData.forEachRow(row -> {
            final String rowHeader = row.getOptional(topLeftCellLabel).orElse("");
            row.getMap().forEach((columnHeader, stringValue) -> {
                // Skip the row header - it's not a decimal value
                if (columnHeader.equals(topLeftCellLabel)) {
                    return;
                }

                final String cleanValue = stringValue
                        .replace(",", "")
                        .replace("%", "");
                final String outputKey = topLeftCellLabel.trim() + "/" + rowHeader.trim() + "/" + columnHeader.trim();
                try {
                    final BigDecimal decimalValue = new BigDecimal(cleanValue);
                    results.put(outputKey, decimalValue);
                } catch (NumberFormatException e) {
                    throw new RuntimeException(outputKey + ": Could not parse value '" + cleanValue + "': " + e.getMessage(), e);
                }
            });
        });
    }
}
