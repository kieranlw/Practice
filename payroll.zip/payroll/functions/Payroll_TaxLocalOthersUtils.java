package payroll.functions;

import org.openqa.selenium.WebDriver;
import payroll.classObjects.CompanyTaxesInfo;
import payroll.pages.payroll.dashboard.DashboardPage_Payroll;
import payroll.pages.payroll.companyProfile.CompanyTaxesPage_Payroll;

public class Payroll_TaxLocalOthersUtils {
    private WebDriver driver;

    public Payroll_TaxLocalOthersUtils(WebDriver driver) {
        this.driver = driver;
    }

    public void deleteLocalTaxes(CompanyTaxesInfo... companyTaxesInfos) throws Exception {
        DashboardPage_Payroll dashboardPage = new DashboardPage_Payroll(driver);
        CompanyTaxesPage_Payroll companyTaxesPage = dashboardPage.companyProfileTabLink.clickToNavigate()
                .stateLink.clickToNavigate()
                .taxesLocalOtherLink.clickToNavigate();
        if(companyTaxesPage.companyTaxesTable.firstCell.getText().equals("There is no data available.")){
            return;
        }
        for (CompanyTaxesInfo companyTaxInfo : companyTaxesInfos) {
            companyTaxesPage.companyTaxesTable.deleteEntry(companyTaxInfo.getTaxCode());
        }
    }
}
