package payroll.functions;

import org.openqa.selenium.WebDriver;
import payroll.classObjects.NewStateInfo;
import payroll.pages.payroll.companyProfile.CompanyStatePage_Payroll;
import payroll.pages.payroll.companyProfile.CompanyTaxesPage_Payroll;

public class Payroll_StateUtils {
    private WebDriver driver;

    public Payroll_StateUtils(WebDriver driver) {
        this.driver = driver;
    }

    public CompanyStatePage_Payroll addState(NewStateInfo newStateInfo) {
        CompanyTaxesPage_Payroll companyTaxesPage = new CompanyTaxesPage_Payroll(driver);
        return companyTaxesPage.companyProfileTabLink.clickToNavigate()
                .stateLink.clickToNavigate()
                .addNewButton.clickToNavigate()
                .selectFields(newStateInfo);
    }

}
