package payroll.functions;

import common.networkFileUtils.ServerFilePath;
import org.apache.commons.io.FileUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import payroll.classObjects.RTSInfo;
import payroll.data.BaseTest;
import payroll.data.Payroll_Logins;
import payroll.data.SessionVariables;
import payroll.pages.workflow.LoginPage_Workflow;
import payroll.pages.workflow.TaxPage_Workflow;
import utils2.DriverSetup;
import utils2.classGroup.GroupBy;
import utils2.page_components.*;

import java.io.File;
import java.nio.file.Files;
import java.util.List;

@GroupBy(groups = {"critical_Tests", "all_Tests", "RTS_Tests"})
public class RTS_Scraper extends BaseTest {

    private static RTSInfo rtsInfo = RTSInfo.builder()
            .setDatabases("FULLRTS")
            .setQuarter(1)
            .setYear("2020")
            .setForceExport(true)
            .build();
    private ServerFilePath filePath_RTS;
    private List<String> rtsFileLinesList;

    private TaxPage_Workflow taxPage;
    private ServerFilePath rtsFile;
    private File outputPath = new File("C:\\DAF\\RTSOutput\\");
    private File finalFile;


    @BeforeClass(alwaysRun = true)
    protected void secondarySetup() throws Exception {
        filePath_RTS = new ServerFilePath(SessionVariables.getEnvironment().rtsLocation);

        driver = new DriverSetup(defaultDriverInfo).startDriver(url_Workflow);
        LoginPage_Workflow loginPage = BasePageObject.createAndLoad(LoginPage_Workflow::new, driver);
        taxPage = loginPage.login(Payroll_Logins.WORKFLOW_DEFAULT.getLoginInfo())
                .taxLink.clickToNavigate()
                .rtsExportLink.clickToNavigate()
                .exportAndWaitForFile(rtsInfo, filePath_RTS, networkFileUtils);

        rtsFile = networkFileUtils.getLatestFile(filePath_RTS);
        finalFile = new File(defaultDriverInfo.getDownloadLocation() + "\\" + rtsFile.getFile());
        networkFileUtils.copyRemoteFileToLocalLocation(rtsFile, finalFile);
        rtsFileLinesList = Files.readAllLines(finalFile.toPath());

    }

    @DataProvider(name = "testData")
    protected Object[][] createData() throws Exception {

        Object[][] changeDeductionAmount = new Object[][]{
                {"AK"}, {"AL"}, {"AR"}, {"AZ"},
                {"CA"}, {"CO"}, {"CT"}, {"DC"},
                {"DE"}, {"FE"}, {"FL"},
                {"GA"}, {"HI"}, {"IA"}, {"ID"},
                {"IL"}, {"IN"}, {"KS"}, {"KY"},
                {"LA"}, {"MA"}, {"MD"}, {"ME"},
                {"MI"}, {"MN"}, {"MO"}, {"MS"},
                {"MT"}, {"NC"}, {"ND"}, {"NE"},
                {"NH"}, {"NJ"}, {"NM"}, {"NV"},
                {"NY"}, {"OH"}, {"OK"}, {"OR"},
                {"PA"}, {"PR"}, {"RI"}, {"SC"},
                {"SD"}, {"TN"}, {"TX"}, {"UT"},
                {"VA"}, {"VI"}, {"VT"}, {"WA"},
                {"WI"}, {"WV"}, {"WY"}
        };

        return changeDeductionAmount;
    }

    @Test(dataProvider = "testData")
    public void ExtractRTS(String state) throws Exception {

        StringBuffer stringBuffer = getDataMatch(state, 15, 17);
        File fullOutputFile = new File(outputPath.getAbsolutePath() + "\\" +  state + ".txt");
        FileUtils.writeByteArrayToFile(fullOutputFile, stringBuffer.toString().getBytes());
    }

    @Test
    public void Extract_EmployeeFile() throws Exception {
        StringBuffer stringBuffer = getDataMatch("600TESTRTS", 0, 10);
        File fullOutputFile = new File(outputPath.getAbsolutePath() + "\\Employees.txt");
        FileUtils.writeByteArrayToFile(fullOutputFile, stringBuffer.toString().getBytes());
    }

    private StringBuffer getDataMatch(String dataMatch, int lowerBound, int upperBound){
        StringBuffer stringBuffer = new StringBuffer();
        for(String line : rtsFileLinesList){
            String substring = line.substring(lowerBound, upperBound);
            if(substring.contains(dataMatch)){
                stringBuffer.append(line);
                stringBuffer.append(System.lineSeparator());
            }
        }

        return stringBuffer;
    }
}