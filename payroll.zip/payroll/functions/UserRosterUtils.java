package payroll.functions;

import common.DataFile;
import utils.DataBuilder;
import utils.FileOperations;
import utils2.LogInfo;
import utils2.TableData2;
import utils2.tableData.TableConverter;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.text.MessageFormat;
import java.time.Duration;

public class UserRosterUtils {


    public static TableData2 getFileData(File fileLocation) {
        TableData2 csvData = TableData2.loadCsv(new DataFile(fileLocation.getAbsolutePath()));
        csvData.format().table.removeCharacter("\"");
        return csvData;
    }

    public static void runCmdFile(File executable, File exportFileLocation) {
        String commandLine = MessageFormat.format("cmd /c {0} && exit", executable.getAbsolutePath());

        try {
            LogInfo.log_Status("Executing script " + commandLine);
            Process proc = Runtime.getRuntime().exec(commandLine);
            BufferedReader r = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String tmp;
            while ((tmp = r.readLine()) != null) {
                System.out.println("> " + tmp);
            }
            proc.waitFor();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        LogInfo.log_Status("Script done.");
    }

}
