package payroll.functions;
import common.ResourceFile;
import common.ThreadUtils;
import common.networkFileUtils.INetworkFilePath;
import common.networkFileUtils.NetworkFileUtils;
import org.testng.asserts.SoftAssert;
import utils.FileOperations;
import utils2.LogInfo;
import java.io.File;
import java.nio.file.Files;
import java.time.Duration;
import java.util.List;
public class PTS_RTS_FileComparison {

    public static void waitForFile(String filePath){
        FileOperations.wait_For_File_To_Exist(filePath);
        ThreadUtils.sleep(2000);
    }

    public static void waitForFile(INetworkFilePath filePath, NetworkFileUtils fileUtils){
        try {
            fileUtils.waitForFile(filePath, Duration.ofMinutes(1));
        }catch(Exception e){
            LogInfo.log_AndFail("Timed out waiting for file " + filePath.getFile());
        }
        ThreadUtils.sleep(2000);
    }

    public static void validatePTSFile(File newPTSFile, ResourceFile expectedPTSDataFile) throws Exception {
        String[] expectedLines = expectedPTSDataFile.readAllLines().toArray(new String[0]);
        List<String> actualLines = Files.readAllLines(newPTSFile.toPath());
        LogInfo.verify_ConditionTrue(actualLines.size() >= expectedLines.length, "Lines from generated file length of "
                + actualLines.size() + " needed to be greater than or equal to expected line count of " + expectedLines.length);
        int startingLine = actualLines.indexOf(expectedLines[0]);
        LogInfo.verify_ConditionTrue(startingLine != -1, "Checking for Starting line match.");
        SoftAssert softAssert = new SoftAssert();
        {
            for (int j = 0; j < expectedLines.length; j++) {
                boolean matchFound = false;
                for (int i = startingLine; i < (expectedLines.length + startingLine); i++) {
                    if (actualLines.get(i).equals(expectedLines[j])) {
                        matchFound = true;
                        break;
                    }
                }
                softAssert.assertTrue(matchFound, "Did NOT find row:\n" + expectedLines[j]);
            }
        }
        softAssert.assertAll();
    }
    public static void validateRTSFile(File newRTSFile, ResourceFile expectedRTSFile) throws Exception {
        String[] expectedLines = expectedRTSFile.readAllLines().toArray(new String[0]);
        List<String> actualLines = Files.readAllLines(newRTSFile.toPath());
        LogInfo.verify_ConditionTrue(actualLines.size() == expectedLines.length, "Lines from generated file length of "
                + actualLines.size() + " needed to be equal to expected line count of " + expectedLines.length);
        SoftAssert softAssert = new SoftAssert();
        //Skip line 0.
        for (int i = 1; i < expectedLines.length; i++) {
            softAssert.assertTrue(actualLines.get(i).equals(expectedLines[i]), "Did NOT find row:\n" + expectedLines[i]);
        }
        softAssert.assertAll();
    }
}