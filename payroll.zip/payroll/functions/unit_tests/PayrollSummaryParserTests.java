package payroll.functions.unit_tests;

import common.*;
import org.testng.annotations.Test;
import payroll.functions.PayrollSummaryParser;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public class PayrollSummaryParserTests {
    private static final String DIRECTORY = "payroll/functions/PayrollSummaryParser";
    private static final ReadableFile PDF_FILE = new ResourceFile(DIRECTORY + "/PayrollSummary.pdf");
    private static final ReadableFile PARSED_DATA_FILE = new ResourceFile(DIRECTORY + "/PayrollSummary.txt");

    @Test
    public void parserRegressionTest() {
        // This test is here to make sure we don't break the Payroll Summary parsing.
        // For example, if we make a change to the PDF parser and it accidentally
        // breaks our Payroll Summary parsing, this test is meant to catch it.
        // Feel free to update the "expected" file if we make an intentional change
        // to the data we parse from the report.

        final Map<String, BigDecimal> parsed = PayrollSummaryParser.parse(PDF_FILE);

        final List<String> actual = ListUtils.map(parsed.entrySet(), entry -> entry.getKey() + "=" + entry.getValue());
        final List<String> expected = PARSED_DATA_FILE.readAllLines();
        Verify.allOf(() -> {
            Verify.that(actual.size(), Is.equalTo(expected.size()), "Number of lines");
            for (int i = 0; i < Math.min(actual.size(), expected.size()); i++) {
                Verify.that(actual.get(i), Is.equalTo(expected.get(i)), "Index " + i);
            }
        });
    }
}
