package payroll.functions;

import common.RuntimeIOException;
import org.apache.commons.io.FileUtils;
import org.apache.xmlbeans.SystemProperties;
import org.testng.annotations.Test;
import utils2.JavaTimeUtils;
import utils2.LogInfo;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Properties;

public class Email {

    @Test
    public void emailReport() {
        addReport();
    }

    public static void addReport() {
        String fileName = "emailable-report.html";

        LocalDateTime localDateTime = LocalDateTime.now();
        String timeStamp = JavaTimeUtils.getLocalDateTimeString(localDateTime, "MMddyy-HHmmss");
        String newFileName = "emailable-report" + timeStamp + ".html";
        File outputFolder = new File("C:\\DAF\\Test Reports\\" + timeStamp);
        outputFolder.mkdirs();
        String originalPath = SystemProperties.getProperty("user.dir") + "\\target\\failsafe-reports\\" + fileName;
        String updatedPath = SystemProperties.getProperty("user.dir") + "\\target\\failsafe-reports\\" + newFileName;
        File source = new File(originalPath);
        File newSource = new File(updatedPath);

        source.renameTo(newSource);
        File dest = new File(System.getenv("USERPROFILE") + "\\Deluxe Corporation\\Deluxe Payroll - Share - Development\\Quality Assurance\\Test Reports\\"
                + JavaTimeUtils.getLocalDateTimeString(localDateTime, "MMddyy"));
        dest.mkdirs();

        RuntimeIOException.withRuntimeIOExceptions(() -> {
            FileUtils.copyFileToDirectory(newSource, outputFolder);
            FileUtils.copyFileToDirectory(newSource, dest);
        });

        final String username = "";
        final String password = "";

        Properties props = new Properties();
        props.put("mail.smtp.auth", false);
        props.put("mail.smtp.starttls.enable", false);
        props.put("mail.smtp.host", "deluxe-com.mail.protection.outlook.com");
        props.put("mail.smtp.port", "25");

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("natalie.demers@deluxe.com"));//from.mail.
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("natalie.demers@deluxe.com"));
            message.addRecipients(Message.RecipientType.CC, InternetAddress.parse("kieran.williams@deluxe.com"));
            message.addRecipients(Message.RecipientType.CC, InternetAddress.parse("nargiza.akbaralieva@deluxe.com"));
            message.addRecipients(Message.RecipientType.CC, InternetAddress.parse("jonathan.hansen@deluxe.com"));
            message.addRecipients(Message.RecipientType.CC, InternetAddress.parse("dominic.giallombardo@deluxe.com"));
            message.addRecipients(Message.RecipientType.CC, InternetAddress.parse("Anton.Pahomov@deluxe.com"));
            message.addRecipients(Message.RecipientType.CC, InternetAddress.parse("victor.skyba@deluxe.com"));
            message.addRecipients(Message.RecipientType.CC, InternetAddress.parse("Vasiliy.KLevchuk@deluxe.com"));
            message.addRecipients(Message.RecipientType.CC, InternetAddress.parse("keri.klug@deluxe.com"));
            message.addRecipients(Message.RecipientType.CC, InternetAddress.parse("rafael.burgos@deluxe.com"));
            message.addRecipients(Message.RecipientType.CC, InternetAddress.parse("james.adams@deluxe.com"));
            message.addRecipients(Message.RecipientType.CC, InternetAddress.parse("tarana.malik@deluxe.com"));
            message.addRecipients(Message.RecipientType.CC, InternetAddress.parse("t463556@deluxe.com"));
            message.addRecipients(Message.RecipientType.CC, InternetAddress.parse("viktor.myrian@deluxe.com"));

            message.setSubject(fileName + " " + timeStamp);
            message.setText("PFA");

            MimeBodyPart messageBodyPart = new MimeBodyPart();

            Multipart multipart = new MimeMultipart();

            String file = outputFolder + "\\" + newFileName;
            DataSource dataSource = new FileDataSource(file);
            messageBodyPart.setDataHandler(new DataHandler(dataSource));
            messageBodyPart.setFileName(newFileName);
            multipart.addBodyPart(messageBodyPart);

            message.setContent(multipart);

            LogInfo.log_Status("Sending");

            Transport.send(message);

            LogInfo.log_Status("Done");
        } catch (MessagingException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }
}
