package payroll.functions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Quotes;
import payroll.classObjects.customFields.CustomField;
import payroll.page_components.TextBox_Payroll;
import payroll.pages.payroll.page_components.Attachment;
import utils2.LogInfo;
import utils2.page_components.*;

public class CustomFieldsUtilities {

    private WebDriver driver;

    public CustomFieldsUtilities(WebDriver driver){
        this.driver = driver;
    }

    public void verifyCustomField(CustomField customField) {
        GenericComponent customComponent = getGenericComponent(customField);

        if (customField.getType().equals("Attachment")) {
            customComponent.click();
        }

        customComponent.verify()
                .displayed();

        if(customField.getRequired() != null) {
            if (customField.getRequired()) {
                customComponent.verify()
                        .attributeContains("class", "req");
            } else {
                customComponent.verify()
                        .attributeNotContains("class", "req");
            }
        }

        if (customField.getDropdownOptions() != null) {
            String[] newOptionsIncludingEmpty = new String[customField.getDropdownOptions().length + 1];
            newOptionsIncludingEmpty[0] = "";
            for (int i = 1; i <= customField.getDropdownOptions().length; i++) {
                newOptionsIncludingEmpty[i] = customField.getDropdownOptions()[i - 1];
            }

            getGenericDropdown(customField.getName()).verify()
                    .optionsMatch(newOptionsIncludingEmpty);
        }

        getGroupingComponent(customComponent).verify()
                .displayed()
                .textEquals(customField.getGrouping());
    }

    //Based on values for Custom Fields we set via Custom Fields Page
    private GenericComponent getGenericComponent(CustomField customField) {
        switch (customField.getType()) {
            case "Currency":
            case "Date Picker":
            case "Flag (1 character)":
            case "Multi-Line Text":
            case "Numeric":
            case "Percent":
            case "Text":
                return getGenericTextbox(customField.getName());
            case "Yes/No Checkbox":
                return new GenericComponent(driver, ElementInfo.createElementInfo("Checkbox for "
                                + customField.getName(),
                        By.xpath(getCheckboxXpath(customField.getName()))));
            case "Attachment":
                return new Attachment(driver, ElementInfo.createElementInfo("Attachment for "
                                + customField.getName(),
                        By.xpath(getInputXpath(customField.getName()))));
            case "Custom List":
                return new GenericComponent(driver, ElementInfo.createElementInfo("Dropdown for "
                                + customField.getName(),
                        By.xpath(getDropdownXpath(customField.getName()))));
            default:
                LogInfo.log_AndFail("Unknown type of " + customField.getType());
        }
        return null;
    }

    private String getInputXpath(String labelText) {
        return "//*[@class='std_layout stdindent']//td[text()=" + Quotes.escape(labelText)
                + "]/following-sibling::td[1]/*[local-name()='input' or local-name()='textarea']";
    }


    private String getCheckboxXpath(String labelText) {
        return "//*[@class='std_layout stdindent']//td[text()=" + Quotes.escape(labelText)
                + "]/input[@type='checkbox']";
    }

    private String getDropdownXpath(String labelText) {
        return "//*[@class='std_layout stdindent']//td[text()=" + Quotes.escape(labelText)
                + "]/following-sibling::td[1]/select";
    }

    public DropDown getGenericDropdown(String labelText) {
        ElementInfo elementInfo = ElementInfo.createElementInfo("Dropdown of " + labelText,
                By.xpath(getDropdownXpath(labelText)));

        return new DropDown(driver,
                elementInfo);
    }

    public TextBox getGenericTextbox(String labelText) {
        ElementInfo elementInfo = ElementInfo.createElementInfo("Textbox of " + labelText,
                By.xpath(getInputXpath(labelText)));

        return new TextBox_Payroll(driver,
                elementInfo);
    }

    private GenericComponent getGroupingComponent(GenericComponent childComponent) {
        String xpath = childComponent.getElementInfo().getElementXpath() + "/ancestor::table/preceding-sibling::h2";
        return new GenericComponent(driver, ElementInfo.createElementInfo("Grouping Element of "
                        + childComponent.getElementInfo().getFriendlyName(),
                By.xpath(xpath)));
    }


}
