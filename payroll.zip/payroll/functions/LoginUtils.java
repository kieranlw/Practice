package payroll.functions;

import org.openqa.selenium.WebDriver;
import payroll.classObjects.LoginInfo;
import payroll.pages.payroll.companyProfile.RestoreDatabasePage_Payroll;
import payroll.pages.payroll.dashboard.DashboardPage_Payroll;
import payroll.pages.workflow.DashboardPage_Workflow;
import payroll.pages.workflow.LoginPage_Workflow;
import utils2.page_components.*;

public class LoginUtils {

    private WebDriver driver;

    public LoginUtils(WebDriver driver) {
        this.driver = driver;
    }

    public RestoreDatabasePage_Payroll loginAndRestoreDB(LoginInfo loginInfo, String account, String restorePoint) {
        LoginPage_Workflow loginPage = BasePageObject.createAndLoad(LoginPage_Workflow::new, driver);
        loginPage.login(loginInfo);
        return accessAccountAndRestoreDB(account, restorePoint);
    }

    public DashboardPage_Payroll loginToPayrollViaWorkflow(LoginInfo loginInfo, String account) {
        LoginPage_Workflow loginPage = BasePageObject.createAndLoad(LoginPage_Workflow::new, driver);
        DashboardPage_Payroll dashboardPage = loginPage.login_AndNavigateAccountsPage(loginInfo)
                .quickSelectAccount(account)
                .loginButton.clickToNavigate();
        dashboardPage.cookieBanner.acceptCookieBannerIfExists();
        dashboardPage.dealWithMissingCompanyAddress();
        return dashboardPage;
    }

    public RestoreDatabasePage_Payroll accessAccountAndRestoreDB(String account, String restorePoint) {
        DashboardPage_Workflow dashboardPage = new DashboardPage_Workflow(driver);
        DashboardPage_Payroll dashboardPagePayroll = dashboardPage.accountsLink.clickToNavigate()
                .quickSelectAccount(account)
                .loginButton.clickToNavigate();
        dashboardPagePayroll.cookieBanner.acceptCookieBannerIfExists();
        dashboardPagePayroll.dealWithMissingCompanyAddress();

        return dashboardPagePayroll.dealWithStuckPayroll()
                .companyProfileTabLink.clickToNavigate()
                .specialLink.clickToNavigate()
                .restoreDatabaseLink.clickToNavigate()
                .restoreDatabaseByDescription(restorePoint);
    }
}
