package payroll.functions;

import org.openqa.selenium.WebDriver;
import payroll.pages.payroll.dashboard.DashboardPage_Payroll;
import payroll.pages.payroll.companyProfile.CompanyWorkLocationDetailPage_Payroll;
import payroll.pages.payroll.companyProfile.CompanyWorkLocationsPage_Payroll;

public class Payroll_WorkLocationsUtils {
    private WebDriver driver;

    public Payroll_WorkLocationsUtils(WebDriver driver) {
        this.driver = driver;
    }

    public CompanyWorkLocationsPage_Payroll addWorkLocation(String state, String workLocation) {
        DashboardPage_Payroll dashboardPage = new DashboardPage_Payroll(driver);
        CompanyWorkLocationDetailPage_Payroll workLocationDetailsPage = dashboardPage.companyProfileTabLink.clickToNavigate()
                .stateLink.clickToNavigate()
                .taxesLocalOtherLink.clickToNavigate()
                .workLocationsLink.clickToNavigate()
                .workLocationsTable.getAddNewButton().clickToNavigate();
        workLocationDetailsPage.stateDropdown.selectValue(state);
        workLocationDetailsPage.descriptionTextbox.enterText(workLocation);
        return workLocationDetailsPage.saveButton.clickToNavigate();
    }
}
