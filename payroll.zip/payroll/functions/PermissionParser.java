package payroll.functions;

import common.ResourceFile;
import common.ThreadUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import payroll.classObjects.PermissionAnnotation;
import payroll.classObjects.PermissionSet;
import payroll.data.Payroll_Logins;
import utils2.TableData2;

import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class PermissionParser {

    private File reportFile;

    public PermissionParser(ResourceFile resourceFile) {
        reportFile = new File(resourceFile.getAbsolutePath());
    }

    public TableData2 parsePermissions() throws Exception {
        FileInputStream file = new FileInputStream(reportFile);
        Workbook workbook = new XSSFWorkbook(file);

        Sheet sheet = workbook.getSheetAt(0);

        List<utils2.tableData.Row> rowList = new ArrayList<>();
        TableData2 newData = new TableData2(rowList);

        String[] userTypes = getUserTypes(sheet.getRow(2));
        for (String userType : userTypes) {
            utils2.tableData.Row newRow = utils2.tableData.Row.of("User Type", userType);
            newData.data.add(newRow);
        }

        //i represents row number
        for (int i = 3; i < sheet.getLastRowNum(); i++) {
            Row currentRow = sheet.getRow(i);
            String permissionName = currentRow.getCell(1).getStringCellValue().trim();
            String permissionDescription = currentRow.getCell(2).getStringCellValue().trim();
            if (!permissionDescription.isEmpty()) {
                //Cells
                for (int j = 3; j < userTypes.length + 3; j++) {
                    newData.data.get(j - 3).put(permissionName, String.valueOf(isPermissionSet(currentRow.getCell(j))));
                }
            }
        }

        return newData;
    }

    public List<PermissionSet> getPermissionList() throws Exception {
        TableData2 tableData = parsePermissions();
        List<PermissionSet> permissionSets = new ArrayList<>();

        for (utils2.tableData.Row dataRow : tableData.data) {
            Class<?> clazz = PermissionSet.class;
            Object newInstance = clazz.getDeclaredConstructor().newInstance();
            for (Field field : clazz.getDeclaredFields()) {
                if (field.getType().isAssignableFrom(Payroll_Logins.class)) {
                    Payroll_Logins login = Payroll_Logins.get(dataRow.get("User Type"));
                    if (login != null) {
                        field.setAccessible(true);
                        field.set(newInstance, login);
                    }
                } else if (field.getName().equals("loginSecurityType")) {
                    field.setAccessible(true);
                    field.set(newInstance, dataRow.get("User Type"));
                } else {

                    PermissionAnnotation permissionAnnotation = field.getAnnotation(PermissionAnnotation.class);
                    if (permissionAnnotation != null) {
                        field.setAccessible(true);
                        String securityName = permissionAnnotation.securityName();
                        field.set(newInstance, dataRow.get(securityName).equals("true"));
                    }
                }
            }
            permissionSets.add((PermissionSet) newInstance);
        }

        return permissionSets;
    }

    private boolean isPermissionSet(Cell cell) {
        CellType cellType = cell.getCellType();
        String value = cell.getStringCellValue();
        return value.equals("x");
    }

    private String[] getUserTypes(Row excelRow) {
        List<String> userTypeList = new ArrayList<>();

        int i = 3;
        while (i < 50) {
            String cellValue = excelRow.getCell(i).getStringCellValue();
            if (cellValue.equals("")) {
                break;
            } else {
                userTypeList.add(cellValue);
            }

            i++;
        }

        return userTypeList.toArray(new String[0]);
    }
}
