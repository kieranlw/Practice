package payroll.functions;

import common.ResourceFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import utils2.Index;
import utils2.LogInfo;
import utils2.TableData2;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

public class ExcelReportParser {

    private File reportFile;

    public ExcelReportParser(ResourceFile resourceFile) {
        reportFile = new File(resourceFile.getAbsolutePath());
    }

    public ExcelReportParser(File fileToParse) {
        reportFile = fileToParse;
    }

    public TableData2 parseReport() throws Exception {
        return parseReport(Index.zeroBased(6));
    }

    public TableData2 parseReport(Index startingRowIndex) throws Exception {
        FileInputStream file = new FileInputStream(reportFile);
        Workbook workbook = new XSSFWorkbook(file);

        Sheet sheet = workbook.getSheetAt(0);

        List<utils2.tableData.Row> rowList = new ArrayList<>();
        TableData2 newData = new TableData2(rowList);

        //start with starting row of data grid that contains headers
        //TODO: change this to be something we pass in if we find that there are reports where data
        // doesn't start on same line
        String[] headers = getRowValues(sheet.getRow(startingRowIndex.asZeroBased()));
        if (headers[0].equals("")) {
            headers[0] = "Category";
        }

        for (int i = startingRowIndex.asZeroBased() + 1; i <= sheet.getLastRowNum(); i++) {
            Row excelRow = sheet.getRow(i);
            if (excelRow != null) {
                String[] rowValues = getRowValues(excelRow);
                utils2.tableData.Row newTableRow = new utils2.tableData.Row();
                rowList.add(newTableRow);
                for (int j = 0; j < headers.length; j++) {
                    newTableRow.put(headers[j], rowValues[j]);
                }
            }
        }
        return newData;
    }

    private Row getRowByIndex(Index index) throws Exception {
        FileInputStream file = new FileInputStream(reportFile);
        Workbook workbook = new XSSFWorkbook(file);

        Sheet sheet = workbook.getSheetAt(0);
        return sheet.getRow(index.asZeroBased());
    }

    public String[] getRowValues(Index index) throws Exception {
        Row rowToExtract = getRowByIndex(index);
        return getRowValues(rowToExtract);
    }

    private String[] getRowValues(Row excelRow) {
        List<String> cellValues = new ArrayList<>();
        for (Cell cell : excelRow) {
            switch (cell.getCellType()) {
                case STRING:
                    cellValues.add(cell.getStringCellValue());
                    break;
                case NUMERIC:
                    cellValues.add(String.valueOf(cell.getNumericCellValue()));
                    break;
                case BOOLEAN:
                    cellValues.add(String.valueOf(cell.getBooleanCellValue()));
                    break;
                case FORMULA:
                    cellValues.add(cell.getCellFormula());
                    break;
                case BLANK:
                    cellValues.add("");
                    break;
                default:
                    LogInfo.log_AndFail("Unrecognized Cell Type of " + cell.getCellType().toString()
                            + ". Add parsing logic to switch case.");
            }
        }

        return cellValues.toArray(new String[0]);
    }
}
