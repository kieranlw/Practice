package payroll.functions.vertex;

import common.Directory;
import common.ReadableFile;
import common.ResourceFile;
import common.WritableFile;
import org.jetbrains.annotations.NotNull;
import payroll.classObjects.payroll.vertex.StateData;

public class FileToCompare {
    private final StateData stateData;
    private final Directory downloadDirectory;
    private final String fileName;

    public FileToCompare(payroll.classObjects.payroll.vertex.StateData stateData, String downloadDirectory, String fileName) {
        this.stateData = stateData;
        this.downloadDirectory = new Directory(downloadDirectory);
        this.fileName = fileName;
    }

    public @NotNull WritableFile downloaded() {
        return downloadDirectory.file(fileName);
    }

    public @NotNull ReadableFile expected() {
        return new ResourceFile("payroll/data/taxCalcData/Reciprocity/" +
                stateData.getStateName() + "/" + fileName);
    }
}