package payroll.functions;

import org.openqa.selenium.WebDriver;
import payroll.classObjects.LocalTaxCodesInfo;
import payroll.classObjects.LocalTaxNewInfo;
import payroll.pages.workflow.DashboardPage_Workflow;
import payroll.pages.workflow.LocalTaxCodesPage_Workflow;

public class Workflow_LocalTaxesUtils {
    private WebDriver driver;

    public Workflow_LocalTaxesUtils(WebDriver driver) {
        this.driver = driver;
    }

    public void updateLocalTaxes(LocalTaxCodesInfo localTaxSearchCriteria, String[] taxCodes, LocalTaxNewInfo[] taxInfos) {
        DashboardPage_Workflow dashboardPage = new DashboardPage_Workflow(driver);
        LocalTaxCodesPage_Workflow localTaxCodesPage = dashboardPage.specialLink.clickToNavigate()
                .taxLink.clickToNavigate()
                .localsLink.clickToNavigate()
                .searchExistingLocalCode(localTaxSearchCriteria);

        for (int i = 0; i < taxCodes.length; i++) {
            localTaxCodesPage.localTaxesTable.getTaxLocalsLinkByDescription(taxCodes[i]).clickToNavigate()
                    .addNewLocalTax(taxInfos[i])
                    .saveButton.clickToNavigate();
        }
    }
}
