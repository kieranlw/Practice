package payroll.functions;

import org.openqa.selenium.WebDriver;
import payroll.classObjects.NewEmployeeInfo;
import payroll.classObjects.NewEmployeePayInfo;
import payroll.classObjects.NewEmployeeTaxInfo;
import payroll.pages.payroll.dashboard.DashboardPage_Payroll;
import payroll.pages.payroll.employees.EmployeePayInfoListPage_Payroll;
import payroll.pages.payroll.employees.EmployeeTaxesPage_Payroll;

public class Payroll_EmployeeUtils {
    private WebDriver driver;

    public Payroll_EmployeeUtils(WebDriver driver) {
        this.driver = driver;
    }

    public EmployeePayInfoListPage_Payroll addEmployee(NewEmployeeInfo employeeInfo, NewEmployeeTaxInfo employeeTaxInfo, NewEmployeePayInfo newEmployeePayInfo) {
        return addEmployee_InfoAndTaxes(employeeInfo, employeeTaxInfo)
                .saveButton_AddEmployee.clickToNavigate()
                .fillInFields(newEmployeePayInfo)
                .saveButton.clickToNavigate();
    }

    //Don't click save yet, needed for other test
    public EmployeeTaxesPage_Payroll addEmployee_InfoAndTaxes(NewEmployeeInfo employeeInfo, NewEmployeeTaxInfo employeeTaxInfo) {
        DashboardPage_Payroll dashboardPage = new DashboardPage_Payroll(driver);
        return dashboardPage.employeesTabLink.clickToNavigate()
                .newEmployeeLink.clickToNavigate()
                .fillInNewEmployeeFields(employeeInfo)
                .clickSaveAndNavigate_EmployeeTaxesPage()
                .fillInNewEmployeeTaxInfoFields(employeeTaxInfo);
    }
}
