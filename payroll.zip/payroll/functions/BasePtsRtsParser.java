package payroll.functions;

import common.ReadableFile;
import common.RuntimeIOException;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public abstract class BasePtsRtsParser {
    // Use a LinkedHashMap to preserve insertion order, for convenience in testing/debugging
    private final Map<String, BigDecimal> results = new LinkedHashMap<>();
    private String currentLine;

    protected Map<String, BigDecimal> execute(ReadableFile file) {
        final List<String> lines;
        try {
            lines = file.readAllLines();
        } catch (RuntimeIOException e) {
            throw new RuntimeException("Error reading " + file + ": " + e.getMessage(), e);
        }

        for (String line : lines) {
            currentLine = line;
            try {
                processRow();
            } catch (RuntimeException ex) {
                // Give some context on what blew up
                throw new RuntimeException("Error: " + ex.getMessage() + "\nwhile parsing line '" + currentLine + "'", ex);
            }
        }

        return results;
    }

    protected abstract void processRow();

    protected String getRecordType() {
        return getField(1, 3);
    }

    /**
     * Reads a field out of a line from the file. Expects start and end indexes in the
     * same format they're shown in the file-format documentation, i.e., one-based indexes
     * that are inclusive on both ends, e.g. 1-3 would return the first three characters.
     *
     * @param rangeStart The starting position as specified in the file-format documentation
     * @param rangeEnd   The ending position as specified in the file-format documentation
     * @return The specified field's value
     */
    protected String getField(int rangeStart, int rangeEnd) {
        if (currentLine.length() < rangeEnd) {
            throw new RuntimeException("Line is too short to read value from positions " +
                    rangeStart + "-" + rangeEnd + ". Line = '" + currentLine + "'");
        }

        // Convert from one-based and inclusive-on-both-ends, as listed in the
        // PDF PTS-file-format documentation, to zero-based and exclusive-at-the-end.
        return currentLine.substring(rangeStart - 1, rangeEnd);
    }

    protected void addValue(int rangeStart, int rangeEnd, String rowIdentifier, String valueName) {
        final String value = getField(rangeStart, rangeEnd);
        final BigDecimal amount = parseAmount(value);
        final String key = getRecordType().trim() + "/" + rowIdentifier.trim() + "/" + valueName.trim();
        results.put(key, amount);
    }

    private BigDecimal parseAmount(String amount) {
        if (!Pattern.matches("^\\d+[-+]$", amount)) {
            throw new RuntimeException("Invalid PTS amount '" + amount +
                    "': expected one or more digits followed by '+' or '-'");
        }

        // Amount in cents
        final String cents = amount.substring(0, amount.length() - 1);
        // Trailing "+" or "-"
        final String sign = amount.substring(amount.length() - 1);

        try {
            return new BigDecimal(sign + cents).scaleByPowerOfTen(-2);
        } catch (RuntimeException ex) {
            throw new RuntimeException("Error parsing amount string '" + amount + "'");
        }
    }
}
