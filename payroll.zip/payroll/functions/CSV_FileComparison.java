package payroll.functions;

import common.DataFile;
import common.ResourceFile;
import utils.DataBuilder;
import utils2.TableData2;
import utils2.tableData.TableConverter;

import java.io.File;

public class CSV_FileComparison {

    public static void validateCSVFile(File newCSVFile, ResourceFile expectedCSVFile) {
        TableData2 newOutput =  TableData2.loadCsv(new DataFile(newCSVFile.getAbsolutePath()));
        TableData2 expectedOutput = TableData2.loadCsv(expectedCSVFile);

        newOutput.verify().tableMatches(expectedOutput);
    }

    public static void validateTwoNewCSVFiles(File newCSVFile1, File newCSVFile2) {
        TableData2 newOutputTable1 =  TableData2.loadCsv(new DataFile(newCSVFile1.getAbsolutePath()));
        TableData2 newOutputTable2 =  TableData2.loadCsv(new DataFile(newCSVFile2.getAbsolutePath()));

        newOutputTable1.verify().tableMatches(newOutputTable2);
    }

}
