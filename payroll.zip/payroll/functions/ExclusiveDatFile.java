package payroll.functions;

import payroll.classObjects.ExclusiveDATFileInfo;
import utils2.LogInfo;

import java.io.File;
import java.nio.file.Files;

public class ExclusiveDatFile {

    private File exclusiveFile;

    public ExclusiveDatFile(File datFile){
        exclusiveFile = datFile;
    }

    public void verifyExclusive(String employee, ExclusiveDATFileInfo exclusiveInfo) throws Exception {
        String[] lines = Files.readAllLines(exclusiveFile.toPath()).toArray(new String[0]);
        String line = lineMatch(lines, employee);

        verifyDeductionMatch(line, exclusiveInfo);
        verifyMatch(line, exclusiveInfo);
    }

    private void verifyMatch(String line,  ExclusiveDATFileInfo exclusiveInfo){
        String match = line.substring(218, 223);
        String expectedMatch = exclusiveInfo.get401KMatch() != null ? exclusiveInfo.get401KMatch() : "00000";
        LogInfo.verify_ConditionTrue(match.equals(expectedMatch), "Expecting Deduction Match " + expectedMatch
                + " to match " + match);
    }

    private void verifyDeductionMatch(String line,  ExclusiveDATFileInfo exclusiveInfo){
        String deduction = line.substring(196, 201);
        String expectedDeduction = exclusiveInfo.get401KDeduction() != null ? exclusiveInfo.get401KDeduction() : "00000";
        LogInfo.verify_ConditionTrue(deduction.equals(expectedDeduction), "Expecting Deduction " + expectedDeduction
                + " to match " + deduction);
    }

    private String lineMatch(String[] lines, String employee){
        for(String line : lines){
            if(line.contains(employee))
                return line;
        }

        LogInfo.log_AndFail("Could not find employee " + employee);

        return null;
    }

}
