package payroll.listeners;

import org.testng.*;
import java.util.*;

public class FixTestOrderingInComplexSuitesListener implements IMethodInterceptor {

    @Override
    public List<IMethodInstance> intercept(List<IMethodInstance> methods, ITestContext context) {

        return sortMethodsAndApplyDependsOn(methods);
    }

    private List<IMethodInstance> sortMethodsAndApplyDependsOn(List<IMethodInstance> methods) {
        Comparator<IMethodInstance> comparator = new Comparator<IMethodInstance>() {
            private int getPriority(IMethodInstance mi) {
                return mi.getMethod().getPriority();
            }

            @Override
            public int compare(IMethodInstance m1, IMethodInstance m2) {
                return getPriority(m1) - getPriority(m2);
            }
        };

        IMethodInstance[] array = methods.toArray(new IMethodInstance[methods.size()]);
        Arrays.sort(array, comparator);

        return Arrays.asList(array);
    }

}

