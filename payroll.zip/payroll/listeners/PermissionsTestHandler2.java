package payroll.listeners;

import common.ResourceFile;
import org.testng.IAlterSuiteListener;
import org.testng.annotations.Test;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlInclude;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;
import payroll.classObjects.PermissionSet;
import payroll.data.Payroll_Logins;
import payroll.data.SessionVariables;
import payroll.functions.PermissionParser;
import utils2.LogInfo;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Listener to build Permissions Harness.  I had to re-write this a second time since using Intercept was a little bit buggy. Saw phantom skip entries on tests that were excluded.
public class PermissionsTestHandler2 implements IAlterSuiteListener {

    private ResourceFile ptsFileToCompareAgainst = new ResourceFile("UserIncludeList.txt");
    private static ResourceFile permissionsXML = new ResourceFile("payroll/data/Permissions.xlsm");

    private static ThreadLocal<Payroll_Logins> login = new ThreadLocal<>();

    private static final String permissionsSuiteName = "PermissionsTests";

    @Override
    public void alter(List<XmlSuite> suites) {
        XmlSuite permissionSuite = getPermissionSuite(suites);
        if(permissionSuite != null) {
            XmlSuite newPermissionSuite = getUpdatedPermissionsSuite(permissionSuite);
            if(suites.contains(permissionSuite)) {
                suites.set(suites.indexOf(permissionSuite), newPermissionSuite);
            }else if(suites.get(0).getChildSuites().contains(permissionSuite)){
                suites.get(0).getChildSuites().set(suites.get(0).getChildSuites().indexOf(permissionSuite), newPermissionSuite);
            }
        }
    }

    private XmlSuite getPermissionSuite(List<XmlSuite> suites) {
        if (suites.get(0).getName().equals(permissionsSuiteName)) {
            return suites.get(0);
        }

        for (XmlSuite xmlSuite : suites.get(0).getChildSuites()) {
            if (xmlSuite.getName().equals(permissionsSuiteName)) {
                return xmlSuite;
            }
        }

        return null;
    }

    private XmlSuite getUpdatedPermissionsSuite(XmlSuite suite) {
        List<XmlClass> classes = suite.getTests().get(0).getClasses();
        List<String> users = new ArrayList<>();
        try {
            users = Files.readAllLines(ptsFileToCompareAgainst.toPath());
        } catch (Exception e) {
        }
        XmlSuite newXMLSuite = new XmlSuite();
        newXMLSuite.setName(suite.getName());

        PermissionParser permissionParser = new PermissionParser(permissionsXML);
        try {
            SessionVariables.setPermissionSets(permissionParser.getPermissionList());
        } catch (Exception e) {
        }

        for (String user : users) {
            LogInfo.log_Status("Seeing user " + user);
            XmlTest xmlTest = new XmlTest(newXMLSuite);
            xmlTest.setName(user);
            xmlTest.setParameters(new HashMap<String, String>() {{
                put("user", user);
            }});
            List<XmlClass> myClasses = new ArrayList<>();

            for(XmlClass xmlClass : classes) {

                XmlClass classToAdd = new XmlClass(xmlClass.getName());
                classToAdd.setXmlTest(xmlTest);
                myClasses.add(classToAdd);
                xmlTest.setXmlClasses(myClasses);
                xmlTest.setGroupByInstances(true);
                classToAdd.setIncludedMethods(getIncludeMethods(xmlClass.getSupportClass(), xmlTest.getName()));
            }
        }

        newXMLSuite.setThreadCount(suite.getThreadCount());
        newXMLSuite.setParallel(suite.getParallel());
       // newXMLSuite.setGuiceStage(suite.getGuiceStage());
        newXMLSuite.setFileName(suite.getFileName());
        newXMLSuite.setListeners(suite.getListeners());
        newXMLSuite.setParsed(suite.isParsed());
        newXMLSuite.setConfigFailurePolicy(suite.getConfigFailurePolicy());
        LogInfo.log_Status(newXMLSuite.toString());

        return newXMLSuite;
    }

    private List<XmlInclude> getIncludeMethods(Class<?> classToExtract, String userToUse) {
        List<XmlInclude> testMethodsToInclude = new ArrayList<>();

        Method[] methods = classToExtract.getMethods();
        for (Method method : methods) {
            Test testAnnotation = method.getAnnotation(Test.class);
            if (testAnnotation != null) {
                String description = testAnnotation.description();
                login.set(Payroll_Logins.valueOf(userToUse));
                PermissionSet permissionSet = login.get().getPermissionSet();

                boolean testMatches = testMatchesParameters(description, permissionSet);
                if (testMatches) {
                    testMethodsToInclude.add(new XmlInclude(method.getName()));
                }
            }
        }

        return testMethodsToInclude;
    }

    private boolean testMatchesParameters(String description, PermissionSet permissionSet) {

        boolean matchesExpectation = true;
        try {
            String[] fieldAndValues = Arrays.stream(description.split(";")).map(String::trim).toArray(String[]::new);
            Map<String, Boolean> fieldMap = new HashMap<>();
            for (String fieldAndValue : fieldAndValues) {
                fieldMap.put(fieldAndValue.split("\\=")[0].trim(), Boolean.valueOf(fieldAndValue.split("\\=")[1].trim()));
            }

            for (String key : fieldMap.keySet()) {
                Field field = PermissionSet.class.getDeclaredField(key);
                field.setAccessible(true);
                boolean fieldValue = field.getBoolean(permissionSet);
                if (fieldValue != fieldMap.get(key)) {
                    matchesExpectation = false;
                }
            }
        } catch (Exception e) {
            matchesExpectation = false;
        }
        return matchesExpectation;
    }
}
