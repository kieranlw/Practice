package payroll.classObjects;

import payroll.classObjects.benefitsDetails.AdjustmentFrequencies;
import payroll.classObjects.benefitsDetails.Types;

public class CompanyBenefitsDetails {

    private String number;
    private String description;
    private boolean isActive;
    private Types type;
    private AdjustmentFrequencies adjustmentFrequency;
    private String amount;
    private boolean isDefaultMax;
    private String defaultMaxAmount;

    public static class Builder {

        private String number;
        private String description;
        private boolean isActive;
        private Types type;
        private AdjustmentFrequencies adjustmentFrequency;
        private String amount;
        private boolean isDefaultMax;
        private String defaultMaxAmount;

        public Builder() {
        }

        Builder(String number, String description, boolean isActive, Types type, AdjustmentFrequencies adjustmentFrequency, String amount, boolean isDefaultMax, String defaultMaxAmount) {
            this.number = number;
            this.description = description;
            this.isActive = isActive;
            this.type = type;
            this.adjustmentFrequency = adjustmentFrequency;
            this.amount = amount;
            this.isDefaultMax = isDefaultMax;
            this.defaultMaxAmount = defaultMaxAmount;
        }

        public Builder number(String number) {
            this.number = number;
            return Builder.this;
        }

        public Builder description(String description) {
            this.description = description;
            return Builder.this;
        }

        public Builder isActive(boolean isActive) {
            this.isActive = isActive;
            return Builder.this;
        }

        public Builder type(Types type) {
            this.type = type;
            return Builder.this;
        }

        public Builder adjustmentFrequency(AdjustmentFrequencies adjustmentFrequency) {
            this.adjustmentFrequency = adjustmentFrequency;
            return Builder.this;
        }

        public Builder amount(String amount) {
            this.amount = amount;
            return Builder.this;
        }

        public Builder isDefaultMax(boolean isDefaultMax) {
            this.isDefaultMax = isDefaultMax;
            return Builder.this;
        }

        public Builder defaultMaxAmount(String defaultMaxAmount) {
            this.defaultMaxAmount = defaultMaxAmount;
            return Builder.this;
        }

        public CompanyBenefitsDetails build() {

            return new CompanyBenefitsDetails(this);
        }
    }

    private CompanyBenefitsDetails(Builder builder) {
        this.number = builder.number;
        this.description = builder.description;
        this.isActive = builder.isActive;
        this.type = builder.type;
        this.adjustmentFrequency = builder.adjustmentFrequency;
        this.amount = builder.amount;
        this.isDefaultMax = builder.isDefaultMax;
        this.defaultMaxAmount = builder.defaultMaxAmount;
    }

    public String getNumber() {
        return number;
    }

    public String getDescription() {
        return description;
    }

    public boolean isActive() {
        return isActive;
    }

    public Types getType() {
        return type;
    }

    public AdjustmentFrequencies getAdjustmentFrequency() {
        return adjustmentFrequency;
    }

    public String getAmount() {
        return amount;
    }

    public boolean isDefaultMax() {
        return isDefaultMax;
    }

    public String getDefaultMaxAmount() {
        return defaultMaxAmount;
    }
}
