package payroll.classObjects;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class GenericExclusiveInfo {

    private Boolean isActive;
    private Boolean isExcludeByState;
    private Boolean enableEmployeePaperChecks;
    private Boolean enableAgencyPaperChecks;

    private String notes,
            locationCode,
            policyEffectiveDate,
            policyNumber,
            policyRenewalDate,
            beginDate,
            endDate,
            policyExpirationDate,
            statesToExclude;

    private List<GenericField> genericFieldList;
}
