package payroll.classObjects;

public class EmployeeName {

    private String firstName;
    private String middleName;
    private String lastName;
    private String employeeNumber;

    public String getFirstName() {
        return firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmployeeNumber() {
        return employeeNumber;
    }

    public String getTableFormattedName(){
        return lastName + ", " + firstName;
    }

    @Override
    public String toString(){
        return firstName + " " + lastName;
    }


    private EmployeeName(Builder builder) {
        firstName = builder.firstName;
        middleName = builder.middleName;
        lastName = builder.lastName;
        employeeNumber = builder.employeeNumber;
    }

    public static EmployeeName.Builder builder(){
        return new EmployeeName.Builder();
    }


    public static class Builder {
        private String firstName;
        private String middleName;
        private String lastName;
        private String employeeNumber;

        public Builder setFirstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder setMiddleName(String middleName) {
            this.middleName = middleName;
            return this;
        }

        public Builder setLastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder setEmployeeNumber(String employeeNumber) {
            this.employeeNumber = employeeNumber;
            return this;
        }


        public Builder() {
        }

        public EmployeeName build() {
            return new EmployeeName(this);
        }

    }

}