package payroll.classObjects;

public class PaySummary_Federal941CreditSummary {

    private DollarCurrency caresRetentionCreditTaxable;
    private DollarCurrency caresRetentionErCredit;
    private DollarCurrency ffcraFamilyLeaveCreditTaxable;
    private DollarCurrency ffcraFamilyLeaveErCredit;
    private DollarCurrency ffcraChildCareCreditTaxable;
    private DollarCurrency ffcraChildCareErCredit;

    public DollarCurrency getCaresRetentionCreditTaxable() {
        return caresRetentionCreditTaxable;
    }

    public DollarCurrency getCaresRetentionErCredit() {
        return caresRetentionErCredit;
    }

    public DollarCurrency getFfcraFamilyLeaveCreditTaxable() {
        return ffcraFamilyLeaveCreditTaxable;
    }

    public DollarCurrency getFfcraFamilyLeaveErCredit() {
        return ffcraFamilyLeaveErCredit;
    }

    public DollarCurrency getFfcraChildCareCreditTaxable() {
        return ffcraChildCareCreditTaxable;
    }

    public DollarCurrency getFfcraChildCareErCredit() {
        return ffcraChildCareErCredit;
    }

    private PaySummary_Federal941CreditSummary(Builder builder) {
        caresRetentionCreditTaxable = builder.caresRetentionCreditTaxable;
        caresRetentionErCredit = builder.caresRetentionErCredit;
        ffcraFamilyLeaveCreditTaxable = builder.ffcraFamilyLeaveCreditTaxable;
        ffcraFamilyLeaveErCredit = builder.ffcraFamilyLeaveErCredit;
        ffcraChildCareCreditTaxable = builder.ffcraChildCareCreditTaxable;
        ffcraChildCareErCredit = builder.ffcraChildCareErCredit;
    }

    public PaySummary_Federal941CreditSummary getReverseFields(){
        return builder()
                .setCaresRetentionCreditTaxable(DollarCurrency.setDollarCurrency(-caresRetentionCreditTaxable.getAmount()))
                .setCaresRetentionErCredit(DollarCurrency.setDollarCurrency(-caresRetentionErCredit.getAmount()))
                .setFfcraFamilyLeaveCreditTaxable(DollarCurrency.setDollarCurrency(-ffcraFamilyLeaveCreditTaxable.getAmount()))
                .setFfcraFamilyLeaveErCredit(DollarCurrency.setDollarCurrency(-ffcraFamilyLeaveErCredit.getAmount()))
                .setFfcraChildCareCreditTaxable(DollarCurrency.setDollarCurrency(-ffcraChildCareCreditTaxable.getAmount()))
                .setFfcraChildCareErCredit(DollarCurrency.setDollarCurrency(-ffcraChildCareErCredit.getAmount()))
                .build();
    }


    public static PaySummary_Federal941CreditSummary.Builder builder() {
        return new PaySummary_Federal941CreditSummary.Builder();
    }

    public static class Builder {
        private DollarCurrency caresRetentionCreditTaxable;
        private DollarCurrency caresRetentionErCredit;
        private DollarCurrency ffcraFamilyLeaveCreditTaxable;
        private DollarCurrency ffcraFamilyLeaveErCredit;
        private DollarCurrency ffcraChildCareCreditTaxable;
        private DollarCurrency ffcraChildCareErCredit;

        public Builder setCaresRetentionCreditTaxable(DollarCurrency caresRetentionCreditTaxable) {
            this.caresRetentionCreditTaxable = caresRetentionCreditTaxable;
            return this;
        }

        public Builder setCaresRetentionErCredit(DollarCurrency caresRetentionErCredit) {
            this.caresRetentionErCredit = caresRetentionErCredit;
            return this;
        }

        public Builder setFfcraFamilyLeaveCreditTaxable(DollarCurrency ffcraFamilyLeaveCreditTaxable) {
            this.ffcraFamilyLeaveCreditTaxable = ffcraFamilyLeaveCreditTaxable;
            return this;
        }

        public Builder setFfcraFamilyLeaveErCredit(DollarCurrency ffcraFamilyLeaveErCredit) {
            this.ffcraFamilyLeaveErCredit = ffcraFamilyLeaveErCredit;
            return this;
        }

        public Builder setFfcraChildCareCreditTaxable(DollarCurrency ffcraChildCareCreditTaxable) {
            this.ffcraChildCareCreditTaxable = ffcraChildCareCreditTaxable;
            return this;
        }

        public Builder setFfcraChildCareErCredit(DollarCurrency ffcraChildCareErCredit) {
            this.ffcraChildCareErCredit = ffcraChildCareErCredit;
            return this;
        }

        private Builder() {
        }

        public PaySummary_Federal941CreditSummary build() {
            return new PaySummary_Federal941CreditSummary(this);
        }
    }
}
