package payroll.classObjects;

public class AscensusInfo {

	private String planId;
	private String formatSiteCode;
	private String deduction_401K;
	private String benefit;
	private Boolean exclude401KMatch;

	public String getPlanId() {
		return planId;
	}

	public String getFormatSiteCode() {
		return formatSiteCode;
	}

	public String getDeduction_401K() {
		return deduction_401K;
	}

	public Boolean getExclude401KMatch() {
		return exclude401KMatch;
	}

	public String getBenefit() {
		return benefit;
	}

	private AscensusInfo(Builder builder) {
		planId = builder.planId;
		formatSiteCode = builder.formatSiteCode;
		deduction_401K = builder.deduction_401K;
		exclude401KMatch = builder.exclude401KMatch;
	}

	public static AscensusInfo.Builder builder() {
		return new AscensusInfo.Builder();
	}


	public static class Builder {
		private String planId;
		private String formatSiteCode;
		private String deduction_401K;
		private Boolean exclude401KMatch;
		private String benefit;

		public Builder setPlanId(String planId) {
			this.planId = planId;
			return this;
		}

		public Builder setBenefit(String benefit) {
			this.benefit = benefit;
			return this;
		}

		public Builder setExclude401KMatch(boolean exclude401KMatch) {
			this.exclude401KMatch = exclude401KMatch;
			return this;
		}

		public Builder setFormatSiteCode(String formatSiteCode) {
			this.formatSiteCode = formatSiteCode;
			return this;
		}

		public Builder set401KDeduction(String deduction_401K) {
			this.deduction_401K = deduction_401K;
			return this;
		}


		private Builder() {
		}

		public AscensusInfo build() {
			return new AscensusInfo(this);
		}

	}
 	
}
