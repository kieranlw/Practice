package payroll.classObjects;

import payroll.data.Payroll_Logins;

public class PermissionSet {

    //
    // Payroll Processing Permissions
    //

    public String getLoginSecurityType() {
        return loginSecurityType;
    }

    private String loginSecurityType;

    @PermissionAnnotation(securityName = "Enable Payroll menu")
    private boolean hasEnablePayrollMenu;
    @PermissionAnnotation(securityName = "Change pay date")
    private boolean hasChangePayDate;
    @PermissionAnnotation(securityName = "Start payroll")
    private boolean hasStartPayroll;
    @PermissionAnnotation(securityName = "Pay employees")
    private boolean hasPayEmployees;
    @PermissionAnnotation(securityName = "Manually pay employees")
    private boolean hasManuallyPayEmployees;
    @PermissionAnnotation(securityName = "Preview payroll")
    private boolean hasPreviewPayroll;
    @PermissionAnnotation(securityName = "Submit payroll")
    private boolean hasSubmitPayroll;
    @PermissionAnnotation(securityName = "Add Pay Rows on Pay Specific")
    private boolean hasAddPayRowsOnSpecificPay;

    public boolean getHasEnablePayrollMenu() {
        return hasEnablePayrollMenu;
    }

    public boolean getHasChangePayDate() {
        return hasChangePayDate;
    }

    public boolean getHasStartPayroll() {
        return hasStartPayroll;
    }

    public boolean getHasPayEmployees() {
        return hasPayEmployees;
    }

    public boolean getHasManuallyPayEmployees() {
        return hasManuallyPayEmployees;
    }

    public boolean getHasPreviewPayroll() {
        return hasPreviewPayroll;
    }

    public boolean getHasSubmitPayroll() {
        return hasSubmitPayroll;
    }

    public boolean getHasAddPayRowsOnSpecificPay() {
        return hasAddPayRowsOnSpecificPay;
    }


//
    // End of Payroll Processing Permissions
    //

    //
    // Employee Maintenance Permissions
    //

    @PermissionAnnotation(securityName = "Enable Employees menu")
    private boolean hasEnableEmployeesMenu;

    @PermissionAnnotation(securityName = "Modify general employee info")
    private boolean hasModifyGeneralEmployeeInfo;

    @PermissionAnnotation(securityName = "View banking and confidential employee info")
    private boolean hasViewBankingAndConfidentialEmployeeInfo;

    @PermissionAnnotation(securityName = "Modify banking and confidential employee info")
    private boolean hasModifyBankingAndConfidentialEmployeeInfo;

    @PermissionAnnotation(securityName = "Show hourly rates")
    private boolean hasShowHourlyRates;

    @PermissionAnnotation(securityName = "Show/modify hourly rates")
    private boolean hasShowModifyHourlyRates;

    @PermissionAnnotation(securityName = "Show salaries")
    private boolean hasShowSalaries;

    @PermissionAnnotation(securityName = "Show/modify salaries")
    private boolean hasShowModifySalaries;

    @PermissionAnnotation(securityName = "Access employee history")
    private boolean hasAccessEmployeeHistory;

    @PermissionAnnotation(securityName = "View employee other information")
    private boolean hasViewEmployeeOtherInformation;

    @PermissionAnnotation(securityName = "Can see all employees, even if departmental permissions set")
    private boolean hasCanSeeAllEmployees;

    @PermissionAnnotation(securityName = "View birth dates")
    private boolean hasViewBirthDates;

    @PermissionAnnotation(securityName = "Perform bulk maintenance")
    private boolean hasPerformBulkMaintenance;

    @PermissionAnnotation(securityName = "Enable manual pre-note convert")
    private boolean hasEnableManualPrenoteConvert;


    public boolean getHasEnableEmployeesMenu() {
        return hasEnableEmployeesMenu;
    }

    public boolean getHasModifyGeneralEmployeeInfo() {
        return hasModifyGeneralEmployeeInfo;
    }

    public boolean getHasViewBankingAndConfidentialEmployeeInfo() {
        return hasViewBankingAndConfidentialEmployeeInfo;
    }

    public boolean getHasModifyBankingAndConfidentialEmployeeInfo() {
        return hasModifyBankingAndConfidentialEmployeeInfo;
    }

    public boolean getHasShowHourlyRates() {
        return hasShowHourlyRates;
    }

    public boolean getHasShowModifyHourlyRates() {
        return hasShowModifyHourlyRates;
    }

    public boolean getHasShowSalaries() {
        return hasShowSalaries;
    }

    public boolean getHasShowModifySalaries() {
        return hasShowModifySalaries;
    }

    public boolean getHasAccessEmployeeHistory() { return hasAccessEmployeeHistory; }

    public boolean getHasViewEmployeeOtherInformation() {
        return hasViewEmployeeOtherInformation;
    }

    public boolean getHasCanSeeAllEmployees() {
        return hasCanSeeAllEmployees;
    }

    public boolean getHasViewBirthDates() {
        return hasViewBirthDates;
    }

    public boolean getHasPerformBulkMaintenance() {
        return hasPerformBulkMaintenance;
    }

    public boolean getHasEnableManualPrenoteConvert() {
        return hasEnableManualPrenoteConvert;
    }


    //
    // End of Employee Maintenance Permissions
    //

    //
    // Company Profile Permissions
    //
    @PermissionAnnotation(securityName = "Enable Company Profile menu")
    private boolean hasEnableCompanyProfileMenu;

    @PermissionAnnotation(securityName = "View master table information")
    private boolean hasViewMasterTableInformation;

    @PermissionAnnotation(securityName = "Modify master table information")
    private boolean hasModifyMasterTableInformation;

    @PermissionAnnotation(securityName = "View account information")
    private boolean hasViewAccountInformation;

    @PermissionAnnotation(securityName = "View account bank info")
    private boolean hasViewAccountBankInfo;

    @PermissionAnnotation(securityName = "General Ledger setup")
    private boolean hasGeneralLedgerSetup;

    @PermissionAnnotation(securityName = "View/Modify User Security")
    private boolean hasViewModifyUserSecurity;

    @PermissionAnnotation(securityName = "Modify Pay Schedule")
    private boolean hasModifyPaySchedule;

    @PermissionAnnotation(securityName = "Access to Special and Preferences menus")
    private boolean hasAccessToSpecialAndPreferencesMenus;

    @PermissionAnnotation(securityName = "Edit user-defined exclusives")
    private boolean hasEditUserDefinedExclusives;

    @PermissionAnnotation(securityName = "Modify Client Preferences")
    private boolean hasModifyClientPreferences;

    @PermissionAnnotation(securityName = "Modify Wage Limit Warnings and Auto-Pay")
    private boolean hasModifyWageLimitWarningsAndAutoPay;

    @PermissionAnnotation(securityName = "Access Employee Self Service Admin Area")
    private boolean hasAccessEmployeeSelfServiceAdminArea;

    @PermissionAnnotation(securityName = "Modify 2-Factor Authentication")
    private boolean hasModify2FactorAuthentication;

    @PermissionAnnotation(securityName = "Restart Current Payroll")
    private boolean hasRestartCurrentPayroll;

    @PermissionAnnotation(securityName = "Make All DD Live (Prenote)")
    private boolean hasMakeAllDDLive;

    @PermissionAnnotation(securityName = "View Company Reminders")
    private boolean hasViewCompanyReminders;

    @PermissionAnnotation(securityName = "Modify Tax Table Setup Info")
    private boolean hasModifyTaxTableSetupInfo;

    @PermissionAnnotation(securityName = "Use ACA Dashboard")
    private boolean hasUseACADashboard;

    @PermissionAnnotation(securityName = "Modify ACA Configuration")
    private boolean hasModifyACAConfiguration;

    @PermissionAnnotation(securityName = "View Pay Warnings on Pay Summary")
    private boolean hasViewPayWarningsOnPaySummary;

    @PermissionAnnotation(securityName = "Modify Leave Pay Notes")
    private boolean hasModifyLeavePayNotes;

    @PermissionAnnotation(securityName = "View Leave Pay Notes")
    private boolean hasViewLeavePayNotes;

    @PermissionAnnotation(securityName = "Modify Multiple IP Check")
    private boolean hasModifyMultipleIPCheck;

    @PermissionAnnotation(securityName = "Disable Location Tracking")
    private boolean hasDisableLocationTracking;

    @PermissionAnnotation(securityName = "Modify ACA Dashboard Layout")
    private boolean hasModifyACADashboardLayout;

    @PermissionAnnotation(securityName = "Applicant Tracking")
    private boolean hasApplicantTracking;

    @PermissionAnnotation(securityName = "Modify User Name")
    private boolean hasModifyUserName;

    @PermissionAnnotation(securityName = "Modify External Integrator Admin user")
    private boolean hasModifyExternalIntegratorAdminUser;


    public boolean getHasEnableCompanyProfileMenu() {
        return hasEnableCompanyProfileMenu;
    }

    public boolean getHasViewMasterTableInformation() { return hasViewMasterTableInformation;}

    public boolean getHasModifyMasterTableInformation() {return hasModifyMasterTableInformation;}

    public boolean getHasViewAccountBankInfo() {return hasViewAccountBankInfo;}

    public boolean getHasViewModifyUserSecurity() {return hasViewModifyUserSecurity;}

    public boolean getHasModifyPaySchedule() {return hasModifyPaySchedule;}

    public boolean getHasAccessToSpecialAndPreferencesMenus() {return hasAccessToSpecialAndPreferencesMenus;}

    public boolean getHasEditUserDefinedExclusives() {return hasEditUserDefinedExclusives;}

    public boolean getHasModifyClientPreferences() {
        return hasModifyClientPreferences;
    }

    public boolean getHasModifyWageLimitWarningsAndAutoPay() { return hasModifyWageLimitWarningsAndAutoPay; }

    public boolean getHasAccessEmployeeSelfServiceAdminArea() { return hasAccessEmployeeSelfServiceAdminArea; }

    public boolean getHasModify2FactorAuthentication() { return hasModify2FactorAuthentication; }

    public boolean getHasRestartCurrentPayroll() { return hasRestartCurrentPayroll; }

    public boolean getHasMakeAllDDLive() { return hasMakeAllDDLive; }

    public boolean getHasViewCompanyReminders() { return hasViewCompanyReminders; }

    public boolean getHasModifyTaxTableSetupInfo() { return hasModifyTaxTableSetupInfo; }

    public boolean getHasUseACADashboard() { return hasUseACADashboard; }

    public boolean getHasModifyACAConfiguration() { return hasModifyACAConfiguration; }

    public boolean getHasViewPayWarningsOnPaySummary() { return hasViewPayWarningsOnPaySummary; }

    public boolean getHasModifyLeavePayNotes() { return hasModifyLeavePayNotes; }

    public boolean getHasViewLeavePayNotes() { return hasViewLeavePayNotes; }

    public boolean getHasModifyMultipleIPCheck() { return hasModifyMultipleIPCheck; }

    public boolean getHasDisableLocationTracking() { return hasDisableLocationTracking; }

    public boolean getHasModifyACADashboardLayout() { return hasModifyACADashboardLayout; }

    public boolean getApplicantTracking() { return hasApplicantTracking; }

    public boolean getHasModifyUserName() { return hasModifyUserName; }

    //
    // End of Company Profile Permissions
    //

    //
    // Reports Permissions
    //

    @PermissionAnnotation(securityName = "Enable Reports menu")
    private boolean hasEnableReportsMenu;

    @PermissionAnnotation(securityName = "Allow Running of Archived PDF Reports")
    private boolean hasAllowRunningArchivedPDFReports;

    @PermissionAnnotation(securityName = "Access to Standard Reports")
    private boolean hasAccessStandardReports;

    @PermissionAnnotation(securityName = "Access to confidential Standard Reports")
    private boolean hasAccessToConfidentialStandardReports;

    @PermissionAnnotation(securityName = "Create Custom Reports")
    private boolean hasCreateCustomReports;

    @PermissionAnnotation(securityName = "Run Custom Reports")
    private boolean hasRunCustomReports;

    @PermissionAnnotation(securityName = "Run All Custom Reports (vs. Personal List)")
    private boolean hasRunCustomReportsWithPersonalList;

    @PermissionAnnotation(securityName = "Modify HR Analytics Dashboard Layout")
    private boolean hasModifyHRAnalyticsDashboardLayout;

    public boolean getHasEnableReportsMenu() { return hasEnableReportsMenu; }

    public boolean getHasAllowRunningArchivedPDFReports() { return hasAllowRunningArchivedPDFReports; }

    public boolean getHasAccessStandardReports() { return hasAccessStandardReports; }

    public boolean getHasAccessToConfidentialStandardReports() { return hasAccessToConfidentialStandardReports; }

    public boolean getHasCreateCustomReports() { return hasCreateCustomReports; }

    public boolean getHasRunCustomReports() { return hasRunCustomReports; }

    public boolean getHasRunCustomReportsWithPersonalList() { return hasRunCustomReportsWithPersonalList; }

    public boolean getHasModifyHRAnalyticsDashboardLayout() { return hasModifyHRAnalyticsDashboardLayout; }

    //
    // End of Reports Permissions
    //

    //
    // Service Bureau Specific - Maintenance in MyPayCenter Permissions
    //

    @PermissionAnnotation(securityName = "Modify account bank info")
    private boolean hasModifyAccountBankInfo;

    @PermissionAnnotation(securityName = "Modify general company info")
    private boolean hasModifyGeneralCompanyInfo;

    @PermissionAnnotation(securityName = "Modify contact information")
    private boolean hasModifyContactInformation;

    @PermissionAnnotation(securityName = "CSR can modify company preferences")
    private boolean hasCSRCanModifyCompanyPreferences;

    @PermissionAnnotation(securityName = "View notes (shipping, handling, memo postee)")
    private boolean hasViewNotesShippingHandlingMemoPostee;

    @PermissionAnnotation(securityName = "Modify notes (shipping, handling, memo postee)")
    private boolean hasModifyNotesShippingHandlingMemoPostee;

    @PermissionAnnotation(securityName = "Modify credit limits - within approved range")
    private boolean hasModifyCreditLimitsWithinApprovedRange;

    @PermissionAnnotation(securityName = "Modify credit limits - significant increase")
    private boolean hasModifyCreditLimitsSignificantIncrease;

    @PermissionAnnotation(securityName = "Setup bank payroll")
    private boolean hasSetupBankPayroll;

    @PermissionAnnotation(securityName = "Override controls")
    private boolean hasOverrideControls;

    @PermissionAnnotation(securityName = "Modify states")
    private boolean hasModifyStates;

    @PermissionAnnotation(securityName = "Setup client custom programs (i.e. CLREQs)")
    private boolean hasSetupClientCustomPrograms;

    @PermissionAnnotation(securityName = "Modify report profiles")
    private boolean hasModifyReportProfiles;

    @PermissionAnnotation(securityName = "Modify exclusive profiles (e.g. Chesapeake, 401k, etc)")
    private boolean hasModifyExclusiveProfiles;

    @PermissionAnnotation(securityName = "Modify taxability of certain Master Items")
    private boolean hasModifyTaxabilityOfCertainMasterItems;

    @PermissionAnnotation(securityName = "Link ESS Admin to Payroll User")
    private boolean hasLinkESSAdminToPayrollUser;

    public boolean getHasModifyAccountBankInfo() { return hasModifyAccountBankInfo; }

    public boolean getHasModifyGeneralCompanyInfo() { return hasModifyGeneralCompanyInfo; }

    public boolean getHasModifyContactInformation() { return hasModifyContactInformation; }

    public boolean getHasCSRCanModifyCompanyPreferences() { return hasCSRCanModifyCompanyPreferences; }

    public boolean getHasViewNotesShippingHandlingMemoPostee() { return hasViewNotesShippingHandlingMemoPostee; }

    public boolean getHasModifyNotesShippingHandlingMemoPostee() { return hasModifyNotesShippingHandlingMemoPostee; }

    public boolean getHasModifyCreditLimitsWithinApprovedRange() { return hasModifyCreditLimitsWithinApprovedRange; }

    public boolean getHasModifyCreditLimitsSignificantIncrease() { return hasModifyCreditLimitsSignificantIncrease; }

    public boolean getHasSetupBankPayroll() { return hasSetupBankPayroll; }

    public boolean getHasOverrideControls() { return hasOverrideControls; }

    public boolean getHasModifyStates() { return hasModifyStates; }

    public boolean getHasSetupClientCustomPrograms() { return hasSetupClientCustomPrograms; }

    public boolean getHasModifyReportProfiles() { return hasModifyReportProfiles; }

    public boolean getHasModifyExclusiveProfiles() { return hasModifyExclusiveProfiles; }

    public boolean getHasModifyTaxabilityOfCertainMasterItems() { return hasModifyTaxabilityOfCertainMasterItems; }

    public boolean getHasLinkESSAdminToPayrollUser() { return hasLinkESSAdminToPayrollUser; }

    //
    // End of Service Bureau Specific - Maintenance in MyPayCenter Permissions
    //
}
