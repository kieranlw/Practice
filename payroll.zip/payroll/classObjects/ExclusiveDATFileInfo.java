package payroll.classObjects;

public class ExclusiveDATFileInfo {

	private String deduction401k;
	private String match401k;

	public String get401KDeduction() {
		return deduction401k;
	}

	public String get401KMatch() {
		return match401k;
	}


	private ExclusiveDATFileInfo(Builder builder) {
		deduction401k = builder.deduction401k;
		match401k = builder.match401k;
	}

	public static ExclusiveDATFileInfo.Builder builder() {
		return new ExclusiveDATFileInfo.Builder();
	}


	public static class Builder {

		private String deduction401k;
		private String match401k;

		public Builder set401KDeduction(String deduction) {
			this.deduction401k = deduction;
			return this;
		}

		public Builder set401KMatch(String match) {
			this.match401k = match;
			return this;
		}

		private Builder() {
		}

		public ExclusiveDATFileInfo build() {
			return new ExclusiveDATFileInfo(this);
		}

	}
 	
}
