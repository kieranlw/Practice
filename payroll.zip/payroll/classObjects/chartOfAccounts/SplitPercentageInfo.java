package payroll.classObjects.chartOfAccounts;

public class SplitPercentageInfo {

	private String accountNumber;
	private String description;
	private Double percentPreviousEntry;
	private Double percentNextEntry;

	public String getAccountNumber() {
		return accountNumber;
	}

	public String getDescription() {
		return description;
	}

	public Double getPercentPreviousEntry() {
		return percentPreviousEntry;
	}

	public Double getPercentNextEntry() {
		return percentNextEntry;
	}

	private SplitPercentageInfo(Builder builder) {
		accountNumber = builder.accountNumber;
		description = builder.description;
		percentPreviousEntry = builder.percentPreviousEntry;
		percentNextEntry = builder.percentNextEntry;
	}

	public static SplitPercentageInfo.Builder builder(){
		return new SplitPercentageInfo.Builder();
	}


	public static class Builder {
		private String accountNumber;
		private String description;
		private Double percentPreviousEntry;
		private Double percentNextEntry;

		public Builder setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
			return this;
		}

		public Builder setDescription(String description) {
			this.description = description;
			return this;
		}

		public Builder setPercentPreviousEntry(double percentPreviousEntry) {
			this.percentPreviousEntry = percentPreviousEntry;
			return this;
		}

		public Builder setPercentNextEntry(double percentNextEntry) {
			this.percentNextEntry = percentNextEntry;
			return this;
		}

		private Builder() {
		}

		public SplitPercentageInfo build() {
			return new SplitPercentageInfo(this);
		}

	}
 	
}
