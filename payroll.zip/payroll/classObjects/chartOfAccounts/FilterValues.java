package payroll.classObjects.chartOfAccounts;

public class FilterValues {

	private String category;
	private String type;
	private String department;
	private String jobCode;

	public String getCategory() {
		return category;
	}

	public String getType() {
		return type;
	}

	public String getDepartment() {
		return department;
	}

	public String getJobCode() {
		return jobCode;
	}

	private FilterValues(Builder builder) {
		category = builder.category;
		type = builder.type;
		department = builder.department;
		jobCode = builder.jobCode;
	}

	public static FilterValues.Builder builder(){
		return new FilterValues.Builder();
	}


	public static class Builder {
		private String category;
		private String type;
		private String department;
		private String jobCode;


		public Builder setCategory(String category) {
			this.category = category;
			return this;
		}

		public Builder setType(String type) {
			this.type = type;
			return this;
		}

		public Builder setDepartment(String department) {
			this.department = department;
			return this;
		}

		public Builder setJobCode(String jobCode) {
			this.jobCode = jobCode;
			return this;
		}

		private Builder() {
		}

		public FilterValues build() {
			return new FilterValues(this);
		}

	}
 	
}
