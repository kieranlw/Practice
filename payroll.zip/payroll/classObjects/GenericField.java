package payroll.classObjects;

public class GenericField {

    private String label;
    //value for checkboxes just enter "true" or "false"
    private String value;
    private Type type;

    public String getLabel() {
        return label;
    }

    public String getValue() {
        return value;
    }

    public Type getType() {
        return type;
    }

    public GenericField(String label, String value, Type type){
        this.label = label;
        this.value = value;
        this.type = type;
    }



    public enum Type{
        CHECKBOX, TEXTBOX, DROPDOWN
    }


}
