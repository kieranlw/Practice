package payroll.classObjects.QuickCalcVoucher;

public enum AddCalculatedGrossTo {
    SELECT("Select"),
    BONUS_PAY("Bonus"),
    MISC_PAY("Misc Pay"),
    OTHER_PAY("Other Pay"),
    LIFE_INSUR_FRINGE("Life Insur Fringe"),
    AUTO_TRUCK_ALLOWANCE("Auto/Truck Allowance"),
    S_CORP_HEALTH("S-Corp Health"),
    CELL_PHONE_PERSONAL("Cell Phone-Personal");

    private final String optionName;

    AddCalculatedGrossTo(String optionName) {
        this.optionName = optionName;
    }

    public String getOptionName() {
        return optionName;
    }
}