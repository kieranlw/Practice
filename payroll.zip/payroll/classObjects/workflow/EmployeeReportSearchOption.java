package payroll.classObjects.workflow;

public enum EmployeeReportSearchOption {
    SSN, NAME
}
