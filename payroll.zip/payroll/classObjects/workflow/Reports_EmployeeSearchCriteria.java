package payroll.classObjects.workflow;

import payroll.classObjects.EmployeeName;

public class Reports_EmployeeSearchCriteria {
    private String ssnText;
    private EmployeeReportSearchOption employeeReportSearchOption;
    private EmployeeName employeeName;

    public EmployeeName getEmployeeName() {
        return employeeName;
    }

    public Reports_EmployeeSearchCriteria setEmployeeName(EmployeeName employeeName) {
        this.employeeName = employeeName;
        return this;
    }

    public String getSSNText() {
        return ssnText;
    }

    public Reports_EmployeeSearchCriteria setSSNText(String ssnText) {
        this.ssnText = ssnText;
        return this;
    }

    public EmployeeReportSearchOption getEmployeeReportSearchOption() {
        return employeeReportSearchOption;
    }

    public Reports_EmployeeSearchCriteria setEmployeeReportSearchOption(EmployeeReportSearchOption employeeReportSearchOption) {
        this.employeeReportSearchOption = employeeReportSearchOption;
        return this;
    }
}
