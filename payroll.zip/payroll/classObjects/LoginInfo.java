package payroll.classObjects;

public class LoginInfo {

	private String loginName;
	private String password;
	private String account;

	public String getLoginName() {
		return loginName;
	}

	public String getPassword() {
		return password;
	}

	public String getAccount() {
		return account;
	}

	private LoginInfo(Builder builder) {
		loginName = builder.loginName;
		password = builder.password;
		account = builder.account;
	}

	public static LoginInfo.Builder builder() {
		return new LoginInfo.Builder();
	}

	@Override
	public String toString(){
		return loginName;
	}

	public static class Builder {
		private String loginName;
		private String password;
		private String account;

		public Builder setAccount(String account) {
			this.account = account;
			return this;
		}

		public Builder setLoginName(String loginName) {
			this.loginName = loginName;
			return this;
		}

		public Builder setPassword(String password) {
			this.password = password;
			return this;
		}

		private Builder() {
		}

		public LoginInfo build() {
			return new LoginInfo(this);
		}

	}
 	
}
