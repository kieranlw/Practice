package payroll.classObjects;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class OverrideBenefitsInfo {

    private String benefit;
    private Double amount;
    private boolean doSkipAgencyPay;
    private boolean doIgnoreAllocations;

}
