package payroll.classObjects.payroll.vertex;

import common.DateFormats;
import utils2.tableData.Row;

import java.time.LocalDate;

public class StateData {
    private final String stateName;
    private final String account;
    private final LocalDate periodEndDate;
    private final LocalDate payDate;

    public StateData(Row row) {
        this.stateName = row.get("State");
        this.account = row.get("Account");
        this.periodEndDate = LocalDate.parse(row.get("PeriodEndDate"), DateFormats.M_D_YYYY);
        this.payDate = LocalDate.parse(row.get("PayDate"), DateFormats.M_D_YYYY);
    }

    public String getStateName() {
        return stateName;
    }

    public String getAccount() {
        return account;
    }

    public LocalDate getPayDate() {
        return payDate;
    }

    public LocalDate getPeriodEndDate() {
        return periodEndDate;
    }

    @Override
    public String toString() {
        return account;
    }
}