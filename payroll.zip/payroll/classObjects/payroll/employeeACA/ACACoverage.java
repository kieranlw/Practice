package payroll.classObjects.payroll.employeeACA;

import utils2.JavaTimeUtils;
import utils2.tableData.Row;

import java.time.LocalDate;

public class ACACoverage {

    private LocalDate effectiveFromDate;
    private Boolean is2PercentCorpOwned;
    private Boolean didWaiveCoverage;
    private String waiverReason;
    private Boolean showAdvancedUncommonOptions;
    private Boolean insuranceIs100PercentEmployerPaid;
    private Boolean employeeDoesNotHaveInsurance;
    private Boolean employeePaidForInsuranceOutsideOfPayroll;
    private Boolean anyCoverageOfferedWillIncludeFamily;
    private String defaultCoverageOffered;

    public Row getExpectedRow() {
        Row row = Row.of(
                "From Date", getEffectiveFromDate_ForTable(),
                "2% Owner", is2PercentCorpOwned == null ? "false" : is2PercentCorpOwned.toString(),
                "Coverage Waived?", didWaiveCoverage == null ? "false" : didWaiveCoverage.toString(),
                "Waived Reason", waiverReason == null ? "" : waiverReason,
                "Full Coverage Offered?", anyCoverageOfferedWillIncludeFamily == null ? "false" : anyCoverageOfferedWillIncludeFamily.toString());

        return row;
    }

    public LocalDate getEffectiveFromDate() {
        return effectiveFromDate;
    }

    public String getEffectiveFromDate_ForTable() {
        return JavaTimeUtils.getLocalDateString(effectiveFromDate, "M/d/yyyy");
    }

    public ACACoverage setEffectiveFromDate(LocalDate effectiveFromDate) {
        this.effectiveFromDate = effectiveFromDate;
        return this;
    }

    public Boolean getIs2PercentCorpOwned() {
        return is2PercentCorpOwned;
    }

    public ACACoverage setIs2PercentCorpOwned(Boolean is2PercentCorpOwned) {
        this.is2PercentCorpOwned = is2PercentCorpOwned;
        return this;
    }

    public Boolean getDidWaiveCoverage() {
        return didWaiveCoverage;
    }

    public ACACoverage setDidWaiveCoverage(Boolean didWaiveCoverage) {
        this.didWaiveCoverage = didWaiveCoverage;
        return this;
    }

    public String getWaiverReason() {
        return waiverReason;
    }

    public ACACoverage setWaiverReason(String waiverReason) {
        this.waiverReason = waiverReason;
        return this;
    }

    public Boolean getShowAdvancedUncommonOptions() {
        return showAdvancedUncommonOptions;
    }

    public ACACoverage setShowAdvancedUncommonOptions(Boolean showAdvancedUncommonOptions) {
        this.showAdvancedUncommonOptions = showAdvancedUncommonOptions;
        return this;
    }

    public Boolean getInsuranceIs100PercentEmployerPaid() {
        return insuranceIs100PercentEmployerPaid;
    }

    public ACACoverage setInsuranceIs100PercentEmployerPaid(Boolean insuranceIs100PercentEmployerPaid) {
        this.insuranceIs100PercentEmployerPaid = insuranceIs100PercentEmployerPaid;
        return this;
    }

    public Boolean getEmployeeDoesNotHaveInsurance() {
        return employeeDoesNotHaveInsurance;
    }

    public ACACoverage setEmployeeDoesNotHaveInsurance(Boolean employeeDoesNotHaveInsurance) {
        this.employeeDoesNotHaveInsurance = employeeDoesNotHaveInsurance;
        return this;
    }

    public Boolean getEmployeePaidForInsuranceOutsideOfPayroll() {
        return employeePaidForInsuranceOutsideOfPayroll;
    }

    public ACACoverage setEmployeePaidForInsuranceOutsideOfPayroll(Boolean employeePaidForInsuranceOutsideOfPayroll) {
        this.employeePaidForInsuranceOutsideOfPayroll = employeePaidForInsuranceOutsideOfPayroll;
        return this;
    }

    public Boolean getAnyCoverageOfferedWillIncludeFamily() {
        return anyCoverageOfferedWillIncludeFamily;
    }

    public ACACoverage setAnyCoverageOfferedWillIncludeFamily(Boolean anyCoverageOfferedWillIncludeFamily) {
        this.anyCoverageOfferedWillIncludeFamily = anyCoverageOfferedWillIncludeFamily;
        return this;
    }

    public String getDefaultCoverageOffered() {
        return defaultCoverageOffered;
    }

    public ACACoverage setDefaultCoverageOffered(String defaultCoverageOffered) {
        this.defaultCoverageOffered = defaultCoverageOffered;
        return this;
    }
}
