package payroll.classObjects.payroll.employeeACA;

import utils2.JavaTimeUtils;
import utils2.tableData.Row;

import java.time.LocalDate;

public class ACAClassification {

    private LocalDate effectiveFromDate;
    private String classification;

    public Row getRow() {
        Row row = Row.of(
                "From Date", JavaTimeUtils.getLocalDateString(effectiveFromDate, "M/d/yyyy"),
                "Classification", classification);
        return row;
    }

    public LocalDate getEffectiveFromDate() {
        return effectiveFromDate;
    }

    public ACAClassification setEffectiveFromDate(LocalDate effectiveFromDate) {
        this.effectiveFromDate = effectiveFromDate;
        return this;
    }

    public String getClassification() {
        return classification;
    }

    public ACAClassification setClassification(String classification) {
        this.classification = classification;
        return this;
    }
}
