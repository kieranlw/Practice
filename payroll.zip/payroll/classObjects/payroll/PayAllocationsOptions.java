package payroll.classObjects.payroll;

public class PayAllocationsOptions {

    private Boolean overrideCompanyPayAllocations;
    private Boolean overrideEarnings;
    private Boolean overrideTaxes;
    private Boolean overrideDeductions;
    private Boolean overrideBenefits;

    public Boolean getOverrideCompanyPayAllocations() {
        return overrideCompanyPayAllocations;
    }

    public PayAllocationsOptions setOverrideCompanyPayAllocations(Boolean overrideCompanyPayAllocations) {
        this.overrideCompanyPayAllocations = overrideCompanyPayAllocations;
        return this;
    }

    public Boolean getOverrideEarnings() {
        return overrideEarnings;
    }

    public PayAllocationsOptions setOverrideEarnings(Boolean overrideEarnings) {
        this.overrideEarnings = overrideEarnings;
        return this;
    }

    public Boolean getOverrideTaxes() {
        return overrideTaxes;
    }

    public PayAllocationsOptions setOverrideTaxes(Boolean overrideTaxes) {
        this.overrideTaxes = overrideTaxes;
        return this;
    }

    public Boolean getOverrideDeductions() {
        return overrideDeductions;
    }

    public PayAllocationsOptions setOverrideDeductions(Boolean overrideDeductions) {
        this.overrideDeductions = overrideDeductions;
        return this;
    }

    public Boolean getOverrideBenefits() {
        return overrideBenefits;
    }

    public PayAllocationsOptions setOverrideBenefits(Boolean overrideBenefits) {
        this.overrideBenefits = overrideBenefits;
        return this;
    }
}
