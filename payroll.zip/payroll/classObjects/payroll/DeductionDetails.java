package payroll.classObjects.payroll;

import payroll.classObjects.deductions.Frequencies;
import payroll.classObjects.deductions.Classifications;
import payroll.classObjects.deductions.PercentOfGrossUses;
import payroll.classObjects.deductions.Types;

public class DeductionDetails {

    private String number;
    private String description;
    private boolean isActive;
    private Classifications classification;
    private boolean isSubclassRequired;
    private Frequencies frequency;
    private boolean overrideDefaults;
    private Types type;
    private PercentOfGrossUses percentOfGross;
    private boolean memoOnly;

    public static class Builder {

        private String number;
        private String description;
        private boolean isActive;
        private Classifications classification;
        private boolean isSubclassRequired;
        private Frequencies frequency;
        private boolean overrideDefaults;
        private Types type;
        private PercentOfGrossUses percentOfGross;
        private boolean memoOnly;

        public Builder() {
        }

        Builder(String number, String description, boolean isActive, Classifications classification, boolean isSubclassRequired, Frequencies frequency, boolean overrideDefaults, Types type, PercentOfGrossUses percentOfGross, boolean memoOnly) {
            this.number = number;
            this.description = description;
            this.isActive = isActive;
            this.classification = classification;
            this.isSubclassRequired = isSubclassRequired;
            this.frequency = frequency;
            this.overrideDefaults = overrideDefaults;
            this.type = type;
            this.percentOfGross = percentOfGross;
            this.memoOnly = memoOnly;
        }

        public Builder number(String number){
            this.number = number;
            return Builder.this;
        }

        public Builder description(String description){
            this.description = description;
            return Builder.this;
        }

        public Builder isActive(boolean isActive){
            this.isActive = isActive;
            return Builder.this;
        }

        public Builder classification(Classifications classification){
            this.classification = classification;
            return Builder.this;
        }

        public Builder isSubclassRequired(boolean isSubclassRequired){
            this.isSubclassRequired = isSubclassRequired;
            return Builder.this;
        }

        public Builder frequency(Frequencies frequency){
            this.frequency = frequency;
            return Builder.this;
        }

        public Builder overrideDefaults(boolean overrideDefaults){
            this.overrideDefaults = overrideDefaults;
            return Builder.this;
        }

        public Builder type(Types type){
            this.type = type;
            return Builder.this;
        }

        public Builder percentOfGross(PercentOfGrossUses percentOfGross){
            this.percentOfGross = percentOfGross;
            return Builder.this;
        }

        public Builder memoOnly(boolean memoOnly){
            this.memoOnly = memoOnly;
            return Builder.this;
        }

        public DeductionDetails build() {

            return new DeductionDetails(this);
        }
    }

    private DeductionDetails(Builder builder) {
        this.number = builder.number;
        this.description = builder.description;
        this.isActive = builder.isActive;
        this.classification = builder.classification;
        this.isSubclassRequired = builder.isSubclassRequired;
        this.frequency = builder.frequency;
        this.overrideDefaults = builder.overrideDefaults;
        this.type = builder.type;
        this.percentOfGross = builder.percentOfGross;
        this.memoOnly = builder.memoOnly;
    }

    public String getNumber() {
        return number;
    }

    public String getDescription() {
        return description;
    }

    public boolean isActive() {
        return isActive;
    }

    public Classifications getClassification() { return classification; }

    public boolean isSubclassRequired() {
        return isSubclassRequired;
    }

    public Frequencies getFrequency() {
        return frequency;
    }

    public boolean isOverrideDefaults() { return overrideDefaults; }

    public boolean isMemoOnly() { return memoOnly; }

    public Types getType() {
        return type;
    }

    public PercentOfGrossUses getPercentOfGross() {
        return percentOfGross;
    }
}
