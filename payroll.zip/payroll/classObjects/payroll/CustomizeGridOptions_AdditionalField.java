package payroll.classObjects.payroll;

public class CustomizeGridOptions_AdditionalField {

    private boolean checkOption;
    private String optionType;
    private String fieldName;

    public String getDropdownFormat() {
        return optionType + ":" + fieldName;
    }

    public boolean isCheckOption() {
        return checkOption;
    }

    public CustomizeGridOptions_AdditionalField setCheckOption(boolean checkOption) {
        this.checkOption = checkOption;
        return this;
    }

    public String getOptionType() {
        return optionType;
    }

    public CustomizeGridOptions_AdditionalField setOptionType(String optionType) {
        this.optionType = optionType;
        return this;
    }

    public String getFieldName() {
        return fieldName;
    }

    public CustomizeGridOptions_AdditionalField setFieldName(String fieldName) {
        this.fieldName = fieldName;
        return this;
    }
}
