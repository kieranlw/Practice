package payroll.classObjects.payroll;

import utils2.tableData.Row;

public class StateTaxDefault {

    private String State;
    private String filingStatus;
    private int dependents;

    public Row getExpectedRow() {
        Row row = Row.of(
                "State", State,
                "Filing Status", filingStatus,
                "Dependents", String.valueOf(dependents));

        return row;
    }

    public String getState() {
        return State;
    }

    public StateTaxDefault setState(String state) {
        State = state;
        return this;
    }

    public String getFilingStatus() {
        return filingStatus;
    }

    public StateTaxDefault setFilingStatus(String filingStatus) {
        this.filingStatus = filingStatus;
        return this;
    }

    public int getDependents() {
        return dependents;
    }

    public StateTaxDefault setDependents(int dependents) {
        this.dependents = dependents;
        return this;
    }
}
