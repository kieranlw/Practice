package payroll.classObjects.payroll;

import payroll.classObjects.agencyDetails.AccountTypes;
import payroll.classObjects.agencyDetails.Frequencies;
import payroll.classObjects.agencyDetails.PaymentMethods;

public class AgencyDetails {

    private String number;
    private String name;
    private boolean isActive;
    private String address1;
    private Frequencies frequency;
    private PaymentMethods paymentMethod;
    private String bankRouting;
    private AccountTypes accountType;
    private boolean isRequireCaseNumber;
    private boolean allowNegativeAmounts;
    private boolean isMaskSSN;

    public static class Builder {

        private String number;
        private String name;
        private boolean isActive;
        private String address1;
        private Frequencies frequency;
        private PaymentMethods paymentMethod;
        private String bankRouting;
        private AccountTypes accountType;
        private boolean isRequireCaseNumber;
        private boolean allowNegativeAmounts;
        private boolean isMaskSSN;

        public Builder() {
        }

        Builder(String number, String name, boolean isActive, String address1, Frequencies frequency, PaymentMethods paymentMethod, String bankRouting, AccountTypes accountType, boolean isRequireCaseNumber, boolean allowNegativeAmounts, boolean isMaskSSN) {
            this.number = number;
            this.name = name;
            this.isActive = isActive;
            this.address1 = address1;
            this.frequency = frequency;
            this.paymentMethod = paymentMethod;
            this.bankRouting = bankRouting;
            this.accountType = accountType;
            this.isRequireCaseNumber = isRequireCaseNumber;
            this.allowNegativeAmounts = allowNegativeAmounts;
            this.isMaskSSN = isMaskSSN;
        }

        public Builder number(String number) {
            this.number = number;
            return Builder.this;
        }

        public Builder name(String name) {
            this.name = name;
            return Builder.this;
        }

        public Builder isActive(boolean isActive) {
            this.isActive = isActive;
            return Builder.this;
        }

        public Builder address1(String address1) {
            this.address1 = address1;
            return Builder.this;
        }

        public Builder frequency(Frequencies frequency) {
            this.frequency = frequency;
            return Builder.this;
        }

        public Builder paymentMethod(PaymentMethods paymentMethod) {
            this.paymentMethod = paymentMethod;
            return Builder.this;
        }

        public Builder bankRouting(String bankRouting) {
            this.bankRouting = bankRouting;
            return Builder.this;
        }

        public Builder accountType(AccountTypes accountType) {
            this.accountType = accountType;
            return Builder.this;
        }

        public Builder isRequireCaseNumber(boolean isRequireCaseNumber) {
            this.isRequireCaseNumber = isRequireCaseNumber;
            return Builder.this;
        }

        public Builder allowNegativeAmounts(boolean allowNegativeAmounts) {
            this.allowNegativeAmounts = allowNegativeAmounts;
            return Builder.this;
        }

        public Builder isMaskSSN(boolean isMaskSSN) {
            this.isMaskSSN = isMaskSSN;
            return Builder.this;
        }

        public AgencyDetails build() {
            if (this.number == null) {
                throw new NullPointerException("The property \"number\" is null. "
                        + "Please set the value by \"number()\". "
                        + "The properties \"number\", \"name\", \"frequency\" and \"paymentMethod\" are required.");
            }
            if (this.name == null) {
                throw new NullPointerException("The property \"name\" is null. "
                        + "Please set the value by \"name()\". "
                        + "The properties \"number\", \"name\", \"frequency\" and \"paymentMethod\" are required.");
            }
            if (this.frequency == null) {
                throw new NullPointerException("The property \"frequency\" is null. "
                        + "Please set the value by \"frequency()\". "
                        + "The properties \"number\", \"name\", \"frequency\" and \"paymentMethod\" are required.");
            }
            if (this.paymentMethod == null) {
                throw new NullPointerException("The property \"paymentMethod\" is null. "
                        + "Please set the value by \"paymentMethod()\". "
                        + "The properties \"number\", \"name\", \"frequency\" and \"paymentMethod\" are required.");
            }

            return new AgencyDetails(this);
        }
    }

    private AgencyDetails(Builder builder) {
        this.number = builder.number;
        this.name = builder.name;
        this.isActive = builder.isActive;
        this.address1 = builder.address1;
        this.frequency = builder.frequency;
        this.paymentMethod = builder.paymentMethod;
        this.bankRouting = builder.bankRouting;
        this.accountType = builder.accountType;
        this.isRequireCaseNumber = builder.isRequireCaseNumber;
        this.allowNegativeAmounts = builder.allowNegativeAmounts;
        this.isMaskSSN = builder.isMaskSSN;
    }

    public String getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public boolean isActive() {
        return isActive;
    }

    public String getAddress1() {
        return address1;
    }

    public Frequencies getFrequency() {
        return frequency;
    }

    public PaymentMethods getPaymentMethod() {
        return paymentMethod;
    }

    public String getBankRouting() {
        return bankRouting;
    }

    public AccountTypes getAccountType() {
        return accountType;
    }

    public boolean isRequireCaseNumber() {
        return isRequireCaseNumber;
    }

    public boolean isAllowNegativeAmounts() {
        return allowNegativeAmounts;
    }

    public boolean isMaskSSN() {
        return isMaskSSN;
    }
}
