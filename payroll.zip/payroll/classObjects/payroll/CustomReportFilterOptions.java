package payroll.classObjects.payroll;

import java.time.LocalDate;

public class CustomReportFilterOptions {

    private LocalDate payDate;
    private String payDateOperator;

    public String getPayDateOperator() {
        return payDateOperator;
    }

    public CustomReportFilterOptions setPayDateOperator(String payDateOperator) {
        this.payDateOperator = payDateOperator;
        return this;
    }

    public LocalDate getPayDate() {
        return payDate;
    }

    public CustomReportFilterOptions setPayDate(LocalDate payDate) {
        this.payDate = payDate;
        return this;
    }
}
