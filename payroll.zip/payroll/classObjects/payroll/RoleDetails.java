package payroll.classObjects.payroll;

import utils2.tableData.Row;

public class RoleDetails {

    private String roleName;
    private String description;
    private String copyPrivelegesFrom;
    private String[] privileges;

    public Row getRolesExpectedRow() {
        Row row = Row.of(
                "Name", roleName,
                "Description", description);
        return row;
    }

    public String getRoleName() {
        return roleName;
    }

    public RoleDetails setRoleName(String roleName) {
        this.roleName = roleName;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public RoleDetails setDescription(String description) {
        this.description = description;
        return this;
    }

    public String getCopyPrivelegesFrom() {
        return copyPrivelegesFrom;
    }

    public RoleDetails setCopyPrivelegesFrom(String copyPrivelegesFrom) {
        this.copyPrivelegesFrom = copyPrivelegesFrom;
        return this;
    }

    public String[] getPrivileges() {
        return privileges;
    }

    public RoleDetails setPrivileges(String[] privileges) {
        this.privileges = privileges;
        return this;
    }
}
