package payroll.classObjects.payroll.manualPay;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import payroll.classObjects.DollarCurrency;

@Getter
@Setter
@Builder

public class EmployeeManualPayLeavePaysInfo {

    private String description;
    private DollarCurrency amount;
    private String hours;
}