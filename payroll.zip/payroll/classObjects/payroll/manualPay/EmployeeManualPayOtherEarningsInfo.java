package payroll.classObjects.payroll.manualPay;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import payroll.classObjects.DollarCurrency;

@Getter
@Setter
@Builder

public class EmployeeManualPayOtherEarningsInfo {

    private String description;
    private String standardOtherEarning;
    private DollarCurrency amount;
    private String hours;
}