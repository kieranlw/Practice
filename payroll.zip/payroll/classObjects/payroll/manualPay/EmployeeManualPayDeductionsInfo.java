package payroll.classObjects.payroll.manualPay;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import payroll.classObjects.DollarCurrency;

@Getter
@Setter
@Builder

public class EmployeeManualPayDeductionsInfo {

    private String description;
    private String standardDeduction;
    private DollarCurrency amount;
}