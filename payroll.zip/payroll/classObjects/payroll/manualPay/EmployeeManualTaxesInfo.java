package payroll.classObjects.payroll.manualPay;

import payroll.classObjects.DollarCurrency;

public class EmployeeManualTaxesInfo {

    private final String description;
    private final DollarCurrency gross;
    private final DollarCurrency taxableGross;
    private final DollarCurrency tax;
    private final DollarCurrency deferredAmount;

    private EmployeeManualTaxesInfo(Builder builder) {
        this.gross = builder.gross;
        this.description = builder.description;
        this.taxableGross = builder.taxableGross;
        this.tax = builder.tax;
        this.deferredAmount = builder.deferredAmount;
    }

    public static EmployeeManualTaxesInfo.Builder builder() {
        return new EmployeeManualTaxesInfo.Builder();
    }

    public String getDescription() {
        return description;
    }

    public DollarCurrency getGross() {
        return gross;
    }

    public DollarCurrency getTaxableGross() {
        return taxableGross;
    }

    public DollarCurrency getTax() {
        return tax;
    }

    public DollarCurrency getDeferredAmount() {
        return deferredAmount;
    }

    public static class Builder {
        private String description;
        private DollarCurrency gross;
        private DollarCurrency taxableGross;
        private DollarCurrency tax;
        private DollarCurrency deferredAmount;

        private Builder() {
        }

        public Builder setDescription(String description) {
            this.description = description;
            return this;
        }

        public Builder setGross(DollarCurrency gross) {
            this.gross = gross;
            return this;
        }

        public Builder setTaxableGross(DollarCurrency taxableGross) {
            this.taxableGross = taxableGross;
            return this;
        }

        public Builder setTax(DollarCurrency tax) {
            this.tax = tax;
            return this;
        }

        public Builder setDeferredAmount(DollarCurrency deferredAmount) {
            this.deferredAmount = deferredAmount;
            return this;
        }

        public EmployeeManualTaxesInfo build() {
            return new EmployeeManualTaxesInfo(this);
        }
    }
}
