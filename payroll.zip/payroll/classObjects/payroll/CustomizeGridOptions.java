package payroll.classObjects.payroll;

import lombok.*;
import org.apache.commons.lang3.ArrayUtils;

@Builder
@Getter
@With
public class CustomizeGridOptions {
    public static CustomizeGridOptions DEFAULT = CustomizeGridOptions.builder()
            .ssn(false)
            .jobCode(false)
            .department(true)
            .employeeNumber(true)
            .otHours(true)
            .build();
    public static CustomizeGridOptions EMPTY = CustomizeGridOptions.builder().build();

    private Boolean employeeNumber;
    private Boolean department;
    private Boolean otHours;
    private Boolean ssn;
    private Boolean jobCode;
    private CustomizeGridOptions_AdditionalField[] additionalFields;

    /**
     * Returns a new CustomizeGridOptions with the given field added to the end of the list.
     *
     * @param field New field to append
     * @return The new CustomizeGridOptions instance
     */
    public CustomizeGridOptions withAdditionalField(CustomizeGridOptions_AdditionalField field) {
        return withAdditionalFields(ArrayUtils.add(additionalFields, field));
    }
}
