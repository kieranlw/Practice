package payroll.classObjects.payroll.addUser;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class AddNewEmployeeUser {

    private String employee;
    private String role;
    private String email;

}
