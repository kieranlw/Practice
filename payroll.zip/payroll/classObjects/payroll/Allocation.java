package payroll.classObjects.payroll;

public class Allocation {

    private double percent;
    private String department;
    private String jobCode;

    public double getPercent() {
        return percent;
    }

    public Allocation setPercent(double percent) {
        this.percent = percent;
        return this;
    }

    public String getDepartment() {
        return department;
    }

    public Allocation setDepartment(String department) {
        this.department = department;
        return this;
    }

    public String getJobCode() {
        return jobCode;
    }

    public Allocation setJobCode(String jobCode) {
        this.jobCode = jobCode;
        return this;
    }
}
