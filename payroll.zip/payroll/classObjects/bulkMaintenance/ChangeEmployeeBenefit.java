package payroll.classObjects.bulkMaintenance;

import lombok.Builder;
import lombok.Data;
@Builder
@Data

public class ChangeEmployeeBenefit {

    private String department;
    private String jobCode;
    private String payType;
    private String benefit;
    private Boolean includeInactiveEmployees;
    private Boolean changeAmount;
    private String fromAmount;
    private String toAmount;
    private Boolean changeMax;
    private String fromMax;
    private String toMax;
}
