package payroll.classObjects.bulkMaintenance;

import java.time.LocalDate;

public class ChangeEmployeeDeduction {

    private String department;
    private String jobCode;
    private String payType;
    private String deduction;
    private Boolean includeInactiveEmployees;
    private Boolean changeAmount;
    private String fromAmount;
    private String toAmount;
    private Boolean changeMax;
    private String fromMax;
    private String toMax;
    private Boolean changeStatus;
    private String status;
    private Boolean changeEndDate;
    private LocalDate endDate;

    public String getDepartment() {
        return department;
    }

    public ChangeEmployeeDeduction setDepartment(String department) {
        this.department = department;
        return this;
    }

    public String getJobCode() {
        return jobCode;
    }

    public ChangeEmployeeDeduction setJobCode(String jobCode) {
        this.jobCode = jobCode;
        return this;
    }

    public String getPayType() {
        return payType;
    }

    public ChangeEmployeeDeduction setPayType(String payType) {
        this.payType = payType;
        return this;
    }

    public String getDeduction() {
        return deduction;
    }

    public ChangeEmployeeDeduction setDeduction(String deduction) {
        this.deduction = deduction;
        return this;
    }

    public Boolean getIncludeInactiveEmployees() {
        return includeInactiveEmployees;
    }

    public ChangeEmployeeDeduction setIncludeInactiveEmployees(Boolean includeInactiveEmployees) {
        this.includeInactiveEmployees = includeInactiveEmployees;
        return this;
    }

    public Boolean getChangeAmount() {
        return changeAmount;
    }

    public ChangeEmployeeDeduction setChangeAmount(Boolean changeAmount) {
        this.changeAmount = changeAmount;
        return this;
    }

    public String getFromAmount() {
        return fromAmount;
    }

    public ChangeEmployeeDeduction setFromAmount(String fromAmount) {
        this.fromAmount = fromAmount;
        return this;
    }

    public String getToAmount() {
        return toAmount;
    }

    public ChangeEmployeeDeduction setToAmount(String toAmount) {
        this.toAmount = toAmount;
        return this;
    }

    public Boolean getChangeMax() {
        return changeMax;
    }

    public ChangeEmployeeDeduction setChangeMax(Boolean changeMax) {
        this.changeMax = changeMax;
        return this;
    }

    public String getFromMax() {
        return fromMax;
    }

    public ChangeEmployeeDeduction setFromMax(String fromMax) {
        this.fromMax = fromMax;
        return this;
    }

    public String getStatus() {
        return status;
    }

    public ChangeEmployeeDeduction setStatus(String status) {
        this.status = status;
        return this;
    }

    public String getToMax() {
        return toMax;
    }

    public ChangeEmployeeDeduction setToMax(String toMax) {
        this.toMax = toMax;
        return this;
    }

    public Boolean getChangeStatus() {
        return changeStatus;
    }

    public ChangeEmployeeDeduction setChangeStatus(Boolean changeStatus) {
        this.changeStatus = changeStatus;
        return this;
    }

    public Boolean getChangeEndDate() {
        return changeEndDate;
    }

    public ChangeEmployeeDeduction setChangeEndDate(Boolean changeEndDate) {
        this.changeEndDate = changeEndDate;
        return this;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public ChangeEmployeeDeduction setEndDate(LocalDate endDate) {
        this.endDate = endDate;
        return this;
    }
}
