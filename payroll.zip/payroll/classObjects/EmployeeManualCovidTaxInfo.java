package payroll.classObjects;

public class EmployeeManualCovidTaxInfo {

	private String description;
	private DollarCurrency taxableWages;
	private DollarCurrency creditAmount;


	public String getDescription() {
		return description;
	}

	public DollarCurrency getTaxableWages() {
		return taxableWages;
	}

	public DollarCurrency getCreditAmount() {
		return creditAmount;
	}


	private EmployeeManualCovidTaxInfo(Builder builder) {
		this.description = builder.description;
		this.taxableWages = builder.taxableWages;
		this.creditAmount = builder.creditAmount;
	}

	public static EmployeeManualCovidTaxInfo.Builder builder(){
		return new EmployeeManualCovidTaxInfo.Builder();
	}


	public static class Builder {
		private String description;
		private DollarCurrency taxableWages;
		private DollarCurrency creditAmount;

		public Builder setDescription(String description) {
			this.description = description;
			return this;
		}

		public Builder setTaxableWages(DollarCurrency taxableWages) {
			this.taxableWages = taxableWages;
			return this;
		}

		public Builder setCreditAmount(DollarCurrency creditAmount) {
			this.creditAmount = creditAmount;
			return this;
		}


		private Builder() {
		}

		public EmployeeManualCovidTaxInfo build() {
			return new EmployeeManualCovidTaxInfo(this);
		}

	}
 	
}
