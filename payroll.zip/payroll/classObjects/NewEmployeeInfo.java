package payroll.classObjects;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.time.LocalDate;
import java.util.List;

@Accessors(chain = true)
@Getter
@Setter
public class NewEmployeeInfo {

    private String lastName;
    private String firstName;
    private String address1;
    private String city;
    private String state;
    private String zip;
    private String status;
    private String ssn;
    private LocalDate hiredDate;
    private LocalDate birthDate;
    private LocalDate medicalInsuranceQualifyDate;
    private String gender;
    private String acaClassification;
    private List<GenericField> genericFieldList;

}
