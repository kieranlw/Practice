package payroll.classObjects;

public class PaySummary_StateSummary {

    private String state;
    private String taxCode;
    private DollarCurrency taxableGross;
    private DollarCurrency tax;

    public String getState() {
        return state;
    }

    public String getTaxCode() {
        return taxCode;
    }

    public DollarCurrency getTaxableGross() {
        return taxableGross;
    }

    public DollarCurrency getTax() {
        return tax;
    }

    private PaySummary_StateSummary(Builder builder) {
        state = builder.state;
        taxCode = builder.taxCode;
        taxableGross = builder.taxableGross;
        tax = builder.tax;
    }

    public static PaySummary_StateSummary.Builder builder() {
        return new PaySummary_StateSummary.Builder();
    }

    public static class Builder {
        private String state;
        private String taxCode;
        private DollarCurrency taxableGross;
        private DollarCurrency tax;

        public Builder setState(String state) {
            this.state = state;
            return this;
        }

        public Builder setTaxCode(String taxCode) {
            this.taxCode = taxCode;
            return this;
        }

        public Builder setTaxableGross(DollarCurrency taxableGross) {
            this.taxableGross = taxableGross;
            return this;
        }

        public Builder setTax(DollarCurrency tax) {
            this.tax = tax;
            return this;
        }

        private Builder() {
        }

        public PaySummary_StateSummary build() {
            return new PaySummary_StateSummary(this);
        }
    }
}
