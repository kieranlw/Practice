package payroll.classObjects;

public class PaySummary_FederalTaxSummary {

    private DollarCurrency ficaSSTaxable;
    private DollarCurrency ficaSSErTax;
    private DollarCurrency ficaSSEeTax;
    private DollarCurrency ficaSSErDeferredTax;
    private DollarCurrency ficaMedTaxable;
    private DollarCurrency ficaMedErTax;
    private DollarCurrency ficaMedEeTax;
    private DollarCurrency fitTaxable;
    private DollarCurrency fitEeTax;
    private DollarCurrency viFitTaxable;
    private DollarCurrency viFitEeTax;
    private DollarCurrency futaTaxable;
    private DollarCurrency futaErTax;
    private DollarCurrency ficaUncollectedErTax;
    private DollarCurrency ficaTpSickTaxable;
    private DollarCurrency ficaTpSickErTax;
    private DollarCurrency total941;
    private DollarCurrency form7200;

    public DollarCurrency getFicaSSTaxable() {
        return ficaSSTaxable;
    }

    public DollarCurrency getFicaSSErTax() {
        return ficaSSErTax;
    }

    public DollarCurrency getFicaSSEeTax() {
        return ficaSSEeTax;
    }

    public DollarCurrency getFicaSSErDeferredTax() {
        return ficaSSErDeferredTax;
    }

    public DollarCurrency getFicaMedTaxable() {
        return ficaMedTaxable;
    }

    public DollarCurrency getFicaMedErTax() {
        return ficaMedErTax;
    }

    public DollarCurrency getFicaMedEeTax() {
        return ficaMedEeTax;
    }

    public DollarCurrency getFitTaxable() {
        return fitTaxable;
    }

    public DollarCurrency getFitEeTax() {
        return fitEeTax;
    }

    public DollarCurrency getViFitTaxable() {
        return viFitTaxable;
    }

    public DollarCurrency getViFitEeTax() {
        return viFitEeTax;
    }

    public DollarCurrency getFutaTaxable() {
        return futaTaxable;
    }

    public DollarCurrency getFutaErTax() {
        return futaErTax;
    }

    public DollarCurrency getFicaUncollectedErTax() {
        return ficaUncollectedErTax;
    }

    public DollarCurrency getFicaTpSickTaxable() {
        return ficaTpSickTaxable;
    }

    public DollarCurrency getFicaTpSickErTax() {
        return ficaTpSickErTax;
    }

    public DollarCurrency getTotal941() {
        return total941;
    }

    public DollarCurrency getForm7200() {
        return form7200;
    }

    public PaySummary_FederalTaxSummary setForm7200(DollarCurrency form7200) {
        this.form7200 = form7200;
        return this;
    }

    public PaySummary_FederalTaxSummary setFicaSSTaxable(DollarCurrency ficaSSTaxable) {
        this.ficaSSTaxable = ficaSSTaxable;
        return this;
    }

    public PaySummary_FederalTaxSummary setFicaSSErTax(DollarCurrency ficaSSErTax) {
        this.ficaSSErTax = ficaSSErTax;
        return this;
    }

    public PaySummary_FederalTaxSummary setFicaSSEeTax(DollarCurrency ficaSSEeTax) {
        this.ficaSSEeTax = ficaSSEeTax;
        return this;
    }

    public PaySummary_FederalTaxSummary setFicaSSErDeferredTax(DollarCurrency ficaSSErDeferredTax) {
        this.ficaSSErDeferredTax = ficaSSErDeferredTax;
        return this;
    }

    public PaySummary_FederalTaxSummary setFicaMedTaxable(DollarCurrency ficaMedTaxable) {
        this.ficaMedTaxable = ficaMedTaxable;
        return this;
    }

    public PaySummary_FederalTaxSummary setFicaMedErTax(DollarCurrency ficaMedErTax) {
        this.ficaMedErTax = ficaMedErTax;
        return this;
    }

    public PaySummary_FederalTaxSummary setFicaMedEeTax(DollarCurrency ficaMedEeTax) {
        this.ficaMedEeTax = ficaMedEeTax;
        return this;
    }

    public PaySummary_FederalTaxSummary setFitTaxable(DollarCurrency fitTaxable) {
        this.fitTaxable = fitTaxable;
        return this;
    }

    public PaySummary_FederalTaxSummary setFitEeTax(DollarCurrency fitEeTax) {
        this.fitEeTax = fitEeTax;
        return this;
    }

    public PaySummary_FederalTaxSummary setViFitTaxable(DollarCurrency viFitTaxable) {
        this.viFitTaxable = viFitTaxable;
        return this;
    }

    public PaySummary_FederalTaxSummary setViFitEeTax(DollarCurrency viFitEeTax) {
        this.viFitEeTax = viFitEeTax;
        return this;
    }

    public PaySummary_FederalTaxSummary setFutaTaxable(DollarCurrency futaTaxable) {
        this.futaTaxable = futaTaxable;
        return this;
    }

    public PaySummary_FederalTaxSummary setFutaErTax(DollarCurrency futaErTax) {
        this.futaErTax = futaErTax;
        return this;
    }

    public PaySummary_FederalTaxSummary setFicaUncollectedErTax(DollarCurrency ficaUncollectedErTax) {
        this.ficaUncollectedErTax = ficaUncollectedErTax;
        return this;
    }

    public PaySummary_FederalTaxSummary setFicaTpSickTaxable(DollarCurrency ficaTpSickTaxable) {
        this.ficaTpSickTaxable = ficaTpSickTaxable;
        return this;
    }

    public PaySummary_FederalTaxSummary setFicaTpSickErTax(DollarCurrency ficaTpSickErTax) {
        this.ficaTpSickErTax = ficaTpSickErTax;
        return this;
    }

    public PaySummary_FederalTaxSummary setTotal941(DollarCurrency total941) {
        this.total941 = total941;
        return this;
    }

    public PaySummary_FederalTaxSummary getReverseFields(){
        PaySummary_FederalTaxSummary newFederalTaxSummary = new PaySummary_FederalTaxSummary()
                .setFicaSSTaxable(DollarCurrency.setDollarCurrency(-ficaSSTaxable.getAmount()))
                .setFicaSSErTax(DollarCurrency.setDollarCurrency(-ficaSSErTax.getAmount()))
                .setFicaSSEeTax(DollarCurrency.setDollarCurrency(-ficaSSEeTax.getAmount()))
                .setFicaSSErDeferredTax(DollarCurrency.setDollarCurrency(-ficaSSErDeferredTax.getAmount()))
                .setFicaMedTaxable(DollarCurrency.setDollarCurrency(-ficaMedTaxable.getAmount()))
                .setFicaMedErTax(DollarCurrency.setDollarCurrency(-ficaMedErTax.getAmount()))
                .setFicaMedEeTax(DollarCurrency.setDollarCurrency(-ficaMedEeTax.getAmount()))
                .setFitTaxable(DollarCurrency.setDollarCurrency(-fitTaxable.getAmount()))
                .setFitEeTax(DollarCurrency.setDollarCurrency(-fitEeTax.getAmount()))
                .setViFitTaxable(DollarCurrency.setDollarCurrency(-viFitTaxable.getAmount()))
                .setViFitEeTax(DollarCurrency.setDollarCurrency(-viFitEeTax.getAmount()))
                .setFutaTaxable(DollarCurrency.setDollarCurrency(-futaTaxable.getAmount()))
                .setFutaErTax(DollarCurrency.setDollarCurrency(-futaErTax.getAmount()))
                .setFicaUncollectedErTax(DollarCurrency.setDollarCurrency(-ficaUncollectedErTax.getAmount()))
                .setFicaTpSickTaxable(DollarCurrency.setDollarCurrency(-ficaTpSickTaxable.getAmount()))
                .setFicaTpSickErTax(DollarCurrency.setDollarCurrency(-ficaTpSickErTax.getAmount()))
                .setTotal941(DollarCurrency.setDollarCurrency(-total941.getAmount()));

        return newFederalTaxSummary;
    }


}
