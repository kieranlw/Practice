package payroll.classObjects;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RoleDetailsInfo {

    private String roleName,
            description,
            copyPrivilegesForm;
}
