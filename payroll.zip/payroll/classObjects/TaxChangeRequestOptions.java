package payroll.classObjects;

public class TaxChangeRequestOptions {

    private Boolean reopenFederal;
    private String reopenFederalNotes;
    private Boolean reopenResidingState;
    private String reopenResidingStateNotes;
    private Boolean reopenWorkingState;
    private String reopenWorkingStateNotes;

    public Boolean getReopenFederal() {
        return reopenFederal;
    }

    public TaxChangeRequestOptions setReopenFederal(boolean reopenFederal) {
        this.reopenFederal = reopenFederal;
        return this;
    }

    public String getReopenFederalNotes() {
        return reopenFederalNotes;
    }

    public TaxChangeRequestOptions setReopenFederalNotes(String reopenFederalNotes) {
        this.reopenFederalNotes = reopenFederalNotes;
        return this;
    }

    public Boolean getReopenResidingState() {
        return reopenResidingState;
    }

    public TaxChangeRequestOptions setReopenResidingState(boolean reopenResidingState) {
        this.reopenResidingState = reopenResidingState;
        return this;
    }

    public String getReopenResidingStateNotes() {
        return reopenResidingStateNotes;
    }

    public TaxChangeRequestOptions setReopenResidingStateNotes(String reopenResidingStateNotes) {
        this.reopenResidingStateNotes = reopenResidingStateNotes;
        return this;
    }

    public Boolean getReopenWorkingState() {
        return reopenWorkingState;
    }

    public TaxChangeRequestOptions setReopenWorkingState(boolean reopenWorkingState) {
        this.reopenWorkingState = reopenWorkingState;
        return this;
    }

    public String getReopenWorkingStateNotes() {
        return reopenWorkingStateNotes;
    }

    public TaxChangeRequestOptions setReopenWorkingStateNotes(String reopenWorkingStateNotes) {
        this.reopenWorkingStateNotes = reopenWorkingStateNotes;
        return this;
    }
}
