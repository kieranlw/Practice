package payroll.classObjects;

import utils2.JavaTimeUtils;

import java.time.LocalDate;

public class Payroll_StartNewPayroll {

    //TODO: update these to LocalDate
    private LocalDate periodEndDate;
    private LocalDate payDate;

    private static final String DATE_FORMAT = "MM/dd/yyyy";

    public String getPeriodEndDate() {
        return JavaTimeUtils.getLocalDateString(periodEndDate, DATE_FORMAT);
    }

    public LocalDate getPeriodEndLocalDate() {
        return periodEndDate;
    }

    public String getPayDate() {
        return JavaTimeUtils.getLocalDateString(payDate, DATE_FORMAT);
    }

    public LocalDate getLocalPayDate() {
        return payDate;
    }



    private Payroll_StartNewPayroll(Builder builder) {
        periodEndDate = builder.periodEndDate;
        payDate = builder.payDate;
    }

    public static Payroll_StartNewPayroll.Builder builder() {
        return new Payroll_StartNewPayroll.Builder();
    }

    public static class Builder {
        private LocalDate periodEndDate;
        private LocalDate payDate;

        public Payroll_StartNewPayroll.Builder setPeriodEndDate(String periodEndDate) {
            this.periodEndDate = JavaTimeUtils.getLocalDate(periodEndDate, DATE_FORMAT);
            return this;
        }

        public Payroll_StartNewPayroll.Builder setPeriodEndDate(LocalDate periodEndDate) {
            this.periodEndDate = periodEndDate;
            return this;
        }

        public Payroll_StartNewPayroll.Builder setPayDate(LocalDate payDate) {
            this.payDate =  payDate;
            return this;
        }

        public Payroll_StartNewPayroll.Builder setPayDate(String payDate) {
            this.payDate = JavaTimeUtils.getLocalDate(payDate, DATE_FORMAT);
            return this;
        }

        private Builder() {
        }

        public Payroll_StartNewPayroll build() {
            return new Payroll_StartNewPayroll(this);
        }
    }
}
