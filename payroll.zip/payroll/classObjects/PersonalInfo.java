package payroll.classObjects;

public class PersonalInfo {

    private final String firstName;
    private final String middleName;
    private final String lastName;
    private final String suffix;
    private final String sSN;
    private final String socialSecurityNumber;
    private final String streetAddress1;
    private final String streetAddress2;
    private final String city;
    private final String state;
    private final String zipCode;
    private final String zipCode4;
    private final boolean addForeignAddress;
    private final String foreignAddress1;
    private final String foreignAddress2;
    private final String foreignAddress3;
    private final String phone;
    private final String birthday;
    private final String gender;
    private final String terminationDate;
    private final String reHiredDate;

    private PersonalInfo(Builder builder) {
        firstName = builder.firstName;
        middleName = builder.middleName;
        lastName = builder.lastName;
        suffix = builder.suffix;
        sSN = builder.sSN;
        socialSecurityNumber = builder.socialSecurityNumber;
        streetAddress1 = builder.streetAddress1;
        streetAddress2 = builder.streetAddress2;
        city = builder.city;
        state = builder.state;
        zipCode = builder.zipCode;
        zipCode4 = builder.zipCode4;
        addForeignAddress = builder.addForeignAddress;
        foreignAddress1 = builder.foreignAddress1;
        foreignAddress2 = builder.foreignAddress2;
        foreignAddress3 = builder.foreignAddress3;
        phone = builder.phone;
        birthday = builder.birthday;
        gender = builder.gender;
        terminationDate = builder.terminationDate;
        reHiredDate = builder.reHiredDate;
    }

    public static PersonalInfo.Builder builder() {
        return new PersonalInfo.Builder();
    }

    public String getFirstName() {
        return firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getSuffix() {
        return suffix;
    }

    public String getsSN() {
        return sSN;
    }

    public String getSocialSecurityNumber() {
        return socialSecurityNumber;
    }

    public String getStreetAddress1() {
        return streetAddress1;
    }

    public String getStreetAddress2() {
        return streetAddress2;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public String getZipCode4() { return zipCode4; }

    public boolean isAddForeignAddress() {
        return addForeignAddress;
    }

    public String getForeignAddress1() {
        return foreignAddress1;
    }

    public String getForeignAddress2() {
        return foreignAddress2;
    }

    public String getForeignAddress3() {
        return foreignAddress3;
    }

    public String getPhone() {
        return phone;
    }

    public String getBirthday() {
        return birthday;
    }

    public String getGender() {
        return gender;
    }

    public String getTerminationDate() { return terminationDate; }

    public String getReHiredDate() { return reHiredDate; }

    public String getAddressFormmatted() {
        return streetAddress1 + "\n" + streetAddress2 + "\n" + city + ", " + state + " " + zipCode;
    }

    public String getAddressFormmattedZip4() {
        return streetAddress1 + "\n" + streetAddress2 + "\n" + city + ", " + state + " " + zipCode + " " + zipCode4;
    }

    public String getAddressFormmattedWithName() {
        return firstName + " " + lastName + "\n" + streetAddress1 + "\n" + streetAddress2 + "\n" + city + ", " + state + " " + zipCode;
    }

    public String getLastNameFirstNameFormatted() {
        return lastName + ", " + firstName;
    }

    @Override
    public String toString() {
        return firstName + " " + lastName;
    }

    public static class Builder {
        private String firstName;
        private String middleName;
        private String lastName;
        private String suffix;
        private String sSN;
        private String socialSecurityNumber;
        private String streetAddress1;
        private String streetAddress2;
        private String city;
        private String state;
        private String zipCode;
        private String zipCode4;
        private boolean addForeignAddress;
        private String foreignAddress1;
        private String foreignAddress2;
        private String foreignAddress3;
        private String phone;
        private String birthday;
        private String gender;
        private String terminationDate;
        private String reHiredDate;

        private Builder() {
        }

        public Builder setFirstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder setMiddleName(String middleName) {
            this.middleName = middleName;
            return this;
        }

        public Builder setLastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder setSuffix(String suffix) {
            this.suffix = suffix;
            return this;
        }

        public Builder setsSN(String sSN) {
            this.sSN = sSN;
            return this;
        }

        public Builder setSocialSecurityNumber(String socialSecurityNumber) {
            this.socialSecurityNumber = socialSecurityNumber;
            return this;
        }

        public Builder setStreetAddress1(String streetAddress1) {
            this.streetAddress1 = streetAddress1;
            return this;
        }

        public Builder setStreetAddress2(String streetAddress2) {
            this.streetAddress2 = streetAddress2;
            return this;
        }

        public Builder setCity(String city) {
            this.city = city;
            return this;
        }

        public Builder setState(String state) {
            this.state = state;
            return this;
        }

        public Builder setZipCode(String zipCode) {
            this.zipCode = zipCode;
            return this;
        }

        public Builder setZipCode4(String zipCode4) {
            this.zipCode4 = zipCode4;
            return this;
        }

        public Builder setAddForeignAddress(boolean addForeignAddress) {
            this.addForeignAddress = addForeignAddress;
            return this;
        }

        public Builder setForeignAddress1(String foreignAddress1) {
            this.foreignAddress1 = foreignAddress1;
            return this;
        }

        public Builder setForeignAddress2(String foreignAddress2) {
            this.foreignAddress2 = foreignAddress2;
            return this;
        }

        public Builder setForeignAddress3(String foreignAddress3) {
            this.foreignAddress3 = foreignAddress3;
            return this;
        }

        public Builder setPhone(String phone) {
            this.phone = phone;
            return this;
        }

        public Builder setBirthday(String birthday) {
            this.birthday = birthday;
            return this;
        }

        public Builder setGender(String gender) {
            this.gender = gender;
            return this;
        }

        public Builder setTerminationDate(String terminationDate) {
            this.terminationDate = terminationDate;
            return this;
        }

        public Builder setReHiredDate(String reHiredDate) {
            this.reHiredDate = reHiredDate;
            return this;
        }

        public PersonalInfo build() {
            return new PersonalInfo(this);
        }
    }
}
