package payroll.classObjects;

public class WitholdingEmployeeInfo {

    private String employee;
    private String additionalWHOption;
    private String additionalWHAmount;

    public String getEmployee() {
        return employee;
    }

    public WitholdingEmployeeInfo setEmployee(String employee) {
        this.employee = employee;
        return this;
    }

    public String getAdditionalWHOption() {
        return additionalWHOption;
    }

    public WitholdingEmployeeInfo setAdditionalWHOption(String additionalWHOption) {
        this.additionalWHOption = additionalWHOption;
        return this;
    }

    public String getAdditionalWHAmount() {
        return additionalWHAmount;
    }

    public WitholdingEmployeeInfo setAdditionalWHAmount(String additionalWHAmount) {
        this.additionalWHAmount = additionalWHAmount;
        return this;
    }
}
