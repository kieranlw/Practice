package payroll.classObjects;

public class Report_ChartOfAccountsReport {

	private boolean showBlanksForEveryDepartment;
	private boolean showBlanksForEveryJobCode;
	private boolean includeBlanksForLiabilityTypes;
	private String exportTo;

	public boolean getShowBlanksForEveryDepartment() {
		return showBlanksForEveryDepartment;
	}

	public boolean getShowBlanksForEveryJobCode() {
		return showBlanksForEveryJobCode;
	}

	public boolean getIncludeBlanksForLiabilityTypes() {
		return includeBlanksForLiabilityTypes;
	}

	public String getExportTo() {
		return exportTo;
	}



	private Report_ChartOfAccountsReport(Builder builder) {
		showBlanksForEveryDepartment = builder.showBlanksForEveryDepartment == null ? false : builder.showBlanksForEveryDepartment;
		showBlanksForEveryJobCode = builder.showBlanksForEveryJobCode  == null ? false : builder.showBlanksForEveryJobCode;
		includeBlanksForLiabilityTypes = builder.includeBlanksForLiabilityTypes == null ? false : builder.includeBlanksForLiabilityTypes;
		exportTo = builder.exportTo;
	}

	public static Report_ChartOfAccountsReport.Builder builder(){
		return new Report_ChartOfAccountsReport.Builder();
	}


	public static class Builder {
		private Boolean showBlanksForEveryDepartment;
		private Boolean showBlanksForEveryJobCode;
		private Boolean includeBlanksForLiabilityTypes;
		private String exportTo;

		public Builder setShowBlanksForEveryDepartment(boolean showBlanksForEveryDepartment) {
			this.showBlanksForEveryDepartment = showBlanksForEveryDepartment;
			return this;
		}

		public Builder setShowBlanksForEveryJobCode(boolean showBlanksForEveryJobCode) {
			this.showBlanksForEveryJobCode = showBlanksForEveryJobCode;
			return this;
		}

		public Builder setIncludeBlanksForLiabilityTypes(boolean includeBlanksForLiabilityTypes) {
			this.includeBlanksForLiabilityTypes = includeBlanksForLiabilityTypes;
			return this;
		}

		public Builder setExportTo(String exportTo) {
			this.exportTo = exportTo;
			return this;
		}

		private Builder() {
		}

		public Report_ChartOfAccountsReport build() {
			return new Report_ChartOfAccountsReport(this);
		}

	}
 	
}
