package payroll.classObjects;

import java.time.LocalDate;

public class NewStateInfo {

    private String state;
    private String sitStatus;
    private String unemploymentStatus;
    private LocalDate dateAdded;

    public String getState() {
        return state;
    }

    public NewStateInfo setState(String state) {
        this.state = state;
        return this;
    }

    public String getSitStatus() {
        return sitStatus;
    }

    public NewStateInfo setSitStatus(String sitStatus) {
        this.sitStatus = sitStatus;
        return this;
    }

    public String getUnemploymentStatus() {
        return unemploymentStatus;
    }

    public NewStateInfo setUnemploymentStatus(String unemploymentStatus) {
        this.unemploymentStatus = unemploymentStatus;
        return this;
    }

    public LocalDate getDateAdded() {
        return dateAdded;
    }

    public NewStateInfo setDateAdded(LocalDate dateAdded) {
        this.dateAdded = dateAdded;
        return this;
    }

}
