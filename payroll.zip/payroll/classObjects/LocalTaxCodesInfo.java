package payroll.classObjects;

public class LocalTaxCodesInfo {


        private String state;
        private String partialTaxCode;
        private String description;



        public String getState() {
            return state;
        }

        public String getPartialTaxCode() {
            return partialTaxCode;
        }

        public String getDescription() {
            return description;
        }



        @Override
        public String toString(){
            String text = getDescription() == null ? getState() : getDescription();
            text = text == null ? getPartialTaxCode() : text;
            return "Local Tax Info for " + text ;
        }

        private LocalTaxCodesInfo(Builder builder) {
            state = builder.state;
            partialTaxCode = builder.partialTaxCode;
            description = builder.description;

        }

        public static LocalTaxCodesInfo.Builder builder() {
            return new LocalTaxCodesInfo.Builder();
        }


        public static class Builder {

            private String state;
            private String partialTaxCode;
            private String description;

            public Builder setState(String state) {
                this.state = state;
                return this;
            }

            public Builder setPartialTaxCode(String partialTaxCode) {
                this.partialTaxCode = partialTaxCode;
                return this;
            }


            public Builder setDescription(String description) {
                this.description = description;
                return this;
            }




            private Builder() {
            }

            public LocalTaxCodesInfo build() {
                return new LocalTaxCodesInfo(this);
            }

        }

    }

