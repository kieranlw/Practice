package payroll.classObjects;

import java.time.LocalDate;

public class PTSInfo {

    private final String databaseName;
    private final LocalDate startPayDate;
    private final LocalDate endPayDate;

    private PTSInfo(Builder builder) {
        databaseName = builder.databaseName;
        startPayDate = builder.startPayDate;
        endPayDate = builder.endPayDate;
    }

    public static PTSInfo.Builder builder() {
        return new PTSInfo.Builder();
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public LocalDate getStartPayDate() {
        return startPayDate;
    }

    public LocalDate getEndPayDate() {
        return endPayDate;
    }

    public static class Builder {
        private String databaseName;
        private LocalDate startPayDate;
        private LocalDate endPayDate;

        private Builder() {
        }

        public Builder setDatabaseName(String databaseName) {
            this.databaseName = databaseName;
            return this;
        }

        public Builder setStartPayDate(LocalDate startPayDate) {
            this.startPayDate = startPayDate;
            return this;
        }

        public Builder setEndPayDate(LocalDate endPayDate) {
            this.endPayDate = endPayDate;
            return this;
        }

        public PTSInfo build() {
            return new PTSInfo(this);
        }
    }
}
