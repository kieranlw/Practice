package payroll.classObjects;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class SelectEmployeesToPayInfo {

    private String defaultDepartment,
            employeeStatus,
            payFrequency,
            payType;
}
