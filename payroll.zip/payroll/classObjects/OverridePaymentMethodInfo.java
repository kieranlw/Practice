package payroll.classObjects;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class OverridePaymentMethodInfo {
    private String payStatus;
    private String payFrequency;
}
