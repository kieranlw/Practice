package payroll.classObjects;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PrintSingleW2Info {

    private String year,
            employees,
            billDate;
    private boolean isBillableRerun,
            isNonBillable,
            billable;
}
