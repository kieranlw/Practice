package payroll.classObjects;

public class BenefitDetailInfo {

	private String relatedDeduction;
	private DollarCurrency accruedAmount;

	public String getRelatedDeduction() {
		return relatedDeduction;
	}

	public DollarCurrency getAccruedAmount() {
		return accruedAmount;
	}

	private BenefitDetailInfo(Builder builder) {
		this.relatedDeduction = builder.relatedDeduction;
		this.accruedAmount = builder.accruedAmount;

	}

	public static BenefitDetailInfo.Builder builder() {
		return new BenefitDetailInfo.Builder();
	}


	public static class Builder {
		private String relatedDeduction;
		private DollarCurrency accruedAmount;

		public Builder setAccruedAmount(DollarCurrency accruedAmount) {
			this.accruedAmount = accruedAmount;
			return this;
		}


		public Builder setRelatedDeduction(String relatedDeduction) {
			this.relatedDeduction = relatedDeduction;
			return this;
		}


		private Builder() {
		}

		public BenefitDetailInfo build() {
			return new BenefitDetailInfo(this);
		}

	}
 	
}
