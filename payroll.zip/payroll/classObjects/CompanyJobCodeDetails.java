package payroll.classObjects;

import payroll.classObjects.jobCodes.ElectronicLocation;

public class CompanyJobCodeDetails {

    private String number;
    private String description;
    private boolean isActive;
    private boolean isHideSalary;
    private boolean isCertifiedJob;
    private String projectName;
    private String projectLocation;
    private String projectContractNumber;
    private String determinationNumber;
    private String jobStartDate;
    private String jobEndDate;
    private ElectronicLocation electronicLocation;
    private String workClassificationRate;
    private String certifiedStartDate;
    private boolean isPrintWH347;
    private String profiles;
    private String signatoryParty;
    private String signorTitle;
    private boolean isFringePaidToApprovedPlan;
    private boolean isFringePaidToCash;
    private String exceptions;
    private String remarks;

    public static class Builder {
        private String number;
        private String description;
        private boolean isActive;
        private boolean isHideSalary;
        private boolean isCertifiedJob;
        private String projectName;
        private String projectLocation;
        private String projectContractNumber;
        private String determinationNumber;
        private String jobStartDate;
        private String jobEndDate;
        private ElectronicLocation electronicLocation;
        private String workClassificationRate;
        private String certifiedStartDate;
        private boolean isPrintWH347;
        private String profiles;
        private String signatoryParty;
        private String signorTitle;
        private boolean isFringePaidToApprovedPlan;
        private boolean isFringePaidToCash;
        private String exceptions;
        private String remarks;

        public Builder() { }

        Builder(String number, String description, boolean isActive, boolean isHideSalary, boolean isCertifiedJob, String projectName, String projectLocation, String projectContractNumber,
                String determinationNumber, String jobStartDate, String jobEndDate, ElectronicLocation electronicLocation, String workClassificationRate, String certifiedStartDate, boolean isPrintWH347,
                String profiles, String signatoryParty, String signorTitle, boolean isFringePaidToApprovedPlan, boolean isFringePaidToCash, String exceptions, String remarks) {
            this.number = number;
            this.description = description;
            this.isActive = isActive;
            this.isHideSalary = isHideSalary;
            this.isCertifiedJob = isCertifiedJob;
            this.projectName = projectName;
            this.projectLocation = projectLocation;
            this.projectContractNumber = projectContractNumber;
            this.determinationNumber = determinationNumber;
            this.jobStartDate = jobStartDate;
            this.jobEndDate = jobEndDate;
            this.electronicLocation = electronicLocation;
            this.workClassificationRate = workClassificationRate;
            this.certifiedStartDate = certifiedStartDate;
            this.isPrintWH347 = isPrintWH347;
            this.profiles = profiles;
            this.signatoryParty = signatoryParty;
            this.signorTitle = signorTitle;
            this.isFringePaidToApprovedPlan = isFringePaidToApprovedPlan;
            this.isFringePaidToCash = isFringePaidToCash;
            this.exceptions = exceptions;
            this.remarks = remarks;
        }

        public Builder number(String number) {
            this.number = number;
            return Builder.this;
        }

        public Builder description(String description) {
            this.description = description;
            return Builder.this;
        }

        public Builder isActive(boolean isActive) {
            this.isActive = isActive;
            return Builder.this;
        }

        public Builder isHideSalary(boolean isHideSalary) {
            this.isHideSalary = isHideSalary;
            return Builder.this;
        }

        public Builder isCertifiedJob(boolean isCertifiedJob) {
            this.isCertifiedJob = isCertifiedJob;
            return Builder.this;
        }

        public Builder projectName(String projectName) {
            this.projectName = projectName;
            return Builder.this;
        }

        public Builder projectLocation(String projectLocation) {
            this.projectLocation = projectLocation;
            return Builder.this;
        }

        public Builder projectContractNumber(String projectContractNumber) {
            this.projectContractNumber = projectContractNumber;
            return Builder.this;
        }

        public Builder determinationNumber(String determinationNumber) {
            this.determinationNumber = determinationNumber;
            return Builder.this;
        }

        public Builder jobStartDate(String jobStartDate) {
            this.jobStartDate = jobStartDate;
            return Builder.this;
        }

        public Builder jobEndDate(String jobEndDate) {
            this.jobEndDate = jobEndDate;
            return Builder.this;
        }

        public Builder electronicLocation(ElectronicLocation electronicLocation) {
            this.electronicLocation = electronicLocation;
            return CompanyJobCodeDetails.Builder.this;
        }
//        public CompanyBenefitsDetails.Builder adjustmentFrequency(AdjustmentFrequencies adjustmentFrequency) {
//            this.adjustmentFrequency = adjustmentFrequency;
//            return CompanyBenefitsDetails.Builder.this;

        public Builder workClassificationRate(String workClassificationRate) {
            this.workClassificationRate = workClassificationRate;
            return Builder.this;
        }

        public Builder certifiedStartDate(String certifiedStartDate) {
            this.certifiedStartDate = certifiedStartDate;
            return Builder.this;
        }

        public Builder isPrintWH347(boolean isPrintWH347) {
            this.isPrintWH347 = isPrintWH347;
            return Builder.this;
        }

        public Builder profiles(String profiles) {
            this.profiles = profiles;
            return Builder.this;
        }

        public Builder signatoryParty(String signatoryParty) {
            this.signatoryParty = signatoryParty;
            return Builder.this;
        }

        public Builder signorTitle(String signorTitle) {
            this.signorTitle = signorTitle;
            return Builder.this;
        }

        public Builder isFringePaidToApprovedPlan(boolean isFringePaidToApprovedPlan) {
            this.isFringePaidToApprovedPlan = isFringePaidToApprovedPlan;
            return Builder.this;
        }

        public Builder isFringePaidToCash(boolean isFringePaidToCash) {
            this.isFringePaidToCash = isFringePaidToCash;
            return Builder.this;
        }

        public Builder exceptions(String exceptions) {
            this.exceptions = exceptions;
            return Builder.this;
        }

        public Builder remarks(String remarks) {
            this.remarks = remarks;
            return Builder.this;
        }

        public CompanyJobCodeDetails build() {

            return new CompanyJobCodeDetails(this);
        }
    }

    private CompanyJobCodeDetails(Builder builder) {
        this.number = builder.number;
        this.description = builder.description;
        this.isActive = builder.isActive;
        this.isHideSalary = builder.isHideSalary;
        this.isCertifiedJob = builder.isCertifiedJob;
        this.projectName = builder.projectName;
        this.projectLocation = builder.projectLocation;
        this.projectContractNumber = builder.projectContractNumber;
        this.determinationNumber = builder.determinationNumber;
        this.jobStartDate = builder.jobStartDate;
        this.jobEndDate = builder.jobEndDate;
        this.electronicLocation = builder.electronicLocation;
        this.workClassificationRate = builder.workClassificationRate;
        this.certifiedStartDate = builder.certifiedStartDate;
        this.isPrintWH347 = builder.isPrintWH347;
        this.profiles = builder.profiles;
        this.signatoryParty = builder.signatoryParty;
        this.signorTitle = builder.signorTitle;
        this.isFringePaidToApprovedPlan = builder.isFringePaidToApprovedPlan;
        this.isFringePaidToCash = builder.isFringePaidToCash;
        this.exceptions = builder.exceptions;
        this.remarks = builder.remarks;
    }

    public String getNumber() {
        return number;
    }

    public String getDescription() {
        return description;
    }

    public boolean isActive() {
        return isActive;
    }

    public boolean isHideSalary() {
        return isHideSalary;
    }

    public boolean isCertifiedJob() {
        return isCertifiedJob;
    }

    public String getProjectName() {
        return projectName;
    }

    public String getProjectLocation() {
        return projectLocation;
    }

    public String getProjectContractNumber() {
        return projectContractNumber;
    }

    public String getDeterminationNumber() {
        return determinationNumber;
    }

    public String getJobStartDate() {
        return jobStartDate;
    }

    public String getJobEndDate() {
        return jobEndDate;
    }

    public ElectronicLocation getElectronicLocation() {
        return electronicLocation;
    }

    public String getWorkClassificationRate() {
        return workClassificationRate;
    }

    public String getCertifiedStartDate() {
        return certifiedStartDate;
    }

    public boolean isPrintWH347() {
        return isPrintWH347;
    }

    public String getProfiles() {
        return profiles;
    }

    public String getSignatoryParty() {
        return signatoryParty;
    }

    public String getSignorTitle() {
        return signorTitle;
    }

    public boolean isFringePaidToApprovedPlan() {
        return isFringePaidToApprovedPlan;
    }

    public boolean isFringePaidToCash() {
        return isFringePaidToCash;
    }

    public String getExceptions() {
        return exceptions;
    }

    public String getRemarks() {
        return remarks;
    }
}

