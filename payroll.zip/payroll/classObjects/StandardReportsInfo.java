package payroll.classObjects;

import common.DateFormats;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
@Data
@Builder(setterPrefix = "set")
public class StandardReportsInfo {

    private String selectReport;
    private String dateRange;
    private String payDate;
    private Boolean showEmployerTaxes;
    private String sortBy;
    private String auditArea;
    private String exportTo;

    public static class StandardReportsInfoBuilder {
        public StandardReportsInfoBuilder setPayDate(LocalDate payDate) {
            this.payDate = payDate.format(DateFormats.MM_DD_YYYY);
            return this;
        }
        public StandardReportsInfoBuilder setPayDate(String payDate) {
            this.payDate = payDate;
            return this;
        }
    }

}
