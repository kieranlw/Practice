package payroll.classObjects;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

public class DollarCurrency {

    private double amount;

    private DollarCurrency(double amount) {
        if(amount == -0.0){
            this.amount = 0.0;
        }else {
            this.amount = amount;
        }
    }

    public static DollarCurrency setDollarCurrency(double amount){
        return new DollarCurrency(amount);
    }

    public String getDoubleAsString2Decimals(){
        DecimalFormat df = new DecimalFormat("#0.00");
        return df.format(amount);
    }

    public String getCurrencyFormatted() {
        NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US);
        String formattedAmount = format.format(amount);
        if(amount >= 0) {
            return formattedAmount;
        }else{
            return "-" + formattedAmount.replace("(", "").replace(")", "");
        }
    }

    @Override
    public String toString() {
        return String.valueOf(amount);
    }

    public double getAmount() {
        return amount;
    }
}
