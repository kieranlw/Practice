package payroll.classObjects;

public class CompanyDepartmentDetails {

    private String number;
    private String description;
    private boolean isActive;
    private boolean isHideSalary;
    private String overrideName;
    private String overrideAddr1;
    private String unemploymentState;
    private String defaultWorkLocation;
    private String workCompCode1;
    private String workCompRate;

    public static class Builder {

        private String number;
        private String description;
        private boolean isActive;
        private boolean isHideSalary;
        private String overrideName;
        private String overrideAddr1;
        private String unemploymentState;
        private String defaultWorkLocation;
        private String workCompCode1;
        private String workCompRate;

        public Builder() {
        }

        Builder(String number, String description, boolean isActive, boolean isHideSalary, String overrideName, String overrideAddr1, String unemploymentState, String defaultWorkLocation, String workCompCode1, String workCompRate) {
            this.number = number;
            this.description = description;
            this.isActive = isActive;
            this.isHideSalary = isHideSalary;
            this.overrideName = overrideName;
            this.overrideName = overrideAddr1;
            this.unemploymentState = unemploymentState;
            this.defaultWorkLocation = defaultWorkLocation;
            this.workCompCode1 = workCompCode1;
            this.workCompRate = workCompRate;
        }

        public Builder number(String number){
            this.number = number;
            return Builder.this;
        }

        public Builder description(String description){
            this.description = description;
            return Builder.this;
        }

        public Builder isActive(boolean isActive){
            this.isActive = isActive;
            return Builder.this;
        }

        public Builder isHideSalary(boolean isHideSalary){
            this.isHideSalary = isHideSalary;
            return Builder.this;
        }

        public Builder overrideName(String overrideName){
            this.overrideName = overrideName;
            return Builder.this;
        }

        public Builder overrideAddr1(String overrideAddr1){
            this.overrideAddr1 = overrideAddr1;
            return Builder.this;
        }

        public Builder unemploymentState(String unemploymentState){
            this.unemploymentState = unemploymentState;
            return Builder.this;
        }

        public Builder defaultWorkLocation(String defaultWorkLocation){
            this.defaultWorkLocation = defaultWorkLocation;
            return Builder.this;
        }

        public Builder workCompCode1(String workCompCode1){
            this.workCompCode1 = workCompCode1;
            return Builder.this;
        }

        public Builder workCompRate(String workCompRate){
            this.workCompRate = workCompRate;
            return Builder.this;
        }

        public CompanyDepartmentDetails build() {

            return new CompanyDepartmentDetails(this);
        }
    }

    private CompanyDepartmentDetails(Builder builder) {
        this.number = builder.number;
        this.description = builder.description;
        this.isActive = builder.isActive;
        this.isHideSalary = builder.isHideSalary;
        this.overrideName = builder.overrideName;
        this.overrideAddr1 = builder.overrideAddr1;
        this.unemploymentState = builder.unemploymentState;
        this.defaultWorkLocation = builder.defaultWorkLocation;
        this.workCompCode1 = builder.workCompCode1;
        this.workCompRate = builder.workCompRate;
    }

    public String getNumber() {
        return number;
    }

    public String getDescription() {
        return description;
    }

    public boolean isActive() {
        return isActive;
    }

    public boolean isHideSalary() {
        return isHideSalary;
    }

    public String getOverrideName() {
        return overrideName;
    }

    public String getOverrideAddr1() {
        return overrideAddr1;
    }

    public String getUnemploymentState() {
        return unemploymentState;
    }

    public String getDefaultWorkLocation() {
        return defaultWorkLocation;
    }

    public String getWorkCompCode1() {
        return workCompCode1;
    }

    public String getWorkCompRate() {
        return workCompRate;
    }
}
