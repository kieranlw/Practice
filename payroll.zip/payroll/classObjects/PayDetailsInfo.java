package payroll.classObjects;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class PayDetailsInfo {

    private String hoursToAutoPay,
            leaveToPay,
            hoursToUse;
}
