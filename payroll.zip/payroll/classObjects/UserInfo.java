package payroll.classObjects;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class UserInfo {

  private String userName;
  private String email;
  private String firstName;
  private String lastName;
  private String csrRole;

}
