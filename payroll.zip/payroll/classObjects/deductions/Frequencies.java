package payroll.classObjects.deductions;

public enum Frequencies {
    FIRST_PAY_OF_MONTH("1st Pay of Month"),
    SECOND_PAY_OF_MONTH("2nd Pay of Month"),
    THIRD_PAY_OF_MONTH("3rd Pay of Month"),
    EVERY_PAY("Every Pay");

    private final String optionName;
    Frequencies(String optionName) {
        this.optionName = optionName;
    }
    public String getOptionName() {
        return optionName;
    }
}
