package payroll.classObjects.deductions;

public enum Types {
    SELECT_ONE("Select One"),
    CUSTOM_RESET("Pre Tax, Custom Reset"),
    RESET_AT_YEAR_END("Pre Tax, Reset at Year End"),
    DEFERRED_COMP("Deferred Comp"),
    AFTER_TAX_REIMBURSEMENT_ADDS_TO_PAY("After Tax Reimbursement (adds to pay)");

    private final String optionName;

    Types(String optionName) {
        this.optionName = optionName;
    }

    public String getOptionName() {
        return optionName;
    }
}
