package payroll.classObjects.deductions;

public enum PercentOfGrossUses {
    SELECT_ONE("Select One"),
    ADJUSTED_GROSS("Adjusted Gross"),
    TRUE_GROSS("True Gross"),
    MASTER_ITEM_GROUP("Master Item Group");

    private final String optionName;

    PercentOfGrossUses(String optionName) {
        this.optionName = optionName;
    }

    public String getOptionName() {
        return optionName;
    }
}
