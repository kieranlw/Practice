package payroll.classObjects.deductions;

public enum Classifications {
    SEP_PLAN("SEP Plan (408k)"),
    WASHINGTON("Washington L&I"),
    BUSINESS_REIMBURSEMENT("Business Exp Reimbursement (adds to pay)"),
    CASH_TIP_MEMO_DEDUCTION("Cash Tip Memo Deduction"),
    CHILD_SUPPORT("Child Support"),
    DEPENDENT_CARE("Dependent Care"),
    CHARGE_TIP_REIMB_DEDUCTION("Charge Tip Reimb Deduction");

    private final String optionName;

    Classifications(String optionName) {
        this.optionName = optionName;
    }

    public String getOptionName() {
        return optionName;
    }
}
