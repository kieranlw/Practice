package payroll.classObjects;

import lombok.Getter;
import utils2.JavaTimeUtils;

import java.time.LocalDate;

public class RunUnscheduledPayroll {

    private LocalDate periodEndDate;
    private LocalDate payDate;
    @Getter
    private boolean priorYearPayroll,
            accruesLeavePay,
            usesStandardDeductionsBenefits,
            blocksFedIncomeTaxes,
            blocksStateLocalIncomeTaxes;
    @Getter
    private String payOfMonth,
            overrideFedRate,
            overrideStateRate;

    private static final String DATE_FORMAT = "MM/dd/yyyy";

    public String getPeriodEndDate() {
        return JavaTimeUtils.getLocalDateString(periodEndDate, DATE_FORMAT);
    }

    public LocalDate getPeriodEndLocalDate() {
        return periodEndDate;
    }

    public String getPayDate() {
        return JavaTimeUtils.getLocalDateString(payDate, DATE_FORMAT);
    }

    public LocalDate getLocalPayDate() {
        return payDate;
    }

    private RunUnscheduledPayroll(RunUnscheduledPayroll.Builder builder) {
        periodEndDate = builder.periodEndDate;
        payDate = builder.payDate;
        priorYearPayroll = builder.priorYearPayroll;
        accruesLeavePay = builder.accruesLeavePay;
        usesStandardDeductionsBenefits = builder.usesStandardDeductionsBenefits;
        blocksFedIncomeTaxes = builder.blocksFedIncomeTaxes;
        blocksStateLocalIncomeTaxes = builder.blocksStateLocalIncomeTaxes;
        payOfMonth = builder.payOfMonth;
        overrideFedRate = builder.overrideFedRate;
        overrideStateRate = builder.overrideStateRate;
    }

    public static RunUnscheduledPayroll.Builder builder() {
        return new RunUnscheduledPayroll.Builder();
    }

    public static class Builder {
        private LocalDate periodEndDate;
        private LocalDate payDate;

        private boolean priorYearPayroll,
                accruesLeavePay,
                usesStandardDeductionsBenefits,
                blocksFedIncomeTaxes,
                blocksStateLocalIncomeTaxes;

        private String payOfMonth,
                overrideFedRate,
                overrideStateRate;

        public RunUnscheduledPayroll.Builder setAccruesLeavePay(boolean accruesLeavePay) {
            this.accruesLeavePay = accruesLeavePay;
            return this;
        }

        public RunUnscheduledPayroll.Builder setUsesStandardDeductionsBenefits(boolean usesStandardDeductionsBenefits) {
            this.usesStandardDeductionsBenefits = usesStandardDeductionsBenefits;
            return this;
        }

        public RunUnscheduledPayroll.Builder setBlocksFedIncomeTaxes(boolean blocksFedIncomeTaxes) {
            this.blocksFedIncomeTaxes = blocksFedIncomeTaxes;
            return this;
        }

        public RunUnscheduledPayroll.Builder setBlocksStateLocalIncomeTaxes(boolean blocksStateLocalIncomeTaxes) {
            this.blocksStateLocalIncomeTaxes = blocksStateLocalIncomeTaxes;
            return this;
        }

        public RunUnscheduledPayroll.Builder setPayOfMonth(String payOfMonth) {
            this.payOfMonth = payOfMonth;
            return this;
        }

        public RunUnscheduledPayroll.Builder setOverrideFedRate(String overrideFedRate) {
            this.overrideFedRate = overrideFedRate;
            return this;
        }

        public RunUnscheduledPayroll.Builder setOverrideStateRate(String overrideStateRate) {
            this.overrideStateRate = overrideStateRate;
            return this;
        }

        public RunUnscheduledPayroll.Builder setPeriodEndDate(String periodEndDate) {
            this.periodEndDate = JavaTimeUtils.getLocalDate(periodEndDate, DATE_FORMAT);
            return this;
        }

        public RunUnscheduledPayroll.Builder setPriorYearPayroll(boolean state) {
            this.priorYearPayroll = state;
            return this;
        }

        public RunUnscheduledPayroll.Builder setPeriodEndDate(LocalDate periodEndDate) {
            this.periodEndDate = periodEndDate;
            return this;
        }

        public RunUnscheduledPayroll.Builder setPayDate(LocalDate payDate) {
            this.payDate = payDate;
            return this;
        }

        public RunUnscheduledPayroll.Builder setPayDate(String payDate) {
            this.payDate = JavaTimeUtils.getLocalDate(payDate, DATE_FORMAT);
            return this;
        }

        private Builder() {
        }

        public RunUnscheduledPayroll build() {
            return new RunUnscheduledPayroll(this);
        }
    }
}
