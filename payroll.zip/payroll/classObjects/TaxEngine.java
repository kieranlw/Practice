package payroll.classObjects;

public enum TaxEngine {
    /**
     * The in-house-built tax engine that's being retired in 2022.
     * Sometimes referred to as "opt-out".
     */
    PAYCE,

    /**
     * Third-party integration that's being rolled out in 2022.
     * Sometimes referred to as "opt-in".
     */
    VERTEX,
}
