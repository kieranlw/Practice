package payroll.classObjects;


public class RTSInfo {

    private String databases;
    private String year;
    private int quarter;
    private Boolean forceExport;

    public String getDatabases() {
        return databases;
    }

    public String getYear() {
        return year;
    }

    public int getQuarter() {
        return quarter;
    }

    public Boolean getForceExport() {
        return forceExport;
    }

    private RTSInfo(Builder builder) {
        databases = builder.databases;
		year = builder.year;
        quarter = builder.quarter;
		forceExport = builder.forceExport;
    }

    public static RTSInfo.Builder builder() {
        return new RTSInfo.Builder();
    }

    public static class Builder {
		private String databases;
		private String year;
		private int quarter;
		private Boolean forceExport;

        public Builder setDatabases(String databases) {
            this.databases = databases;
            return this;
        }

		public Builder setForceExport(boolean forceExport) {
			this.forceExport = forceExport;
			return this;
		}

        public Builder setYear(String year) {
            this.year = year;
            return this;
        }

        public Builder setQuarter(int quarter) {
            this.quarter = quarter;
            return this;
        }

        private Builder() {
        }

        public RTSInfo build() {
            return new RTSInfo(this);
        }
    }
}
