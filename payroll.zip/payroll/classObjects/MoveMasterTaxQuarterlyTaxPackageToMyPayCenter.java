package payroll.classObjects;

public class MoveMasterTaxQuarterlyTaxPackageToMyPayCenter {

    private String taxYear;
    private String quarter;

    public String getTaxYear() {
        return taxYear;
    }

    public String getQuarter() {
        return quarter;
    }

    public MoveMasterTaxQuarterlyTaxPackageToMyPayCenter setTaxYear(String taxYear) {
        this.taxYear = taxYear;
        return this;
    }

    public MoveMasterTaxQuarterlyTaxPackageToMyPayCenter setQuarter(String quarter) {
        this.quarter = quarter;
        return this;
    }

}
