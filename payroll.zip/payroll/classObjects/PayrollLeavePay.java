package payroll.classObjects;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class PayrollLeavePay {

    private String description;
    private Double hours, rate;
    private String allocations;

}
