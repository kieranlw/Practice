package payroll.classObjects;

public class PaySpecificEmployeeModalInfo {

    public String employee;

    public String getEmployee() {
        return employee;
    }

    public PaySpecificEmployeeModalInfo setEmployee(String employee) {
        this.employee = employee;
        return this;
    }
}
