package payroll.classObjects;

import java.time.LocalDate;

public class InvoiceQuoteFilters {
    private int quoteNumber;
    private String createdBy;
    private String salesRep;
    private String companyName;
    private String doingBusinessAs;
    private String databaseName;
    private LocalDate dateRangeStart;
    private LocalDate dateRangeEnd;

    public int getQuoteNumber() {
        return quoteNumber;
    }

    public InvoiceQuoteFilters setQuoteNumber(int quoteNumber) {
        this.quoteNumber = quoteNumber;
        return this;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public InvoiceQuoteFilters setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
        return this;
    }

    public String getSalesRep() {
        return salesRep;
    }

    public InvoiceQuoteFilters setSalesRep(String salesRep) {
        this.salesRep = salesRep;
        return this;
    }

    public String getCompanyName() {
        return companyName;
    }

    public InvoiceQuoteFilters setCompanyName(String companyName) {
        this.companyName = companyName;
        return this;
    }

    public String getDoingBusinessAs() {
        return doingBusinessAs;
    }

    public InvoiceQuoteFilters setDoingBusinessAs(String doingBusinessAs) {
        this.doingBusinessAs = doingBusinessAs;
        return this;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public InvoiceQuoteFilters setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
        return this;
    }

    public LocalDate getDateRangeStart() {
        return dateRangeStart;
    }

    public InvoiceQuoteFilters setDateRangeStart(LocalDate dateRangeStart) {
        this.dateRangeStart = dateRangeStart;
        return this;
    }

    public LocalDate getDateRangeEnd() {
        return dateRangeEnd;
    }

    public InvoiceQuoteFilters setDateRangeEnd(LocalDate dateRangeEnd) {
        this.dateRangeEnd = dateRangeEnd;
        return this;
    }
}
