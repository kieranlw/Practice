package payroll.classObjects;

import common.DateFormats;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDate;

@Getter
@Builder
public class PayrollRegisterReportParameters {
    private final String payDate;
    private final boolean showEmployerTaxes;

    public static PayrollRegisterReportParameters withDefaultsAndPayDate(LocalDate payDate) {
        return withDefaultsAndPayDate(payDate.format(DateFormats.MM_DD_YYYY));
    }

    public static PayrollRegisterReportParameters withDefaultsAndPayDate(String payDate) {
        return builder()
                .payDate(payDate)
                .showEmployerTaxes(true)
                .build();
    }
}
