package payroll.classObjects;

public class CompanyWorkLocationDetails {

    private String description;
    private String state;
    private String overrideMinimumWage;
    private String address;
    private String address2;
    private String city;
    private String zip;
    private String zipFourDigit;

    private CompanyWorkLocationDetails(Builder builder) {
        this.description = builder.description;
        this.state = builder.state;
        this.overrideMinimumWage = builder.overrideMinimumWage;
        this.address = builder.address;
        this.address2 = builder.address2;
        this.city = builder.city;
        this.zip = builder.zip;
        this.zipFourDigit = builder.zipFourDigit;
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getDescription() {
        return description;
    }

    public String getState() {
        return state;
    }

    public String getOverrideMinimumWage() {
        return overrideMinimumWage;
    }

    public String getAddress() {
        return address;
    }

    public String getAddress2() {
        return address2;
    }

    public String getCity() {
        return city;
    }

    public String getZip() {
        return zip;
    }

    public String getZipFourDigit() {
        return zipFourDigit;
    }

    public static class Builder {
        private String description;
        private String state;
        private String overrideMinimumWage;
        private String address;
        private String address2;
        private String city;
        private String zip;
        private String zipFourDigit;

        public Builder setDescription(String description) {
            this.description = description;
            return this;
        }

        public Builder setState(String state) {
            this.state = state;
            return this;
        }

        public Builder setOverrideMinimumWage(String overrideMinimumWage) {
            this.overrideMinimumWage = overrideMinimumWage;
            return this;
        }

        public Builder setAddress(String address) {
            this.address = address;
            return this;
        }

        public Builder setAddress2(String address2) {
            this.address2 = address2;
            return this;
        }

        public Builder setCity(String city) {
            this.city = city;
            return this;
        }

        public Builder setZip(String zip) {
            this.zip = zip;
            return this;
        }

        public Builder setZipFourDigit(String zipFourDigit) {
            this.zipFourDigit = zipFourDigit;
            return this;
        }

        private Builder() {}

        public CompanyWorkLocationDetails build() {return new CompanyWorkLocationDetails(this);}
    }
}
