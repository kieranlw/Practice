package payroll.classObjects;

public class NewCustomReportInfo {

	private String category;
	private String template;
	private String reportTitle;
	private String cSVFileSeparator;

	public String getCategory() {
		return category;
	}

	public String getTemplate() {
		return template;
	}

	public String getCSVFileSeparator() {
		return cSVFileSeparator;
	}


	public String getReportTitle() {
		return reportTitle;
	}

	private NewCustomReportInfo(Builder builder) {
		category = builder.category;
		template = builder.template;
		reportTitle = builder.reportTitle;
		cSVFileSeparator = builder.cSVFileSeparator;
	}

	public static NewCustomReportInfo.Builder builder() {
		return new NewCustomReportInfo.Builder();
	}


	public static class Builder {
		private String category;
		private String template;
		private String reportTitle;
		private String cSVFileSeparator;


		public Builder setCategory(String category) {
			this.category = category;
			return this;
		}

		public Builder setTemplate(String template) {
			this.template = template;
			return this;
		}

		public Builder setReportTitle(String reportTitle) {
			this.reportTitle = reportTitle;
			return this;
		}

		public Builder setCSVFileSeparator(String cSVFileSeparator) {
			this.cSVFileSeparator = cSVFileSeparator;
			return this;
		}

		private Builder() {
		}

		public NewCustomReportInfo build() {
			return new NewCustomReportInfo(this);
		}


	}
 	
}
