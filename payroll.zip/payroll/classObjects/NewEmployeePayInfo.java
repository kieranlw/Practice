package payroll.classObjects;

public class NewEmployeePayInfo {

    private String payType;
    private String department;
    private double rate;

    public String getPayType() {
        return payType;
    }

    public NewEmployeePayInfo setPayType(String payType) {
        this.payType = payType;
        return this;
    }

    public String getDepartment() {
        return department;
    }

    public NewEmployeePayInfo setDepartment(String department) {
        this.department = department;
        return this;
    }

    public double getRate() {
        return rate;
    }

    public NewEmployeePayInfo setRate(double rate) {
        this.rate = rate;
        return this;
    }
}
