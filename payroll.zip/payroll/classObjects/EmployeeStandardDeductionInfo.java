package payroll.classObjects;

public class EmployeeStandardDeductionInfo {

	private String status;
	private Double amount;

	public Double getAmount() {
		return amount;
	}

	public String getStatus() {
		return status;
	}


	private EmployeeStandardDeductionInfo(Builder builder) {

		this.status = builder.status;
		this.amount = builder.amount;
	}

	public static EmployeeStandardDeductionInfo.Builder builder() {
		return new EmployeeStandardDeductionInfo.Builder();
	}


	public static class Builder {
		private String status;
		private Double amount;

		public Builder setStatus(String status) {
			this.status = status;
			return this;
		}

		public Builder setAmount(double amount) {
			this.amount = amount;
			return this;
		}

		private Builder() {
		}

		public EmployeeStandardDeductionInfo build() {
			return new EmployeeStandardDeductionInfo(this);
		}

	}
 	
}
