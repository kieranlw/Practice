package payroll.classObjects;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class OverrideTaxCalculationsInfo {
    private String fedAdditionalTax;
    private String mDAdditionalStateTax;
    private boolean blockFedTax;
    private boolean blockStateTax;
    private boolean overrideDirectDeposit;
    private Double fedPercent;
    private Double fedAmount;
    private Double statePercent;
    private Double stateAmount;
}
