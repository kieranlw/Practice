package payroll.classObjects;

import java.time.LocalDate;

public class LocalTaxNewInfo {

    private String state;
    private String type;
    private String code;
    private String taxCodeOverride;
    private String description;
    private LocalDate effectiveFrom;
    private LocalDate effectiveTo;
    private String localTaxType;
    private String percent;
    private DollarCurrency yTDMaxTax;
    private String yTDMaxTaxableWages;
    private boolean treatAsOtherTax;
    private boolean isRequired;

    private Integer numberOfActiveEmployeesToMakeRequired;

    public String getState() {
        return state;
    }

    public LocalTaxNewInfo setState(String state) {
        this.state = state;
        return this;
    }

    public String getType() {
        return type;
    }

    public LocalTaxNewInfo setType(String type) {
        this.type = type;
        return this;
    }

    public boolean isTreatAsOtherTax() {
        return treatAsOtherTax;
    }

    public LocalTaxNewInfo setTreatAsOtherTax(boolean treatAsOtherTax) {
        this.treatAsOtherTax = treatAsOtherTax;
        return this;
    }

    public String getCode() {
        return code;
    }

    public LocalTaxNewInfo setCode(String code) {
        this.code = code;
        return this;
    }

    public String getTaxCodeOverride() {
        return taxCodeOverride;
    }

    public LocalTaxNewInfo setTaxCodeOverride(String taxCodeOverride) {
        this.taxCodeOverride = taxCodeOverride;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public LocalTaxNewInfo setDescription(String description) {
        this.description = description;
        return this;
    }

    public LocalDate getEffectiveFrom() {
        return effectiveFrom;
    }

    public LocalTaxNewInfo setEffectiveFrom(LocalDate effectiveFrom) {
        this.effectiveFrom = effectiveFrom;
        return this;
    }

    public LocalDate getEffectiveTo() {
        return effectiveTo;
    }

    public LocalTaxNewInfo setEffectiveTo(LocalDate effectiveTo) {
        this.effectiveTo = effectiveTo;
        return this;
    }

    public String getLocalTaxType() {
        return localTaxType;
    }

    public LocalTaxNewInfo setLocalTaxType(String localTaxType) {
        this.localTaxType = localTaxType;
        return this;
    }

    public String getPercent() {
        return percent;
    }

    public LocalTaxNewInfo setPercent(String percent) {
        this.percent = percent;
        return this;
    }

    public DollarCurrency getYTDMaxTax() {
        return yTDMaxTax;
    }

    public LocalTaxNewInfo setYTDMaxTax(DollarCurrency yTDMaxTax) {
        this.yTDMaxTax = yTDMaxTax;
        return this;
    }

    public String getYTDMaxTaxableWages() {
        return yTDMaxTaxableWages;
    }

    public LocalTaxNewInfo setYTDMaxTaxableWages(String yTDMaxTaxableWages) {
        this.yTDMaxTaxableWages = yTDMaxTaxableWages;
        return this;
    }

    public boolean getIsRequired() {
        return isRequired;
    }

    public LocalTaxNewInfo setIsRequired(boolean required) {
        isRequired = required;
        return this;
    }

    public Integer getNumberOfActiveEmployeesToMakeRequired() {
        return numberOfActiveEmployeesToMakeRequired;
    }

    public LocalTaxNewInfo setNumberOfActiveEmployeesToMakeRequired(int numberOfActiveEmployeesToMakeRequired) {
        this.numberOfActiveEmployeesToMakeRequired = numberOfActiveEmployeesToMakeRequired;
        return this;
    }
}
