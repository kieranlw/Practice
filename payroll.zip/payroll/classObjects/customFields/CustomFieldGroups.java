package payroll.classObjects.customFields;

public class CustomFieldGroups {

    private String description;
    private Integer displayPriority;

    public String getDescription() {
        return description;
    }

    public CustomFieldGroups setDescription(String description) {
        this.description = description;
        return this;
    }

    public Integer getDisplayPriority() {
        return displayPriority;
    }

    public CustomFieldGroups setDisplayPriority(Integer displayPriority) {
        this.displayPriority = displayPriority;
        return this;
    }
}
