package payroll.classObjects.customFields;

public class CustomField {

    private String name;
    private String grouping;
    private String type;
    private String area;
    private Integer displayPriority;
    private Boolean isRequired;
    private String[] dropdownOptions;

    @Override
    public String toString() {
        return name + " - type of '" + type + "'";
    }

    public String[] getDropdownOptions() {
        return dropdownOptions;
    }

    public CustomField setDropdownOptions(String[] dropdownOptions) {
        this.dropdownOptions = dropdownOptions;
        return this;
    }

    public String getName() {
        return name;
    }

    public CustomField setName(String name) {
        this.name = name;
        return this;
    }

    public String getGrouping() {
        return grouping;
    }

    public CustomField setGrouping(String grouping) {
        this.grouping = grouping;
        return this;
    }

    public String getType() {
        return type;
    }

    public CustomField setType(String type) {
        this.type = type;
        return this;
    }

    public String getArea() {
        return area;
    }

    public CustomField setArea(String area) {
        this.area = area;
        return this;
    }

    public Integer getDisplayPriority() {
        return displayPriority;
    }

    public CustomField setDisplayPriority(Integer displayPriority) {
        this.displayPriority = displayPriority;
        return this;
    }

    public Boolean getRequired() {
        return isRequired;
    }

    public CustomField setRequired(Boolean required) {
        isRequired = required;
        return this;
    }
}
