package payroll.classObjects;

import common.DateFormats;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDate;

@Getter
@Builder
public class PayrollSummaryReportParameters {
    private final String dateRange;
    private final String payDate;
    private final String exportTo;

    public static PayrollSummaryReportParameters withDefaultsAndPayDate(LocalDate payDate) {
        return withDefaultsAndPayDate(payDate.format(DateFormats.MM_DD_YYYY));
    }

    public static PayrollSummaryReportParameters withDefaultsAndPayDate(String payDate) {
        return builder()
                .dateRange("Pay Date")
                .payDate(payDate)
                .exportTo("PDF")
                .build();
    }
}