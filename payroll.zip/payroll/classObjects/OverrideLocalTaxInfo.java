package payroll.classObjects;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class OverrideLocalTaxInfo {

    private String localTax;
    private Double amount;

}
