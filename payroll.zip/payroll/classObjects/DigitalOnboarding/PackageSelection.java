package payroll.classObjects.DigitalOnboarding;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder

public class PackageSelection {
    private String packageSelection;
    private String litePackage;
    private String blendedPackage;
    private String theWorksPackage;
    private String package1;
    private String package2;
    private String package3;
}

