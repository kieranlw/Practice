package payroll.classObjects.DigitalOnboarding;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder

public class AccountRegistrationLoginInfo {
    private String emailAddress;
    private String password;
    private String confirmPassword;
    private Boolean iConsentCheckbox;
}

