package payroll.classObjects.DigitalOnboarding;

import lombok.Getter;
import lombok.Setter;
import lombok.Builder;

@Getter
@Setter
@Builder

public class ResetPassword {
    private String newPassword;
    private String confirmPassword;
}
