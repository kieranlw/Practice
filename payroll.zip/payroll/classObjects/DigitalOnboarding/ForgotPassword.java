package payroll.classObjects.DigitalOnboarding;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder

public class ForgotPassword {
    private String emailAddress;
    private String captcha;
    private String sendResetPasswordLink;
    private String forgotPassword;
}

