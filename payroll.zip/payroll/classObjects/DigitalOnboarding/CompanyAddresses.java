package payroll.classObjects.DigitalOnboarding;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class CompanyAddresses {

    private String address1;
    private String address2;
    private String city;
    private String stateProvince;
    private String zipPostalCode;
    private String phoneNumber;

    public static CompanyAddresses createDefaultAddress() {
        return CompanyAddresses.builder()
                .address1("1 Atlanta Street")
                .address2("Apartment 1")
                .city("Atlanta")
                .stateProvince("Georgia")
                .zipPostalCode("12345")
                .phoneNumber("1234567890")
                .build();
    }


}
