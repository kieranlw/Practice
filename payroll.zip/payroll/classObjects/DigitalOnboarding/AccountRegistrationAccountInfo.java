package payroll.classObjects.DigitalOnboarding;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder

public class AccountRegistrationAccountInfo {
    private String firstName;
    private String lastName;
    private String emailAddress;
    private String companyPhone;
    private String companyName;
    private String employeeCount;
    private String state;
    private String zip;
}

