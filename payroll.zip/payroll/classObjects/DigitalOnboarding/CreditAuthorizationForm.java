package payroll.classObjects.DigitalOnboarding;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import payroll.api.DeluxeUnifiedOnboarding.Account;
import payroll.api.DeluxeUnifiedOnboarding.Company;

import java.util.Random;

@Setter
@Getter
@Builder
public class CreditAuthorizationForm {
    private String businessLegalName;
    private String tradeDBAName;
    private String businessStructure;
    private String fein;
    private String businessAddress;
    private String city;
    private String state;
    private String zipCode;
    private String businessPhoneNumber;
    private String ownerFirstName;
    private String ownerLastName;
    private String ownerEmail;
    private Boolean authorizeBusinessCredit;

    public static CreditAuthorizationForm createCommercialThreeDayFundingCreditForm(Account account) {
        return CreditAuthorizationForm.builder()
                .businessLegalName("zurbrigen orthidontics lallet 714116 tucker")
                .tradeDBAName("Test DBA Name")
                .businessStructure("C-Corporation")
                .fein(Company.generateRandomFein())
                .businessAddress("15-1580 lusterview blvd")
                .city("newport news")
                .state("Virginia")
                .zipCode("23602-5560")
                .businessPhoneNumber(account.getCompanyPhone())
                .ownerFirstName(account.getFirstName())
                .ownerLastName(account.getLastName())
                .ownerEmail(account.getEmailAddress())
                .authorizeBusinessCredit(true)
                .build();
    }



}
