package payroll.classObjects.DigitalOnboarding;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder

public class AuthorizationForms {
    private String authorizationForms;
    private String form8655ReportingAgentAuthorization;
    private String form8655DownloadFile;
    private String form8655UploadFile;
    private String form8655RemoveButton;
    private String form8655UploadProof;
    private String form8655ErrorMessage;
    private String form8832EntityClassification;
    private String form8832DownloadFile;
    private String form8832UploadFile;
    private String form8832RemoveButton;
    private String form8832UploadProof;
    private String form8832ErrorMessage;
    private String directDepositAuthorization;
    private String directDepositAuthorizationDownloadFile;
    private String directDepositAuthorizationUploadFile;
    private String directDepositAuthorizationRemoveButton;
    private String directDepositAuthorizationUploadProof;
    private String directDepositAuthorizationErrorMessage;
    private String beneficialOwnershipForm;
    private String beneficialOwnershipDownloadFile;
    private String beneficialOwnershipUploadFile;
    private String beneficialOwnershipRemoveButton;
    private String beneficialOwnershipUploadProof;
    private String beneficialOwnershipErrorMessage;
    private String creditCardAuthorization;
    private String creditCardDownloadFile;
    private String creditCardUploadFile;
    private String creditCardRemoveButton;
    private String creditCardUploadProof;
    private String creditCardErrorMessage;
    private String personalGuarantee;
    private String personalGuaranteeDownloadFile;
    private String personalGuaranteeUploadFile;
    private String personalGuaranteeRemoveButton;
    private String personalGuaranteeUploadProof;
    private String personalGuaranteeErrorMessage;
}

