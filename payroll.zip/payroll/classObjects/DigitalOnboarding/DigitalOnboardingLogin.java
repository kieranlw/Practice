package payroll.classObjects.DigitalOnboarding;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;


@Builder
@Setter
@Getter

public class DigitalOnboardingLogin {

    private String userName;
    private String password;
}
