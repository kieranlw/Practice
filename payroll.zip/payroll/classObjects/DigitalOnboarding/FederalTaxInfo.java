package payroll.classObjects.DigitalOnboarding;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder

public class FederalTaxInfo {
    private String federalFilingForm;
    private Boolean seasonalEmployerCheckBox;
    private String federalDepositFrequency;
    private String naicsCode;
    private String irsFederalProof;
    private String workerTypesPaying;
    private String charity501C3;
    private String upload;

    public static FederalTaxInfo createDefaultFedTax() {
        return FederalTaxInfo.builder()
                .charity501C3("Yes")
                .federalFilingForm("941 Employer's QUARTERLY Federal Tax Return")
                .federalDepositFrequency("Monthly")
                .workerTypesPaying("W-2 employees only")
                .seasonalEmployerCheckBox(true)
                .naicsCode("123456")
                .build();
    }
}

