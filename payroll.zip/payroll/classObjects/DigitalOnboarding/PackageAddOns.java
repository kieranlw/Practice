package payroll.classObjects.DigitalOnboarding;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder

public class PackageAddOns {
    private String packageAddOns;
    private String benefitsAdministration;
    private String unlimitedWorkFlows;
    private String timeTrackingAndProjectCodes;
    private String ptoAccrualPolicies;
    private String posters;
    private String applicantTrackingSystem;
    private String heroBasePackage;
    private String plus;
    private String pro;
    private String atsNone;
    private String hrSolutionCenter;
    private String support;
    private String onDemand;
    private String complete;
    private String hrSolutionCenterNone;
    private String hrTrainingModules;
    private String learn1;
    private String learn2;
    private String learn3;
    private String hrTrainingModuleNone;
    private String hrHandbookCreation;
    private String hrHandbookReview;
    private String hrWizardHandbookCreation;
    private String hrHandbookCreationNone;
    private String benefitsAdministrationPrice;
    private String unlimitedWorkFlowsPrice;
    private String timeTrackingAndProjectCodesPrice;
    private String ptoAccrualPoliciesPrice;
    private String postersPrice;
    private String heroBasePackagePrice;
    private String plusPrice;
    private String proPrice;
    private String supportPrice;
    private String onDemandPrice;
    private String completePrice;
    private String learn1Price;
    private String learn2Price;
    private String learn3Price;
    private String hrHandbookReviewPrice;
    private String hrWizardHandbookCreationPrice;
}

