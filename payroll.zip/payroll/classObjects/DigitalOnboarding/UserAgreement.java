package payroll.classObjects.DigitalOnboarding;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class UserAgreement {

    private Boolean authorizedSignature;
    private Boolean termsAndConditions;

    public static UserAgreement createDefaultUserAgreement() {
        return UserAgreement.builder()
                .authorizedSignature(true)
                .termsAndConditions(true)
                .build();
    }

}
