package payroll.classObjects.DigitalOnboarding;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class InviteAuthorizedUser {
    private String firstName;
    private String lastName;
    private String emailAddress;
    private String specifyRoleTextBox;
    private String companyName;
    private String roleDropdown;
}
