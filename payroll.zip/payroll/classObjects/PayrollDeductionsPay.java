package payroll.classObjects;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class PayrollDeductionsPay {

    private String description;
    private Double amount;
    private boolean doSkipAgencyPay;

}
