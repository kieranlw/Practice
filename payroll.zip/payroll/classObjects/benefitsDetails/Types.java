package payroll.classObjects.benefitsDetails;

public enum Types {
    SELECT_ONE("Select One"),
    PERCENT_OF_PAY("% of Pay"),
    FLAT_AMOUNT("Flat Amount"),
    MATCH_PERCENT_OF_DEDUCTIONS("Match % of Deduction");

    private final String optionName;

    Types(String optionName) {
        this.optionName = optionName;
    }

    public String getOptionName() {
        return optionName;
    }
}
