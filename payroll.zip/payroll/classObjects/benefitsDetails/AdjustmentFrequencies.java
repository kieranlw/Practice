package payroll.classObjects.benefitsDetails;

public enum AdjustmentFrequencies {
    SELECT_ONE("Select One"),
    FIRST_AND_THIRD_PAYS_MONTH("1st and 3rd Pays Month"),
    FIRST_PAY_OF_MONTH("1st Pay of Month"),
    SECOND_PAY_OF_MONTH("2nd Pay of Month"),
    THIRD_PAY_OF_MONTH("3rd Pay of Month"),
    FOURTH_PAY_OF_MONTH("4th Pay of Month"),
    EVERY_PAY("Every Pay");

    private final String optionName;

    AdjustmentFrequencies(String optionName) {
        this.optionName = optionName;
    }

    public String getOptionName() {
        return optionName;
    }
}
