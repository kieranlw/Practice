package payroll.classObjects;

public class ReportTypeSelectionInfo {

    private Boolean firstName;
    private Boolean lastName;
    private Boolean departmentDescription;
    private Boolean jobCodeNumber;
    private Boolean otHours;
    private Boolean employeeNumber;
    private Boolean homePayType;
    private Boolean otGross;
    private Boolean departmentNumber;
    private Boolean payDate;
    private Boolean regularHours;
    private Boolean regularGross;

    private Boolean miscellaneousPayOtherPayAmount;
    private Boolean perDiemREMOtherPayAmount;
    private Boolean separationOtherPayAmount;
    private Boolean pRREIMOtherPayAmount;
    private Boolean vehicleOtherPayAmount;
    private Boolean bonusOtherPayAmount;
    private Boolean otherPayOtherPayAmount;
    private Boolean reimbursementOtherPayAmount;
    private Boolean cellOtherPayAmount;
    private Boolean perDiemOHOtherPayAmount;
    private Boolean rEIMOHOtherPayAmount;
    private Boolean commissionOtherPayAmount;

    private Boolean tax_FICASDeferred;
    private Boolean taxCredit_FCCRE;
    private Boolean taxCredit_FCFAM;
    private Boolean taxCredit_FCRET;
    private Boolean taxCreditAmount_FCCRE;
    private Boolean taxCreditAmount_FCFAM;
    private Boolean taxCreditAmount_FCRET;
    private Boolean taxCreditTaxable_FCCRE;
    private Boolean taxCreditTaxable_FCFAM;
    private Boolean taxCreditTaxable_FCRET;

    public Boolean getFirstName() {
        return firstName;
    }

    public Boolean getDepartmentDescription() {
        return departmentDescription;
    }

    public Boolean getJobCodeNumber() {
        return jobCodeNumber;
    }

    public Boolean getEmployeeNumber() {
        return employeeNumber;
    }

    public Boolean getHomePayType() {
        return homePayType;
    }

    public Boolean getOtGross() {
        return otGross;
    }

    public Boolean getOtHours() {
        return otHours;
    }

    public Boolean getLastName() {
        return lastName;
    }

    public Boolean getPayDate() {
        return payDate;
    }

    public Boolean getDepartmentNumber() {
        return departmentNumber;
    }

    public Boolean getRegularHours() {
        return regularHours;
    }

    public Boolean getRegularGross() {
        return regularGross;
    }

    public Boolean getVehicleOtherPayAmount() {
        return vehicleOtherPayAmount;
    }

    public Boolean getBonusOtherPayAmount() {
        return bonusOtherPayAmount;
    }

    public Boolean getOtherPayOtherPayAmount() {
        return otherPayOtherPayAmount;
    }

    public Boolean getSeparationOtherPayAmount() {
        return separationOtherPayAmount;
    }

    public Boolean getPRREIMOtherPayAmount() {
        return pRREIMOtherPayAmount;
    }

    public Boolean getReimbursementOtherPayAmount() {
        return reimbursementOtherPayAmount;
    }

    public Boolean getCellOtherPayAmount() {
        return cellOtherPayAmount;
    }

    public Boolean getPerDiemOHOtherPayAmount() {
        return perDiemOHOtherPayAmount;
    }

    public Boolean getREIMOHOtherPayAmount() {
        return rEIMOHOtherPayAmount;
    }

    public Boolean getCommissionOtherPayAmount() {
        return commissionOtherPayAmount;
    }

    public Boolean getMiscellaneousPayOtherPayAmount() {
        return miscellaneousPayOtherPayAmount;
    }

    public Boolean getPerDiemREMOtherPayAmount() {
        return perDiemREMOtherPayAmount;
    }

    public Boolean getTax_FICASDeferred() {
        return tax_FICASDeferred;
    }

    public Boolean getTaxCredit_FCCRE() {
        return taxCredit_FCCRE;
    }

    public Boolean getTaxCredit_FCFAM() {
        return taxCredit_FCFAM;
    }

    public Boolean getTaxCredit_FCRET() {
        return taxCredit_FCRET;
    }

    public Boolean getTaxCreditAmount_FCCRE() {
        return taxCreditAmount_FCCRE;
    }

    public Boolean getTaxCreditAmount_FCFAM() {
        return taxCreditAmount_FCFAM;
    }

    public Boolean getTaxCreditAmount_FCRET() {
        return taxCreditAmount_FCRET;
    }

    public Boolean getTaxCreditTaxable_FCCRE() {
        return taxCreditTaxable_FCCRE;
    }

    public Boolean getTaxCreditTaxable_FCFAM() {
        return taxCreditTaxable_FCFAM;
    }

    public Boolean getTaxCreditTaxable_FCRET() {
        return taxCreditTaxable_FCRET;
    }

    private ReportTypeSelectionInfo(Builder builder) {

        this.firstName = builder.firstName;
        this.lastName = builder.lastName;
        this.departmentDescription = builder.departmentDescription;
        this.jobCodeNumber = builder.jobCodeNumber;
        this.employeeNumber = builder.employeeNumber;
        this.homePayType = builder.homePayType;
        this.otGross = builder.otGross;
        this.otHours = builder.otHours;
        this.departmentNumber = builder.departmentNumber;
        this.payDate = builder.payDate;
        this.regularHours = builder.regularHours;
        this.regularGross = builder.regularGross;

        this.miscellaneousPayOtherPayAmount = builder.miscellaneousPayOtherPayAmount;
        this.perDiemREMOtherPayAmount = builder.perDiemREMOtherPayAmount;
        this.separationOtherPayAmount = builder.separationOtherPayAmount;
        this.pRREIMOtherPayAmount = builder.pRREIMOtherPayAmount;
        this.vehicleOtherPayAmount = builder.vehicleOtherPayAmount;
        this.bonusOtherPayAmount = builder.bonusOtherPayAmount;
        this.otherPayOtherPayAmount = builder.otherPayOtherPayAmount;
        this.reimbursementOtherPayAmount = builder.reimbursementOtherPayAmount;
        this.cellOtherPayAmount = builder.cellOtherPayAmount;
        this.perDiemOHOtherPayAmount = builder.perDiemOHOtherPayAmount;
        this.rEIMOHOtherPayAmount = builder.rEIMOHOtherPayAmount;
        this.commissionOtherPayAmount = builder.commissionOtherPayAmount;

        this.tax_FICASDeferred = builder.tax_FICASDeferred;
        this.taxCredit_FCCRE = builder.taxCredit_FCCRE;
        this.taxCredit_FCFAM = builder.taxCredit_FCFAM;
        this.taxCredit_FCRET = builder.taxCredit_FCRET;
        this.taxCreditAmount_FCCRE = builder.taxCreditAmount_FCCRE;
        this.taxCreditAmount_FCFAM = builder.taxCreditAmount_FCFAM;
        this.taxCreditAmount_FCRET = builder.taxCreditAmount_FCRET;
        this.taxCreditTaxable_FCCRE = builder.taxCreditTaxable_FCCRE;
        this.taxCreditTaxable_FCFAM = builder.taxCreditTaxable_FCFAM;
        this.taxCreditTaxable_FCRET = builder.taxCreditTaxable_FCRET;
    }

    public static ReportTypeSelectionInfo.Builder builder() {
        return new ReportTypeSelectionInfo.Builder();
    }

    public static class Builder {

        private Boolean firstName;
        private Boolean departmentDescription;
        private Boolean jobCodeNumber;
        private Boolean employeeNumber;
        private Boolean homePayType;
        private Boolean otGross;
        private Boolean otHours;
        private Boolean lastName;
        private Boolean departmentNumber;
        private Boolean payDate;
        private Boolean regularHours;
        private Boolean regularGross;
        //Per Pay Other Pay Amount CheckBoxes
        private Boolean miscellaneousPayOtherPayAmount;
        private Boolean perDiemREMOtherPayAmount;
        private Boolean separationOtherPayAmount;
        private Boolean pRREIMOtherPayAmount;
        private Boolean vehicleOtherPayAmount;
        private Boolean bonusOtherPayAmount;
        private Boolean otherPayOtherPayAmount;
        private Boolean reimbursementOtherPayAmount;
        private Boolean cellOtherPayAmount;
        private Boolean perDiemOHOtherPayAmount;
        private Boolean rEIMOHOtherPayAmount;
        private Boolean commissionOtherPayAmount;
        //Newly added Covid Tax fields for Custom Reports
        private Boolean tax_FICASDeferred;
        private Boolean taxCredit_FCCRE;
        private Boolean taxCredit_FCFAM;
        private Boolean taxCredit_FCRET;
        private Boolean taxCreditAmount_FCCRE;
        private Boolean taxCreditAmount_FCFAM;
        private Boolean taxCreditAmount_FCRET;
        private Boolean taxCreditTaxable_FCCRE;
        private Boolean taxCreditTaxable_FCFAM;
        private Boolean taxCreditTaxable_FCRET;

        public Boolean getFirstName() {
            return firstName;
        }

        public void setFirstName(Boolean firstName) {
            this.firstName = firstName;
        }

        public Builder setFirstName(boolean firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder setOTGross(boolean otGross) {
            this.otGross = otGross;
            return this;
        }

        public Builder setOTHours(boolean otHours) {
            this.otHours = otHours;
            return this;
        }

        public Builder setHomePayType(boolean homePayType) {
            this.homePayType = homePayType;
            return this;
        }

        public Builder setDepartmentDescription(boolean departmentDescription) {
            this.departmentDescription = departmentDescription;
            return this;
        }

        public Builder setJobCodeNumber(boolean jobCodeNumber) {
            this.jobCodeNumber = jobCodeNumber;
            return this;
        }

        public Builder setEmployeeNumber(boolean employeeNumber) {
            this.employeeNumber = employeeNumber;
            return this;
        }

        public Builder setLastName(boolean lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder setDepartmentNumber(boolean departmentNumber) {
            this.departmentNumber = departmentNumber;
            return this;
        }

        public Builder setPayDate(boolean payDate) {
            this.payDate = payDate;
            return this;
        }

        public Builder setRegularHours(boolean regularHours) {
            this.regularHours = regularHours;
            return this;
        }

        public Builder setRegularGross(boolean regularGross) {
            this.regularGross = regularGross;
            return this;
        }

        public Builder setMiscellaneousPayOtherPayAmount(Boolean miscellaneousPayOtherPayAmount) {
            this.miscellaneousPayOtherPayAmount = miscellaneousPayOtherPayAmount;
            return this;
        }

        public Builder setPerDiemREMOtherPayAmount(Boolean perDiemREMOtherPayAmount) {
            this.perDiemREMOtherPayAmount = perDiemREMOtherPayAmount;
            return this;
        }

        public Builder setSeparationOtherPayAmount(Boolean separationOtherPayAmount) {
            this.separationOtherPayAmount = separationOtherPayAmount;
            return this;
        }

        public Builder setPRREIMOtherPayAmount(Boolean pRREIMOtherPayAmount) {
            this.pRREIMOtherPayAmount = pRREIMOtherPayAmount;
            return this;
        }

        public Builder setVehicleOtherPayAmount(Boolean vehicleOtherPayAmount) {
            this.vehicleOtherPayAmount = vehicleOtherPayAmount;
            return this;
        }

        public Builder setBonusOtherPayAmount(Boolean bonusOtherPayAmount) {
            this.bonusOtherPayAmount = bonusOtherPayAmount;
            return this;
        }

        public Builder setOtherPayOtherPayAmount(Boolean otherPayOtherPayAmount) {
            this.otherPayOtherPayAmount = otherPayOtherPayAmount;
            return this;
        }

        public Builder setReimbursementOtherPayAmount(Boolean reimbursementOtherPayAmount) {
            this.reimbursementOtherPayAmount = reimbursementOtherPayAmount;
            return this;
        }

        public Builder setCellOtherPayAmount(Boolean cellOtherPayAmount) {
            this.cellOtherPayAmount = cellOtherPayAmount;
            return this;
        }

        public Builder setPerDiemOHOtherPayAmount(Boolean perDiemOHOtherPayAmount) {
            this.perDiemOHOtherPayAmount = perDiemOHOtherPayAmount;
            return this;
        }

        public Builder setCommissionOtherPayAmount(Boolean commissionOtherPayAmount) {
            this.commissionOtherPayAmount = commissionOtherPayAmount;
            return this;
        }

        public Builder setREIMOHOtherPayAmount(Boolean rEIMOHOtherPayAmount) {
            this.rEIMOHOtherPayAmount = rEIMOHOtherPayAmount;
            return this;
        }

        public Builder setTax_FICASDeferred(boolean tax_FICASDeferred) {
            this.tax_FICASDeferred = tax_FICASDeferred;
            return this;
        }

        public Builder setTaxCredit_FCCRE(boolean taxCredit_FCCRE) {
            this.taxCredit_FCCRE = taxCredit_FCCRE;
            return this;
        }

        public Builder setTaxCredit_FCFAM(boolean taxCredit_FCFAM) {
            this.taxCredit_FCFAM = taxCredit_FCFAM;
            return this;
        }

        public Builder setTaxCredit_FCRET(boolean taxCredit_FCRET) {
            this.taxCredit_FCRET = taxCredit_FCRET;
            return this;
        }

        public Builder setTaxCreditAmount_FCCRE(boolean taxCreditAmount_FCCRE) {
            this.taxCreditAmount_FCCRE = taxCreditAmount_FCCRE;
            return this;
        }

        public Builder setTaxCreditAmount_FCFAM(boolean taxCreditAmount_FCFAM) {
            this.taxCreditAmount_FCFAM = taxCreditAmount_FCFAM;
            return this;
        }

        public Builder setTaxCreditAmount_FCRET(boolean taxCreditAmount_FCRET) {
            this.taxCreditAmount_FCRET = taxCreditAmount_FCRET;
            return this;
        }

        public Builder setTaxCreditTaxable_FCCRE(boolean taxCreditTaxable_FCCRE) {
            this.taxCreditTaxable_FCCRE = taxCreditTaxable_FCCRE;
            return this;
        }

        public Builder setTaxCreditTaxable_FCFAM(boolean taxCreditTaxable_FCFAM) {
            this.taxCreditTaxable_FCFAM = taxCreditTaxable_FCFAM;
            return this;
        }

        public Builder setTaxCreditTaxable_FCRET(boolean taxCreditTaxable_FCRET) {
            this.taxCreditTaxable_FCRET = taxCreditTaxable_FCRET;
            return this;
        }

        private Builder() {
        }

        public ReportTypeSelectionInfo build() {
            return new ReportTypeSelectionInfo(this);
        }
    }
}
