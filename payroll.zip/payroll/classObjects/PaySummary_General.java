package payroll.classObjects;

import java.time.LocalDate;

public class PaySummary_General {

    private String summaryType;
    private LocalDate payDate;
    private String numberPaid;
    private DollarCurrency preGross;
    private DollarCurrency tpSickPay;
    private DollarCurrency sales;
    private LocalDate processedDate;
    private DollarCurrency totalNet;
    private DollarCurrency memo;
    private DollarCurrency tips;

    public String getSummaryType() {
        return summaryType;
    }

    public LocalDate getPayDate() {
        return payDate;
    }

    public String getNumberPaid() {
        return numberPaid;
    }

    public DollarCurrency getPreGross() {
        return preGross;
    }

    public DollarCurrency getTpSickPay() {
        return tpSickPay;
    }

    public DollarCurrency getSales() {
        return sales;
    }

    public LocalDate getProcessedDate() {
        return processedDate;
    }

    public DollarCurrency getTotalNet() {
        return totalNet;
    }

    public DollarCurrency getMemo() {
        return memo;
    }

    public DollarCurrency getTips() {
        return tips;
    }


    public PaySummary_General setSummaryType(String summaryType) {
        this.summaryType = summaryType;
        return this;
    }

    public PaySummary_General setPayDate(LocalDate payDate) {
        this.payDate = payDate;
        return this;
    }

    public PaySummary_General setNumberPaid(String numberPaid) {
        this.numberPaid = numberPaid;
        return this;
    }

    public PaySummary_General setPreGross(DollarCurrency preGross) {
        this.preGross = preGross;
        return this;
    }

    public PaySummary_General setTpSickPay(DollarCurrency tpSickPay) {
        this.tpSickPay = tpSickPay;
        return this;
    }

    public PaySummary_General setSales(DollarCurrency sales) {
        this.sales = sales;
        return this;
    }

    public PaySummary_General setProcessedDate(LocalDate processedDate) {
        this.processedDate = processedDate;
        return this;
    }

    public PaySummary_General setTotalNet(DollarCurrency totalNet) {
        this.totalNet = totalNet;
        return this;
    }

    public PaySummary_General setMemo(DollarCurrency memo) {
        this.memo = memo;
        return this;
    }

    public PaySummary_General setTips(DollarCurrency tips) {
        this.tips = tips;
        return this;
    }

    //Needed to test reversals efficiently
    public PaySummary_General getReverseFields() {
        PaySummary_General newPaySummary = new PaySummary_General()
                .setSummaryType(summaryType)
                .setPayDate(payDate)
                .setNumberPaid(numberPaid)
                .setPreGross(DollarCurrency.setDollarCurrency(-preGross.getAmount()))
                .setTpSickPay(DollarCurrency.setDollarCurrency(-tpSickPay.getAmount()))
                .setSales(DollarCurrency.setDollarCurrency(-sales.getAmount()))
                .setProcessedDate(processedDate)
                .setTotalNet(DollarCurrency.setDollarCurrency(-totalNet.getAmount()))
                .setMemo(DollarCurrency.setDollarCurrency(-memo.getAmount()))
                .setTips(DollarCurrency.setDollarCurrency(-tips.getAmount()));
        return newPaySummary;
    }

    public PaySummary_General importValues(PaySummary_General importData) {
        summaryType = importData.getSummaryType();
        payDate = importData.getPayDate();
        numberPaid = importData.getNumberPaid();
        preGross = importData.getPreGross();
        tpSickPay = importData.getTpSickPay();
        sales = importData.getSales();
        processedDate = importData.getProcessedDate();
        totalNet = importData.getTotalNet();
        memo = importData.getMemo();
        tips = importData.getTips();
        return this;
    }
}
