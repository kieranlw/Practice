package payroll.classObjects;

public class PayrollOtherPay {

    private String description;
    private Double amount;
    private String department;

    public String getDescription() {
        return description;
    }

    public Double getAmount() {
        return amount;
    }

    public String getDepartment() {
        return department;
    }

    private PayrollOtherPay(PayrollOtherPay.Builder builder) {
        description = builder.description;
        amount = builder.amount;
        department = builder.department;
    }

    public static PayrollOtherPay.Builder builder() {
        return new PayrollOtherPay.Builder();
    }

    public static class Builder {
        private String description;
        private Double amount;
        private String department;

        public PayrollOtherPay.Builder setDescription(String description) {
            this.description = description;
            return this;
        }

        public PayrollOtherPay.Builder setAmount(double amount) {
            this.amount = amount;
            return this;
        }

        public PayrollOtherPay.Builder setDepartment(String allocations) {
            this.department = allocations;
            return this;
        }

        private Builder() {
        }

        public PayrollOtherPay build() {
            return new PayrollOtherPay(this);
        }
    }

}
