package payroll.classObjects;

public class Report_TrialBalanceDetailReport {

	private String dateRange;
	//Pay Date won't always be a date
	private String payDate;
	private boolean hideMemo;
	private String sortBy;
	private String exportTo;

	public String getDateRange() {
		return dateRange;
	}

	public String getPayDate() {
		return payDate;
	}

	public String getSortBy() {
		return sortBy;
	}

	public String getExportTo() {
		return exportTo;
	}


	public boolean getHideMemo() {
		return hideMemo;
	}

	private Report_TrialBalanceDetailReport(Builder builder) {
		dateRange = builder.dateRange;
		payDate = builder.payDate;
		hideMemo = builder.hideMemo == null ? false : builder.hideMemo;
		sortBy = builder.sortBy;
		exportTo = builder.exportTo;
	}

	public static Report_TrialBalanceDetailReport.Builder builder(){
		return new Report_TrialBalanceDetailReport.Builder();
	}


	public static class Builder {
		private String dateRange;
		private String payDate;
		private Boolean hideMemo;
		private String sortBy;
		private String exportTo;

		public Builder setDateRange(String dateRange) {
			this.dateRange = dateRange;
			return this;
		}

		public Builder setPayDate(String payDate) {
			this.payDate = payDate;
			return this;
		}

		public Builder setHideMemo(boolean hideMemo) {
			this.hideMemo = hideMemo;
			return this;
		}

		public Builder setSortBy(String sortBy) {
			this.sortBy = sortBy;
			return this;
		}

		public Builder setExportTo(String exportTo) {
			this.exportTo = exportTo;
			return this;
		}

		private Builder() {
		}

		public Report_TrialBalanceDetailReport build() {
			return new Report_TrialBalanceDetailReport(this);
		}

	}
 	
}
