package payroll.classObjects;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import payroll.classObjects.QuickCalcVoucher.AddCalculatedGrossTo;
@Data
@Builder
@Getter
public class QuickCalcVoucherDetails {

    private boolean isIncludeStandardDeductions;
    private boolean isCurrentPayVoucherOrPayCheck;
    private boolean isIncludeInactive;
    private boolean isRegularPay;
    private boolean isAdditionalSupplementalCheck;
    private boolean isNetToGross;
    private String goalNetPay,
            employeeName,
            addCalculatedGrossTo;


}



