package payroll.classObjects;

import utils2.tableData.Row;

import java.util.HashMap;
import java.util.Set;

public class EmployeePayByPayReport {
    private final String employeeName;
    private final String employeeId;
    private final String employeeNumber;
    private final String PAEIT6521RTaxable;
    private final String PALST6521LTaxable;
    private final String PASDITaxable;
    private final String PASITTaxable;
    private final String PASUTATaxable;
    private final String USER_FICAMTaxable;
    private final String USER_FICASTaxable;
    private final String USFICAMTaxable;
    private final String USFICASTaxable;
    private final String USFITTaxable;
    private final String USFUTATaxable;
    private final String MDSITTaxable;
    private final String MDSUTATaxable;
    private final String PAEIT6753RTaxable;
    private final String PALST6773LTaxable;

    private final HashMap<String, String> taxes = new HashMap<>();

    public EmployeePayByPayReport(Row row) {
        this.employeeName = row.get("employee_name");
        this.employeeId = row.get("employee_id");
        this.employeeNumber = row.get("employee_number");
        this.PAEIT6521RTaxable = row.get("PA-EIT-6521R Taxable");
        this.PALST6521LTaxable = row.get("PA-LST-6521L Taxable");
        this.PASDITaxable = row.get("PA-SDI Taxable");
        this.PASITTaxable = row.get("PA-SIT Taxable");
        this.PASUTATaxable = row.get("PA-SUTA Taxable");
        this.USER_FICAMTaxable = row.get("US-ER_FICAM Taxable");
        this.USER_FICASTaxable = row.get("US-ER_FICAS Taxable");
        this.USFICAMTaxable = row.get("US-FICAM Taxable");
        this.USFICASTaxable = row.get("US-FICAS Taxable");
        this.USFITTaxable = row.get("US-FIT Taxable");
        this.USFUTATaxable = row.get("US-FUTA Taxable");
        this.MDSITTaxable = row.get("MD-SIT Taxable");
        this.MDSUTATaxable = row.get("MD-SUTA Taxable");
        this.PAEIT6753RTaxable = row.get("PA-EIT-6753R Taxable");
        this.PALST6773LTaxable = row.get("PA-LST-6773L Taxable");

        taxes.put("PA-EIT-6521R Taxable", PAEIT6521RTaxable);
        taxes.put("PA-LST-6521L Taxable", PALST6521LTaxable);
        taxes.put("PA-SDI Taxable", PASDITaxable);
        taxes.put("PA-SIT Taxable", PASITTaxable);
        taxes.put("PA-SUTA Taxable", PASUTATaxable);
        taxes.put("US-ER_FICAM Taxable", USER_FICAMTaxable);
        taxes.put("US-ER_FICAS Taxable", USER_FICASTaxable);
        taxes.put("US-FICAM Taxable", USFICAMTaxable);
        taxes.put("US-FICAS Taxable", USFICASTaxable);
        taxes.put("US-FIT Taxable", USFITTaxable);
        taxes.put("US-FUTA Taxable", USFUTATaxable);
        taxes.put("MD-SIT Taxable", MDSITTaxable);
        taxes.put("MD-SUTA Taxable", MDSUTATaxable);
        taxes.put("PA-EIT-6753R Taxable", PAEIT6753RTaxable);
        taxes.put("PA-LST-6773L Taxable", PALST6773LTaxable);
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public Set<String> getAvailableTaxNames() {
        return taxes.keySet();
    }

    public String getEmployeeNumber() {
        return employeeNumber;
    }

    public HashMap<String, String> getTaxes() {
        return taxes;
    }

    @Override
    public String toString() {
        return "EmployeePayByPayReport{" +
                "employeeName='" + employeeName + '\'' +
                ", employeeId='" + employeeId + '\'' +
                ", employeeNumber='" + employeeNumber + '\'' +
                ", PAEIT6521RTaxable='" + PAEIT6521RTaxable + '\'' +
                ", PALST6521LTaxable='" + PALST6521LTaxable + '\'' +
                ", PASDITaxable='" + PASDITaxable + '\'' +
                ", PASITTaxable='" + PASITTaxable + '\'' +
                ", PASUTATaxable='" + PASUTATaxable + '\'' +
                ", USER_FICAMTaxable='" + USER_FICAMTaxable + '\'' +
                ", USER_FICASTaxable='" + USER_FICASTaxable + '\'' +
                ", USFICAMTaxable='" + USFICAMTaxable + '\'' +
                ", USFICASTaxable='" + USFICASTaxable + '\'' +
                ", USFITTaxable='" + USFITTaxable + '\'' +
                ", USFUTATaxable='" + USFUTATaxable + '\'' +
                ", MDSITTaxable='" + MDSITTaxable + '\'' +
                ", MDSUTATaxable='" + MDSUTATaxable + '\'' +
                ", PAEIT6753RTaxable='" + PAEIT6753RTaxable + '\'' +
                ", PALST6773LTaxable='" + PALST6773LTaxable + '\'' +
                ", taxes=" + taxes +
                '}';
    }
}
