package payroll.classObjects.jobCodes;

public enum ElectronicLocation {
    NONE_SELECTED("None Selected"),
    MARYLAND("Maryland");

    private final String optionName;

    ElectronicLocation(String optionName) {
        this.optionName = optionName;
    }

    public String getSelectedOption() {
        if (optionName.equals("Maryland")) {
            return "MD";
        } else {
            return null;
        }
    }

    public String getOptionName() {
        return optionName;
    }
}
