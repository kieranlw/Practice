package payroll.classObjects.agencyDetails;

public enum PaymentMethods {
    SELECT_ONE("Select One"),
    CHECK("Check"),
    ELECTRONIC("Electronic");

    private final String optionName;
    PaymentMethods(String optionName) {
        this.optionName = optionName;
    }
    public String getOptionName() {
        return optionName;
    }
}
