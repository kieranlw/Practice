package payroll.classObjects.agencyDetails;

public enum Frequencies {
    SELECT_ONE("Select One"),
    MONTHLY("Monthly"),
    NOT_COLLECTED("Not Collected"),
    PER_PAY("Per Pay");

    private final String optionName;
    Frequencies(String optionName) {
        this.optionName = optionName;
    }
    public String getOptionName() {
        return optionName;
    }
}
