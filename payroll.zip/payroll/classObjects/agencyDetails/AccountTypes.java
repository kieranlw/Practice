package payroll.classObjects.agencyDetails;

public enum AccountTypes {
    CHECKING("Checking"),
    SAVINGS("Savings");

    private final String optionName;
    AccountTypes(String optionName) {
        this.optionName = optionName;
    }
    public String getOptionName() {
        return optionName;
    }
}
