package payroll.classObjects;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class PayrollPayInfo {

    private Double regularHours,
            rate,
            OTHours,
            otFactor;

    private Integer workPeriod;
    private String department,
            jobCode;
    private boolean autoOtFactor;
}
