package payroll.classObjects;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class PaySpecificInfo {

    private String department,
    jobCode,
    payType,
    rate,
    factorOT;
    private int workPeriodNumber;

}
