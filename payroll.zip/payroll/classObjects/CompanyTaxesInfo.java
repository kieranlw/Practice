package payroll.classObjects;

import utils2.tableData.Row;

public class CompanyTaxesInfo {

    private String taxCode;
    private String description;
    private String rate;
    private String taxType;
    private String frequency;
    private String status;

    public String getTaxCode() {
        return taxCode;
    }

    public CompanyTaxesInfo setTaxCode(String taxCode) {
        this.taxCode = taxCode;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public CompanyTaxesInfo setDescription(String description) {
        this.description = description;
        return this;
    }

    public String getRate() {
        return rate;
    }

    public CompanyTaxesInfo setRate(String rate) {
        this.rate = rate;
        return this;
    }

    public String getTaxType() {
        return taxType;
    }

    public CompanyTaxesInfo setTaxType(String taxType) {
        this.taxType = taxType;
        return this;
    }

    public String getFrequency() {
        return frequency;
    }

    public CompanyTaxesInfo setFrequency(String frequency) {
        this.frequency = frequency;
        return this;
    }

    public String getStatus() {
        return status;
    }

    public CompanyTaxesInfo setStatus(String status) {
        this.status = status;
        return this;
    }

    public Row getCompanyTaxesRow() {
        Row row = Row.of(
                "Tax Code", taxCode,
                "Description", description,
                "Rate", rate,
                "Tax Type", taxType,
                "Frequency", frequency,
                "Status", status);

        return row;
    }

    public Row getEmployeeTaxesRow() {
        Row row = Row.of(
                "Tax Code", taxCode,
                "Description", description,
                "Status", status);

        return row;
    }

    public Row getOtherTaxesRow() {
        Row row = Row.of(
                "Tax Code", taxCode,
                "Description", description,
                //Update if we add additional fields
                "Amount", "Defaults",
                "Other Information", "");

        return row;
    }

    public String getDefaultLocalsDropdownString() {
        return "(" + taxCode + ")  " + description;
    }

    public String getDescriptionWithoutPrefix() {
        return description.substring(3, description.length());
    }

    public String getExtraTaxCodeDetailsDescriptionString() {
        return description.replace("-", " - ") + " (" + taxCode + ")";
    }
}
