package payroll.classObjects;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class EmployeeManualPayInfo {

    private DollarCurrency trueGross,
            sales,
            chargeTips,
            tips,
            netPay,
            ficaUncollectedTax,
            regularGross,
            overtimeGross;
    private Double regularHours, overtimeHours;

}
