package payroll.classObjects.eeAdmin;

import utils2.JavaTimeUtils;
import utils2.tableData.Row;

import java.time.LocalDate;

public class DependentInfo {

    private String firstName;
    private String middleName;
    private String lastName;
    private String suffix;
    private LocalDate birthdate;
    private String ssn;

    public String getFirstName() {
        return firstName;
    }

    public DependentInfo setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public String getMiddleName() {
        return middleName;
    }

    public DependentInfo setMiddleName(String middleName) {
        this.middleName = middleName;
        return this;
    }

    public String getLastName() {
        return lastName;
    }

    public DependentInfo setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public String getSuffix() {
        return suffix;
    }

    public DependentInfo setSuffix(String suffix) {
        this.suffix = suffix;
        return this;
    }

    public LocalDate getBirthdate() {
        return birthdate;
    }

    public DependentInfo setBirthdate(LocalDate birthdate) {
        this.birthdate = birthdate;
        return this;
    }

    public String getSsn() {
        return ssn;
    }

    public DependentInfo setSsn(String ssn) {
        this.ssn = ssn;
        return this;
    }

    public Row getDependentRow() {
        Row row = Row.of(
                "First Name", firstName,
                "Middle Name", middleName,
                "Last Name", lastName,
                "Suffix", suffix,
                "Birth Date", JavaTimeUtils.getLocalDateString(birthdate, "MM/dd/yyyy"));

        return row;
    }

    public Row getESSRow() {
        Row row = Row.of("Requested", firstName + "\n"
                + middleName + "\n"
                + lastName + "\n"
                + suffix + "\n"
                + JavaTimeUtils.getLocalDateString(birthdate, "M/d/yyyy") + "\n"
                + ssn);

        return row;
    }
}
