package payroll.classObjects.eeAdmin;

import utils2.JavaTimeUtils;
import utils2.tableData.Row;

import java.text.DecimalFormat;
import java.time.LocalDate;

public class PersonalLeaveInfo {

    private String leavePayType;
    private LocalDate startDate;
    private LocalDate endDate;
    private Double hoursRequested;
    private String requesterNotes;

    private static final String DATE_FORMAT = "MM/dd/yyyy";

    public String getRequesterNotes() {
        return requesterNotes;
    }

    public PersonalLeaveInfo setRequesterNotes(String requesterNotes) {
        this.requesterNotes = requesterNotes;
        return this;
    }

    public String getLeavePayType() {
        return leavePayType;
    }

    public PersonalLeaveInfo setLeavePayType(String leavePayType) {
        this.leavePayType = leavePayType;
        return this;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public PersonalLeaveInfo setStartDate(LocalDate startDate) {
        this.startDate = startDate;
        return this;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public PersonalLeaveInfo setEndDate(LocalDate endDate) {
        this.endDate = endDate;
        return this;
    }

    public Double getHoursRequested() {
        return hoursRequested;
    }

    public PersonalLeaveInfo setHoursRequested(double hoursRequested) {
        this.hoursRequested = hoursRequested;
        return this;
    }

    public Row getTableRow() {
        Row row = Row.of(
                "Leave Pay Type", leavePayType,
                "Start Date", JavaTimeUtils.getLocalDateString(startDate, DATE_FORMAT),
                "End Date", JavaTimeUtils.getLocalDateString(endDate, DATE_FORMAT),
                "Requested Hours", getHoursRequestedFormattedForTables());

        return row;
    }

    public Row getTableRow_TimeOffRequestCalendar() {
        Row row = Row.of(
                "Leave Pay Type", leavePayType,
                "Start Date", JavaTimeUtils.getLocalDateString(startDate, DATE_FORMAT),
                "End Date", JavaTimeUtils.getLocalDateString(endDate, DATE_FORMAT),
                "Hours Requested", getHoursRequestedFormattedForTables());

        return row;
    }

    public String getHoursRequestedFormattedForTables() {
        DecimalFormat df = new DecimalFormat("#0.00");
        return df.format(hoursRequested);
    }
}
