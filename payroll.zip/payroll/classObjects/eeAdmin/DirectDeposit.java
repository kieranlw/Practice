package payroll.classObjects.eeAdmin;

import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class DirectDeposit {
    private String routingNumber;
    private String accountNumber;
    private String accountType;

    public String getRoutingNumber() {
        return routingNumber;
    }

    public DirectDeposit setRoutingNumber(String routingNumber) {
        this.routingNumber = routingNumber;
        return this;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getAccountNumberAsteriskized() {
        return asteriskisizeTheValue(accountNumber);
    }

    public String getRoutingNumberAsteriskized() {
        return asteriskisizeTheValue(routingNumber);
    }

    public DirectDeposit setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
        return this;
    }

    public String getAccountType() {
        return accountType;
    }

    public DirectDeposit setAccountType(String accountType) {
        this.accountType = accountType;
        return this;
    }


    public String getRequestedChanges(){
        return "ADD\nAccount#: " + getAccountNumberAsteriskized() + "\nDFI#: " + getRoutingNumberAsteriskized();
    }

    private String asteriskisizeTheValue(String value){
        return IntStream.range(0, value.length()-4).mapToObj(i -> "*").collect(Collectors.joining())
                + value.substring(value.length() - 4);

    }
}
