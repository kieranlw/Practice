package payroll.classObjects;

import utils2.tableData.Row;

public class EmployeePaidInfo {

    private String num;
    private EmployeeName employeeName;
    private DollarCurrency trueGross;
    private DollarCurrency netPay;
    private DollarCurrency employeeTax;
    private DollarCurrency employerTax;

    public String getNum() {
        return num;
    }

    public EmployeeName getEmployeeName() {
        return employeeName;
    }

    public DollarCurrency getTrueGross() {
        return trueGross;
    }

    public DollarCurrency getNetPay() {
        return netPay;
    }

    public DollarCurrency getEmployeeTax() {
        return employeeTax;
    }

    public DollarCurrency getEmployerTax() {
        return employerTax;
    }

    public Row getRow() {
        Row rowToReturn = Row.of(
                "Num", num,
                "Employee", employeeName.getLastName() + ", " + employeeName.getFirstName(),
                "True Gross", trueGross.getDoubleAsString2Decimals(),
                "Net Pay", netPay.getDoubleAsString2Decimals(),
                "Employee Tax", employeeTax.getDoubleAsString2Decimals(),
                "Employer Tax", employerTax.getDoubleAsString2Decimals());

        return rowToReturn;
    }

    private EmployeePaidInfo(Builder builder) {
        num = builder.num;
        employeeName = builder.employeeName;
        trueGross = builder.trueGross;
        netPay = builder.netPay;
        employeeTax = builder.employeeTax;
        employerTax = builder.employerTax;
    }

    public static EmployeePaidInfo.Builder builder() {
        return new EmployeePaidInfo.Builder();
    }

    public static class Builder {
        private String num;
        private EmployeeName employeeName;
        private DollarCurrency trueGross;
        private DollarCurrency netPay;
        private DollarCurrency employeeTax;
        private DollarCurrency employerTax;

        public Builder setNum(String num) {
            this.num = num;
            return this;
        }

        public Builder setEmployeeName(EmployeeName employeeName) {
            this.employeeName = employeeName;
            return this;
        }

        public Builder setTrueGross(DollarCurrency trueGross) {
            this.trueGross = trueGross;
            return this;
        }

        public Builder setNetPay(DollarCurrency netPay) {
            this.netPay = netPay;
            return this;
        }

        public Builder setEmployeeTax(DollarCurrency employeeTax) {
            this.employeeTax = employeeTax;
            return this;
        }

        public Builder setEmployerTax(DollarCurrency employerTax) {
            this.employerTax = employerTax;
            return this;
        }

        private Builder() {
        }

        public EmployeePaidInfo build() {
            return new EmployeePaidInfo(this);
        }
    }
}
