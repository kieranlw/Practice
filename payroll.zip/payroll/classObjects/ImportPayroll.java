package payroll.classObjects;

import java.time.LocalDate;

public class ImportPayroll {

    private String selectImport;
    private String selectDepartment;
    private LocalDate periodStartDate;
    private LocalDate periodEndDate;
    private String weekNumber;

    public LocalDate getPeriodStartDate() {
        return periodStartDate;
    }

    public ImportPayroll setPeriodStartDate(LocalDate periodStartDate) {
        this.periodStartDate = periodStartDate;
        return this;
    }

    public LocalDate getPeriodEndDate() {
        return periodEndDate;
    }

    public ImportPayroll setPeriodEndDate(LocalDate periodEndDate) {
        this.periodEndDate = periodEndDate;
        return this;
    }

    public String getSelectImport() {
        return selectImport;
    }

    public ImportPayroll setSelectImport(String selectImport) {
        this.selectImport = selectImport;
        return this;
    }

    public String getSelectDepartment() {
        return selectDepartment;
    }

    public ImportPayroll setSelectDepartment(String selectDepartment) {
        this.selectDepartment = selectDepartment;
        return this;
    }

    public String getWeekNumber() {
        return weekNumber;
    }

    public ImportPayroll setWeekNumber(String weekNumber) {
        this.weekNumber = weekNumber;
        return this;
    }
}

