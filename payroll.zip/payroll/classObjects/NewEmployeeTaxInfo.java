package payroll.classObjects;

public class NewEmployeeTaxInfo {

    private String rateSchedule;
    private String witholdingStatus;
    private int dependentsCount;
    private DollarCurrency dependentsExemption;
    private String workLocation;
    private String state;
    private String filingStatus;
    private String mdCounty;

    public String getRateSchedule() {
        return rateSchedule;
    }

    public NewEmployeeTaxInfo setRateSchedule(String rateSchedule) {
        this.rateSchedule = rateSchedule;
        return this;
    }

    public DollarCurrency getDependentsExemption() {
        return dependentsExemption;
    }

    public NewEmployeeTaxInfo setDependentsExemption(DollarCurrency dependentsExemption) {
        this.dependentsExemption = dependentsExemption;
        return this;
    }

    public String getFilingStatus() {
        return filingStatus;
    }

    public NewEmployeeTaxInfo setFilingStatus(String filingStatus) {
        this.filingStatus = filingStatus;
        return this;
    }

    public String getMdCounty() {
        return mdCounty;
    }

    public NewEmployeeTaxInfo setMdCounty(String mdCounty) {
        this.mdCounty = mdCounty;
        return this;
    }

    public String getWitholdingStatus() {
        return witholdingStatus;
    }

    public NewEmployeeTaxInfo setWitholdingStatus(String witholdingStatus) {
        this.witholdingStatus = witholdingStatus;
        return this;
    }

    public int getDependentsCount() {
        return dependentsCount;
    }

    public NewEmployeeTaxInfo setDependentsCount(int dependentsCount) {
        this.dependentsCount = dependentsCount;
        return this;
    }

    public String getWorkLocation() {
        return workLocation;
    }

    public NewEmployeeTaxInfo setWorkLocation(String workLocation) {
        this.workLocation = workLocation;
        return this;
    }

    public String getState() {
        return state;
    }

    public NewEmployeeTaxInfo setState(String state) {
        this.state = state;
        return this;
    }
}
