package payroll.pages.onboardingAdmin;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

import java.time.Duration;


public class AdministrativeSettings_Page extends BasePage_EEAdmin {

    @ComponentFindBy(id = "BtnCreateInviteLetter")
    public GenericComponent createInviteUsersLink;

    @ComponentFindBy(id = "BtnOnboardingTemplates")
    public NavigateTo<OnboardingTemplates_Page> onboardingTemplatesLink;

    @Override
    public void waitForPageToLoad() {
        createInviteUsersLink.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public AdministrativeSettings_Page(WebDriver driver) {
        super(driver);
    }
}
