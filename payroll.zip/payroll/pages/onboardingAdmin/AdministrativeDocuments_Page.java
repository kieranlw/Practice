package payroll.pages.onboardingAdmin;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.pages.onboardingAdmin.pageComponents.Table_AdministrativeDocuments;
import utils2.page_components.*;

import java.time.Duration;

public class AdministrativeDocuments_Page extends BasePage_EEAdmin {



    @ComponentFindBy(friendlyName = "View Personal Documents Link", xpath = "//a[contains(.,'View Your Personal Documents')]")
    public Label viewPersonalDocumentsLink;

    @ComponentFindBy(friendlyName = "Administrative Documents Table", xpath = "//h3[text()='Administrative Documents']/following-sibling::div[1]//table")
    public Table_AdministrativeDocuments administrativeDocumentsTable;

    @Override
    public void waitForPageToLoad() {
        viewPersonalDocumentsLink.waitUntil(Duration.ofMinutes(2)).displayed();
        ThreadUtils.sleep(500);
    }

    public AdministrativeDocuments_Page(WebDriver driver) {
        super(driver);
    }
}
