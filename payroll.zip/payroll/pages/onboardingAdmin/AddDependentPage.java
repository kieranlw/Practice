package payroll.pages.onboardingAdmin;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.classObjects.eeAdmin.DependentInfo;
import payroll.page_components.TextBox_Payroll;
import utils2.JavaTimeUtils;
import utils2.page_components.*;

import java.time.Duration;

public class AddDependentPage extends BasePage_EEAdmin {

    @ComponentFindBy(id = "btn-save")
    public NavigateTo<DependentsInformation_Page> saveRequestButton;

    @ComponentFindBy(id = "EmpChangeDependentInformation_FirstName")
    private TextBox firstNameTextbox;

    @ComponentFindBy(id = "EmpChangeDependentInformation_MiddleName")
    private TextBox middleNameTextbox;

    @ComponentFindBy(id = "EmpChangeDependentInformation_LastName")
    private TextBox lastNameTextbox;

    @ComponentFindBy(id = "EmpChangeDependentInformation_Suffix")
    private TextBox suffixTextbox;

    @ComponentFindBy(id = "EmpChangeDependentInformation_BirthDate")
    private TextBox birthDateTextbox;

    @ComponentFindBy(id = "EmpChangeDependentInformation_Ssn")
    private TextBox_Payroll ssnTextbox;

    public AddDependentPage enterDependentInfo(DependentInfo dependentInfo){
        firstNameTextbox.enterText(dependentInfo.getFirstName());
        middleNameTextbox.enterText(dependentInfo.getMiddleName());
        lastNameTextbox.enterText(dependentInfo.getLastName());
        suffixTextbox.enterText(dependentInfo.getSuffix());
        ssnTextbox.enterText(dependentInfo.getSsn());
        if(dependentInfo.getBirthdate() != null){
            birthDateTextbox.enterText(JavaTimeUtils.getLocalDateString(dependentInfo.getBirthdate(), "MM/dd/yyyy"));
        }

        return this;
    }



    @Override
    public void waitForPageToLoad() {
        firstNameTextbox.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public AddDependentPage(WebDriver driver) {
        super(driver);
    }
}
