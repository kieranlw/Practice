package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.pages.workflow.BasePage;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_AccessibilityPolicy_Page extends BasePage {

    @ComponentFindBy(xpath = "//h1[contains(text(), 'Deluxe Website Accessibility Policy')]")
    public Label accessibilityPolicyHeader;


    @Override
    public void waitForPageToLoad() throws Exception {

        accessibilityPolicyHeader.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_AccessibilityPolicy_Page(WebDriver driver) {
        super(driver);
    }
}
