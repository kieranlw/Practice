package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_InvitationExpired_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//h1")
    public Label invitationExpired;

    @ComponentFindBy(xpath = "//button[contains(text(),'Login')]")
    public NavigateTo<DUO_Login_Page> loginButton;

    public DUO_InvitationExpired_Page verifyLinkExpired() {
        invitationExpired.verify().textEquals("Invitation Expired");
        return this;
    }

    @Override
    public void waitForPageToLoad() {
        loginButton.waitUntil(Duration.ofSeconds(60)).displayed();
        ThreadUtils.sleep(2500);
    }

    public DUO_InvitationExpired_Page(WebDriver driver) {
        super(driver);
    }
}
