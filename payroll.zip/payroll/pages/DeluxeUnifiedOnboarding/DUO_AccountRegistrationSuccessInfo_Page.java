package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_AccountRegistrationSuccessInfo_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//a[contains(text(),'Log into your account')]")
    public NavigateTo<DUO_Login_Page> loginLink;

    @ComponentFindBy(xpath = "//h2[contains(text(),'Success!')]")
    public Label successMsg;

    @ComponentFindBy(xpath = "//p[contains(text(),\"You’ve set up your account, now it’s time to start setting up your company. We’ve sent a confirmation to\")]/strong")
    public Label eMailVerification;

    @Override
    public void waitForPageToLoad() {
        loginLink.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_AccountRegistrationSuccessInfo_Page(WebDriver driver) {
        super(driver);
    }
}
