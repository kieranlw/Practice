package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_EmailVerification_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//span[text()='HR Solutions']")
    public NavigateTo<DUO_Login_Page> emailVerificationHeaderLink;

    @ComponentFindBy(xpath = "//h1[contains(text(),'Email Verification Required')]")
    public Label emailVerificationRequiredHeader;

    @ComponentFindBy(xpath = "//p[contains(text(),\"Your email address has not been verified. Please look for the verification email in your inbox and click on the link contained within.\")]")
    public Label emailVerificationRequiredSubHeader;

    @ComponentFindBy(xpath = "//h1[contains(text(),'Email Verification Error')]")
    public Label emailVerificationErrorHeader;

    @ComponentFindBy(xpath = "//p[contains(text(),\"Verification email link expired or invalid. Please log in to resend the verification email\")]")
    public Label emailVerificationErrorSubHeader;

    @ComponentFindBy(xpath = "//h1[contains(text(),'Email Verified')]")
    public Label emailVerifiedHeader;

    @ComponentFindBy(xpath = "//p[contains(text(),\"Your email address has been verified. Please log in to continue\")]")
    public Label emailVerifiedSubHeader;

    @ComponentFindBy(xpath = "//BUTTON[text()='Resend Email']")
    public Button resendEmailBtn;

    @ComponentFindBy(xpath = "//BUTTON[text()='Email Sent!']")
    public Button emailSentBtn;

    @ComponentFindBy(xpath = "//BUTTON[text()='Logout']")
    public NavigateTo<DUO_Login_Page> logoutBtn;

    @ComponentFindBy(xpath = "//BUTTON[text()='Login']")
    public NavigateTo<DUO_Login_Page> loginBtn;

    @ComponentFindBy(xpath = "//BUTTON[text()='Login to resend the verification email']")
    public NavigateTo<DUO_Login_Page> loginToResendEmailBtn;

    @ComponentFindBy(xpath = "//a[contains(text(),'Forgot password?')]")
    public GenericComponent forgotPasswordLnk;

    public void verifyResendEmail(){
        resendEmailBtn.click();
        emailSentBtn.waitUntil(Duration.ofSeconds(5)).displayed();
        emailSentBtn.verify().disabled();
    }
    @Override
    public void waitForPageToLoad() {
        emailVerificationHeaderLink.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(5000);
    }

    public DUO_EmailVerification_Page(WebDriver driver) {
        super(driver);
    }
}
