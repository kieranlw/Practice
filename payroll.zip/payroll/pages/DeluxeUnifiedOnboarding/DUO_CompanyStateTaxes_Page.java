package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

import java.io.File;
import java.time.Duration;

public class DUO_CompanyStateTaxes_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//h2[normalize-space()='State Tax Info']")
    public Label companyStateTaxes;

    @ComponentFindBy(xpath = "//BUTTON[text()='Back']")
    public NavigateTo<DUO_AuthorizationForms_Page> backBtn;

    @ComponentFindBy(xpath = "//BUTTON[text()='Next Step']")
    public NavigateTo<DUO_CompanyBankAccount_Page> nextStepBtn;

    @ComponentFindBy(xpath = "//button[.=' Add State']")
    public Button addStateBtn;

    @ComponentFindBy(xpath = "//button[.=' Edit Tax Info']")
    public Button editTaxInfoBtn;

    @ComponentFindBy(xpath = "//span[contains(.,'Remove')]")
    public Button removeBtn;

    @ComponentFindBy(xpath = "//select[@id='state']")
    public DropDown stateDropDown;

    @ComponentFindBy(xpath = "//select[@id='withHoldingStatus']")
    public DropDown withHoldingStatusDropDown;

    @ComponentFindBy(xpath = "//select[@id='unemploymentStatus']")
    public DropDown unemploymentStatusDropDown;

    @ComponentFindBy(id = "unemploymentId")
    public TextBox unemploymentIDTextbox;

    @ComponentFindBy(id = "unemploymentSuiRate")
    public TextBox unemploymentRateTextbox;

    @ComponentFindBy(xpath = "//input[@id='unemploymentProofFile']")
    public TextBox unemploymentUploadFileBtn;

    @ComponentFindBy(id = "unemploymentElement")
    public TextBox unemploymentElement;

    @ComponentFindBy(xpath = "//input[@id='stateWithholdingProofFile']")
    public TextBox withHoldingUploadFileBtn;

    @ComponentFindBy(xpath = "//button[.='Cancel']")
    public Button cancelBtn;

    @AfterClick_HardCodedSleep(milliseconds = 2000, why = "for element display")
    @ComponentFindBy(xpath = "//button[.='Save State']")
    public Button saveStateBtn;

    //'State is required'
    @ComponentFindBy(xpath = "//label[@for='state']/../div")
    public Label stateRequiredError;

    //'Withholding Status is required.'
    @ComponentFindBy(xpath = "//label[@for='withholdingStatus']/../div")
    public Label withholdingStatusRequiredError;

    //'Unemployment status is required.'
    @ComponentFindBy(xpath = "//label[@for='unemploymentStatus']/../div")
    public Label unemploymentRequiredError;

    //'State withholding proof is required.'
    @ComponentFindBy(xpath = "//label[@for='stateWithholdingProofFile']/../div")
    public Label stateWithHoldingProofRequiredError;

    //'State unemployment proof is required.'
    @ComponentFindBy(xpath = "//label[@for='unemploymentProofFile']/../div")
    public Label unemploymentProofRequiredError;

    @ComponentFindBy(xpath = "//input[@id='withholdingId']")
    public TextBox withHoldingIdTextBox;

    @ComponentFindBy(xpath = "//label[@for='withholdingId']")
    public Label withHoldingIdLabel;

    //'SIT Frequency is required.'
    @ComponentFindBy(xpath = "//label[@for='sitFrequency']/../div")
    public Label withHoldingFreqError;

    @ComponentFindBy(xpath = "//label[@for='sitFrequency']")
    public Label withHoldingFreqLabel;

    //'Withholding ID is required.'
    @ComponentFindBy(xpath = "//label[@for='withholdingId']/../div")
    public Label withHoldingIdError;

    //'Only PDF, PNG & JPG files are allowed'
    @ComponentFindBy(xpath = "//label[@for='stateWithholdingProofFile']/../div")
    public Label withHoldingProofFileIncorrectTypeUploadError;

    //'Max file size 5MB'
    @ComponentFindBy(xpath = "//label[@for='stateWithholdingProofFile']/../div")
    public Label withHoldingProofFileMaxFileSizeUploadError;

    @ComponentFindBy(xpath = "//button[.='Remove ']")
    public Label removeWithHoldingProofFile;

    @ComponentFindBy(xpath = "//select[@id='sitFrequency']")
    public DropDown withHoldingFreqDropDown;

    @ComponentFindBy(xpath = "//input[@id='withholdingStatusWaiverFile']/preceding-sibling::label/parent::div/preceding-sibling::div/parent::form/i")
    public Label penaltiesLabel;

    @ComponentFindBy(xpath = "//input[@id='withholdingStatusWaiverFile']/preceding-sibling::p")
    public Label disclosureWaiverLabel;

    @ComponentFindBy(xpath = "//input[@id='withholdingStatusWaiverFile']/parent::div/a")
    public TextBox withholdingStatusWaiverDownloadFileBtn;

    @ComponentFindBy(xpath = "//input[@id='withholdingStatusWaiverFile']")
    public TextBox withholdingStatusWaiverUploadFileBtn;

    @ComponentFindBy(xpath = "//a[contains(text(),'Registration for your state')]")
    public Label stateRegistrationLink;

    @ComponentFindBy(xpath = "//input[@id='withholdingStatusWaiverFile']/parent::div/div/button")
    public Button withholdingStatusWaiverRemoveBtn;

    @ComponentFindBy(xpath = "//input[@id='withholdingStatusWaiverFile']/parent::div/div/div/span")
    public Label withholdingStatusWaiverUploadedLabel;

    @ComponentFindBy(xpath = "//input[@id='withholdingStatusWaiverFile']/parent::div/button/following-sibling::div")
    public Label withholdingStatusWaiverErrorLabel;

    
    @Override
    public void waitForPageToLoad() {
        companyStateTaxes.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_CompanyStateTaxes_Page navigateToTheAddStateScreen() {
        addStateBtn.click();
        stateDropDown.waitUntil(Duration.ofSeconds(10)).displayed();
        return this;
    }

    public DUO_CompanyStateTaxes_Page cancelAddingTheState() {
        if (cancelBtn.exists()) {
            cancelBtn.click();
            addStateBtn.waitUntil(Duration.ofSeconds(10)).displayed();
        }
        return this;
    }

    public DUO_CompanyStateTaxes_Page verifyWithholdingProofFileUploaded() {
        removeWithHoldingProofFile.verify().displayed();
        return this;
    }

    public DUO_CompanyStateTaxes_Page uploadUnemploymentProofFile(File file) {
        unemploymentUploadFileBtn.removeAttribute("style");
        unemploymentUploadFileBtn.enterText(file.getAbsolutePath());

        ThreadUtils.sleep(500);
        return this;
    }

    public DUO_CompanyStateTaxes_Page uploadWithHoldingProofFile(File file) {
        withHoldingUploadFileBtn.removeAttribute("style");
        withHoldingUploadFileBtn.enterText(file.getAbsolutePath());

        ThreadUtils.sleep(500);
        return this;
    }

    public DUO_CompanyStateTaxes_Page saveStateCallingErrors() {
        saveStateBtn.click();
        unemploymentProofRequiredError.waitUntil(Duration.ofSeconds(10));

        return this;
    }

    public DUO_CompanyStateTaxes_Page saveStateWaitingToReturnToStateScreen() {
        saveStateBtn.click();
        addStateBtn.waitUntil(Duration.ofSeconds(20)).displayed();
        return this;
    }

    public DUO_CompanyStateTaxes_Page removeStateAndWaitUntilPageGetLoaded() {
        removeBtn.click();
        editTaxInfoBtn.waitUntil(Duration.ofSeconds(20)).notDisplayed();
        removeBtn.waitUntil(Duration.ofSeconds(20)).notDisplayed();
        return this;
    }

    public DUO_CompanyStateTaxes_Page addExemptNoSITState(File file) {
        addStateBtn.click();
        stateDropDown.selectValue("Alaska");
        unemploymentStatusDropDown.selectValue("No");
        unemploymentUploadFileBtn.click();
        unemploymentElement.removeAttribute("style");
        unemploymentElement.enterText(file.getAbsolutePath());
        saveStateBtn.click();

        ThreadUtils.sleep(500);

        return this;
    }

    public DUO_CompanyStateTaxes_Page(WebDriver driver) {
        super(driver);
    }
}
