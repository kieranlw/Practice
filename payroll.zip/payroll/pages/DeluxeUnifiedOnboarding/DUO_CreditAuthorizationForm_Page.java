package payroll.pages.DeluxeUnifiedOnboarding;

import common.Is;
import common.ThreadUtils;
import common.Verify;
import org.openqa.selenium.WebDriver;
import payroll.api.DeluxeUnifiedOnboarding.Account;
import payroll.api.DeluxeUnifiedOnboarding.Company;
import payroll.api.DeluxeUnifiedOnboarding.CompanyAddress;
import payroll.classObjects.DigitalOnboarding.CreditAuthorizationForm;
import utils2.page_components.*;

import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class DUO_CreditAuthorizationForm_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//h2[normalize-space()='Business Information & Credit Authorization']")
    public TextBox creditAuthorizationHeader;

    @ComponentFindBy(xpath = "//p[normalize-space()='By completing the application you are applying for Deluxe HR Solutions for your business and are relying on your business credit history on the basis for repayment of the credit requested.']")
    public TextBox creditAuthorizationSubHeader;

    @ComponentFindBy(id = "companyName")
    public TextBox businessLegalName;

    @ComponentFindBy(xpath = "//div[text()='Company Name is required.']")
    public Label businessLegalNameError;

    @ComponentFindBy(id = "tradeNameDBA")
    public TextBox tradeOrDBAName;

    @ComponentFindBy(xpath = "//div[text()='Trade Name(s) or DBA is required.']")
    public Label tradeOrDBAError;

    @ComponentFindBy(id = "businessStructure")
    public DropDown businessOrganizationStructure;

    @ComponentFindBy(xpath = "//div[text()='Business organization must be selected.']")
    public Label businessOrganizationStructureError;

    @ComponentFindBy(id = "fein")
    public TextBox fein;

    @ComponentFindBy(xpath = "//div[text()='Sorry! FEIN is required.']")
    public Label feinError;

    @ComponentFindBy(id = "companyAddress")
    public TextBox businessAddress;

    @ComponentFindBy(xpath = "//div[text()='Business address is required.']")
    public Label businessAddressError;

    @ComponentFindBy(id = "city")
    public TextBox city;

    @ComponentFindBy(xpath = "//div[text()='City is required.']")
    public Label cityError;

    @ComponentFindBy(id = "state")
    public DropDown state;

    @ComponentFindBy(xpath = "//div[text()='State is required.']")
    public Label stateError;

    @ComponentFindBy(id = "zip")
    public TextBox zipCode;

    @ComponentFindBy(xpath = "//div[text()='Zip code is required.']")
    public Label zipCodeError;

    @ComponentFindBy(id = "companyPhoneNumber")
    public TextBox businessPhoneNumber;

    @ComponentFindBy(xpath = "//div[text()='Company Phone Number is required.']")
    public Label businessPhoneNumberError;

    @ComponentFindBy(id = "firstName")
    public TextBox ownerFirstName;

    @ComponentFindBy(xpath = "//div[text()='First Name is required.']")
    public Label ownerFirstNameError;

    @ComponentFindBy(id = "lastName")
    public TextBox ownerLastName;

    @ComponentFindBy(xpath = "//div[text()='Last Name is required.']")
    public Label ownerLastNameError;

    @ComponentFindBy(id = "primaryContactEmail")
    public TextBox ownerEmail;

    @ComponentFindBy(xpath = "//div[text()='Company Name is required.']")
    public Label ownerEmailError;

    @ComponentFindBy(id = "authorizationCommercialCreditCheck")
    public CheckBox creditAuthorization;

    @ComponentFindBy(xpath = "//span[contains(text()='I agree that everything I have stated in this application is correct to the best of my knowledge.')]")
    public Label creditAuthorizationMessage;

    @ComponentFindBy(xpath = "//div[text()='Company Name is required.']")
    public Label creditAuthorizationError;

    @ComponentFindBy(xpath = "//span[@class='form-check-label']")
    public Button creditAuthorizationLabel;

    @ComponentFindBy(xpath = "//button[text()='Previous']")
    public NavigateTo<DUO_PackageAddOns_Page> previousBtn;

    @ComponentFindBy(xpath = "//button[text()='Submit']")
    public NavigateTo<DUO_CreditAuthorization_SuccessPage> submitBtn;

    public static final List<String> DROPDOWN_VALUES = Collections.unmodifiableList(Arrays.asList("State", "Alabama", "Alaska", "Arkansas",
            "Arizona", "California", "Colorado", "Connecticut", "Delaware", "District Of Columbia", "Florida", "Georgia",
            "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland",
            "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire",
            "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania",
            "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington",
            "West Virginia", "Wisconsin", "Wyoming"));

    public DUO_CreditAuthorizationForm_Page(WebDriver driver) {
        super(driver);
    }

    public DUO_CreditAuthorizationForm_Page deleteCommercialData() {
        businessLegalName.waitUntil(Duration.ofSeconds(50)).enabled();
        businessLegalName.deleteAllText();
        tradeOrDBAName.deleteAllText();
        businessOrganizationStructure.selectValue("Select one");
        fein.deleteAllText();
        businessAddress.deleteAllText();
        city.deleteAllText();
        state.selectValue("State");
        zipCode.deleteAllText();
        businessPhoneNumber.deleteAllText();
        ownerFirstName.deleteAllText();
        ownerLastName.deleteAllText();
        ownerEmail.deleteAllText();
        creditAuthorization.toggle(false);
        return this;
    }

    public DUO_CreditAuthorizationForm_Page deleteAllTextFromCompanyFields() {
        businessLegalName.waitUntil(Duration.ofSeconds(50)).enabled();
        businessLegalName.deleteAllText();
        tradeOrDBAName.deleteAllText();
        businessOrganizationStructure.selectValue("Select one");
        fein.deleteAllText();
        businessAddress.deleteAllText();
        city.deleteAllText();
        state.selectValue("State");
        zipCode.deleteAllText();
        businessPhoneNumber.deleteAllText();
        ownerFirstName.deleteAllText();
        ownerLastName.deleteAllText();
        ownerEmail.deleteAllText();
        creditAuthorization.toggle(false);
        return this;
    }

    public DUO_CreditAuthorizationForm_Page verifyHydratedData(Company company, Account account, CompanyAddress address) {
        businessLegalName.verify().textEquals(company.getCompanyLegalName());
        fein.verify().textEquals(company.getFein());
        businessAddress.verify().textEquals(address.getAddressLine1());
        city.verify().textEquals(address.getCity());
        state.verify().itemSelected(address.getState());
        zipCode.verify().textEquals(address.getZip());
        ownerFirstName.verify().textEquals(account.getFirstName() + " " + account.getLastName());
        ownerEmail.verify().textEquals(account.getEmailAddress());
        return this;
    }

    public DUO_CreditAuthorizationForm_Page fillInFieldsForCompany(CreditAuthorizationForm creditAuthorizationForm) {
        businessLegalName.deleteAllText().enterText(creditAuthorizationForm.getBusinessLegalName());
        fein.deleteAllText().enterText(creditAuthorizationForm.getFein());
        businessOrganizationStructure.selectValue("C-Corporation");
        businessAddress.deleteAllText().enterText(creditAuthorizationForm.getBusinessAddress());
        city.deleteAllText().enterText(creditAuthorizationForm.getCity());
        state.selectValue(creditAuthorizationForm.getState());
        zipCode.deleteAllText().enterText(creditAuthorizationForm.getZipCode());
        businessPhoneNumber.deleteAllText().enterText(creditAuthorizationForm.getBusinessPhoneNumber());
        ownerFirstName.deleteAllText().enterText(creditAuthorizationForm.getOwnerFirstName());
        ownerLastName.deleteAllText().enterText(creditAuthorizationForm.getOwnerLastName());
        ownerEmail.deleteAllText().enterText(creditAuthorizationForm.getOwnerEmail());
        return this;
    }

    public DUO_CreditAuthorizationForm_Page fillInFields(CreditAuthorizationForm creditAuthorizationForm) {
        businessLegalName.deleteAllText().enterText(creditAuthorizationForm.getBusinessLegalName());
        fein.deleteAllText().enterText(creditAuthorizationForm.getFein());
        businessOrganizationStructure.selectValue("C-Corporation");
        businessAddress.deleteAllText().enterText(creditAuthorizationForm.getBusinessAddress());
        city.deleteAllText().enterText(creditAuthorizationForm.getCity());
        state.selectValue(creditAuthorizationForm.getState());
        zipCode.deleteAllText().enterText(creditAuthorizationForm.getZipCode());
        businessPhoneNumber.deleteAllText().enterText(creditAuthorizationForm.getBusinessPhoneNumber());
        ownerFirstName.deleteAllText().enterText(creditAuthorizationForm.getOwnerFirstName());
        ownerLastName.deleteAllText().enterText(creditAuthorizationForm.getOwnerLastName());
        ownerEmail.deleteAllText().enterText(creditAuthorizationForm.getOwnerEmail());
        creditAuthorizationLabel.click();
        return this;
    }

    @Override
    public void waitForPageToLoad() throws Exception {
        creditAuthorizationHeader.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(3000);
    }
}
