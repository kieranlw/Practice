package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.DriverUtils;
import utils2.page_components.*;

import java.io.File;
import java.time.Duration;

public class DUO_AuthorizationForms_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//h2[normalize-space()='Authorization Forms']")
    public Label authorizationForms;

    @ComponentFindBy(xpath = "//h2[text()='Authorization Forms'] /following-sibling::p")
    public Label authorizationFormsPageSubheader;

    @ComponentFindBy(xpath = "//h2[text()='Authorization Forms'] /following-sibling::p/a/nobr")
    public Label authorizationFormsPageSubheaderPhoneNumber;

    @ComponentFindBy(xpath = "//button[text()='Next Step']")
    public NavigateTo<DUO_CompanyStateTaxes_Page> nextStepBtn;

    @ComponentFindBy(xpath = "//button[text()='Back']")
    public NavigateTo<DUO_FederalTaxInfo_Page> backBtn;

    @ComponentFindBy(id = "form8655File")
    public TextBox form8655UploadElement;

    @ComponentFindBy(xpath = "//input[@id='form8655File']/following-sibling::div//span[not(@class='input-group-text')]")
    public Label uploadFileText;

    @ComponentFindBy(xpath = "//input[@name='form8655File']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label uploadElementErrorMsg;

    @ComponentFindBy(xpath = "//label[normalize-space()='Form 8655: Reporting Agent Authorization']")
    public Label form8655ReportingAgentAuthorization;

    @ComponentFindBy(xpath = "//a[@download ='form8655File']")
    public GenericComponent form8655DownloadFile;

    @ComponentFindBy(xpath = "//input[@id='form8655File']//following-sibling::button")
    @AfterClick_HardCodedSleep(milliseconds = 500, why = "legacy code, reason unknown")
    public Button form8655UploadFile;

    @ComponentFindBy(xpath = "//input[@id='form8655File']//following-sibling::div/button")
    public Button form8655RemoveButton;

    @ComponentFindBy(xpath = "//span[normalize-space()='form8655.pdf']")
    public Label form8655UploadProof;

    @ComponentFindBy(xpath = "//div[@class='py-5 col-md-8']//div[@class='row']//div[1]//div[1]")
    public Label form8655ErrorMessage;

    @ComponentFindBy(xpath = "//label[normalize-space()='Form Substitution 8832: Entity Classification']")
    public Label form8832EntityClassification;

    @ComponentFindBy(xpath = "//a[@download ='form8832File']")
    public Button form8832DownloadFile;

    @ComponentFindBy(xpath = "//input[@id='form8832File']//following-sibling::button")
    @AfterClick_HardCodedSleep(milliseconds = 500, why = "legacy code, reason unknown")
    public Button form8832UploadFile;

    @ComponentFindBy(xpath = "//input[@id='form8832File']//following-sibling::div/button")
    public Button form8832RemoveButton;

    @ComponentFindBy(xpath = "//span[normalize-space()='form8832.pdf']")
    public Label form8832UploadProof;

    @ComponentFindBy(xpath = "//div[@class='col-md-7 offset-md-1']//div[2]//div[1]")
    public Label form8832ErrorMessage;

    @ComponentFindBy(xpath = "//label[normalize-space()='Direct Deposit Authorization']")
    public Label directDepositAuthorization;

    @ComponentFindBy(xpath = "//a[@download ='directDepositAuthorizationFormFile']")
    public Button directDepositAuthorizationDownloadFile;

    @ComponentFindBy(xpath = "//input[@id='directDepositAuthorizationFormFile']//following-sibling::button")
    @AfterClick_HardCodedSleep(milliseconds = 500, why = "legacy code, reason unknown")
    public Button directDepositAuthorizationUploadFile;

    @ComponentFindBy(xpath = "//input[@id='directDepositAuthorizationFormFile']//following-sibling::div/button")
    public Button directDepositAuthorizationRemoveButton;

    @ComponentFindBy(xpath = "//span[normalize-space()='directDepositAuthorization.pdf']")
    public Label directDepositAuthorizationUploadProof;

    @ComponentFindBy(xpath = "//div[@class='container-fluid']//div[3]//div[1]")
    public Label directDepositAuthorizationErrorMessage;

    @ComponentFindBy(xpath = "//label[normalize-space()='Beneficial Ownership Form']")
    public Label beneficialOwnershipForm;

    @ComponentFindBy(xpath = "//a[@download ='beneficialOwnershipFormFile']")
    public Button beneficialOwnershipDownloadFile;

    @ComponentFindBy(xpath = "//input[@id='beneficialOwnershipFormFile']//following-sibling::button")
    @AfterClick_HardCodedSleep(milliseconds = 500, why = "legacy code, reason unknown")
    public Button beneficialOwnershipUploadFile;

    @ComponentFindBy(xpath = "//input[@id='beneficialOwnershipFormFile']//following-sibling::div/button")
    public Button beneficialOwnershipRemoveButton;

    @ComponentFindBy(xpath = "//span[normalize-space()='beneficialOwnership.pdf']")
    public Label beneficialOwnershipUploadProof;

    @ComponentFindBy(xpath = "//div[@class='container-fluid']//div[4]//div[1]")
    public Label beneficialOwnershipErrorMessage;

    @ComponentFindBy(xpath = "//div[@class='container-fluid']//div[5]//div[1]")
    public Label creditCardErrorMessage;

    @ComponentFindBy(xpath = "//label[normalize-space()='Personal Guarantee Form']")
    public Label personalGuarantee;

    @ComponentFindBy(xpath = "//a[@download ='personalGuaranteeFormFile']")
    public Button personalGuaranteeDownloadFile;

    @ComponentFindBy(xpath = "//input[@id='personalGuaranteeFormFile']//following-sibling::button")
    @AfterClick_HardCodedSleep(milliseconds = 500, why = "legacy code, reason unknown")
    public Button personalGuaranteeUploadFile;

    @ComponentFindBy(xpath = "//input[@id='personalGuaranteeFormFile']//following-sibling::div/button")
    public Button personalGuaranteeRemoveButton;

    @ComponentFindBy(xpath = "//span[normalize-space()='personalGuarantee.pdf']")
    public Label personalGuaranteeUploadProof;

    @ComponentFindBy(xpath = "//div[@class='container-fluid']//div[5]//div[1]")
    public Label personalGuaranteeErrorMessage;

    public DUO_AuthorizationForms_Page clickNextCausesErrors() {
        nextStepBtn.click();
        ThreadUtils.sleep(500);
        new DriverUtils(driver).waitForReadyStateComplete(Duration.ofSeconds(5));
        return this;
    }

    public DUO_AuthorizationForms_Page clickToRemoveButton() {
        form8655RemoveButton.click();
        ThreadUtils.sleep(50);
        form8832RemoveButton.click();
        ThreadUtils.sleep(50);
        directDepositAuthorizationRemoveButton.click();
        ThreadUtils.sleep(50);
        beneficialOwnershipRemoveButton.click();
        ThreadUtils.sleep(50);
        personalGuaranteeRemoveButton.click();
        ThreadUtils.sleep(50);

        return this;
    }

    public DUO_AuthorizationForms_Page uploadFileForm8655(File file) {
        form8655UploadElement.removeAttribute("style");
        form8655UploadElement.enterText(file.getAbsolutePath());

        ThreadUtils.sleep(500);

        return this;
    }

    public DUO_AuthorizationForms_Page uploadFileForm8322(File file) {
        form8655UploadElement.removeAttribute("style");
        form8655UploadElement.enterText(file.getAbsolutePath());

        ThreadUtils.sleep(500);

        return this;
    }

    public DUO_AuthorizationForms_Page uploadFileDirectDeposit(File file) {
        form8655UploadElement.removeAttribute("style");
        form8655UploadElement.enterText(file.getAbsolutePath());

        ThreadUtils.sleep(500);

        return this;
    }

    public DUO_AuthorizationForms_Page uploadFileBeneficialOwnership(File file) {
        form8655UploadElement.removeAttribute("style");
        form8655UploadElement.enterText(file.getAbsolutePath());

        ThreadUtils.sleep(500);

        return this;
    }

    public DUO_AuthorizationForms_Page uploadFilePersonalGuarantee(File file) {
        form8655UploadElement.removeAttribute("style");
        form8655UploadElement.enterText(file.getAbsolutePath());

        ThreadUtils.sleep(500);

        return this;
    }

    @Override
    public void waitForPageToLoad() {
        authorizationForms.waitUntil(Duration.ofSeconds(50)).exists();
        ThreadUtils.sleep(1500);
    }

    public DUO_AuthorizationForms_Page(WebDriver driver) {
        super(driver);
    }
}

