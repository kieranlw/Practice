package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.classObjects.DigitalOnboarding.CompanyAddresses;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_CompanyAddresses_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//BUTTON[text()='Back']")
    public NavigateTo<DUO_CreditAuthorization_SuccessPage> backBtnForCreditAuthorizationSuccessPage;

    @ComponentFindBy(xpath = "//BUTTON[text()='Back']")
    public NavigateTo<DUO_PackageAddOns_Page> backBtnForPackageAddOns;

    @ComponentFindBy(xpath = "//BUTTON[text()='Back']")
    public NavigateTo<DUO_CreditAuthorizationForm_Page> backBtnforCreditAuthorizationPage;

    @ComponentFindBy(xpath = "//BUTTON[text()='Next Step']")
    public NavigateTo<DUO_FederalTaxInfo_Page> nextStepBtn;

    @ComponentFindBy(xpath = "//BUTTON[text()='Next Step']")
    public NavigateTo<DUO_CompanySummary_Page> nextStepBtnForSummaryPage;

    @ComponentFindBy(xpath = "//BUTTON[text()='Next Step']")
    public NavigateTo<DUO_CreditAuthorizationErrorPage1> nextStepBtnForErrorPage1;

    @ComponentFindBy(xpath = "//h3[text() ='Filing Address']")
    public GenericComponent filingAddressLabel;

    @ComponentFindBy(xpath = "//h3[text() ='Filing Address']//following-sibling::button[contains(text(), 'Add Address')]")
    public NavigateTo<DUO_CompanyAddresses_Page> filingAddress_AddNewAddressButton;

    @ComponentFindBy(xpath = "//h3[text()='Filing Address']/following-sibling::address")
    public GenericComponent filingAddress_Address;

    @ComponentFindBy(xpath = "//input[@id ='filing_addressLine1']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent filingAddress_address1ErrorMsg;

    @ComponentFindBy(xpath = "//input[@id ='filing_city']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent filingAddress_cityErrorMsg;

    @ComponentFindBy(xpath = "//select[@id ='filing_state']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent filingAddress_stateErrorMsg;

    @ComponentFindBy(xpath = "//input[@id ='filing_zip']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent filingAddress_zipCodeErrorMsg;

    @ComponentFindBy(xpath = "//input[@id ='filing_phone']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent filingAddress_phoneErrorMsg;

    @ComponentFindBy(xpath = "//h3[text() ='Mailing/Delivery Address']//following-sibling::button[contains(text(), 'Add Address')]")
    public NavigateTo<DUO_CompanyAddresses_Page> mailingAddress_AddNewAddressButton;

    @ComponentFindBy(xpath = "//h3[text() ='Mailing/Delivery Address']//following-sibling::button[contains(text(), 'Edit Address')]")
    @AfterClick_HardCodedSleep(milliseconds = 500, why = "legacy code, reason unknown")
    public NavigateTo<DUO_CompanyAddresses_Page> mailingAddress_EditNewAddressButton;

    @ComponentFindBy(xpath = "//h3[text() ='Mailing/Delivery Address']/following-sibling::address")
    public GenericComponent mailingDeliveryAddress_Address;

    @ComponentFindBy(xpath = "//input[@id ='mailing_addressLine1']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent mailingAddress_address1ErrorMsg;

    @ComponentFindBy(xpath = "//input[@id ='mailing_city']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent mailingAddress_cityErrorMsg;

    @ComponentFindBy(xpath = "//select[@id ='mailing_state']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent mailingAddress_stateErrorMsg;

    @ComponentFindBy(xpath = "//input[@id ='mailing_zip']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent mailingAddress_zipCodeErrorMsg;

    @ComponentFindBy(xpath = "//input[@id ='mailing_phone']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent mailingAddress_phoneErrorMsg;

    @ComponentFindBy(xpath = "//h3[text() ='Work Location(s)']/following-sibling::div/address")
    public GenericComponent worklocationsAddress_Address;

    @ComponentFindBy(xpath = "//h3[text()='Work Location(s)']/following-sibling::div[2]/address")
    public GenericComponent secondWorklocationsAddress_Address;

    @ComponentFindBy(xpath = "//input[@id ='work_1_addressLine1']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent workAddress_address1ErrorMsg;

    @ComponentFindBy(xpath = "//input[@id ='work_1_city']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent workAddress_cityErrorMsg;

    @ComponentFindBy(xpath = "//select[@id ='work_1_state']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent workAddress_stateErrorMsg;

    @ComponentFindBy(xpath = "//input[@id ='work_1_zip']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent workAddress_zipCodeErrorMsg;

    @ComponentFindBy(xpath = "//input[@id ='work_1_phone']//following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent workAddress_phoneErrorMsg;

    @ComponentFindBy(xpath = "//h3[text()='Filing Address']/following-sibling::button[text()=' Edit Address']")
    public NavigateTo<DUO_CompanyAddresses_Page> filingAddressEditFieldsButton;

    @ComponentFindBy(xpath = "//h3[text()='Work Location(s)']/following-sibling::div/button[text()=' Add Address']")
    public NavigateTo<DUO_CompanyAddresses_Page> workLocationAddNewAddressButton;

    @ComponentFindBy(xpath = "//h3[text()='Work Location(s)']/following-sibling::div/button[text()=' Edit Address']")
    public NavigateTo<DUO_CompanyAddresses_Page> workLocationAddressEditFields;

    @ComponentFindBy(xpath = "//div[./h3[text()='Mailing/Delivery Address']]")
    public Button mailingDeliveryAddressEditFields;

    @ComponentFindBy(id = "filing_addressLine1")
    public TextBox filingAddressLine1;

    @ComponentFindBy(id = "filing_addressLine2")
    public TextBox filingAddressLine2;

    @ComponentFindBy(id = "filing_city")
    private TextBox filingAddressCity;

    @ComponentFindBy(id = "filing_state")
    public DropDown filingAddressState;

    @ComponentFindBy(id = "filing_zip")
    private TextBox filingAddressZip;

    @ComponentFindBy(id = "filing_phone")
    private TextBox filingAddressPhone;

    @ComponentFindBy(id = "mailing_addressLine1")
    public TextBox mailingAddressLine1;

    @ComponentFindBy(id = "mailing_addressLine2")
    public TextBox mailingAddressLine2;

    @ComponentFindBy(id = "mailing_city")
    private TextBox mailingAddressCity;

    @ComponentFindBy(id = "mailing_state")
    public DropDown mailingAddressState;

    @ComponentFindBy(id = "mailing_zip")
    private TextBox mailingAddressZip;

    @ComponentFindBy(id = "mailing_phone")
    private TextBox mailingAddressPhone;

    @ComponentFindBy(id = "work_1_addressLine1")
    public TextBox workLocationAddressLine1;

    @ComponentFindBy(id = "work_1_addressLine2")
    public TextBox workLocationAddressLine2;

    @ComponentFindBy(id = "work_1_city")
    private TextBox workLocationAddressCity;

    @ComponentFindBy(id = "work_1_state")
    public DropDown workLocationAddressState;

    @ComponentFindBy(id = "work_1_zip")
    private TextBox workLocationAddressZip;

    @ComponentFindBy(id = "work_1_phone")
    private TextBox workLocationAddressPhone;

    @ComponentFindBy(id = "work_2_addressLine1")
    public TextBox secondWorkLocationAddressLine1;

    @ComponentFindBy(id = "work_2_addressLine2")
    public TextBox secondWorkLocationAddressLine2;

    @ComponentFindBy(id = "work_2_city")
    private TextBox secondWorkLocationAddressCity;

    @ComponentFindBy(id = "work_2_state")
    private DropDown secondWorkLocationAddressState;

    @ComponentFindBy(id = "work_2_zip")
    private TextBox secondWorkLocationAddressZip;

    @ComponentFindBy(id = "work_2_phone")
    private TextBox secondWorkLocationAddressPhone;

    @ComponentFindBy(xpath = "(//div[@class='mt-2 d-block text-muted'])[1]")
    private GenericComponent firstErrorMsg;

    @ComponentFindBy(xpath = "//button[contains(text(),'Save Address')]")
    @AfterClick_Wait(waitMethodName="waitForSave", timeoutInMilliseconds = 10000)
    @AfterClick_HardCodedSleep(milliseconds = 500, why="legacy code, reason unknown")
    public Button saveAddressButton;

    @ComponentFindBy(xpath = "//h3[text() ='Filing Address']//following-sibling::button[contains(text(), 'Edit Address')]")
    public NavigateTo<DUO_CompanyAddresses_Page> filingAddress_EditAddressButton;

    private boolean waitForSave() {
        return !saveAddressButton.exists() || firstErrorMsg.exists() || worklocationsAddressAlreadyExistErrorMsg.exists();
    }

    @ComponentFindBy(xpath = "//button[contains(text(),'Cancel')]")
    @AfterClick_HardCodedSleep(milliseconds = 500, why = "legacy code, reason unknown")
    public Button cancelAddressButton;

    @ComponentFindBy(xpath = "//span[contains(text(),'Copy address from filing address')]")
    public CheckBox copyAddressFromFilingAddressCheckbox;

    @ComponentFindBy(xpath = "//h3[text() ='Work Location(s)']/following-sibling::div/div[@class='mb-3 alert alert-error alert-dismissible fade show']")
    public GenericComponent worklocationsAddressAlreadyExistErrorMsg;

    @ComponentFindBy(xpath = "//h3[text() ='Work Location(s)']/following-sibling::div/div[@class='mb-3 alert alert-error alert-dismissible fade show']/button[@class='close']")
    public Button worklocationsAddressAlreadyExistErrorMsgCloseBtn;

    // new
    @ComponentFindBy(xpath = "//a [text()='Company Addresses']")
    public GenericComponent companyAdressesBar;

    @ComponentFindBy(xpath = "//h2 [text()='Company Addresses']")
    public Label companyAdressesHeader;

    @ComponentFindBy(xpath = "//a [text()='Federal Tax Info']")
    public GenericComponent federalTaxInfoBar;

    @ComponentFindBy(xpath = "//h2 [text()='Federal Tax Info']")
    public Label federalTaxInfoHeader;

    @ComponentFindBy(xpath = "//a[normalize-space()='Authorization Forms']")
    public GenericComponent authorizationFormsBar;

    @ComponentFindBy(xpath = "//a [text()='Authorization Forms']")
    public Label authorizationFormsHeader;

    @ComponentFindBy(xpath = "//a[normalize-space()='State Tax Info']")
    public GenericComponent stateTaxInfoBar;

    @ComponentFindBy(xpath = "//a [text()='State Tax Info']")
    public Label stateTaxInfoHeader;

    @ComponentFindBy(xpath = "//a [text()='Bank Account(s)']")
    public GenericComponent bankAccountsBar;

    @ComponentFindBy(xpath = "//h2 [text()='Bank Account(s)']")
    public Label bankAccountsHeader;

    @ComponentFindBy(xpath = "//a [text()='Summary']")
    public GenericComponent summaryBar;

    @ComponentFindBy(xpath = "//h2 [text()='Summary']")
    public Label summaryHeader;

    @ComponentFindBy(xpath = "//a [text()='User Agreement']")
    public GenericComponent userAgreementBar;

    @ComponentFindBy(xpath = "//h2 [text()='User Agreement']")
    public Label userAgreementHeader;

    @ComponentFindBy(xpath = "//button [@type='submit']")
    public Label disabledNextStep;

    @ComponentFindBy(xpath = "//div[@role='tooltip']")
    public Label toolTip;

    public DUO_CompanyAddresses_Page editFilingAddress(CompanyAddresses filingAddress) {
        filingAddress_AddNewAddressButton.click();
        filingAddressFillFields(filingAddress);
        saveAddressButton.click();
        return this;
    }

    public DUO_CompanyAddresses_Page editMailingAddress(CompanyAddresses mailingAddress) {
        mailingAddress_EditNewAddressButton.click();
        mailingAddressFillFields(mailingAddress);
        saveAddressButton.click();
        return this;
    }

    public DUO_CompanyAddresses_Page editWorklocation(CompanyAddresses worklocationAddress) {
        workLocationAddressEditFields.click();
        workLocationAddressFillFields(worklocationAddress);
        saveAddressButton.click();

        return this;
    }


    public DUO_CompanyAddresses_Page filingAddressFillFields(CompanyAddresses filingAddress) {

        filingAddressClearFields();
        filingAddressLine1.enterText(filingAddress.getAddress1());
        filingAddressLine2.enterText(filingAddress.getAddress2());
        filingAddressCity.enterText(filingAddress.getCity());
        filingAddressState.selectValue(filingAddress.getStateProvince());
        filingAddressZip.enterText(filingAddress.getZipPostalCode());
        filingAddressPhone.enterText(filingAddress.getPhoneNumber());
        saveAddressButton.click();
        ThreadUtils.sleep(1000);
        return this;
    }

    public DUO_CompanyAddresses_Page filingAddressClearFields() {
        filingAddressLine1.deleteAllText();
        filingAddressLine2.deleteAllText();
        filingAddressCity.deleteAllText();
        filingAddressState.selectValue("Please select");
        filingAddressPhone.deleteAllText();
        filingAddressZip.deleteAllText();
        filingAddressLine1.enterText("");
        ThreadUtils.sleep(500);

        return this;
    }

    public DUO_CompanyAddresses_Page mailingAddressFillFields(CompanyAddresses mailingAddress) {
        mailingAddress_AddNewAddressButton.click();
        mailingAddressClearFields();
        mailingAddressLine1.enterText(mailingAddress.getAddress1());
        mailingAddressLine2.enterText(mailingAddress.getAddress2());
        mailingAddressCity.enterText(mailingAddress.getCity());
        mailingAddressState.selectValue(mailingAddress.getStateProvince());
        mailingAddressZip.enterText(mailingAddress.getZipPostalCode());
        mailingAddressPhone.enterText(mailingAddress.getPhoneNumber());
        ThreadUtils.sleep(1000);
        saveAddressButton.click();
        return this;
    }

    public DUO_CompanyAddresses_Page mailingAddressClearFields() {
        mailingAddressLine1.deleteAllText();
        mailingAddressLine2.deleteAllText();
        mailingAddressCity.deleteAllText();
        mailingAddressState.selectValue("Please select");
        mailingAddressZip.deleteAllText();
        mailingAddressPhone.deleteAllText();
        mailingAddressLine1.enterText("");
        ThreadUtils.sleep(500);

        return this;
    }

    public DUO_CompanyAddresses_Page workLocationAddressFillFields(CompanyAddresses workLocationAddress) {
        workLocationAddNewAddressButton.click();
        worklocationAddressClearFields();
        workLocationAddressLine1.enterText(workLocationAddress.getAddress1());
        workLocationAddressLine2.enterText(workLocationAddress.getAddress2());
        workLocationAddressCity.enterText(workLocationAddress.getCity());
        workLocationAddressState.selectValue(workLocationAddress.getStateProvince());
        workLocationAddressZip.enterText(workLocationAddress.getZipPostalCode());
        workLocationAddressPhone.enterText(workLocationAddress.getPhoneNumber());
        ThreadUtils.sleep(1000);
        saveAddressButton.click();
        return this;
    }

    public DUO_CompanyAddresses_Page secondWorkLocationAddressFillFields(CompanyAddresses workLocationAddress) {
        secondWorkLocationAddressLine1.enterText(workLocationAddress.getAddress1());
        secondWorkLocationAddressLine2.enterText(workLocationAddress.getAddress2());
        secondWorkLocationAddressCity.enterText(workLocationAddress.getCity());
        secondWorkLocationAddressState.selectValue(workLocationAddress.getStateProvince());
        secondWorkLocationAddressZip.enterText(workLocationAddress.getZipPostalCode());
        secondWorkLocationAddressPhone.enterText(workLocationAddress.getPhoneNumber());
        ThreadUtils.sleep(1000);
        return this;
    }

    public DUO_CompanyAddresses_Page worklocationAddressClearFields() {
        workLocationAddressLine1.deleteAllText();
        workLocationAddressLine2.deleteAllText();
        workLocationAddressCity.deleteAllText();
        workLocationAddressState.selectValue("Please select");
        workLocationAddressZip.deleteAllText();
        workLocationAddressPhone.deleteAllText();
        workLocationAddressLine1.enterText("");
        ThreadUtils.sleep(500);
        return this;
    }

    @Override
    public void waitForPageToLoad() {
        filingAddressLabel.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(2500);
    }

    public DUO_CompanyAddresses_Page(WebDriver driver) {
        super(driver);
    }
}