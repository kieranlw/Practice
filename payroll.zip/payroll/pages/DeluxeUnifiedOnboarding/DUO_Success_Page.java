package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.pageControls.annotations.ControlFindBy;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_Success_Page extends DUO_BasePage {


    @ControlFindBy(xpath = "//h2[contains(text(), 'Congratulations')]")
    public Label successPageLabel;

    @ComponentFindBy(xpath = "//h2[contains(text(), 'Congratulations')]/following-sibling::p")
    public Label subheaderOne;

    @ComponentFindBy(xpath = "//h2[contains(text(), 'Congratulations')]/following-sibling::p/following-sibling::p")
    public Label subheaderTwo;

    @ComponentFindBy(xpath = "//h2[contains(text(), 'Congratulations')]/following-sibling::p/following-sibling::p/following-sibling::p")
    public Label subheaderThree;


    public DUO_Success_Page(WebDriver driver) {
        super(driver);
    }

    @Override
    public void waitForPageToLoad() throws Exception {
        successPageLabel.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }
}
