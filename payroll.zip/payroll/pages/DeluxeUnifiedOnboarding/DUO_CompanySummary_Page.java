package payroll.pages.DeluxeUnifiedOnboarding;

import common.Is;
import common.ThreadUtils;
import common.Verify;
import org.openqa.selenium.WebDriver;
import payroll.decisions.Environment;
import payroll.pages.DeluxeUnifiedOnboarding.pageComponents.ReactCheckbox;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_CompanySummary_Page extends DUO_BasePage {


    @ComponentFindBy(xpath = "//h2[text()='Summary']")
    public GenericComponent summaryLabel;

    @ComponentFindBy(xpath = "//td[@id='packagePrice']/label")
    public GenericComponent packageSelection_PackagePrice;

    @ComponentFindBy(xpath = "//td[@id='packagePrice']/preceding-sibling::td")
    public GenericComponent packageSelection_PackageChoice;

    @ComponentFindBy(xpath = "//td[text() = 'Benefits Administration']")
    public GenericComponent packageSelectionAddOns_BenefitsAdministration;

    @ComponentFindBy(id = "lblunlimitedWorkFlows")
    public GenericComponent packageSelectionAddOns_UnlimitedWorkFlows;

    @ComponentFindBy(id = "lbltimeTrackingAndProjectCodes")
    public GenericComponent packageSelectionAddOns_TimeTrackingAndProjectCodes;

    @ComponentFindBy(id = "lblptoAccrualPolicies")
    public GenericComponent packageSelectionAddOns_PTOAccrualPolicies;

    @ComponentFindBy(id = "lblposters")
    public GenericComponent packageSelectionAddOns_Posters;

    @ComponentFindBy(xpath = "//label[@id='lblATS']/parent::td/preceding-sibling::td")
    public GenericComponent packageSelectionAddOns_ATSSelection;

    @ComponentFindBy(id = "lblATS")
    public GenericComponent packageSelectionAddOns_ATSValue;

    @ComponentFindBy(xpath = "//label[@id='lblhrSolutionCenter']/parent::td/preceding-sibling::td")
    public GenericComponent packageSelectionAddOns_HRSolutionCenterSelection;

    @ComponentFindBy(id = "lblhrSolutionCenter")
    public GenericComponent packageSelectionAddOns_HRSolutionCenterValue;

    @ComponentFindBy(xpath = "//label[@id='lblhrTrainingModule']/parent::td/preceding-sibling::td")
    public GenericComponent packageSelectionAddOns_HRTrainingModulesSelection;

    @ComponentFindBy(id = "lblhrTrainingModule")
    public GenericComponent packageSelectionAddOns_HRTRainingModulesValue;

    @ComponentFindBy(xpath = "//label[@id='lblhrHandbookCreation']/parent::td/preceding-sibling::td")
    public GenericComponent packageSelectionAddOns_HRHandbookCreationSelection;

    @ComponentFindBy(id = "lblhrHandbookCreation")
    public GenericComponent packageSelectionAddOns_HRHandbookCreationValue;

    @ComponentFindBy(xpath = "//button[@id='btnPackageEdit']/label")
    public NavigateTo<DUO_PackageSelection_Page> packageSelection_EditButtonLabel;

    @ComponentFindBy(id = "FilingAddress_addressLine1_0")
    public GenericComponent companyAddresses_FilingAddressAddressLine1;

    @ComponentFindBy(id = "FilingAddress_AddressLine2_0")
    public GenericComponent companyAddresses_FilingAddressAddressLine2;

    @ComponentFindBy(id = "FilingAddress_citystatezip_0")
    public GenericComponent companyAddresses_FilingAddressCityStateZip;

    @ComponentFindBy(id = "FilingAddress_phone_0")
    public GenericComponent companyAddresses_FilingAddressPhone;

    @ComponentFindBy(id = "MailingAddress_addressLine1_0")
    public GenericComponent companyAddresses_MailingAddressAddressLine1;

    @ComponentFindBy(id = "MailingAddress_addressLine2_0")
    public GenericComponent companyAddresses_MailingAddressAddressLine2;

    @ComponentFindBy(id = "MailingAddress_citystatezip_0")
    public GenericComponent companyAddresses_MailingAddressCityStateZip;

    @ComponentFindBy(id = "MailingAddress_phone_0")
    public GenericComponent companyAddresses_MailingAddressPhone;

    @ComponentFindBy(id = "WorkLocationAddress_addressLine1_0")
    public GenericComponent companyAddresses_WorkLocationAddressLine1;

    @ComponentFindBy(id = "WorkLocationAddress_addressLine2_0")
    public GenericComponent companyAddresses_WorkLocationAddressLine2;

    @ComponentFindBy(id = "WorkLocationAddress_citystatezip_0")
    public GenericComponent companyAddresses_WorkLocationCityStateZip;

    @ComponentFindBy(id = "WorkLocationAddress_phone_0")
    public GenericComponent companyAddresses_WorkLocationPhone;

    @ComponentFindBy(xpath = "//button[@id='btnCompanyAddressEdit']/label")
    public NavigateTo<DUO_CompanyAddresses_Page> companyAddresses_EditButtonLabel;

    @ComponentFindBy(xpath = "//button[@id='btnBankAccountEdit']/parent::div/parent::div/parent::div/following-sibling::div/div/div/following-sibling::div/span")
    public GenericComponent bankAccounts_BankName;

    @ComponentFindBy(xpath = "//button[@id='btnBankAccountEdit']/parent::div/parent::div/parent::div/following-sibling::div/div/div/following-sibling::div/span/following-sibling::span")
    public GenericComponent bankAccounts_AccountNumber;

    @ComponentFindBy(xpath = "//button[@id='btnBankAccountEdit']/parent::div/parent::div/parent::div/following-sibling::div/div/div/following-sibling::div/span/following-sibling::span/following-sibling::span")
    public GenericComponent bankAccounts_AccountUses;

    @ComponentFindBy(xpath = "//button[@id='btnBankAccountEdit']/label")
    public NavigateTo<DUO_CompanyBankAccount_Page> bankAccounts_EditButtonLabel;

    @ComponentFindBy(id = "fed_fein")
    public GenericComponent federalTaxInfo_FEIN;

    @ComponentFindBy(id = "fed_legalEntityName")
    public GenericComponent federalTaxInfo_LegalEntityName;

    @ComponentFindBy(id = "federalFilingForm")
    public GenericComponent federalTaxInfo_FederalFilingForm;

    @ComponentFindBy(id = "federalDepositFrequency")
    public GenericComponent federalTaxInfo_DirectDepositFrequency;

    @ComponentFindBy(id = "isSeasonalEmployer")
    public GenericComponent federalTaxInfo_SeasonalEmployer;

    @ComponentFindBy(id = "naicsCode")
    public GenericComponent federalTaxInfo_NAICSCode;

    @ComponentFindBy(id = "workerTypesPaying")
    public GenericComponent federalTaxInfo_WorkerTypesPaying;

    @ComponentFindBy(id = "charity501C3")
    public GenericComponent federalTaxInfo_Charity501C3;

    @ComponentFindBy(id = "fed_fileName")
    public GenericComponent federalTaxInfo_IRSProof;

    @ComponentFindBy(xpath = "//button[@id='btnFedTaxEdit']/label")
    public NavigateTo<DUO_FederalTaxInfo_Page> federalTaxInfo_EditButtonLabel;

    @ComponentFindBy(id = "form8655FileName")
    public GenericComponent authorizationForms_Form8655;

    @ComponentFindBy(id = "form8832FileName")
    public GenericComponent authorizationForms_Form8832;

    @ComponentFindBy(id = "directDepositAuthorizationFormFileName")
    public GenericComponent authorizationForms_DirectDepositAuthorization;

    @ComponentFindBy(id = "beneficialOwnershipFormFileName")
    public GenericComponent authorizationForms_BeneficialOwnership;

    @ComponentFindBy(id = "personalGuaranteeFormFileName")
    public GenericComponent authorizationForms_PersonalGuarantee;

    @ComponentFindBy(id = "creditCardAuthorizationFormFileName")
    public GenericComponent authorizationForms_CreditCardAuthorization;

    @ComponentFindBy(xpath = "//button[@id='btnAuthorizationEdit']/label")
    public NavigateTo<DUO_AuthorizationForms_Page> authorizationForms_EditButtonLabel;

    @ComponentFindBy(xpath = "//button[@id='btnStateTaxEdit']/parent::div/parent::div/parent::div/following-sibling::div/div/div/label")
    public GenericComponent stateTaxInfo_StateLabel;

    @ComponentFindBy(xpath = "//button[@id='btnStateTaxEdit']/parent::div/parent::div/parent::div/following-sibling::div/div/div/following-sibling::div")
    public GenericComponent stateTaxInfo_StateInfo;

    @ComponentFindBy(xpath = "//button[@id='btnStateTaxEdit']/label")
    public NavigateTo<DUO_CompanyStateTaxes_Page> stateTaxInfo_EditButtonLabel;

    @ComponentFindBy(id = "btnNextStep")
    public NavigateTo<DUO_UserAgreement_Page> nextStepBtn;

    @ComponentFindBy(id = "btnBack")
    public NavigateTo<DUO_CompanyBankAccount_Page> backButton;

    @ComponentFindBy(id = "btnBack")
    public NavigateTo<DUO_CompanyAddresses_Page> backButtonForCompanyAddressesPage;

    @ComponentFindBy(xpath ="//h2[contains(text(),'Summary')]")
    public GenericComponent summaryPageHeader;

    @ComponentFindBy(id = "summaryHeaderText")
    public GenericComponent accountSummarySubHeader;

    @ComponentFindBy(id = "btnCompanyEdit")
    public GenericComponent companyID_EditButton;

    @ComponentFindBy(id = "btnPackageEdit")
    public GenericComponent packageSelection_EditButton;

    @ComponentFindBy(id = "btnCompanyAddressEdit")
    public GenericComponent companyAddresses_EditButton;

    @ComponentFindBy(id = "btnFedTaxEdit")
    public GenericComponent companyFederalTaxes_EditButton;

    @ComponentFindBy(id = "btnAuthorizationEdit")
    public GenericComponent companyAuthorizationForms_EditButton;

    @ComponentFindBy(id = "btnStateTaxEdit")
    public GenericComponent companyStateTaxes_EditButton;

    @ComponentFindBy(id = "btnBankAccountEdit")
    public GenericComponent companyBankAccounts_EditButton;

    @ComponentFindBy(xpath = "//div[@id='form-checkbox-agreedToAuthorizedSignature']/div/label")
    private ReactCheckbox authorizedSignatureCheckBox;

    @ComponentFindBy(xpath = "//div[@id='form-checkbox-agreedToTermsAndConditions']/div/label")
    private ReactCheckbox termsAndConditionsCheckBox;

    public DUO_CompanySummary_Page verifyEditButtonHiddenAndDisabled() {
        /*companyID_EditButtonLabel.verify().attributeHasValue("disabled", null).attributeHasValue("class", "btn d-none");
        packageSelection_EditButtonLabel.verify().attributeHasValue("disabled", null).attributeHasValue("class", "btn d-none");
        companyAddresses_EditButtonLabel.verify().attributeHasValue("disabled", null).attributeHasValue("class", "btn d-none");
        federalTaxInfo_EditButtonLabel.verify().attributeHasValue("disabled", null).attributeHasValue("class", "btn d-none");
        authorizationForms_EditButtonLabel.verify().attributeHasValue("disabled", null).attributeHasValue("class", "btn d-none");
        stateTaxInfo_EditButtonLabel.verify().attributeHasValue("disabled", null).attributeHasValue("class", "btn d-none");
        bankAccounts_EditButtonLabel.verify().attributeHasValue("disabled", null).attributeHasValue("class", "btn d-none");
        */

        companyID_EditButton.verify().disabled().notDisplayed();
        packageSelection_EditButton.verify().disabled().notDisplayed();
        companyAddresses_EditButton.verify().disabled().notDisplayed();
        companyFederalTaxes_EditButton.verify().disabled().notDisplayed();
        companyAuthorizationForms_EditButton.verify().disabled().notDisplayed();
        companyStateTaxes_EditButton.verify().disabled().notDisplayed();
        companyBankAccounts_EditButton.verify().disabled().notDisplayed();

        return this;
    }

    public DUO_CompanySummary_Page verifyNextAndBackButtonHiddenAndDisabled(){
        /*nextStepBtn.verify().disabled().notDisplayed();
        backButton.verify().disabled().notDisplayed();
        */
        nextStepBtn.verify().doesNotExist();
        backButton.verify().doesNotExist();
        return this;
    }

    public DUO_CompanySummary_Page verifyEditButtonShownAndEnabled(){
        companyID_EditButton.verify().enabled().displayed();
        packageSelection_EditButton.verify().enabled().displayed();
        companyAddresses_EditButton.verify().enabled().displayed();
        companyFederalTaxes_EditButton.verify().enabled().displayed();
        companyAuthorizationForms_EditButton.verify().enabled().displayed();
        companyStateTaxes_EditButton.verify().enabled().displayed();
        companyBankAccounts_EditButton.verify().enabled().displayed();
        return this;
    }

    public DUO_CompanySummary_Page verifyNextAndBackButtonShownAndEnabled(){
        nextStepBtn.verify().enabled().displayed();
        backButton.verify().enabled().displayed();
        return this;
    }


    public DUO_CompanySummary_Page verifyRedirectingToSummaryPage(WebDriver driver, Environment environment){
      driver.get(environment.getDO_Packages_URL());
      ThreadUtils.sleep(2000);
      Verify.that(driver.getCurrentUrl(), Is.equalTo(environment.getDO_Summary_URL()));

      driver.get(environment.getDO_CompanyAddresses_URL());
      ThreadUtils.sleep(2000);
      Verify.that(driver.getCurrentUrl(), Is.equalTo(environment.getDO_Summary_URL()));

      driver.get(environment.getDO_CompanyBankAccounts_URL());
      ThreadUtils.sleep(2000);
      Verify.that(driver.getCurrentUrl(), Is.equalTo(environment.getDO_Summary_URL()));
      return this;
    }

    public DUO_CompanySummary_Page verifySummaryPageAfterSelectingBlendedTheHrPackage(){
        summaryPageHeader.verify().displayed();
        packageSelection_PackageChoice.verify().displayed();
        packageSelectionAddOns_BenefitsAdministration.verify().displayed();
        companyAddresses_FilingAddressAddressLine1.verify().displayed();
        companyAddresses_MailingAddressAddressLine1.verify().displayed();
        companyAddresses_WorkLocationAddressLine1.verify().displayed();
        return this;
    }

    @Override
    public void waitForPageToLoad() {
        summaryPageHeader.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(1000);

    }

    public DUO_CompanySummary_Page(WebDriver driver) {
        super(driver);
    }


}
