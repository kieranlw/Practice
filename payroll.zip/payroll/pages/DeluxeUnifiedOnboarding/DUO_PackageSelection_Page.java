package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import utils2.DriverUtils;

import utils2.page_components.*;

import java.time.Duration;

public class DUO_PackageSelection_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//h2[text()='Package Selection']")
    public Label packageSelection;

    @ComponentFindBy(xpath = "//h2[text()='Package Selection']/following-sibling::p")
    public Label subheaderOne;

    @ComponentFindBy(xpath = "//h2[text()='Package Selection']/following-sibling::p/following-sibling::p")
    public Label subheaderTwo;

    @ComponentFindBy(xpath = "//h2[text()='Package Selection']/following-sibling::p/following-sibling::p/following-sibling::p")
    public Label subheaderThree;

    @ComponentFindBy(xpath = "//strong[contains(text(),'PAYROLL + HR ESSENTIALS')]")
    public Label essentialPackage;

    @ComponentFindBy(xpath = "//strong[contains(text(),'Blended: The HR Package')]")
    public Label blendedPackage;

    @ComponentFindBy(xpath = "//strong[contains(text(),'PAYROLL + HR ENHANCED')]")
    public Label enhancedPackage;

    @ComponentFindBy(id = "label-package4")
    @AfterClick_HardCodedSleep(milliseconds = 1000, why = "Page has slight delay to display the toast popup after selcting this package")
    public Button package1;

    @ComponentFindBy(id = "label-package2")
    @AfterClick_HardCodedSleep(milliseconds = 1000, why = "Page has slight delay to display the toast popup after selcting this package")
    public Button package2;

    @ComponentFindBy(id = "label-package5")
    @AfterClick_HardCodedSleep(milliseconds = 1000, why = "Page has slight delay to display the toast popup after selcting this package")
    public Button package3;

    @ComponentFindBy(xpath = "//*[@id=\"label-package1\"]/div")
    public GenericComponent package1Color;

    @ComponentFindBy(xpath = "//*[@id=\"label-package2\"]/div")
    public GenericComponent package2Color;

    @ComponentFindBy(xpath = "//*[@id=\"label-package3\"]/div")
    public GenericComponent package3Color;


    @ComponentFindBy(xpath = "//label[@id=\"label-package1\"]/div/h2")
    public Label litePackagePrice;

    @ComponentFindBy(xpath = "//*[@id=\"label-package1\"]/div/p[2]")
    public Label litePackageAdditionalPrice;

    @ComponentFindBy(id = "btnSeeDetails-package1")
    @AfterClick_HardCodedSleep(milliseconds = 1500, why="Legacy code, reason unknown")
    public Button litePackageSeeDetails;

    @ComponentFindBy(xpath = "//h5[@id='exampleModalLabel']")
    public Label litePackagePopUp;

    @ComponentFindBy(xpath = "//*[@id=\"label-package2\"]/div/h2")
    public Label blendedPackagePrice;

    @ComponentFindBy(xpath = "//*[@id=\"label-package2\"]/div/p[2]")
    public Label blendedPackageAdditionalPrice;

    @ComponentFindBy(id = "btnSeeDetails-package2")
    @AfterClick_HardCodedSleep(milliseconds = 500,why="Legacy code,reason unknown")
    public Button blendedPackageSeeDetails;

    @ComponentFindBy(xpath = "//h5[@id='exampleModalLabel']")
    public Label blendedPackagePopUp;

    @ComponentFindBy(xpath = "//*[@id=\"label-package3\"]/div/h2")
    public Label theWorksPackagePrice;

    @ComponentFindBy(xpath = "//*[@id=\"label-package3\"]/div/p[2]")
    public Label theWorksPackageAdditionalPrice;

    @ComponentFindBy(id = "btnSeeDetails-package3")
    @AfterClick_HardCodedSleep(milliseconds = 500,why="Legacy code,reason unknown")
    public Button theWorksPackageSeeDetails;

    @ComponentFindBy(xpath = "//h5[@id='exampleModalLabel']")
    public Label theWorksPackagePopUp;

    @ComponentFindBy(xpath = "//button[contains(text(),'Done')]")
    @AfterClick_HardCodedSleep(milliseconds = 1500,why="Legacy code,reason unknown")
    public Button packagePopUpDone;

    @ComponentFindBy(xpath = "//span[contains(text(),'×')]")
    @AfterClick_HardCodedSleep(milliseconds = 1500,why="Legacy code,reason unknown")
    public Button litePackagePopUpX;

    @ComponentFindBy(xpath = "//button[contains(text(),'Next Step')]")
    public NavigateTo<DUO_PackageAddOns_Page> nextStepBtn;

    @ComponentFindBy(id = "pricingPackageCodeError")
    public Label packageNotSelectedErrorMsg;


    public DUO_PackageSelection_Page selectPackage1(){
        package1.click();
        return this;
    }

    public DUO_PackageSelection_Page selectPackage2(){
        package2.click();
        return this;
    }

    public DUO_PackageSelection_Page selectPackage3(){
        package3.click();
        return this;
    }

    public DUO_PackageSelection_Page escapeModal(){
        Actions action = new Actions(driver);
        action.sendKeys(Keys.ESCAPE).perform();
        ThreadUtils.sleep(1500);
        return this;
    }


    public DUO_PackageSelection_Page closeModal(){

        if (packagePopUpDone.isDisplayed()) {

            packagePopUpDone.click();
        }

        return this;
    }


    @Override
    public void waitForPageToLoad() {
        essentialPackage.waitUntil(Duration.ofSeconds(50)).displayed();
        nextStepBtn.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(1000);

    }

    public DUO_PackageSelection_Page(WebDriver driver) {
        super(driver);
    }
}
