package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.pages.payroll.BasePage;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_Error404_Page extends BasePage {

    @ComponentFindBy(xpath = "//h2[text()='404']")
    public GenericComponent lostPageAlert;

    @Override
    public void waitForPageToLoad() {
        lostPageAlert.waitUntil(Duration.ofSeconds(10)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_Error404_Page(WebDriver driver) {
        super(driver);
    }
}
