package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.api.DeluxeUnifiedOnboarding.Account;
import payroll.classObjects.DigitalOnboarding.DigitalOnboardingLogin;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_OKTA_SignIn_Page extends DUO_BasePage {

    @ComponentFindBy(id = "okta-signin-username")
    public TextBox usernameTextbox;

    @ComponentFindBy(id = "okta-signin-password")
    public TextBox passwordTextbox;

    @ComponentFindBy(id = "okta-signin-submit")
    @AfterClick_HardCodedSleep(milliseconds = 1000,why="Legacy code, reason unknown")
    public NavigateTo<DUO_AccountHome_Page> signInButton;

    public DUO_OKTA_SignIn_Page fillInFields(DigitalOnboardingLogin loginInfo) {
        usernameTextbox.enterText(loginInfo.getUserName());
        passwordTextbox.enterText(loginInfo.getPassword());
        return this;
    }
    public DUO_OKTA_SignIn_Page fillInFields(Account loginInfo) {
        usernameTextbox.enterText(loginInfo.getEmailAddress());
        passwordTextbox.enterText(loginInfo.getPassword());
        return this;
    }

    @Override
    public void waitForPageToLoad() {
        usernameTextbox.waitUntil(Duration.ofSeconds(50)).displayed();
        passwordTextbox.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_OKTA_SignIn_Page(WebDriver driver) {
        super(driver);
    }
}
