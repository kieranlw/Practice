package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_ForgotPassword_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//button[normalize-space()='Send Reset Password Link']")
    public Label sendResetPasswordLink;

    @ComponentFindBy(xpath = "//h1[text()='Forgot Password']")
    public Label forgotPasswordPageHeader;

    @ComponentFindBy(xpath = "//span[text()='HR Solutions']")
    public NavigateTo<DUO_Login_Page> forgotPasswordHeaderLink;

    @Override
    public void waitForPageToLoad() {
        sendResetPasswordLink.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_ForgotPassword_Page(WebDriver driver) {
        super(driver);
    }
}

