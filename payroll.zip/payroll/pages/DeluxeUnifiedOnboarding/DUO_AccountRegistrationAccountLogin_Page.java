package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.page_components.TextBox_Payroll;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_AccountRegistrationAccountLogin_Page extends DUO_BasePage {

    @ComponentFindBy(id = "emailAddress")
    public TextBox_Payroll loginEmailAddressTextbox;

    @Override
    public void waitForPageToLoad() {
        loginEmailAddressTextbox.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_AccountRegistrationAccountLogin_Page(WebDriver driver) {
        super(driver);
    }
}

