package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.pageControls.annotations.ControlFindBy;
import utils2.page_components.*;
import java.time.Duration;

public class DUO_CreditAuthorization_SuccessPage extends DUO_BasePage {


    @ControlFindBy(xpath="//h2[contains(text(), 'Deluxe Credit Authorization')]/parent::div/following-sibling::div/div")
    public Label successPageText;

    @ComponentFindBy(xpath="//button[contains(text(), 'Back')]")
    public NavigateTo<DUO_PackageAddOns_Page> backButton;

    @ComponentFindBy(xpath="//button[contains(text(), 'Next Stage')]")
    public NavigateTo<DUO_CompanyAddresses_Page> nextStageBtn;

    public static final String THREE_DAYS_FUNDING = "Your credit has been checked and you have been approved to process your payroll 3 business days after payroll is submitted to Deluxe. Please continue onboarding.";
    public static final String FIVE_DAYS_FUNDING = "Your credit has been checked and you have been approved to process your payroll 5 business days after payroll is submitted to Deluxe. Please continue onboarding.";
    public static final String WIRE_ONLY = "Your credit has been checked and you have been approved to process your payroll once a wire has been received by Deluxe. Please continue onboarding.";

    public DUO_CreditAuthorization_SuccessPage(WebDriver driver) {
        super(driver);
    }

    @Override
    public void waitForPageToLoad() throws Exception {
        nextStageBtn.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(5000);
    }
}
