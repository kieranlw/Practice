package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_CreditAuthorizationErrorPage1 extends DUO_BasePage {

    @ComponentFindBy(xpath = "//h5[contains(text(),'We have encountered an issue with your account please contact us at')]")
    public GenericComponent errorPage1Text1;

    @ComponentFindBy(xpath = "//button[contains(text(), 'Try Again')]/preceding-sibling::p")
    public Label tryAgainMessage;

    @ComponentFindBy(xpath = "//button[contains(text(), 'Try Again')]")
    public NavigateTo<DUO_CreditAuthorizationForm_Page> tryAgainButton;

    public DUO_CreditAuthorizationErrorPage1 verifyErrorPageTextIsDisplayed() {
        errorPage1Text1.verify().displayed().textEquals("We have encountered an issue with your account please contact us at 1.833.200.4671 or PayOnboardingAdmin@deluxe.com\n" +
                "Thank You");
        return this;
    }

    public DUO_CreditAuthorizationErrorPage1(WebDriver driver) {
        super(driver);
    }

    @Override
    public void waitForPageToLoad() throws Exception {
        errorPage1Text1.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }
}
