package payroll.pages.DeluxeUnifiedOnboarding;

import common.Is;
import common.ThreadUtils;
import common.Verify;
import org.openqa.selenium.WebDriver;
import payroll.api.DeluxeUnifiedOnboarding.Account;
import payroll.api.DeluxeUnifiedOnboarding.CompanyAuthorizedUserInvitation;
import payroll.classObjects.DigitalOnboarding.AccountRegistrationAccountInfo;
import payroll.page_components.TextBox_Payroll;
import utils2.DriverUtils;
import utils2.page_components.*;

import java.time.Duration;

// todo update digital onboarding header page

public class DUO_AccountRegistrationAccountInfo_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//h1[text()='Create your setup account']")
    public Label accountInfoHeader;

    @ComponentFindBy(xpath = "//span[text()='Account Registration']")
    public NavigateTo<DUO_Login_Page> accountRegistrationHeaderLink;

    @ComponentFindBy(id = "firstName")
    public TextBox_Payroll firstNameTextbox;

    @ComponentFindBy(id = "lastName")
    public TextBox_Payroll lastNameTextbox;

    @ComponentFindBy(id = "emailAddress")
    public TextBox_Payroll emailAddressTextbox;

    @ComponentFindBy(id = "companyPhone")
    public TextBox_Payroll companyPhoneTextbox;

    @ComponentFindBy(id = "companyName")
    public TextBox_Payroll companyNameTextbox;

    @ComponentFindBy(id="state")
    public DropDown stateDropDown;

    @ComponentFindBy(id = "numberOfEmployees")
    public TextBox_Payroll employeeCountTextbox;

    @ComponentFindBy(id = "state")
    public DropDown stateDropdown;

    @ComponentFindBy(id = "zip")
    public TextBox_Payroll zip;

    @ComponentFindBy(xpath = "//BUTTON[text()='Next Step']")
    public NavigateTo<DUO_AccountRegistrationLoginInfo_Page> nextStepBtn;

    @ComponentFindBy(xpath = "//input[@id='firstName']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label firstNameErrorMsg;

    @ComponentFindBy(xpath = "//input[@id='lastName']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label lastNameErrorMsg;

    @ComponentFindBy(xpath = "//input[@id='emailAddress']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label emailAddressErrorMsg;

    @ComponentFindBy(xpath = "//input[@id='companyPhone']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label companyPhoneErrorMsg;

    @ComponentFindBy(xpath = "//input[@id='companyName']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label companyNameErrorMsg;

    @ComponentFindBy(xpath = "//select[@id='state']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label stateDropdownErrorMsg;

    @ComponentFindBy(xpath = "//input[@id='zip']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label zipCodeErrorMsg;

    @ComponentFindBy(xpath = "//input[@id='numberOfEmployees']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label employeeCountErrorMsg;

    public DUO_AccountRegistrationAccountInfo_Page fillInFields(AccountRegistrationAccountInfo accountRegistrationAccountInfo) {
        firstNameTextbox.enterText(accountRegistrationAccountInfo.getFirstName());
        lastNameTextbox.enterText(accountRegistrationAccountInfo.getLastName());
        emailAddressTextbox.enterText(accountRegistrationAccountInfo.getEmailAddress());
        companyPhoneTextbox.enterText(accountRegistrationAccountInfo.getCompanyPhone());
        companyNameTextbox.enterText(accountRegistrationAccountInfo.getCompanyName());
        employeeCountTextbox.enterText(accountRegistrationAccountInfo.getEmployeeCount());
        stateDropdown.selectValue(accountRegistrationAccountInfo.getState());
        zip.enterText(accountRegistrationAccountInfo.getZip());
        return this;
    }

    public DUO_AccountRegistrationAccountInfo_Page fillInFields(Account account) {
        firstNameTextbox.deleteAllText().enterText(account.getFirstName());
        lastNameTextbox.deleteAllText().enterText(account.getLastName());
        emailAddressTextbox.deleteAllText().enterText(account.getEmailAddress());
        companyPhoneTextbox.deleteAllText().enterText(account.getCompanyPhone());
        companyNameTextbox.deleteAllText().enterText(account.getCompanyName());
        employeeCountTextbox.deleteAllText().enterText("1000");
        stateDropdown.selectValue("Georgia");
        zip.deleteAllText().enterText(account.getZip());
        return this;
    }

    public void verifyFieldData(Account account) {
        String phone = companyPhoneTextbox.getText()
                .replace("(", "")
                .replace(")", "")
                .replace(" ", "")
                .replace("-", "");
        firstNameTextbox.verify().textEquals(account.getFirstName());
        lastNameTextbox.verify().textEquals(account.getLastName());
        emailAddressTextbox.verify().textEquals(account.getEmailAddress());
        Verify.that(phone, Is.equalTo(account.getCompanyPhone()));
        companyNameTextbox.verify().textEquals(account.getCompanyName());
        employeeCountTextbox.verify().textEquals("1000");
        stateDropdown.verify().itemSelected("Georgia");
        zip.verify().textEquals(account.getZip());
    }

    public DUO_AccountRegistrationAccountInfo_Page verifyHydratedEditableFields(CompanyAuthorizedUserInvitation userInvitation) {
        firstNameTextbox.verify().enabled().textEquals(userInvitation.getFirstName());
        lastNameTextbox.verify().enabled().textEquals(userInvitation.getLastName());
        return this;
    }

    public DUO_AccountRegistrationAccountInfo_Page verifyHydratedNotEditableFields(CompanyAuthorizedUserInvitation userInvitation) {
        companyNameTextbox.verify().disabled().textEquals(userInvitation.getCompanyName());
        emailAddressTextbox.verify().disabled().textEquals(userInvitation.getEmailAddress());
        return this;
    }

    public DUO_AccountRegistrationAccountInfo_Page verifyNotHydratedButEditableFields() {
        companyPhoneTextbox.verify().enabled().textEquals("");
        stateDropdown.verify().enabled().itemSelected("Please select");
        zip.verify().enabled().textEquals("");
        return this;
    }

    @Override
    public void waitForPageToLoad() {
        firstNameTextbox.waitUntil(Duration.ofSeconds(50)).displayed();
        nextStepBtn.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(2000);
    }

    public DUO_AccountRegistrationAccountInfo_Page(WebDriver driver) {
        super(driver);
    }
}
