package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.pages.DeluxeUnifiedOnboarding.pageComponents.ReactCheckbox;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_PackageAddOns_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//h2[text()='Expanded Features']")
    public Label packageAddOnsHeader;

    @ComponentFindBy(xpath = "//h2[contains(text(),'Package Add-ons')]")
    public Label packageAddOns;

    @ComponentFindBy(xpath = "//h2[contains(text(),'Package Add-ons')]/following-sibling::p")
    public Label subheaderOne;

    @ComponentFindBy(xpath = "//h2[contains(text(),'Package Add-ons')]/following-sibling::p/following-sibling::p")
    public Label subheaderTwo;

    @ComponentFindBy(id = "benefitsAdministration-label")
    public ReactCheckbox benefitsAdministration;

    @ComponentFindBy(id = "unlimitedWorkFlows-label")
    public ReactCheckbox unlimitedWorkFlows;

    @ComponentFindBy(id = "TimeTrackingForProjectsAndPTO-label")
    public ReactCheckbox timeTrackingForProjectsAndPTO;

    @ComponentFindBy(id = "TimeTrackingAndProjectCodes-label")
    public ReactCheckbox timeTrackingAndProjectCodes;

    @ComponentFindBy(id = "PTOAccrualPolicies-label")
    public ReactCheckbox ptoAccrualPolicies;

    @ComponentFindBy(id = "posters-label")
    public ReactCheckbox posters;

    @ComponentFindBy(xpath = "//h4[contains(text(),'Applicant Tracking System (ATS)')]")
    public Label applicantTrackingSystem;

    @ComponentFindBy(id = "toggle_ats")
    @AfterClick_HardCodedSleep(milliseconds = 1000, why = "Page has slight delay after click")
    public Button ats_showHideOptions;

    @ComponentFindBy(xpath = "//label[@id='HeroBasePackage-label']")
    public ReactCheckbox heroBasePackage;

    @ComponentFindBy(id = "Plus-label")
    public ReactCheckbox plus;

    @ComponentFindBy(id = "Pro-label")
    public ReactCheckbox pro;

    @ComponentFindBy(id = "ats-none-label")
    public ReactCheckbox atsNone;

    @ComponentFindBy(id = "toggle_hrSolutionCenter")
    @AfterClick_HardCodedSleep(milliseconds = 1000, why = "Page has slight delay after click")
    public Button hrSolutionCenter_showHideOptions;

    @ComponentFindBy(xpath = "//h4[normalize-space()='HR Solution Center']")
    public Label hrSolutionCenter;

    @ComponentFindBy(xpath = "//label[@id='Support-label']")
    public ReactCheckbox support;

    @ComponentFindBy(id = "OnDemand-label")
    public ReactCheckbox onDemand;

    @ComponentFindBy(id = "Complete-label")
    public ReactCheckbox complete;

    @ComponentFindBy(id = "hrSolutionCenter-none-label")
    public ReactCheckbox hrSolutionCenterNone;

    @ComponentFindBy(id = "toggle_hrTrainingModule")
    @AfterClick_HardCodedSleep(milliseconds = 1000, why = "Page has slight delay after click")
    public Button hrTrainingModule_showHideOptions;

    @ComponentFindBy(xpath = "//h4[normalize-space()='HR Training Modules']")
    public Label hrTrainingModules;

    @ComponentFindBy(xpath = "//label[@id='Learn1-label']")
    public ReactCheckbox learn1;

    @ComponentFindBy(id = "Learn2-label")
    public ReactCheckbox learn2;

    @ComponentFindBy(id = "Learn3-label")
    public ReactCheckbox learn3;

    @ComponentFindBy(id = "hrTrainingModule-none-label")
    public ReactCheckbox hrTrainingModuleNone;

    @ComponentFindBy(id = "toggle_hrHandbookCreation")
    @AfterClick_HardCodedSleep(milliseconds = 1000, why = "Page has slight delay after click")
    public Button hrHandbookCreation_showHideOptions;

    @ComponentFindBy(xpath = "//h5[normalize-space()='HR Handbook Creation']")
    public Label hrHandbookCreation;

    @ComponentFindBy(xpath = "//label[@id='HRHandbookReview-label']")
    public ReactCheckbox hrHandbookReview;

    @ComponentFindBy(id = "HRWizardHandbookCreation-label")
    public ReactCheckbox hrWizardHandbookCreation;

    @ComponentFindBy(id = "hrHandbookCreation-none-label")
    public ReactCheckbox hrHandbookCreationNone;

    @ComponentFindBy(id = "TimeSolutions-none-label")
    public ReactCheckbox timeSolutionsNone;

    @ComponentFindBy(xpath = "//label[@id=\"benefitsAdministration-label\"]//p[2]")
    public Label benefitsAdministrationPrice;

    @ComponentFindBy(xpath = "//label[@id='unlimitedWorkFlows-label']//p[2]")
    public Label unlimitedWorkFlowsPrice;

    @ComponentFindBy(xpath = "//label[@id='TimeTrackingAndProjectCodes-label']//p[2]")
    public Label timeTrackingAndProjectCodesPrice;

    @ComponentFindBy(xpath = "//label[@id='PTOAccrualPolicies-label']//p[2]")
    public Label ptoAccrualPoliciesPrice;

    @ComponentFindBy(xpath = "//label[@id=\"posters-label\"]//p[2]")
    public Label postersPrice;

    @ComponentFindBy(xpath = "//label[@id='HeroBasePackage-label']//p[2]")
    public Label heroBasePackagePrice;

    @ComponentFindBy(xpath = "//label[@id='Plus-label']//p[2]")
    public Label plusPrice;

    @ComponentFindBy(xpath = "//label[@id='Pro-label']//p[2]")
    public Label proPrice;

    @ComponentFindBy(xpath = "//label[@id='Support-label']//p[2]")
    public Label supportPrice;

    @ComponentFindBy(xpath = "//label[@id='OnDemand-label']//p[2]")
    public Label onDemandPrice;

    @ComponentFindBy(xpath = "//label[@id='Complete-label']//p[2]")
    public Label completePrice;

    @ComponentFindBy(xpath = "//label[@id='Learn1-label']//p[2]")
    public Label learn1Price;

    @ComponentFindBy(xpath = "//label[@id='Learn2-label']//p[2]")
    public Label learn2Price;

    @ComponentFindBy(xpath = "//label[@id='Learn3-label']//p[2]")
    public Label learn3Price;

    @ComponentFindBy(xpath = "//label[@id='HRHandbookReview-label']//p[2]")
    public Label hrHandbookReviewPrice;

    @ComponentFindBy(xpath = "//label[@id='HRWizardHandbookCreation-label']//p[2]")
    public Label hrWizardHandbookCreationPrice;

    @ComponentFindBy(xpath = "//label[@id='HRHandbookCreation-label']//p[2]")
    public Label hrHandbookCreationPrice;

    @ComponentFindBy(xpath = "//button[text()='Next Step']")
    public NavigateTo<DUO_CreditAuthorizationForm_Page> nextStepBtn;

    @ComponentFindBy(xpath = "//button[text()='Next Step']")
    public NavigateTo<DUO_CreditAuthorization_SuccessPage> nextStepBtnForSuccessPage;

    @ComponentFindBy(xpath = "//button[text()='Next Step']")
    public NavigateTo<DUO_CreditAuthorizationForm_Page> nextStepBtnForCreditAuthorizationPage;

    @ComponentFindBy(xpath = "//BUTTON[text()='Back']")
    public NavigateTo<DUO_PackageSelection_Page> backBtn;

    @ComponentFindBy(id = "toggle_TimeSolutions")
    @AfterClick_HardCodedSleep(milliseconds = 2000, why = "Page has slight delay after click")
    public Button timeSolution_showHideOptions;

    public DUO_PackageAddOns_Page defaultSettings() {
        benefitsAdministration.toggle(false);
        unlimitedWorkFlows.toggle(false);
        timeSolutionsNone.toggle(true);
        posters.toggle(false);
        atsNone.toggle(true);
        hrSolutionCenterNone.toggle(true);
        hrTrainingModuleNone.toggle(true);
        hrHandbookCreationNone.toggle(true);
        return this;
    }


    @Override
    public void waitForPageToLoad() {
        packageAddOnsHeader.waitUntil(Duration.ofSeconds(50)).exists();
        benefitsAdministration.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(2500);
    }

    public DUO_PackageAddOns_Page(WebDriver driver) {
        super(driver);
    }
}




