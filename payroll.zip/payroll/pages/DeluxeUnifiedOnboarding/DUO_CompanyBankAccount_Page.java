package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import payroll.api.DeluxeUnifiedOnboarding.CompanyBankAccount;
import payroll.page_components.TextBox_Payroll;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_CompanyBankAccount_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//h4[normalize-space()='Test Account']")
    public Label testAccountText;

    @ComponentFindBy(xpath = "//button[contains(text(),'Next Step')]")
    public NavigateTo<DUO_CompanySummary_Page> nextStepBtn;

    @ComponentFindBy(xpath = "//button[contains(text(),'Back')]")
    public NavigateTo<DUO_CompanyStateTaxes_Page> backBtn;

    @ComponentFindBy(xpath = "//button[contains(text(),'Save Account')]")
    public NavigateTo<DUO_CompanyBankAccount_Page> saveAccountBtn;

    @ComponentFindBy(id = "nickname")
    public TextBox_Payroll accountNickname;

    @ComponentFindBy(id = "accountType")
    public TextBox_Payroll accountType;

    @ComponentFindBy(id = "bankName")
    public TextBox_Payroll bankName;

    @ComponentFindBy(id = "routingNumber")
    public TextBox_Payroll routingNumber;

    @ComponentFindBy(id = "accountNumber")
    public TextBox_Payroll accountNumber;

    @ComponentFindBy(xpath = "//input[@id='accountUses-payroll']/following-sibling::span[1]")
    public CheckBox payrollChb;

    @ComponentFindBy(xpath = "//input[@id='accountUses-taxes']/following-sibling::span[1]")
    public CheckBox taxesChb;

    @ComponentFindBy(xpath = "//input[@id='accountUses-invoice-fees']/following-sibling::span[1]")
    public CheckBox invoiceFeesChb;

    @ComponentFindBy(xpath = "//input[@id='accountUses-payroll']")
    public GenericComponent payrollInput;

    @ComponentFindBy(xpath = "//input[@id='accountUses-taxes']")
    public GenericComponent taxesInput;

    @ComponentFindBy(xpath = "//input[@id='accountUses-invoice-fees']")
    public GenericComponent invoiceFeesInput;

    @ComponentFindBy(xpath = "//input[@id='authorizationHold']/following-sibling::span[1]")
    public CheckBox authorizationHoldChb;

    @ComponentFindBy(xpath = "//input[@id='authorizationHold']")
    public GenericComponent authorizationHoldInput;

    @ComponentFindBy(xpath = "//button[contains(.,'Edit')]")
    public Button editAccountButton;

    @ComponentFindBy(xpath = "//button[contains(.,'Verify')]")
    private Button verifyAccountButton;

    @ComponentFindBy(xpath = "//button[contains(.,'Add')]")
    private Button addAccountButton;

    @ComponentFindBy(xpath = "//button[contains(.,'Account Use(s)')]")
    private Label accountUseLabel;

    @ComponentFindBy(xpath = "//input[@name='bankName']/..//div")
    private Label bankNameEmptyStateError;

    @ComponentFindBy(xpath = "//input[@name='accountNumber']/../div")
    private Label accountNumberEmptyStateError;

    @ComponentFindBy(xpath = "//input[@name='accountUses']/../../../div/i/..")
    private Label accountUsesEmptyStateError;

    @ComponentFindBy(xpath = "//input[@name='authorizationHold']/../../../div/i/..")
    private Label authorizationHoldEmptyStateError;

    @ComponentFindBy(xpath = "//select[@name='accountType']/../div")
    private Label accountTypeEmptyStateError;

    @ComponentFindBy(xpath = "//h5[@id='exampleModalLabel']")
    private Label warningPopUpLabel;

    @ComponentFindBy(xpath = "//h5[@id='exampleModalLabel']/parent::div/following-sibling::div/p")
    private GenericComponent warningPopUpMessageFirstLine;

    @ComponentFindBy(xpath = "//div[./h5[@id='exampleModalLabel']]/following-sibling::div/p[2]")
    private GenericComponent warningPopUpMessageSecondLine;

    @ComponentFindBy(xpath = "//div[./h5[@id='exampleModalLabel']]/following-sibling::div/p[3]")
    private GenericComponent warningPopUpMessageThirdLine;

    @ComponentFindBy(xpath = "//button[contains(text(),'Close')]")
    public GenericComponent warningPopUpCloseBtn;

    @ComponentFindBy(xpath = "//span[contains(text(),'×')]")
    public GenericComponent warningPopUpXSign;

    @ComponentFindBy(xpath = "//h2[contains(text(),'Bank Account(s)')]")
    public GenericComponent bankAccountsPageLabel;

    @ComponentFindBy(xpath = "//p[contains(text(),'This is for your Payroll/Taxes run not your monthly subscription fee.')]")
    public GenericComponent bankAccountsPageSubheader;

    @ComponentFindBy(xpath = "//input[@id='accountNumber']/parent::div/div")
    public Label accountNumberErrorMessage;




    public DUO_CompanyBankAccount_Page saveBankAccount(CompanyBankAccount bankAccount) {
        if (!accountNickname.isDisplayed()) {
            addAccountButton.click();
            accountNickname.waitUntil(Duration.ofSeconds(10)).displayed();
        }
        accountNickname.enterText(bankAccount.getNickname());
        accountType.enterText(bankAccount.getAccountType());
        bankName.enterText(bankAccount.getBankName());
        routingNumber.enterText(bankAccount.getRoutingNumber());
        accountNumber.enterText(bankAccount.getAccountNumber());
        for (String accountUse : bankAccount.getAccountUses()) {
            switch (accountUse) {
                case "Payroll":
                    checkCheckbox(payrollChb, payrollInput);
                    break;
                case "Taxes":
                    checkCheckbox(taxesChb, taxesInput);
                    break;
                case "Invoice Fees":
                    checkCheckbox(invoiceFeesChb, invoiceFeesInput);
                    break;
            }
        }
        checkCheckbox(authorizationHoldChb, authorizationHoldInput);
        saveAccountBtn.click();
        warningPopUpMessageFirstLine.waitUntil(Duration.ofSeconds(10)).displayed();
        return this;
    }

    public DUO_CompanyBankAccount_Page editBankAccount(CompanyBankAccount bankAccount) {
        if (!accountNickname.isDisplayed()) {
            addAccountButton.click();
            accountNickname.waitUntil(Duration.ofSeconds(10)).displayed();
        }
        accountNickname.enterText(bankAccount.getNickname());
        accountType.enterText(bankAccount.getAccountType());
        bankName.enterText(bankAccount.getBankName());
        routingNumber.enterText(bankAccount.getRoutingNumber());
        accountNumber.enterText(bankAccount.getAccountNumber());
        saveAccountBtn.click();
        warningPopUpMessageFirstLine.waitUntil(Duration.ofSeconds(10)).displayed();
        return this;
    }

    private void checkCheckbox(CheckBox checkbox, GenericComponent elementWithState) {
        if (!Boolean.parseBoolean(elementWithState.getAttribute("value"))) {
            checkbox.check();
        }
    }

    public DUO_CompanyBankAccount_Page editAccount(CompanyBankAccount bankAccount) {
        GenericComponent editBankAccount = new GenericComponent(driver, ElementInfo.createElementInfo("Edit Bank Account button", By.xpath(String.format("//h4[.='%s']/..//button[contains(.,'Edit')]", bankAccount.getNickname()))));
        editBankAccount.click();
        return this;
    }

    public void verifyBankAccount(CompanyBankAccount bankAccount, String expectedStatus) {
        GenericComponent bankAccountUse = new GenericComponent(driver, ElementInfo.createElementInfo("Bank Account to use label", By.xpath(String.format("//h4[.='%s']/..//strong[contains(.,'Account Use')]/..", bankAccount.getNickname()))));
        GenericComponent bankAccountStatus = new GenericComponent(driver, ElementInfo.createElementInfo("Bank Account status label", By.xpath(String.format("//h4[.='%s']/..//strong[contains(.,'Status')]/..", bankAccount.getNickname()))));
        GenericComponent bankAccountNumber = new GenericComponent(driver, ElementInfo.createElementInfo("Bank Account number label", By.xpath(String.format("//h4[.='%s']/..//p[contains(.,'**********')]", bankAccount.getNickname()))));
        if(warningPopUpCloseBtn.isDisplayed()){
            warningPopUpCloseBtn.click();
        }
        for (String accountUse : bankAccount.getAccountUses()) {
            bankAccountUse.verify().textContains(accountUse);
        }
        bankAccountStatus.verify().textEquals(String.format("Status: %s", expectedStatus));
        bankAccountNumber.verify().textEquals(String.format("**********%s", bankAccount.getAccountNumber().substring(bankAccount.getAccountNumber().length() - 4)));
    }

    public void verifyAllEmptyFieldsErrorsPresence() {
        accountTypeEmptyStateError.verify().textEquals("Account Type is required.");
        bankNameEmptyStateError.verify().textEquals("Please provide a bankName.");
        accountNumberEmptyStateError.verify().textEquals("Please provide an account number.");
        accountUsesEmptyStateError.verify().textEquals("Please choose what will this account be used for.");
        authorizationHoldEmptyStateError.verify().textEquals("Authorization Hold permission must be checked");
    }

    public void verifyInterstitialWarningPop() {
        warningPopUpLabel.verify().displayed();
        warningPopUpLabel.verify().textEquals("Verification");
        warningPopUpMessageFirstLine.verify().displayed();
        warningPopUpMessageFirstLine.verify().textEquals("Thank you for providing bank account information. ");
        warningPopUpMessageSecondLine.verify().textEquals("To verify your account, we will send 2 microdeposits within 2-3 business days.");
        warningPopUpMessageThirdLine.verify().textEquals("Once you see the deposits in your account, log back in and follow instructions to enter the amounts to complete verification.");
        warningPopUpXSign.verify().displayed();
        warningPopUpCloseBtn.verify().displayed();
        warningPopUpCloseBtn.verify().textEquals("Close");
    }

    public void verifyHandlesInvalidDataCorrectly(){
        routingNumber.enterText("testing").verify().textEquals("");
        routingNumber.enterText("%$#!@").verify().textEquals("");
        accountNumber.enterText("%$#!@");
        saveAccountBtn.click();
        accountNumberErrorMessage.verify().textEquals("Please enter a valid account number");
        accountNumber.deleteAllText();
    }

    @Override
    public void waitForPageToLoad() {
        nextStepBtn.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(5000);

    }

    public DUO_CompanyBankAccount_Page(WebDriver driver) {
        super(driver);
    }
}
