package payroll.pages.DeluxeUnifiedOnboarding.pageComponents;

import org.openqa.selenium.WebDriver;
import utils2.page_components.*;
import utils2.page_components.element_utils.ElementUtils;

public class ReactCheckbox extends Component {

    @ComponentFindBy(friendlyName = "Hidden Input Element", xpath="{0}//input[@type='checkbox' or @type='radio']|{0}/preceding-sibling::input[@type='checkbox' or @type='radio']")
    private CheckBox elementToCheck;

    public ReactCheckbox(WebDriver driver, ElementInfo elementInfo){
        super(driver, elementInfo);
        ComponentFactory.initElements(_driver, this, new String[] {elementInfo.getElementXpath()});
    }

    public void click() {
        new ElementUtils(_elementInfo.getFriendlyName(), findElement()).click();
    }

    public void check() {
        if(!isChecked()) {
            click();
        }
    }

    public void uncheck() {
        if(isChecked()) {
            click();
        }
    }

    public void toggle(Boolean turnOn) {
        if(turnOn == null) {
            return;
        }

        if (turnOn) {
            check();
        } else {
            uncheck();
        }
    }

    public Boolean isChecked() {
        return elementToCheck.isChecked();
    }

    public CheckboxValidations verify() {
        return elementToCheck.verify();
    }

}
