package payroll.pages.DeluxeUnifiedOnboarding.pageComponents;

import common.ThreadUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

import java.time.Duration;

public class DecisionsDropdown extends GenericComponent {

    @ComponentFindBy(xpath = "{0}/following-sibling::span[contains(@class,'arrow-down')]")
    private GenericComponent dropdownArrow;

    private GenericComponent dropdownOption(String text) {
        String xpath = "//div[contains(@class,'dp-popup-layer ui-front dp-popup-layer--default dp-popup-layer__combobox')]//div[contains(@class,'dp-combo')][./*[text()='" + text + "']]";
        return new GenericComponent(_driver, ElementInfo.createElementInfo("Dropdown option " + text, By.xpath(xpath)));
    }

    public void selectValue(String text) {
        dropdownArrow.click();
        dropdownOption(text).waitUntil(Duration.ofSeconds(5)).displayed();
        ThreadUtils.sleep(200);
        dropdownOption(text).click_JS();
        ThreadUtils.sleep(200);
    }

    public DecisionsDropdown(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
        ComponentFactory.initElements(_driver, this, new String[]{elementInfo.getElementXpath()});
    }
}
