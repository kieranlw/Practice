package payroll.pages.DeluxeUnifiedOnboarding.pageComponents;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.classObjects.DigitalOnboarding.CompanyAddresses;
import payroll.page_components.TextBox_Payroll;
import utils2.page_components.*;

import java.time.Duration;

public class AddressFields extends GenericComponent {

    @ComponentFindBy(xpath = "{0}//input[@name='addressLine1']")
    private TextBox_Payroll addressLine1Textbox;

    @ComponentFindBy(xpath = "{0}//input[@name='addressLine2']")
    private TextBox_Payroll addressLine2Textbox;

    @ComponentFindBy(xpath = "{0}//input[@name='city']")
    private TextBox_Payroll cityTextbox;

    @ComponentFindBy(xpath = "{0}//select[@name='state']")
    private DropDown stateDropdown;

    @ComponentFindBy(xpath = "{0}//input[@name='zip']")
    private TextBox_Payroll zipTextbox;

    @ComponentFindBy(xpath = "{0}//input[@name='phone']")
    private TextBox_Payroll phoneTextbox;

    @ComponentFindBy(xpath = "{0}//button[contains(text(),'Save Address')]")
    public Button saveAddressButton;

    @ComponentFindBy(xpath = "{0}//button[contains(text(),'Edit Address')]")
    private GenericComponent editAddressButton;

    @ComponentFindBy(xpath = "{0}//button[contains(text(),'Add Address')]")
    private GenericComponent addAddressButton;

    public void editAddress(CompanyAddresses address){
        editAddressButton.click();
        addressLine1Textbox.waitUntil(Duration.ofSeconds(5)).displayed();
        ThreadUtils.sleep(200);
        fillInAddress(address);
    }

    public void addAddress(CompanyAddresses address){
        addAddressButton.click();
        addressLine1Textbox.waitUntil(Duration.ofSeconds(5)).displayed();
        ThreadUtils.sleep(200);
        fillInAddress(address);
    }

    public void fillInAddress(CompanyAddresses address) {
        addressLine1Textbox.enterText(address.getAddress1());
        addressLine2Textbox.enterText(address.getAddress2());
        cityTextbox.enterText(address.getCity());
        stateDropdown.selectValue(address.getStateProvince());
        zipTextbox.enterText(address.getZipPostalCode());
        phoneTextbox.enterText(address.getPhoneNumber());

    }

    public void verifyCompanyAddressFields(CompanyAddresses address) {
        addressLine1Textbox.verify()
                .displayed()
                .textEquals(address.getAddress1());

        addressLine2Textbox.verify()
                .displayed()
                .textEquals(address.getAddress2());

        cityTextbox.verify()
                .displayed()
                .textEquals(address.getCity());

        stateDropdown.verify()
                .displayed()
                .itemSelected(address.getStateProvince());

        zipTextbox.verify()
                .displayed()
                .textEquals(address.getZipPostalCode());

        phoneTextbox.verify()
                .displayed()
                .textEquals(address.getPhoneNumber());
    }
    public AddressFields(WebDriver driver, ElementInfo elementInfo) {
        super(driver, elementInfo);
        ComponentFactory.initElements(_driver, this, new String[]{elementInfo.getElementXpath()});
    }
}
