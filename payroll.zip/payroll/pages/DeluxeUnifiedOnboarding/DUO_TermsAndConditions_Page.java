package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.pages.workflow.BasePage;

import utils2.page_components.*;

import java.time.Duration;

public class DUO_TermsAndConditions_Page extends BasePage {

    @ComponentFindBy(xpath = "//h1[contains(text(), 'Deluxe Payroll Services Agreement')]")
    public Label termsAndConditionsHeader;

    @Override
    public void waitForPageToLoad() throws Exception {

        termsAndConditionsHeader.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_TermsAndConditions_Page(WebDriver driver) {
        super(driver);
    }
}
