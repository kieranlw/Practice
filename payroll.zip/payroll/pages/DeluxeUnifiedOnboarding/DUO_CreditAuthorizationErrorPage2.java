package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_CreditAuthorizationErrorPage2 extends DUO_BasePage {

    @ComponentFindBy(xpath = "//h5[contains(text(),'Sorry we are unable to proceed. Please check your email for additional information.')]")
    public GenericComponent errorPage2Text;

    @ComponentFindBy(xpath = "//button[contains(text(), 'Try Again')]/preceding-sibling::p")
    public Label tryAgainMessage;

    @ComponentFindBy(xpath = "//button[contains(text(), 'Try Again')]")
    public NavigateTo<DUO_CreditAuthorizationForm_Page> tryAgainButton;

    public DUO_CreditAuthorizationErrorPage2 verifyErrorPageTextIsDisplayed() {
        errorPage2Text.verify().displayed().textEquals("Sorry we are unable to proceed. Please check your email for additional information. " +
                "If you do not see the email in your inbox, please check your junk mail folder.");
        return this;
    }

    public DUO_CreditAuthorizationErrorPage2(WebDriver driver) {
        super(driver);
    }

    @Override
    public void waitForPageToLoad() throws Exception {
        errorPage2Text.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }
}
