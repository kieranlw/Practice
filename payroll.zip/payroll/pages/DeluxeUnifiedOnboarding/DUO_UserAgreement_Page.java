package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.classObjects.DigitalOnboarding.UserAgreement;
import payroll.pages.DeluxeUnifiedOnboarding.pageComponents.ReactCheckbox;
import utils2.DriverUtils;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_UserAgreement_Page extends DUO_BasePage {

//    @ComponentFindBy(id = "form-checkbox-agreedToAuthorizedSignature")
    @ComponentFindBy(xpath = "//div[@id='form-checkbox-agreedToAuthorizedSignature']/div/label")
    public ReactCheckbox authorizedSignatureCheckBox;

    @ComponentFindBy(xpath = "//div[@id='form-checkbox-agreedToTermsAndConditions']/div/label")
    public ReactCheckbox termsAndConditionsCheckBox;

    @ComponentFindBy(xpath = "//a[@class='d-block mt-2'][text()='Terms & Conditions']")
    public NavigateTo<DUO_TermsAndConditions_Page> termsAndConditionsLink;

    @ComponentFindBy(xpath = "//div[@class='form-check']/following-sibling::div[@class='mt-2 d-block text-muted'][text()='Please select check box for Authorized Signature']")
    public GenericComponent authorizedSignatureErrorMsg;

    @ComponentFindBy(xpath = "//div[@class='form-check']/following-sibling::div[@class='mt-2 d-block text-muted'][text()='Please select check box for Terms & Conditions']")
    public GenericComponent termsAndConditionsErrorMsg;

    @ComponentFindBy(xpath ="//button[@class='close']")

    private GenericComponent headerErrorMsg;

    @ComponentFindBy(xpath = "//span[text()=' Next Step ']")
    public NavigateTo<DUO_Success_Page> nextStepBtn;

    public DUO_UserAgreement_Page fillFields(UserAgreement userAgreement) {
        authorizedSignatureCheckBox.toggle(userAgreement.getAuthorizedSignature());
        termsAndConditionsCheckBox.toggle(userAgreement.getTermsAndConditions());
        return this;
    }

    public void verifyErrorMsg(String errorMsg) {
        authorizedSignatureErrorMsg.verify()
                .displayed()
                .textEquals(errorMsg);

        termsAndConditionsErrorMsg.verify()
                .displayed()
                .textEquals(errorMsg);
    }

    public void verifyFields(UserAgreement userAgreement) {
        authorizedSignatureCheckBox.verify()
                .checked();

        termsAndConditionsCheckBox.verify()
                .checked();
    }

    public DUO_UserAgreement_Page clickNextCausesErrors() {
        nextStepBtn.click();
        ThreadUtils.sleep(1000);
        new DriverUtils(driver).waitForReadyStateComplete(Duration.ofSeconds(5));

        if(headerErrorMsg.exists())
            headerErrorMsg.click();
            ThreadUtils.sleep(1500);
        new DriverUtils(driver).waitForReadyStateComplete(Duration.ofSeconds(5));
        return this;
    }

    @Override
    public void waitForPageToLoad() {
        authorizedSignatureCheckBox.waitUntil(Duration.ofSeconds(5)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_UserAgreement_Page(WebDriver driver) {
        super(driver);
    }
}
