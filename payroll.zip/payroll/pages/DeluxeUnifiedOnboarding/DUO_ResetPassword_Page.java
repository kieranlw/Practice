package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.classObjects.DigitalOnboarding.ResetPassword;
import payroll.page_components.TextBox_Payroll;
import utils2.DriverUtils;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_ResetPassword_Page extends DUO_BasePage {

    @ComponentFindBy(id = "password")
    private TextBox_Payroll newPasswordField;

    @ComponentFindBy(id = "confirmPassword")
    private TextBox_Payroll confirmPasswordField;

    @ComponentFindBy(xpath = "//BUTTON[text()='Reset Password']")
    @AfterClick_Wait(waitMethodName = "waitForSuccessMessage")
    @AfterClick_HardCodedSleep(milliseconds = 500, why = "legacy code, reason unknown")
    public GenericComponent resetPassword_ResetPasswordButton;

    @ComponentFindBy(xpath = "//input[@id='password']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent newPasswordField_Error;

    @ComponentFindBy(xpath = "//input[@id='confirmPassword']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent confirmPasswordField_Error;

    @ComponentFindBy(xpath = "//div[@class='mb-3 alert alert-error alert-dismissible fade show']")
    @AfterClick_HardCodedSleep(milliseconds = 15000,why="Legacy code, reason unknown")
    public GenericComponent resetPasswordToken_Error;

    @ComponentFindBy(xpath = "//*[text()='Success!']/following-sibling::p[1]")
    @AfterClick_HardCodedSleep(milliseconds = 2000,why="Legacy code, reason unknown")
    public GenericComponent resetPassword_SuccessMessage;

    @ComponentFindBy (xpath = "//*[text()='Success!']/following-sibling::p[1] | " +
                            "//input[@id='password']/following-sibling::div[@class='mt-2 d-block text-muted'] | " +
                            "//input[@id='confirmPassword']/following-sibling::div[@class='mt-2 d-block text-muted'] | " +
                            "//div[@class='mb-3 alert alert-error alert-dismissible fade show']")
    public GenericComponent waitElement;

    @WaitMethod
    public boolean waitForSuccessMessage() {
        waitElement.waitUntil(Duration.ofSeconds(50)).displayed();
        return waitElement.isDisplayed();
    }


    public DUO_ResetPassword_Page fillFields(ResetPassword resetPassword){
        newPasswordField.enterText(resetPassword.getNewPassword());
        confirmPasswordField.enterText(resetPassword.getConfirmPassword());
        return this;
    }

    public DUO_ResetPassword_Page clickNextCausesErrors() {
        resetPassword_ResetPasswordButton.click();
        ThreadUtils.sleep(500);
        new DriverUtils(driver).waitForReadyStateComplete(Duration.ofSeconds(5));
        return this;
    }

    @Override
    public void waitForPageToLoad() {
        newPasswordField.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_ResetPassword_Page(WebDriver driver) {
        super(driver);
    }


}
