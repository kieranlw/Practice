package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.pages.workflow.BasePage;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_CaliforniaSpecificAddendum_Page extends BasePage {

    @ComponentFindBy(xpath = "//h1[contains(text(), 'California Specific Addendum')]")
    public Label californiaSpecificAddendumHeader;


    @Override
    public void waitForPageToLoad() throws Exception {

        californiaSpecificAddendumHeader.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_CaliforniaSpecificAddendum_Page(WebDriver driver) {
        super(driver);
    }
}
