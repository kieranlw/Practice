package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.page_components.TextBox_Payroll;
import utils2.pageControls.annotations.ControlFindBy;
import utils2.page_components.*;

import java.time.Duration;
import java.util.List;

public class DUO_AccountPreferences_Page extends DUO_BasePage {

    @ComponentFindBy(id = "accountPreferencesLabel")
    public Label accountPreferencesLabel;

    @ComponentFindBy(xpath = "//div[@id='email']/div")
    public GenericComponent emailAddress;

    @ComponentFindBy(xpath = "//div[@id='email']/div")
    public GenericComponent password;

    @ComponentFindBy(id = "changepassword")
    public NavigateTo<DUO_ChangePassword_Page> changePasswordLink;

    @ComponentFindBy(id = "addAuthorizedUserInvitation")
    public NavigateTo<DUO_InviteAuthorizedUser_Page> addNewContact;

    @ComponentFindBy(id = "ddlRole")
    public DropDown roleDropdown;

    @ComponentFindBy(id = "txtOtherRole")
    public TextBox otherRole;

    @ComponentFindBy(id = "ddlPreferredContactMethod")
    public DropDown preferredContactDropdown;

    @ComponentFindBy(id = "addCompanyIcon")
    public TextBox_Payroll accountActivityLastLoginInfo;

    @ComponentFindBy(id = "viewactivityhistory")
    public NavigateTo<DUO_AccountPreferences_Page> accountActivityHistoryLink;

    @ComponentFindBy(id = "btnSaveRole")
    @AfterClick_HardCodedSleep(milliseconds = 3000, why = "legacy code, reason unknown")
    public NavigateTo<DUO_AccountPreferences_Page> saveChanges;

    @AfterClick_HardCodedSleep(milliseconds = 2000, why = "legacy code, reason unknown")//this is needed
    @ComponentFindBy(id = "btnReSendEmail0")
    public NavigateTo<DUO_AccountPreferences_Page> resendInvitationButton;

    @ComponentFindBy(xpath = "//div[@id='contact']//button[@id='btnReSendEmail1']")
    public NavigateTo<DUO_AccountPreferences_Page> resendInvitationButton1;

    @ComponentFindBy(xpath = "//input[@id='txtOtherRole']/following-sibling::div")
    public Label otherTextFieldErrorMessage;

    @ComponentFindBy(xpath = "//*[text()='Role is required']")
    public Label dropDownErrorMessage;

    @ControlFindBy(xpath = "//strong[text()='Success,']")
    public Label successBannerAlertTitle;

    @ControlFindBy(xpath = "//div[text()='Account Preferences Saved!']")
    public Label successBannerAlertMessage;

    @ControlFindBy(xpath = "//div[text()='Account Preferences Saved!']/button")
    public Label successBannerClosebutton;

    @ComponentFindBy(xpath = "//div[@role='alert']")
    public Label successMessage;

    @AfterClick_HardCodedSleep(milliseconds = 1000, why = "legacy code, reason unknown")
    @ComponentFindBy(xpath = "//button[contains(@id, 'btnDeactivateInvitation')]")
    public NavigateTo<DUO_AccountPreferences_Page> deactivateInvitationButton;

    @ComponentFindBy(xpath = "//h5[@id='deleteUserModalLabel']")
    public Label deleteModalWindow;

    @ComponentFindBy(xpath = "//button[@id='DoNotDeleteUserButton']")
    public NavigateTo<DUO_AccountPreferences_Page> cancelButton;

    @AfterClick_HardCodedSleep(milliseconds = 1000, why = "legacy code, reason unknown")
    @ComponentFindBy(xpath = "//button[@id='DeleteUserButton']")
    public NavigateTo<DUO_AccountPreferences_Page> deleteUserButton;

    @ComponentFindBy(xpath = "//span[@id='email1']")
    public Label invitedEmailAddress;

    public DUO_AccountPreferences_Page(WebDriver driver) {
        super(driver);
    }

    public List<String> getAllDropdownItems() {
        return roleDropdown.getAllOptions();
    }

    public DUO_AccountPreferences_Page verifyEmptyOtherFieldErrorMessage() {
        otherTextFieldErrorMessage.verify().textEquals("Please enter other role");
        return this;
    }

    public DUO_AccountPreferences_Page verifyThatNoRoleIsSelected() {
        roleDropdown.verify().itemSelected("Please Select...");
        return this;
    }

    public DUO_AccountPreferences_Page verifyThatEachRoleCanBeSelected() {
        List<String> roles = roleDropdown.getAllOptions();
        String[] str = {
                "Please Select...",
                "Owner",
                "Chief Executive Officer (CEO)",
                "President",
                "Vice President",
                "Treasurer",
                "Chief Accounting Officer",
                "Secretary",
                "Partner",
                "Payroll Admin",
                "Bookkeeper",
                "CPA/Accountant",
                "Other"};
        for (int i = 0; i < roles.size(); i++) {
            roleDropdown.selectValue(roles.get(i));
            roleDropdown.verify().itemSelected(str[i]);
        }
        return this;
    }

    public DUO_AccountPreferences_Page verifyDefaultValue() {
        roleDropdown.verify().itemSelected("Owner");
        return this;
    }

    public DUO_AccountPreferences_Page verifyValueNotOverridden(String text) {
        roleDropdown.verify().itemSelected(text);
        return this;
    }

    public DUO_AccountPreferences_Page verifyOtherRoleIsSaved(String text) {
        otherRole.verify().textEquals(text);
        return this;
    }

    public DUO_AccountPreferences_Page verifyOtherTextFiledEnterNumber() {
        otherTextFieldErrorMessage.verify().textEquals("Alphabets and digits, but not digits only.");
        return this;
    }

    public DUO_AccountPreferences_Page verifyOtherTextFiledEnterSpecialCharacter() {
        otherTextFieldErrorMessage.verify().textEquals("Only alphabets and digits are allowed for other role field.");
        return this;
    }

    public DUO_AccountPreferences_Page verifyNoValueSelected() {
        dropDownErrorMessage.verify().textEquals("Role is required");
        return this;
    }

    public DUO_AccountPreferences_Page verifySaveChangesButtonDisabled() {
        saveChanges.verify().disabled();
        return this;
    }

    public DUO_AccountPreferences_Page verifyOtherTextFieldDoNotAcceptMoreThanFortyCharacters() {
        otherRole.verify().textLengthEquals(40);
        return this;
    }

    public DUO_AccountPreferences_Page verifyAddNewContactDisabled() {
        addNewContact.verify().disabled();
        return this;
    }

    public DUO_AccountPreferences_Page verifyAddNewContactEnabled() {
        addNewContact.verify().enabled();
        return this;
    }

    public DUO_AccountPreferences_Page verifyResendSuccessMessage() {
        resendInvitationButton.click();
        resendInvitationButton.verify().disabled();
        successMessage.verify().textContains("Authorized user invitation email re-sent successfully.");
        return this;
    }

    public DUO_AccountPreferences_Page verifyResendButtonNotDisplayForActiveAndExpiredInvitation() {
        resendInvitationButton.verify().notDisplayed();
        resendInvitationButton1.verify().notDisplayed();
        return this;
    }

    public DUO_AccountPreferences_Page verifyDeleteButtonDisplay() {
        deactivateInvitationButton.verify().displayed();
        return this;
    }

    public DUO_AccountPreferences_Page verifyModalWindow() {
        deactivateInvitationButton.click();
        deleteModalWindow.verify().displayed();
        cancelButton.click();
        return this;
    }

    public DUO_AccountPreferences_Page verifyUserDeleteSuccessfully() {
        deactivateInvitationButton.click();
        deleteUserButton.click();
        successMessage.verify().textContains("Authorized user was deleted.");
        return this;
    }

    public DUO_AccountPreferences_Page verifyDeleteButtonDoesNotDisplayForExpiredInvitation() {
        deactivateInvitationButton.verify().notDisplayed();
        return this;
    }

    public DUO_AccountPreferences_Page verifyDeleteButtonDoesNotDisplayForPendingInvitation() {
        deactivateInvitationButton.verify().notDisplayed();
        return this;
    }

    public DUO_AccountPreferences_Page verifyDeleteButtonDoesNotDisplayForNonOriginalEmployee() {
        deactivateInvitationButton.verify().notDisplayed();
        return this;
    }

    public DUO_AccountPreferences_Page verifyOriginalEmployeeCanAddNewUserOncePreviousWasDeleted() {
        invitedEmailAddress.verify().textEquals("test12@test.io");
        return this;
    }

    @Override
    public void waitForPageToLoad() throws Exception {
        accountPreferencesLabel.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(2000);
    }
}
