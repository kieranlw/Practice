package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;
import java.time.Duration;

public class DUO_AccountHome_Page extends DUO_BasePage {

    @ComponentFindBy(id = "accountHomeLabel")
    public Label accountHomeLabel;

    @ComponentFindBy(id = "userNameLabelFullView")
    public GenericComponent accountEmailAddress;

    @ComponentFindBy(id = "signOutMenuItem")
    public NavigateTo<DUO_Login_Page> signOut;

    @ComponentFindBy(id = "userWelcomeLabel")
    public Label userEmailAddress;

    @ComponentFindBy(xpath = "//h6[contains(@id,'companyStatus')]/following-sibling::p/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> continueSetUpButton;

    @ComponentFindBy(xpath = "//h6[@id='companyStatus_New_0']/following-sibling::p/following-sibling::button")
    public NavigateTo<DUO_CompanyAddresses_Page> continueSetUpButtonAddressPage;

    @ComponentFindBy(xpath = "//h6[@id='companyStatus_New_0']/following-sibling::p/following-sibling::button")
    public NavigateTo<DUO_CreditAuthorizationForm_Page> continueSetUpButtonForCreditAuthorizationPage;

    @ComponentFindBy(id = "addCompanyIcon")
    public NavigateTo<DUO_PackageSelection_Page> addCompanyIcon;


    @ComponentFindBy(id = "companyName_Submitted_0")
    public Label submittedCompanyNameOne;

    @ComponentFindBy(id = "companyName_Submitted_1")
    public Label submittedCompanyNameTwo;

    @ComponentFindBy(id = "companyName_Submitted_2")
    public Label submittedCompanyNameThree;

    @ComponentFindBy(id = "companyStatus_Submitted_0")
    public Label submittedCompanyStatusOne;

    @ComponentFindBy(id = "companyStatus_Submitted_2")
    public Label submittedCompanyStatusTwo;

    @ComponentFindBy(id = "companyStatus_Submitted_2")
    public Label submittedCompanyStatusThree;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_Submitted_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_Success_Page> submittedContinueSetupButtonOne;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_Submitted_1')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_Success_Page> submittedContinueSetupButtonTwo;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_Submitted_2')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_Success_Page> submittedContinueSetupButtonThree;


    @ComponentFindBy(id = "companyName_NotSubmitted_0")
    public Label notSubmittedCompanyNameOne;

    @ComponentFindBy(id = "companyName_NotSubmitted_1")
    public Label notSubmittedCompanyNameTwo;

    @ComponentFindBy(id = "companyName_NotSubmitted_2")
    public Label notSubmittedCompanyNameThree;

    @ComponentFindBy(id = "companyName_NotSubmitted_3")
    public Label notSubmittedCompanyNameFour;

    @ComponentFindBy(id = "companyName_NotSubmitted_4")
    public Label notSubmittedCompanyNameFive;

    @ComponentFindBy(id = "companyName_NotSubmitted_5")
    public Label notSubmittedCompanyNameSix;

    @ComponentFindBy(id = "companyName_NotSubmitted_6")
    public Label notSubmittedCompanyNameSeven;

    @ComponentFindBy(id = "companyName_NotSubmitted_7")
    public Label notSubmittedCompanyNameEight;

    @ComponentFindBy(id = "companyStatus_NotSubmitted_0")
    public Label notSubmittedCompanyStatusOne;

    @ComponentFindBy(id = "companyStatus_NotSubmitted_1")
    public Label notSubmittedCompanyStatusTwo;

    @ComponentFindBy(id = "companyStatus_NotSubmitted_2")
    public Label notSubmittedCompanyStatusThree;

    @ComponentFindBy(id = "companyStatus_NotSubmitted_3")
    public Label notSubmittedCompanyStatusFour;

    @ComponentFindBy(id = "companyStatus_NotSubmitted_4")
    public Label notSubmittedCompanyStatusFive;

    @ComponentFindBy(id = "companyStatus_NotSubmitted_5")
    public Label notSubmittedCompanyStatusSix;

    @ComponentFindBy(id = "companyStatus_NotSubmitted_6")
    public Label notSubmittedCompanyStatusSeven;

    @ComponentFindBy(id = "companyStatus_NotSubmitted_7")
    public Label notSubmittedCompanyStatusEight;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_NotSubmitted_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> notSubmittedContinueSetupButtonOne;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_Submitted_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_Success_Page> submittedContinueSetupButtonOneForSuccessPage;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_NotSubmitted_1')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> notSubmittedContinueSetupButtonTwo;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_NotSubmitted_2')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> notSubmittedContinueSetupButtonThree;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_NotSubmitted_3')]/following-sibling::div/h6/following-sibling::button")
    @AfterClick_HardCodedSleep(milliseconds = 2000, why = "legacy code, reason unknown")
    public NavigateTo<DUO_PackageSelection_Page> notSubmittedContinueSetupButtonFour;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_NotSubmitted_4')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> notSubmittedContinueSetupButtonFive;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_NotSubmitted_5')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> notSubmittedContinueSetupButtonSix;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_NotSubmitted_6')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> notSubmittedContinueSetupButtonSeven;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_NotSubmitted_7')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> notSubmittedContinueSetupButtonEight;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_NotSubmitted_8')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> notSubmittedContinueSetupButtonNine;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_NotSubmitted_9')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> notSubmittedContinueSetupButtonTen;

    @ComponentFindBy(id = "companyName_New_0")
    public Label newCompanyNameOne;

    @ComponentFindBy(id = "companyName_New_1")
    public Label newCompanyNameTwo;

    @ComponentFindBy(id = "companyName_New_2")
    public Label newCompanyNameThree;

    @ComponentFindBy(id = "companyName_New_3")
    public Label newCompanyNameFour;

    @ComponentFindBy(id = "companyName_New_4")
    public Label newCompanyNameFive;

    @ComponentFindBy(id = "companyName_New_6")
    public Label newCompanyNameSix;

    @ComponentFindBy(id = "companyName_New_7")
    public Label newCompanyNameSeven;

    @ComponentFindBy(id = "companyName_New_7")
    public Label newCompanyNameEight;

    @ComponentFindBy(id = "companyStatus_New_0")
    public Label newCompanyStatusOne;

    @ComponentFindBy(id = "companyStatus_New_1")
    public Label newCompanyStatusTwo;

    @ComponentFindBy(id = "companyStatus_New_2")
    public Label newCompanyStatusThree;

    @ComponentFindBy(id = "companyStatus_New_3")
    public Label newCompanyStatusFour;

    @ComponentFindBy(id = "companyStatus_New_4")
    public Label newCompanyStatusFive;

    @ComponentFindBy(id = "companyStatus_New_5")
    public Label newCompanyStatusSix;

    @ComponentFindBy(id = "companyStatus_New_6")
    public Label newCompanyStatusSeven;

    @ComponentFindBy(id = "companyStatus_New_7")
    public Label newCompanyStatusEight;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> newContinueSetupButtonOne;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageAddOns_Page> newContinueSetupButtonOneForAddOns;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageAddOns_Page> newContinueSetupButtonOneToPackageAddonPage;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CreditAuthorizationForm_Page> newContinueSetupButtonOneToCreditAuthPage;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CreditAuthorization_SuccessPage> newContinueSetupButtonOneToCreditAuthSuccessPage;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CompanyAddresses_Page> newContinueSetupButtonOneToCompanyAddressPage;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_FederalTaxInfo_Page> newContinueSetupButtonOneToFederalTaxPage;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_AuthorizationForms_Page> newContinueSetupButtonOneToAuthFormPage;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CompanyStateTaxes_Page> newContinueSetupButtonOneToStateTaxPage;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CompanyBankAccount_Page> newContinueSetupButtonOneToBankAcctPage;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CompanySummary_Page> newContinueSetupButtonOneToSummaryPage;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_UserAgreement_Page> newContinueSetupButtonOneToUserAgreementPage;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_Success_Page> newContinueSetupButtonOneToSuccessPage;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_1')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> newContinueSetupButtonTwo;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_2')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> newContinueSetupButtonThree;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_3')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> newContinueSetupButtonFour;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_4')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page>newContinueSetupButtonFive;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_5')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> newContinueSetupButtonSix;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_6')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> newContinueSetupButtonSeven;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_7')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> newContinueSetupButtonEight;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_9')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CreditAuthorizationErrorPage1> newContinueSetupButtonTenForErrorPage1;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_Success_Page> newContinueSetupButtonOneForSuccessPage;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_New_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CreditAuthorizationForm_Page> newContinueSetupButtonOneForCreditAuthorizationPage;


    @ComponentFindBy(id = "companyName_UnderReview_0")
    public Label underReviewCompanyNameOne;

    @ComponentFindBy(id = "companyName_UnderReview_1")
    public Label underReviewCompanyNameTwo;

    @ComponentFindBy(id = "companyName_UnderReview_2")
    public Label underReviewCompanyNameThree;

    @ComponentFindBy(id = "companyStatus_UnderReview_0")
    public Label underReviewCompanyStatusOne;

    @ComponentFindBy(id = "companyStatus_UnderReview_1")
    public Label underReviewCompanyStatusTwo;

    @ComponentFindBy(id = "companyStatus_UnderReview_2")
    public Label underReviewCompanyStatusThree;

    @ComponentFindBy(xpath = "//h6[contains(@id,'companyStatus_UnderReview_0')]/following-sibling::p/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> underReviewContinueSetupButtonOne;

    @ComponentFindBy(xpath = "//h6[contains(@id,'companyStatus_UnderReview_1')]/following-sibling::p/following-sibling::button")
    public NavigateTo<DUO_CreditAuthorizationForm_Page> underReviewContinueSetupButtonTwo;

    @ComponentFindBy(xpath = "//h6[contains(@id,'companyStatus_UnderReview_2')]/following-sibling::p/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> underReviewContinueSetupButtonThree;

    @ComponentFindBy(xpath = "//h6[contains(@id,'companyStatus_UnderReview_0')]/following-sibling::p/following-sibling::button")
    public NavigateTo<DUO_Success_Page> underReviewContinueSetupButtonOneForSuccessPage;


    @ComponentFindBy(id = "companyName_PendingVerification_0")
    public Label pendingVerificationCompanyNameOne;

    @ComponentFindBy(id = "companyName_PendingVerification_1")
    public Label pendingVerificationCompanyNameTwo;

    @ComponentFindBy(id = "companyName_PendingVerification_2")
    public Label pendingVerificationCompanyNameThree;

    @ComponentFindBy(id = "companyStatus_PendingVerification_0")
    public Label pendingVerificationCompanyStatusOne;

    @ComponentFindBy(id = "companyStatus_PendingVerification_1")
    public Label pendingVerificationCompanyStatusTwo;

    @ComponentFindBy(id = "companyStatus_PendingVerification_2")
    public Label pendingVerificationCompanyStatusThree;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_PendingVerification_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> pendingVerificationContinueSetupButtonOne;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_PendingVerification_1')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CreditAuthorizationForm_Page> pendingVerificationContinueSetupButtonTwo;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_PendingVerification_2')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> pendingVerificationContinueSetupButtonThree;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_PendingVerification_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CreditAuthorizationForm_Page> pendingVerificationContinueSetupButtonOneForCreditAuthorizationPage;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_PendingVerification_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CreditAuthorization_SuccessPage> pendingVerificationContinueSetupButtonOneForCreditAuthorizationSuccessPage;


    @ComponentFindBy(id = "companyName_Rejected_0")
    public Label rejectedCompanyNameOne;

    @ComponentFindBy(id = "companyName_Rejected_1")
    public Label rejectedCompanyNameTwo;

    @ComponentFindBy(id = "companyName_Rejected_2")
    public Label rejectedCompanyNameThree;

    @ComponentFindBy(id = "companyStatus_Rejected_0")
    public Label rejectedCompanyStatusOne;

    @ComponentFindBy(id = "companyStatus_Rejected_1")
    public Label rejectedCompanyStatusTwo;

    @ComponentFindBy(id = "companyStatus_Rejected_2")
    public Label rejectedCompanyStatusThree;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_Rejected_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CompanyAddresses_Page> rejectedContinueSetupButtonOne;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_Rejected_1')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CompanyAddresses_Page> rejectedContinueSetupButtonTwo;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_Rejected_2')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CompanyAddresses_Page> rejectedContinueSetupButtonThree;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_Rejected_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CompanyAddresses_Page> rejectedContinueSetupButtonOneForSuccessPage;



    @ComponentFindBy(id = "companyName_Approved_0")
    public Label approvedCompanyNameOne;

    @ComponentFindBy(id = "companyName_Approved_1")
    public Label approvedCompanyNameTwo;

    @ComponentFindBy(id = "companyName_Approved_2")
    public Label approvedCompanyNameThree;

    @ComponentFindBy(id = "companyStatus_Approved_0")
    public Label approvedCompanyStatusOne;

    @ComponentFindBy(id = "companyStatus_Approved_1")
    public Label approvedCompanyStatusTwo;

    @ComponentFindBy(id = "companyStatus_Approved_2")
    public Label approvedCompanyStatusThree;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_Approved_0')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_CompanySummary_Page> approvedContinueSetupButtonOne;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_Approved_1')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> approvedContinueSetupButtonTwo;

    @ComponentFindBy(xpath = "//h5[contains(@id,'companyName_Approved_2')]/following-sibling::div/h6/following-sibling::button")
    public NavigateTo<DUO_PackageSelection_Page> approvedContinueSetupButtonThree;


    @ComponentFindBy(id = "companyName_Pending_0")
    public Label pendingInviteCompanyNameOne;

    @ComponentFindBy(id = "companyStatus_Pending_0")
    public Label pendingInviteCompanyStatusOne;

    @ComponentFindBy(xpath = "//h6[@id='companyStatus_Pending_0']/following-sibling::p/following-sibling::button")
    @AfterClick_Wait(waitMethodName = "waitForHeadsUpModal")
    public NavigateTo<DUO_AccountHome_Page> pendingInviteAcceptInviteButtonOne;

    @ComponentFindBy(id = "companyName_Pending_1")
    public Label pendingInviteCompanyNameTwo;

    @ComponentFindBy(id = "companyStatus_Pending_1")
    public Label pendingInviteCompanyStatusTwo;

    @ComponentFindBy(xpath = "//h6[@id='companyStatus_Pending_1']/following-sibling::p/following-sibling::button")
    @AfterClick_Wait(waitMethodName = "waitForHeadsUpModal")
    public NavigateTo<DUO_AccountHome_Page> pendingInviteAcceptInviteButtonTwo;

    @ComponentFindBy(id = "companyName_Pending_2")
    public Label pendingInviteCompanyNameThree;

    @ComponentFindBy(id = "companyStatus_Pending_1")
    public Label pendingInviteCompanyStatusThree;

    @ComponentFindBy(xpath = "//h6[@id='companyStatus_Pending_2']/following-sibling::p/following-sibling::button")
    public NavigateTo<DUO_AccountHome_Page> pendingInviteAcceptInviteButtonThree;


    @ComponentFindBy(xpath = "//h5[@id='exampleModalLabel']/strong")
    public Label headsUpModalLabel;

    @ComponentFindBy(xpath = "//div[@class='modal-body']/p")
    public Label headsUpModalText;

    @ComponentFindBy(xpath = "//button[text()='Back']")
    public Button headsUpModalBackButton;

    @AfterClick_HardCodedSleep(milliseconds = 2500, why = "page takes a long time to load")
    @ComponentFindBy(xpath = "//button[text()='Continue']")
    public Button headsUpModalContinueButton;

    @ComponentFindBy(xpath = "//button[@class='close']")
    public Button headsUpModalCloseButton;


    @ComponentFindBy(xpath = "//span[normalize-space()='No thanks']")
    public GenericComponent noThanksLinkInFeedbackPopup;


    @WaitMethod
    public boolean waitForHeadsUpModal() {
        return headsUpModalLabel.isDisplayed();
    }

    @WaitMethod
    public boolean waitForContinueSetupButton() {
        return notSubmittedCompanyNameOne.isDisplayed();
    }


    public DUO_AccountHome_Page verifyTheUserSignedIn() {
        accountHomeLabel.verify().displayed().textEquals("Account Home");
        return this;
    }

    public DUO_AccountHome_Page verifyRemovalOfPreferences() {
        menu_arrow.hover();
        menu_preferences.verify().notDisplayed();
        return this;
    }

    public DUO_AccountHome_Page verifyHeadsUpModalInformation() {
        headsUpModalLabel.verify().textEquals("Heads up!");
        headsUpModalText.verify().textEquals("By clicking \"Start onboarding\" you are accepting an invitation as an authorized user for this company");
        return this;
    }


    @Override
    public void waitForPageToLoad() {
        accountHomeLabel.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(1000);
        if (noThanksLinkInFeedbackPopup.exists())
            noThanksLinkInFeedbackPopup.click_JS();
    }

    public DUO_AccountHome_Page(WebDriver driver) {
        super(driver);
    }
}