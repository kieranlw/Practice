package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.classObjects.DigitalOnboarding.FederalTaxInfo;
import utils2.DriverUtils;
import utils2.page_components.*;

import java.io.File;
import java.time.Duration;

public class DUO_FederalTaxInfo_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//h2[contains(text(), 'Federal Tax Info')]")
    public Label federalTaxInfoPageHeader;

    @ComponentFindBy(xpath = "//h2[contains(text(), 'Enter the Federal Tax information necessary to accurately calculate, deposit, and file your business' federal taxes')]")
    public Label federalTaxInfoPageSubHeader;

    @ComponentFindBy(id = "federalFilingForm")
    public DropDown federalFilingFormDropdown;

    @ComponentFindBy(xpath = "//span[contains(text(),'Yes')]")
    public CheckBox seasonalEmployerCheckBox;

    @ComponentFindBy(id = "federalDepositFrequency")
    public DropDown federalDepositFrequencyDropdown;

    @ComponentFindBy(id = "naicsCode")
    private TextBox naicsCodeTextbox;

    @ComponentFindBy(id = "is1099Contractors")
    public DropDown contractors1099Dropdown;

    @ComponentFindBy(id = "charity501C3")
    public DropDown workerTypesPayingDropdown;

    @ComponentFindBy(id = "irsFederalProof")
    public TextBox uploadElement;

    @ComponentFindBy(xpath = "//button[contains(.,'Upload File')]")
    public TextBox uploadButtonElement;

    @ComponentFindBy(xpath = "//button[contains(text(),'Remove')]")
    public Button removeButton;

    @ComponentFindBy(xpath = "//BUTTON[text()='Next Step']")
    public NavigateTo<DUO_AuthorizationForms_Page> nextStepBtn;

    @ComponentFindBy(xpath = "//button[text()='Back']")
    public NavigateTo<DUO_PackageAddOns_Page> backBtn;

    @ComponentFindBy(xpath = "//select[@name='companyType']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label companyTypeErrorMsg;

    @ComponentFindBy(xpath = "//input[@id='dbaOrTradeName']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label dbaTradeNameErrorMsg;

    @ComponentFindBy(xpath = "//select[@name='federalFilingForm']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label federalFilingFormErrorMsg;

    @ComponentFindBy(xpath = "//select[@name='federalDepositFrequency']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label federalDepositFrequencyErrorMsg;

    @ComponentFindBy(xpath = "//input[@id='naicsCode']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label naicsCodeErrorMsg;

    @ComponentFindBy(xpath = "//select[@name='is1099Contractors']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label contractors1099ErrorMsg;

    @ComponentFindBy(xpath = "//select[@name='futaExempt']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label futaExemptErrorMsg;

    @ComponentFindBy(xpath = "//input[@name='irsFederalProof']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label irsFederalProofErrorMsg;

    @ComponentFindBy(id = "dbaOrTradeName")
    public Label dbaTradeNameVerification;

    @ComponentFindBy(id = "naicsCode")
    public Label naicsCodeWith10NumbersVerification;

    @ComponentFindBy(xpath = "//a[contains(text(),'Search for NAICS Code')]")
    public Label naicsCodeWebLinkVerification;

    @ComponentFindBy(xpath = "//input[@id='irsFederalProof']/following-sibling::div//span[not(@class='input-group-text')]")
    public Label uploadFileText;

    public DUO_FederalTaxInfo_Page fillInFields(FederalTaxInfo federalTaxInfo) {
        federalFilingFormDropdown.selectValue(federalTaxInfo.getFederalFilingForm());
        seasonalEmployerCheckBox.toggle(federalTaxInfo.getSeasonalEmployerCheckBox());
        federalDepositFrequencyDropdown.selectValue(federalTaxInfo.getFederalDepositFrequency());
        naicsCodeTextbox.enterText(federalTaxInfo.getNaicsCode());
        contractors1099Dropdown.selectValue(federalTaxInfo.getWorkerTypesPaying());
        workerTypesPayingDropdown.selectValue(federalTaxInfo.getCharity501C3());

        return this;
    }

    public DUO_FederalTaxInfo_Page uploadFile(File file) {

        uploadElement.removeAttribute("style");
        uploadElement.enterText(file.getAbsolutePath());

        ThreadUtils.sleep(500);
        return this;
    }

    public DUO_FederalTaxInfo_Page clickNextCausesErrors() {
        nextStepBtn.click();
        ThreadUtils.sleep(500);
        new DriverUtils(driver).waitForReadyStateComplete(Duration.ofSeconds(5));
        return this;
    }

    public DUO_FederalTaxInfo_Page removeFileClickNext() {

        if (removeButton.isDisplayed()) {
            removeButton.click();
            ThreadUtils.sleep(500);
        }

        nextStepBtn.click();
        ThreadUtils.sleep(500);
        new DriverUtils(driver).waitForReadyStateComplete(Duration.ofSeconds(5));
        return this;
    }

    public DUO_FederalTaxInfo_Page removeUploadFile() {

        if (removeButton.isDisplayed()) {
            removeButton.click();
            ThreadUtils.sleep(500);
        }

        return this;
    }

    @Override
    public void waitForPageToLoad() {
        federalTaxInfoPageHeader.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_FederalTaxInfo_Page(WebDriver driver) {
        super(driver);
    }
}
