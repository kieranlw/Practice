package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

import java.time.Duration;

public abstract class DUO_BasePage extends BasePageObject {

    protected WebDriver driver;

    @ComponentFindBy(xpath = "//h2[contains(.,'Company I.D.')]")
    private GenericComponent headerLabel;

    @ComponentFindBy(xpath = "//strong[text()='Uh oh!']/parent::div")
    public Label alertErrorMsg;

    // FOOTER
    @ComponentFindBy(xpath = "//span[@class = 'nav-item']/a[text()='Terms & Conditions']")
    public NavigateTo<DUO_TermsAndConditions_Page> termsAndConditionsLink;

    @ComponentFindBy(xpath = "//a[@class = 'nav-item'][text()='Privacy Policy']")
    public NavigateTo<DUO_PrivacyPolicy_Page> privacyPolicyLink;

    @ComponentFindBy(xpath = "//a[@class = 'nav-item'][text()='Do Not Sell My Personal Information']")
    public NavigateTo<DUO_CaliforniaSpecificAddendum_Page> doNotSellMyPersonalInfoLink;

    @ComponentFindBy(xpath = "//a[@class = 'nav-item'][text()='Accessibility Policy']")
    public NavigateTo<DUO_AccessibilityPolicy_Page> accessibilityPolicyLink;

    @ComponentFindBy(xpath = "//h5[text()='Sales Support']/following-sibling::div/div/a")
    public GenericComponent salesSupportNumber;


    // HEADER MENU
    @ComponentFindBy(xpath = "//a[contains(text(), 'Save and Sign Out')]")
    public NavigateTo<DUO_Login_Page> saveAndSignOutButton;

    @ComponentFindBy(id = "userNameLabelFullView")
    public NavigateTo<DUO_Login_Page> menu_accountEmail;

    @ComponentFindBy(xpath = "//span[@id='userNameLabelFullView']/parent::span/following-sibling::div")
    public GenericComponent menu_arrow;

    @ComponentFindBy(xpath = "//span[@id='userNameLabelFullView']/parent::span/parent::a/parent::li/parent::div/preceding-sibling::div")
    public GenericComponent menu_companyName;

    @ComponentFindBy(id = "accountHomeMenuItem")
    @AfterClick_HardCodedSleep(milliseconds = 2000, why = "legacy code, reason unknown")
    public NavigateTo<DUO_AccountHome_Page> menu_accountHome;

    @ComponentFindBy(id = "preferencesMenuItem")
    @AfterClick_HardCodedSleep(milliseconds = 3000, why = "legacy code, reason unknown")
    public NavigateTo<DUO_AccountPreferences_Page> menu_preferences;

    @ComponentFindBy(xpath = "//a[@id = 'signOutMenuItem']/i")
    @AfterClick_HardCodedSleep(milliseconds = 3000, why = "legacy code, reason unknown")
    public NavigateTo<DUO_Login_Page> menu_signOut;

    @ComponentFindBy(xpath = "//a[@class = 'nav-item'][text()='SupportHRSolutions@deluxe.com']")
    public GenericComponent supportHRSolutionsEmailLink;

    @ComponentFindBy(xpath = "//a[@class = 'nav-item'][text()='PayOnboardingAdmin@deluxe.com']")
    public GenericComponent payOnboardingAdminEmailLink;

    @ComponentFindBy(xpath = "//a[.='Log Off/Finish Later']")
    public NavigateTo<DUO_Login_Page> logOffOrFinishLaterButton;

    public void goToSummaryPage() {
        driver.get("https://dlx-cob-spa-qa.herokuapp.com/company/summary");
    }


    // LEFT MENU NAV ITEMS
    @ComponentFindBy(xpath ="//a[contains(text(),'Package Selection')]")
    public GenericComponent leftMenuPackageSelectionItem;

    @ComponentFindBy(xpath ="//a[contains(text(),'Package Add-ons')]")
    public GenericComponent leftMenuPackageAddonsItem;

    @ComponentFindBy(xpath = "//a[contains(text(),'Credit Authorization')]")
    public GenericComponent leftMenuCreditAuthorization;

    @ComponentFindBy(xpath = "//a[contains(text(),'Authorization')]")
    public GenericComponent leftMenuAuthorization;

    @ComponentFindBy(xpath ="//a[contains(text(),'Company Addresses')]")
    public GenericComponent leftMenuCompanyAddressesItem;

    @ComponentFindBy(xpath ="//a[contains(text(),'Federal Tax Info')]")
    public GenericComponent leftMenuFederalTaxInfoItem;

    @ComponentFindBy(xpath ="//a[contains(text(),'Authorization Forms')]")
    public GenericComponent leftMenuAuthorizationFormsItem;

    @ComponentFindBy(xpath ="//a[contains(text(),'State Tax Info')]")
    public GenericComponent leftMenuStateTaxInfoItem;

    @ComponentFindBy(xpath ="//a[contains(text(),'Bank Account(s)')]")
    public GenericComponent leftMenuBankAccountsItem;

    @ComponentFindBy(xpath = "//a[contains(text(), 'Summary')]")
    public GenericComponent leftMenuSummaryItem;

    @ComponentFindBy(xpath = "//a[contains(text(),'User Agreement')]")
    public GenericComponent leftMenuUserAgreementItem;

    @ComponentFindBy(xpath = "//a[contains(text(),'Success')]")
    @AfterClick_HardCodedSleep(milliseconds = 3000, why = "legacy code, reason unknown")
    public GenericComponent leftMenuSuccessItem;

    @ComponentFindBy(xpath = "//a[contains(text(),'Company Addresses')]/parent::span/preceding-sibling::span")
    public GenericComponent leftMenuCompanyAddressesStatus;

    @ComponentFindBy(xpath = "//a[contains(text(),'Federal Tax Info')]/parent::span/preceding-sibling::span")
    public GenericComponent leftMenuFederalTaxInfoStatus;

    @ComponentFindBy(xpath = "//a[contains(text(),'Authorization Forms')]/parent::span/preceding-sibling::span")
    public GenericComponent leftMenuAuthorizationFormsStatus;

    @ComponentFindBy(xpath = "//a[contains(text(),'State Tax Info')]/parent::span/preceding-sibling::span")
    public GenericComponent leftMenuStateTaxInfoStatus;

    @ComponentFindBy(xpath = "//a[contains(text(),'Bank Account(s)')]/parent::span/preceding-sibling::span")
    public GenericComponent leftMenuBankAccountsStatus;

    @ComponentFindBy(xpath = "//a[contains(text(),'Summary')]/parent::span/preceding-sibling::span")
    public GenericComponent leftMenuSummaryStatus;

    @ComponentFindBy(xpath = "//a[contains(text(),'User Agreement')]/parent::span/preceding-sibling::span")
    public GenericComponent leftMenuUserAgreementStatus;

    @ComponentFindBy(xpath = "//a[contains(text(),'Package Selection')]/parent::span/preceding-sibling::span")
    public GenericComponent leftMenuPackageSelectionStatus;

    @ComponentFindBy(xpath = "//a[contains(text(),'Package Add-ons')]/parent::span/preceding-sibling::span")
    public GenericComponent leftMenuPackageAddOnsStatus;

    @ComponentFindBy(xpath = "//a[contains(text(),'Credit Authorization')]/parent::span/preceding-sibling::span")
    public GenericComponent leftMenuCreditAuthorizationStatus;


    // Toast Pop Up Locators

    @ComponentFindBy(xpath = "//div[contains(@class,'Toastify__toast-body')]/div[2]/div/h5")
    public Label toastPopUpHeader;

    @ComponentFindBy(xpath = "//div[contains(@class,'Toastify__toast-body')]/div[2]/div/p")
    public Label toastPopUpMessage;

    @ComponentFindBy(xpath = "//div[contains(@class,'Toastify__toast-icon Toastify--animate-icon Toastify__zoom-enter')]")
    public GenericComponent toastPopUpInfoIcon;

    @ComponentFindBy(xpath = "//button[contains(@class,'Toastify__close-button Toastify__close-button--light')]")
    public GenericComponent toastPopUpCloseButton;



    @Override
    public void waitForPageToLoad() throws Exception {
        headerLabel.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_BasePage(WebDriver driver) {
        this.driver = driver;
        ComponentFactory.initElements(this.driver, this);
    }

    public DUO_BasePage verifyDisplayOfNavBarAfterSelectingLitePayrollOrAllAccessPackageFirstPage(){
        leftMenuPackageSelectionItem.verify().enabled().displayed();
        leftMenuPackageAddonsItem.verify().enabled().displayed();
        leftMenuCreditAuthorization.verify().enabled().displayed();
        return this;
    }

    public DUO_BasePage verifyDisplayOfNavBarAfterSelectingLitePayrollOrAllAccessPackageSecondPage(){

        leftMenuCompanyAddressesItem.verify().enabled().displayed();
        leftMenuFederalTaxInfoItem.verify().enabled().displayed();
        leftMenuAuthorizationFormsItem.verify().enabled().displayed();
        leftMenuStateTaxInfoItem.verify().enabled().displayed();
        leftMenuBankAccountsItem.verify().enabled().displayed();
        leftMenuSummaryItem.verify().enabled().displayed();
        leftMenuUserAgreementItem.verify().enabled().displayed();
        return this;
    }

    public DUO_BasePage verifyLeftMenuItemsAfterSelectingBlendedTheHrPackageForFirstStep(){
        leftMenuPackageSelectionItem.verify().enabled().displayed();
        leftMenuPackageAddonsItem.verify().enabled().displayed();
        leftMenuAuthorizationFormsItem.verify().enabled().displayed();
        return this;
    }

    public DUO_BasePage verifyLeftMenuItemsAfterSelectingBlendedTheHrPackageForSecondStep(){
        leftMenuCompanyAddressesItem.verify().enabled().displayed();
        leftMenuSummaryItem.verify().enabled().displayed();
        return this;
    }
    public DUO_BasePage verifySomePagesAreNotDisplayedAfterSelectingBlendedTheHrPackage(){
        leftMenuFederalTaxInfoItem.verify().notDisplayed();
        leftMenuAuthorizationFormsItem.verify().notDisplayed();
        leftMenuStateTaxInfoItem.verify().notDisplayed();
        leftMenuBankAccountsItem.verify().notDisplayed();
        return this;
    }
}



