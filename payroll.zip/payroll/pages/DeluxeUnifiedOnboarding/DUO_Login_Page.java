package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.api.DeluxeUnifiedOnboarding.Account;
import payroll.classObjects.DigitalOnboarding.DigitalOnboardingLogin;

import utils2.page_components.*;

import java.time.Duration;

public class DUO_Login_Page extends DUO_BasePage {

    @ComponentFindBy(id = "emailAddress")
    public TextBox usernameTextbox;

    @ComponentFindBy(id = "password")
    public TextBox passwordTextbox;

    @ComponentFindBy(xpath = "//button[text()='Login']")
    @AfterClick_HardCodedSleep(milliseconds = 2000, why="Legacy code, reason unknown")
    public NavigateTo<DUO_AccountHome_Page> loginButton;

    @ComponentFindBy(xpath = "//button[contains(text(), 'Login')]")
    public NavigateTo<DUO_EmailVerification_Page> loginButtonforUnregisteredUser;

    @ComponentFindBy(xpath = "//a[contains(text(), 'Forgot')]")
    public NavigateTo<DUO_ForgotPassword_Page> forgotPasswordLink;

    @ComponentFindBy(xpath = "//a[contains(text(), 'Create an Account')]")
    public NavigateTo<DUO_AccountRegistrationAccountInfo_Page> createAnAccountLink;

    @ComponentFindBy(xpath = "//h1[contains(text(), 'Log In')]")
    public NavigateTo<DUO_Login_Page> loginPageLabel;

    @ComponentFindBy(xpath = "//label[@for = 'emailAddress']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent emailFieldError;

    @ComponentFindBy(xpath = "//label[@for = 'password']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public GenericComponent passwordFieldError;

    @ComponentFindBy(xpath = "//div[@class='mb-3 alert alert-error alert-dismissible fade show']")
    public GenericComponent generalLoginPageError;

    @ComponentFindBy(xpath = "  //div[@class='danger validation-summary-errors']//li[2]")
    public Label lockOutErrorMessage;

    public DUO_Login_Page fillInFields(DigitalOnboardingLogin loginInfo) {
        usernameTextbox.deleteAllText().enterText(loginInfo.getUserName());
        passwordTextbox.deleteAllText().enterText(loginInfo.getPassword());
        return this;
    }
    public DUO_Login_Page fillInFields(Account loginInfo) {
        usernameTextbox.deleteAllText().enterText(loginInfo.getEmailAddress());
        passwordTextbox.deleteAllText().enterText(loginInfo.getPassword());
        return this;
    }

    public void verifyEmailFieldError(String errorDescription) {
        emailFieldError.verify().textEquals(errorDescription);
    }

    public void verifyPasswordFieldError(String errorDescription) {
        passwordFieldError.verify().textEquals(errorDescription);
    }

    public void verifyGeneralLoginError(String errorDescription) {
        generalLoginPageError.waitUntil(Duration.ofSeconds(50)).displayed();
        generalLoginPageError.verify().textEquals(errorDescription);
    }

    public void verifyLockOutErrorMessage(){
        lockOutErrorMessage.verify().textEquals("Account is locked, try again in 30 minutes.");
    }

    public void verifyEmailPasswordAndLoginDisabled(){
        usernameTextbox.verify().attributeDoesExist("disabled");
        passwordTextbox.verify().attributeDoesExist("disabled");
        loginButton.verify().attributeDoesExist("disabled");
    }

    public void verifyEmailPasswordAndLoginEnabled(){
        usernameTextbox.verify().attributeDoesNOTExist("disabled");
        passwordTextbox.verify().attributeDoesNOTExist("disabled");
        loginButton.verify().attributeDoesNOTExist("disabled");
    }

    @Override
    public void waitForPageToLoad() {
        usernameTextbox.waitUntil(Duration.ofSeconds(50)).displayed();
        loginButton.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_Login_Page(WebDriver driver) {
        super(driver);
    }
}
