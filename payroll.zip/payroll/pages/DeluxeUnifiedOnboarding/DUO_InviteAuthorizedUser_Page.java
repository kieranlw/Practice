package payroll.pages.DeluxeUnifiedOnboarding;

import common.Is;
import common.ThreadUtils;
import common.Verify;
import org.openqa.selenium.WebDriver;
import payroll.classObjects.DigitalOnboarding.InviteAuthorizedUser;
import utils2.page_components.*;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

public class DUO_InviteAuthorizedUser_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//div[@class='col-md-8 my-1 col']/h2")
    public Label inviteAuthorizedUserHeader;

    @ComponentFindBy(id = "companyNameLabel")
    public Label companyNameSubHeader;

    @ComponentFindBy(id = "firstName")
    public TextBox firstNameTextBox;

    @ComponentFindBy(id = "lastName")
    public TextBox lastNameTextBox;

    @ComponentFindBy(xpath = "//select[@name='role']")
    public DropDown roleDropdown;

    @ComponentFindBy(id = "emailAddress-auto")
    public TextBox emailAddressTextBox;

    @ComponentFindBy(xpath = "//button[text()= 'Back']")
    public NavigateTo<DUO_AccountPreferences_Page> backButton;

    @AfterClick_HardCodedSleep(milliseconds = 1000, why = "legacy code, reason unknown")
    @ComponentFindBy(xpath = "//button[text()= 'Invite Contact']")
    public NavigateTo<DUO_AccountPreferences_Page> inviteContactButton;

    @ComponentFindBy(xpath = "//input[@id='firstName']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label firstNameErrorMsg;

    @ComponentFindBy(xpath = "//input[@id='lastName']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label lastNameErrorMsg;

    @ComponentFindBy(xpath = "//select[@name='role']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label roleErrorMsg;

    @ComponentFindBy(xpath = "//div[@class='form-group'][4]/div[1]")
    public Label emailErrorMsg;

    @ComponentFindBy(xpath = "//input[@name='otherRoleText']")
    public TextBox specifyRoleTextBox;

    @ComponentFindBy(xpath = "//label[@for='otherRoleText']/parent::div/div")
    public Label specifyRoleErrorMsg;

    @ComponentFindBy(xpath = "//strong[text()='Uh oh!']/parent::div")
    public Label alertErrorMsg;

    @ComponentFindBy(xpath = "//select[@name='role']/option[13]")
    public GenericComponent otherOption;

    private final String TEXT_STARTS_WITH_NUMBER_OR_ONLY_NUMBERS_ERROR = "Numbers only are not allowed, nor can the first character be a number.";

    public static final List<String> dropdownValues = Arrays.asList("Please Select...", "Owner", "Chief Executive Officer (CEO)", "President",
            "Vice President", "Treasurer", "Chief Accounting Officer", "Secretary",
            "Partner",
            "Payroll Admin",
            "Bookkeeper", "CPA/Accountant", "Other");

    public DUO_InviteAuthorizedUser_Page verifyInviteAuthorizedUserPageVisibility(InviteAuthorizedUser inviteAuthorizedUser) {
        inviteAuthorizedUserHeader.verify().displayed().textEquals("Invite Authorized User");
        companyNameSubHeader.verify().displayed().textEquals("Invitation for: " + inviteAuthorizedUser.getCompanyName());
        backButton.verify().displayed();
        inviteContactButton.verify().displayed();
        return this;
    }

    public DUO_InviteAuthorizedUser_Page fillInFields(InviteAuthorizedUser inviteAuthorizedUser) {
        firstNameTextBox.enterText(inviteAuthorizedUser.getFirstName());
        lastNameTextBox.enterText(inviteAuthorizedUser.getLastName());
        roleDropdown.selectValue(inviteAuthorizedUser.getRoleDropdown());
        emailAddressTextBox.enterText(inviteAuthorizedUser.getEmailAddress());
        return this;
    }

    public DUO_InviteAuthorizedUser_Page deleteTextFromFields() {
        firstNameTextBox.deleteAllText();
        lastNameTextBox.deleteAllText();
        roleDropdown.selectValue("Other");
        specifyRoleTextBox.deleteAllText();
        roleDropdown.selectValue("Please Select...");
        emailAddressTextBox.deleteAllText();
        return this;
    }

    public DUO_InviteAuthorizedUser_Page verifyInviteContactButtonClickable() {
        inviteContactButton.verify().enabled();
        inviteContactButton.click();
        return this;
    }

    public DUO_InviteAuthorizedUser_Page verifyTextBoxFunctionality() {
        firstNameTextBox.verify().enabled();
        lastNameTextBox.verify().enabled();
        emailAddressTextBox.verify().enabled();
        return this;
    }

    public DUO_InviteAuthorizedUser_Page verifyErrorMessagesDisplayedwithMissingFields() {
        inviteContactButton.click();
        firstNameErrorMsg.verify().displayed().textEquals("First name is a required field.");
        lastNameErrorMsg.verify().displayed().textEquals("Last name is a required field.");
        roleErrorMsg.verify().displayed().textEquals("A role must be selected.");
        emailErrorMsg.verify().displayed().textEquals("Email address is a required field.");
        return this;
    }

    public DUO_InviteAuthorizedUser_Page verifyErrorMessagesWithTextStartsWithNumbersOrOnlyWithNumbers
            (Label label) {
        label.verify().displayed().textEquals(TEXT_STARTS_WITH_NUMBER_OR_ONLY_NUMBERS_ERROR);
        return this;
    }

    public DUO_InviteAuthorizedUser_Page verifyNoErrorMessageAlphanumericTextStartsWithLetter() {
        firstNameErrorMsg.verify().notDisplayed();
        lastNameErrorMsg.verify().notDisplayed();
        return this;
    }

    public DUO_InviteAuthorizedUser_Page verifyMaxLengthIs40Characters() {
        Verify.that(firstNameTextBox.getText().length(), Is.equalTo(40));
        return this;
    }

    public DUO_InviteAuthorizedUser_Page verifyInvalidEmailErrorMessage() {
        emailErrorMsg.verify().displayed().textEquals("Must be a valid email address.");
        return this;
    }

    public DUO_InviteAuthorizedUser_Page verifyValidEmailAddress() {
        emailErrorMsg.verify().notDisplayed();
        return this;
    }

    public DUO_InviteAuthorizedUser_Page verifyErrorMessageWithMissingSpecifyRole() {
        specifyRoleErrorMsg.verify().displayed().textEquals("Please enter other role description.");
        return this;
    }

    public DUO_InviteAuthorizedUser_Page verifyAlertErrorMessage() {
        alertErrorMsg.verify().displayed().textContains("Something went wrong!");
        return this;
    }

    public DUO_InviteAuthorizedUser_Page(WebDriver driver) {
        super(driver);
    }

    @Override
    public void waitForPageToLoad() throws Exception {
        inviteAuthorizedUserHeader.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }
}
