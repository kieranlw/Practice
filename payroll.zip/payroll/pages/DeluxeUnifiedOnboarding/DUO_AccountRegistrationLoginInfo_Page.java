package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.api.DeluxeUnifiedOnboarding.Account;
import payroll.classObjects.DigitalOnboarding.AccountRegistrationLoginInfo;
import utils2.DriverUtils;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_AccountRegistrationLoginInfo_Page extends DUO_BasePage {

    @ComponentFindBy(id = "emailAddress-auto")
    public TextBox emailAddress;

    @ComponentFindBy(id = "password")
    public TextBox password;

    @ComponentFindBy(id = "confirmPassword")
    public TextBox confirmPassword;

    @ComponentFindBy(xpath = "//input[@name='consent']")
    public CheckBox termsAndConditionsCheckbox;

    @ComponentFindBy(xpath = "//span[@class='form-check-label']")
    public CheckBox termsAndConditionsLabel;

    @ComponentFindBy(xpath = "//BUTTON[text()='Submit']")
    public NavigateTo<DUO_AccountRegistrationConfirmation_Page> submitBtn;

    @ComponentFindBy(xpath = "//BUTTON[text()='Previous Step']")
    public NavigateTo<DUO_AccountRegistrationAccountInfo_Page> previousStepBtn;

    @ComponentFindBy(xpath = "//input[@id='password']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label passwordErrorMsg;

    @ComponentFindBy(xpath = "//input[@id='password']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label oneNumberErrorMsg;

    @ComponentFindBy(xpath = "//p[normalize-space()='Must be 8 characters']//i[@class='fas fa-check']")
    public Label eightCharsCheck;

    @ComponentFindBy(xpath = "//p[normalize-space()='Must include one lowercase character']//i[@class='fas fa-check']")
    public Label oneLowerCaseCharCheck;

    @ComponentFindBy(xpath = "//p[normalize-space()='Must include one uppercase character']//i[@class='fas fa-check']")
    public Label oneUpperCaseCharCheck;

    @ComponentFindBy(xpath = "//p[normalize-space()='Must include one number']//i[@class='fas fa-check']")
    public Label oneNumberCharCheck;

    @ComponentFindBy(xpath = "//p[normalize-space()='Must include one special character @:$!%*#?&^']//i[@class='fas fa-check']")
    public Label oneSpecialCharCheck;

    @ComponentFindBy(xpath = "//div[@role='alert']")
    public Label errorMessage;

    @ComponentFindBy(xpath = "//input[@id='confirmPassword']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label confirmPasswordErrorMsg;

    @ComponentFindBy(xpath = "//*[@class='form-check']/following-sibling::div[@class='mt-2 d-block text-muted']")
    public Label termsAndConditionsErrorMsg;

    @ComponentFindBy(xpath = "//a[text()='Terms & Conditions']")
    public NavigateTo<DUO_TermsAndConditions_Page> termsAndConditionsLink;

    @ComponentFindBy(xpath = "//input[@id='password']/parent::div/div[1]/p")
    public GenericComponent passwordStrengthText;

    @ComponentFindBy(xpath = "//input[@id='password']/parent::div/div[1]/div/div[1]")
    public GenericComponent passwordStrengthMeter1;

    @ComponentFindBy(xpath = "//input[@id='password']/parent::div/div[1]/div/div[3]")
    public GenericComponent passwordStrengthMeter2;

    @ComponentFindBy(xpath = "//input[@id='password']/parent::div/div[1]/div/div[5]")
    public GenericComponent passwordStrengthMeter3;

    @ComponentFindBy(xpath = "//input[@id='password']/parent::div/div[1]/div/div[7]")
    public GenericComponent passwordStrengthMeter4;


    public DUO_AccountRegistrationLoginInfo_Page fillInFields(AccountRegistrationLoginInfo accountRegistrationLoginInfo) {
        password.enterText(accountRegistrationLoginInfo.getPassword());
        confirmPassword.enterText(accountRegistrationLoginInfo.getConfirmPassword());
        termsAndConditionsCheckbox.toggle(accountRegistrationLoginInfo.getIConsentCheckbox());

        return this;
    }
    public DUO_AccountRegistrationLoginInfo_Page fillInFields(Account account) {
        password.enterText(account.getPassword());
        confirmPassword.enterText(account.getPassword());
        termsAndConditionsLabel.check();

        return this;
    }

    public DUO_AccountRegistrationLoginInfo_Page clickNextCausesErrors() {
        submitBtn.click();
        ThreadUtils.sleep(500);
        new DriverUtils(driver).waitForReadyStateComplete(Duration.ofSeconds(5));
        return this;
    }

    public void verifyAccountRegistrationAccountSetupFields(AccountRegistrationLoginInfo accountRegistrationLoginInfo) {
        emailAddress.verify()
                .displayed()
                .textEquals(accountRegistrationLoginInfo.getEmailAddress());
    }

    public enum StrengthColors {
        GREY("rgb(221, 221, 221)"),
        RED("rgb(239, 72, 54)"),
        YELLOW("rgb(246, 180, 77)"),
        BLUE("rgb(43, 144, 239)"),
        GREEN("rgb(37, 194, 129)");

        public final String message;

        StrengthColors(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }

    public enum StrengthLevels {
        TOO_SHORT,
        WEAK,
        OKAY,
        GOOD,
        STRONG;
    }

    public DUO_AccountRegistrationLoginInfo_Page verifyStrengthMeter(String strengthLevel) {
        switch(strengthLevel) {
            case "TOO_SHORT" :
                passwordStrengthText.verify().textEquals("too short");
                passwordStrengthMeter1.verify().attributeContains("style", StrengthColors.GREY.getMessage());
                passwordStrengthMeter2.verify().attributeContains("style", StrengthColors.GREY.getMessage());
                passwordStrengthMeter3.verify().attributeContains("style", StrengthColors.GREY.getMessage());
                passwordStrengthMeter4.verify().attributeContains("style", StrengthColors.GREY.getMessage());
                break;
            case "WEAK" :
                passwordStrengthText.verify().textEquals("weak");
                passwordStrengthMeter1.verify().attributeContains("style", StrengthColors.RED.getMessage());
                passwordStrengthMeter2.verify().attributeContains("style", StrengthColors.GREY.getMessage());
                passwordStrengthMeter3.verify().attributeContains("style", StrengthColors.GREY.getMessage());
                passwordStrengthMeter4.verify().attributeContains("style", StrengthColors.GREY.getMessage());
                break;
            case "OKAY" :
                passwordStrengthText.verify().textEquals("okay");
                passwordStrengthMeter1.verify().attributeContains("style", StrengthColors.YELLOW.getMessage());
                passwordStrengthMeter2.verify().attributeContains("style", StrengthColors.YELLOW.getMessage());
                passwordStrengthMeter3.verify().attributeContains("style", StrengthColors.GREY.getMessage());
                passwordStrengthMeter4.verify().attributeContains("style", StrengthColors.GREY.getMessage());
                break;
            case "GOOD" :
                passwordStrengthText.verify().textEquals("good");
                passwordStrengthMeter1.verify().attributeContains("style", StrengthColors.BLUE.getMessage());
                passwordStrengthMeter2.verify().attributeContains("style", StrengthColors.BLUE.getMessage());
                passwordStrengthMeter3.verify().attributeContains("style", StrengthColors.BLUE.getMessage());
                passwordStrengthMeter4.verify().attributeContains("style", StrengthColors.GREY.getMessage());
                break;
            case "STRONG" :
                passwordStrengthText.verify().textEquals("strong");
                passwordStrengthMeter1.verify().attributeContains("style", StrengthColors.GREEN.getMessage());
                passwordStrengthMeter2.verify().attributeContains("style", StrengthColors.GREEN.getMessage());
                passwordStrengthMeter3.verify().attributeContains("style", StrengthColors.GREEN.getMessage());
                passwordStrengthMeter4.verify().attributeContains("style", StrengthColors.GREEN.getMessage());
                break;
        }
        return this;
    }


    @Override
    public void waitForPageToLoad() {
        emailAddress.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_AccountRegistrationLoginInfo_Page(WebDriver driver) {
        super(driver);
    }
}
