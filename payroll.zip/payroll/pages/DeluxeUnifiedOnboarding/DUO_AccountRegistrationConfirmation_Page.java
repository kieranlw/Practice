package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_AccountRegistrationConfirmation_Page extends DUO_BasePage {

    @ComponentFindBy(xpath = "//h2[normalize-space()='Check your email!']")
    public Label checkYourEmailLbl;

    @ComponentFindBy(xpath = "//span[text()='Account Registration']")
    public NavigateTo<DUO_Login_Page> accountRegistrationHeaderLink;

    @ComponentFindBy(xpath = "//h2[contains(text(),'Check your email!')]/following-sibling::p[1]")
    public Label firstTextUnderCheckYourEmailLbl;

    @ComponentFindBy(xpath = "//h2[contains(text(),'Check your email!')]/following-sibling::p[2]")
    public Label secondTextUnderCheckYourEmailLbl;

    @ComponentFindBy(xpath = "//BUTTON[text()='Resend Email']")
    public Button resendEmailBtn;

    @ComponentFindBy(xpath = "//BUTTON[text()='Email Sent!']")
    public Button emailSentBtn;

    @ComponentFindBy(xpath = "//a[contains(text(),'Account Info')]")
    public GenericComponent AccountInfoLnk;

    @ComponentFindBy(xpath = "//a[contains(text(),'Login Info')]")
    public GenericComponent loginInfoLnk;

    @ComponentFindBy(xpath = "//a[contains(text(),'Confirmation')]")
    public GenericComponent confirmationLnk;

    @ComponentFindBy(xpath = "//a[contains(text(),'Terms & Conditions')]")
    public NavigateTo<DUO_TermsAndConditions_Page> termsAndConditionsLnk;

    @ComponentFindBy(xpath = "//a[contains(text(),'Privacy Policy')]")
    public NavigateTo<DUO_PrivacyPolicy_Page> privacyPolicyLnk;

    @ComponentFindBy(xpath = "//a[contains(text(),'Do Not Sell My Personal Information')]")
    public NavigateTo<DUO_CaliforniaSpecificAddendum_Page> doNotSellPersonalInfnLnk;

    @ComponentFindBy(xpath = "//a[contains(text(),'Accessibility Policy')]")
    public NavigateTo<DUO_AccessibilityPolicy_Page> accessibilityPolicyLnk;

    @ComponentFindBy(xpath = "//BUTTON[text()='Logout']")
    public Button logoutBtn;

    @ComponentFindBy(xpath = "//a[contains(text(),'Forgot password?')]")
    public GenericComponent forgotPasswordLnk;



    public void verifyResendEmail(){
        resendEmailBtn.click();
        emailSentBtn.waitUntil(Duration.ofSeconds(15)).displayed();
        emailSentBtn.verify().disabled();
    }

    public DUO_AccountRegistrationConfirmation_Page verifyAccountCreated(){
        checkYourEmailLbl.verify().displayed().textEquals("Check your email!");
        return this;
    }

    @Override
    public void waitForPageToLoad() {
        resendEmailBtn.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DUO_AccountRegistrationConfirmation_Page(WebDriver driver) {
        super(driver);
    }
}
