package payroll.pages.DeluxeUnifiedOnboarding;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.api.DeluxeUnifiedOnboarding.Account;
import payroll.api.DeluxeUnifiedOnboarding.ChangePassword;
import payroll.page_components.TextBox_Payroll;
import utils2.page_components.*;

import java.time.Duration;

public class DUO_ChangePassword_Page extends DUO_BasePage {

    @ComponentFindBy(id = "changePasswordLabel")
    public GenericComponent changePasswordLabel;

    @ComponentFindBy(xpath = "//button[text() = 'Back']")
    public NavigateTo<DUO_AccountPreferences_Page> backBtn;

    @ComponentFindBy(xpath = "//button[text() = 'Save']")
    @AfterClick_HardCodedSleep(milliseconds = 1000, why = "legacy code, reason unknown")
    public NavigateTo<DUO_AccountPreferences_Page> saveBtn;

    @ComponentFindBy(id = "oldPassword")
    public TextBox_Payroll oldPasswordTextbox;

    @ComponentFindBy(xpath = "//input[@id = 'oldPassword']/following-sibling::div")
    public Label oldPasswordErrorMsg;

    @ComponentFindBy(id = "password")
    public TextBox_Payroll newPasswordTextbox;

    @ComponentFindBy(xpath = "//input[@id = 'password']/following-sibling::div/following-sibling::div")
    public Label passwordErrorMsg;

    @ComponentFindBy(id = "confirmPassword")
    public TextBox_Payroll confirmPasswordTextbox;

    @ComponentFindBy(xpath = "//input[@id = 'confirmPassword']/following-sibling::div")
    public Label confirmPasswordErrorMsg;

    @ComponentFindBy(id = "alertError")
    @AfterClick_HardCodedSleep(milliseconds = 1000, why = "legacy code, reason unknown")
    public Label bannerErrorMsg;

    
    public DUO_ChangePassword_Page fillInFields(ChangePassword changePassword) {
        oldPasswordTextbox.enterText(changePassword.getOldPassword());
        newPasswordTextbox.enterText(changePassword.getNewPassword());
        confirmPasswordTextbox.enterText(changePassword.getNewPassword());
        return this;
    }

    public DUO_ChangePassword_Page fillInFields(Account account) {
        oldPasswordTextbox.enterText(account.getPassword());
        newPasswordTextbox.enterText("Update***" + account.getPassword());
        confirmPasswordTextbox.enterText("Update***" + account.getPassword());
        return this;
    }

    public DUO_ChangePassword_Page verifyOldPasswordError() {
        oldPasswordErrorMsg.verify().displayed().textEquals("Old Password is required");
        return this;
    }

    public DUO_ChangePassword_Page verifyOldPasswordError(String errorMessage) {
        oldPasswordErrorMsg.verify().displayed().textEquals(errorMessage);
        return this;
    }

    public DUO_ChangePassword_Page verifyNewPasswordError() {
        passwordErrorMsg.verify().displayed().textEquals("New Password is required.");
        return this;
    }

    public DUO_ChangePassword_Page verifyNewPasswordError(String errorMessage) {
        passwordErrorMsg.verify().displayed().textEquals(errorMessage);
        return this;
    }

    public DUO_ChangePassword_Page verifyConfirmPasswordError() {
        confirmPasswordErrorMsg.verify().displayed().textEquals("Confirm password is required.");
        return this;
    }

    public DUO_ChangePassword_Page verifyConfirmPasswordError(String errorMessage) {
        confirmPasswordErrorMsg.verify().displayed().textEquals(errorMessage);
        return this;
    }

    public DUO_ChangePassword_Page(WebDriver driver) {
        super(driver);
    }

    @Override
    public void waitForPageToLoad() throws Exception {
        saveBtn.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }
}
