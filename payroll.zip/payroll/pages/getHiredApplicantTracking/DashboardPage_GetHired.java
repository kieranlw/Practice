package payroll.pages.getHiredApplicantTracking;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.pages.payroll.BasePage;
import utils2.page_components.*;

import java.time.Duration;

public class DashboardPage_GetHired extends BasePage {

    @ComponentFindBy(linkText = "Post New Job")
    public GenericComponent postNewJobButton;

    @Override
    public void waitForPageToLoad() {
        postNewJobButton.waitUntil(Duration.ofSeconds(50)).displayed();
        ThreadUtils.sleep(500);
    }

    public DashboardPage_GetHired(WebDriver driver) {
        super(driver);
    }
}
