package payroll.api;

import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.http.ContentType;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.config;
import static io.restassured.RestAssured.given;

public class ClientOnboardingAPI {
    public RequestSpecification globalRequestSpec;
    private APICredentials credentials;
    private String url;

    public ClientOnboardingAPI(APICredentials apiCredentials, String url) {
        RestAssured.defaultParser = Parser.JSON;
        this.credentials = apiCredentials;
        this.url = url;
        globalRequestSpec = getRequest();
    }
    public Response postTokenRequestGetResponse() {
        RequestSpecification request = given().log().all()
                .config(config().encoderConfig(
                        EncoderConfig.encoderConfig().encodeContentTypeAs("x-www-form-urlencoded", ContentType.URLENC)))
                .contentType("x-www-form-urlencoded")
                .formParam("grant_type", credentials.getGrantType())
                .formParam("scope", credentials.getScope())
                .formParam("client_id", credentials.getClientId())
                .formParam("client_secret", credentials.getClientSecretPassword())
                .header("accept", "application/json")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .request();
        //TODO: feed in URL once I get API access in UAT.
        Response res = request.post("https://qa-mypaycenteridentity.mypaycenter.com" + "/connect/token");
        return res;
    }

    public Department[] getDepartments() {
        Department[] departments = globalRequestSpec
                .contentType("application/json")
                .get(url + "/api/Departments/")
                .as(Department[].class);
        return departments;
    }
    public DepartmentDetails getDepartmentDetails(String id) {
        DepartmentDetails department = globalRequestSpec
                .contentType("application/json")
                .get(url + "/api/Departments/" + id)
                .as(DepartmentDetails.class);
        return department;
    }

    private Token postTokenRequestGetTokenResponse() {
        Response res = postTokenRequestGetResponse();
        return res.as(Token.class);
    }
    private RequestSpecification getRequest() {
        Token requestToken = postTokenRequestGetTokenResponse();
        RequestSpecification requestSpec = setupRequestWithToken(requestToken.access_token);
        return requestSpec;
    }
    private RequestSpecification setupRequestWithToken(String token) {
        RequestSpecification request = given().log().all()
                .header("Authorization", "Bearer " + token)
                .request();
        return request;
    }
}