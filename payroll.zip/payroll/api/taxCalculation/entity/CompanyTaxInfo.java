
package payroll.api.taxCalculation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import utils2.tableData.Row;

public class CompanyTaxInfo {
    /**
     * {
     * "IsExempt": true,
     * "IsBlocked": false,
     * "Rate": 0,
     * "TaxCode": {
     * "MajorLocation": 54,
     * "TaxType": 2,
     * "MinorLocation": null
     * }
     * }
     */

    @JsonIgnore
    private String employeeId;
    @JsonIgnore
    private int employeeNum;
    private boolean isExempt;
    private boolean isBlocked;
    private int rate;
    private TaxCode taxCode;

    public CompanyTaxInfo(boolean isExempt,
                          boolean isBlocked,
                          boolean rateIsOverridden,
                          int rate,
                          TaxCode taxCode) {
        this.isExempt = isExempt;
        this.isBlocked = isBlocked;
        this.rate = rate;
        this.taxCode = taxCode;
    }

    public CompanyTaxInfo() {
        this(true, false, false, 0, new TaxCode());
    }

    public CompanyTaxInfo(Row row) {
        this.employeeId = row.get("EmployeeId");
        this.employeeNum = Integer.parseInt(row.get("EmployeeNum"));
        this.isExempt = Boolean.parseBoolean(row.get("isExempt"));
        this.isBlocked = Boolean.parseBoolean(row.get("isBlocked"));
        this.rate = Integer.parseInt(row.get("Rate"));
        this.taxCode = new TaxCode(row.get("MajorLocation"),Integer.parseInt(row.get("TaxType")), row.getNullable("MinorLocation"));
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public int getEmployeeNum() {
        return employeeNum;
    }

    public boolean getIsExempt() {
        return isExempt;
    }

    public void setIsExempt(boolean isExempt) {
        this.isExempt = isExempt;
    }

    public boolean getIsBlocked() {
        return isBlocked;
    }

    public void setIsBlocked(boolean isBlocked) {
        this.isBlocked = isBlocked;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public TaxCode getTaxCode() {
        return taxCode;
    }

    public void setTaxCode(TaxCode taxCode) {
        this.taxCode = taxCode;
    }
}