
package payroll.api.taxCalculation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import utils2.tableData.Row;

public class TaxCalculationLocation {
    /**
     * {
     * "TaxLocationId": "343b277f-4340-4025-bca2-9e63541a5fd4",
     * "IsPrimary": true,
     * "State": "Md",
     * "Zip": "21057-1234",
     * "LocationType": 2
     * }
     */

    @JsonIgnore
    private String employeeId;
    @JsonIgnore
    private int employeeNum;
    private String taxLocationId;
    private boolean isPrimary;
    private String state;
    private String zip;
    private String locationType;

    public TaxCalculationLocation(String taxLocationId,
                                  boolean isPrimary,
                                  String state,
                                  String zip,
                                  String locationType) {
        this.taxLocationId = taxLocationId;
        this.isPrimary = isPrimary;
        this.state = state;
        this.zip = zip;
        this.locationType = locationType;
    }

    public TaxCalculationLocation() {
        this.taxLocationId = "28c9b80d-1007-4318-86f7-886f8d89e58b";
        this.isPrimary = true;
        this.state = "Md";
        this.zip = "21057-9303";
        this.locationType = "2";
    }

    public TaxCalculationLocation(Row row) {
        this.employeeId = row.get("EmployeeId");
        this.employeeNum = Integer.parseInt(row.get("EmployeeNum"));
        this.taxLocationId = row.get("TaxLocationId");
        this.isPrimary = Boolean.parseBoolean(row.get("IsPrimary"));
        this.state = row.get("State");
        this.zip = row.get("Zip");
        this.locationType = row.get("LocationType");
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public int getEmployeeNum() {
        return employeeNum;
    }

    public String getTaxLocationId() {
        return taxLocationId;
    }

    public void setTaxLocationId(String taxLocationId) {
        this.taxLocationId = taxLocationId;
    }

    public boolean getIsPrimary() {
        return isPrimary;
    }

    public void setIsPrimary(boolean isPrimary) { this.isPrimary = isPrimary; }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getLocationType() {
        return locationType;
    }

    public void setLocationType(String locationType) {
        this.locationType = locationType;
    }
}