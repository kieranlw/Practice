
package payroll.api.taxCalculation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import utils2.tableData.Row;

public class MonthToDate {
    /**
     * {
     * "CalculatedTaxAmount": 25.26,
     * "TaxableGrossAmount": 1500,
     * "DeferredAmount": 0
     * }
     */

    @JsonIgnore
    private String employeeId;
    @JsonIgnore
    private int employeeNum;
    @JsonIgnore
    private String taxCodeDescription;
    @JsonIgnore
    private String taxAggregatedType;

    private double calculatedTaxAmount;
    private double taxableGrossAmount;
    private double deferredAmount;

    public MonthToDate (double calculatedTaxAmount,
                        double taxableGrossAmount,
                        double deferredAmount) {
        this.calculatedTaxAmount = calculatedTaxAmount;
        this.taxableGrossAmount = taxableGrossAmount;
        this.deferredAmount = deferredAmount;
    }

    public MonthToDate (Row row) {
        this.employeeId = row.get ("EmployeeId");
        this.employeeNum = Integer.parseInt (row.get ("EmployeeNum"));
        this.taxCodeDescription = row.get ("TaxCode");
        this.taxAggregatedType = row.get ("AggregatedType");
        this.calculatedTaxAmount = tryParseDouble(row,"CalculatedTaxAmount");
        this.taxableGrossAmount = tryParseDouble(row,"TaxableGrossAmount");
        this.deferredAmount = tryParseDouble(row,"DeferredAmount");
    }

    private Double tryParseDouble(Row row, String value) {
        String contentValue = row.get(value);
        return Double.parseDouble(contentValue.replace(",", "."));
    }

    public MonthToDate () {
        this (25.26, 1500, 0);
    }

    public double getCalculatedTaxAmount () {
        return calculatedTaxAmount;
    }

    public void setCalculatedTaxAmount (double calculatedTaxAmount) {
        this.calculatedTaxAmount = calculatedTaxAmount;
    }

    public double getTaxableGrossAmount () {
        return taxableGrossAmount;
    }

    public void setTaxableGrossAmount (int taxableGrossAmount) {
        this.taxableGrossAmount = taxableGrossAmount;
    }

    public double getDeferredAmount () {
        return deferredAmount;
    }

    public void setDeferredAmount (int deferredAmount) {
        this.deferredAmount = deferredAmount;
    }

    public String getEmployeeId () {return employeeId;}

    public String getTaxCodeDescription () {
        return taxCodeDescription;
    }
    public String getAggregatedType () {
        return taxAggregatedType;
    }
}