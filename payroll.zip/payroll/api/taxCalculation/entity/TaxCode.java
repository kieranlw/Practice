
package payroll.api.taxCalculation.entity;

import lombok.Data;

@Data
public class TaxCode {
    /**
     * {
     * "MajorLocation": 54,
     * "TaxType": 1,
     * "MinorLocation": null
     * }
     */

    private String majorLocation;
    private int taxType;
    private String minorLocation;

    public TaxCode(String majorLocation,
                   int taxType,
                   String minorLocation) {
        this.majorLocation = majorLocation;
        this.taxType = taxType;
        this.minorLocation = minorLocation;
    }

    public TaxCode() {
        this.majorLocation = "US";
        this.taxType = 2;
        this.minorLocation = null;
    }

    public boolean isFITTaxType() {
        return this.taxType == 1;
    }

}