
package payroll.api.taxCalculation.entity;

public class Location {
    /**
     {
     "State": "Md",
     "Zip": "21057-1234",
     "LocationType": 1
     }
     */

    private String state;
    private String zip;
    private Integer locationType;

    public Location(String state,
                    String zip,
                    Integer locationType) {
        this.state = state;
        this.zip = zip;
        this.locationType = locationType;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getZip() {
        return zip;
    }
    public void setZip(String zip) {
        this.zip = zip;
    }
    public Integer getLocationType() {
        return locationType;
    }
    public void setLocationType(Integer locationType) {
        this.locationType = locationType;
    }
}