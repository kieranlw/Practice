
package payroll.api.taxCalculation.entity;

import lombok.Data;

@Data
public class TaxCodeResp {
    /**
     * {
     * "MajorLocation": 54,
     * "TaxType": 1,
     * "MinorLocation": null
     * }
     */

    private String majorLocation;
    private String taxType;
    private String minorLocation;

    public TaxCodeResp(String majorLocation,
                       String taxType,
                       String minorLocation) {
        this.majorLocation = majorLocation;
        this.taxType = taxType;
        this.minorLocation = minorLocation;
    }

    public TaxCodeResp() {
        this.majorLocation = "US";
        this.taxType = "SIT";
        this.minorLocation = null;
    }

    public String getMinorLocation () {
        return minorLocation;
    }

    public String getTaxType () {return taxType;}

    public String getMajorLocation () {return majorLocation;}
}