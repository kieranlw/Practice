
package payroll.api.taxCalculation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import utils2.tableData.Row;

public class EmpPayDetails {
    /**
     * {
     * "Amount": 1500,
     * "TaxLocationId": "343b277f-4340-4025-bca2-9e63541a5fd4",
     * "RegularHours": 80,
     * "OvertimeHours": 0
     * }
     */

    @JsonIgnore
    private String employeeId;
    @JsonIgnore
    private int employeeNum;
    private double amount;
    private String taxLocationId;
    private double regularHours;
    private double overtimeHours;

    public EmpPayDetails(double amount,
                         String taxLocationId,
                         double regularHours,
                         double overtimeHours) {
        this.amount = amount;
        this.taxLocationId = taxLocationId;
        this.regularHours = regularHours;
        this.overtimeHours = overtimeHours;
    }

    public EmpPayDetails() {
        this(1500, "f344faf9-4730-4689-8f8a-bf73cf669a91", 80, 0);
    }

    public EmpPayDetails(Row row) {
        this.employeeId = row.get("EmployeeId");
        this.employeeNum = Integer.parseInt(row.get("EmployeeNum"));
        this.amount = Double.parseDouble(row.get("Amount"));
        this.taxLocationId = row.get("TaxLocationId");
        this.regularHours = Double.parseDouble(row.get("RegularHours"));
        this.overtimeHours = Double.parseDouble(row.get("OvertimeHours"));
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public int getEmployeeNum() {
        return employeeNum;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getTaxLocationId() {
        return taxLocationId;
    }

    public void setTaxLocationId(String taxLocationId) {
        this.taxLocationId = taxLocationId;
    }

    public double getRegularHours() {
        return regularHours;
    }

    public void setRegularHours(double regularHours) {
        this.regularHours = regularHours;
    }

    public double getOvertimeHours() {
        return overtimeHours;
    }

    public void setOvertimeHours(double overtimeHours) {
        this.overtimeHours = overtimeHours;
    }
}