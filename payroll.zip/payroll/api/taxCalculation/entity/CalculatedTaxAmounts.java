
package payroll.api.taxCalculation.entity;

public class CalculatedTaxAmounts {

    private TaxCodeResp taxCode;
    private double taxAmount;
    private double grossAmount;
    private double taxableGrossAmount;
    private double deferredAmount;

    public CalculatedTaxAmounts(TaxCodeResp taxCode, double taxAmount, double grossAmount, double taxableGrossAmount, double deferredAmount) {
        this.taxCode = taxCode;
        this.taxAmount = taxAmount;
        this.grossAmount = grossAmount;
        this.taxableGrossAmount = taxableGrossAmount;
        this.deferredAmount = deferredAmount;
    }

    public CalculatedTaxAmounts() {
        this.taxCode = new TaxCodeResp();
        this.taxAmount = 0;
        this.grossAmount = 0;
        this.taxableGrossAmount = 0;
        this.deferredAmount = 0;
    }

    public TaxCodeResp getTaxCode() {
        return taxCode;
    }

    public void setTaxCode(TaxCodeResp taxCode) {
        this.taxCode = taxCode;
    }

    public double getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(double taxAmount) {
        this.taxAmount = taxAmount;
    }

    public double getGrossAmount() {
        return grossAmount;
    }

    public void setGrossAmount(double grossAmount) {
        this.grossAmount = grossAmount;
    }

    public double getTaxableGrossAmount() {
        return taxableGrossAmount;
    }

    public void setTaxableGrossAmount(double taxableGrossAmount) {
        this.taxableGrossAmount = taxableGrossAmount;
    }

    public double getDeferredAmount() {
        return deferredAmount;
    }

    public void setDeferredAmount(double deferredAmount) {
        this.deferredAmount = deferredAmount;
    }
}
