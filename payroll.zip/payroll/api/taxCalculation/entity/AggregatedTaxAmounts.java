
package payroll.api.taxCalculation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import utils2.tableData.Row;

public class AggregatedTaxAmounts {
    /**
     * {
     * "YearToDate": {
     * "CalculatedTaxAmount": 25.26,
     * "TaxableGrossAmount": 1500,
     * "DeferredAmount": 0
     * },
     * "QuarterToDate": {
     * "CalculatedTaxAmount": 25.26,
     * "TaxableGrossAmount": 1500,
     * "DeferredAmount": 0
     * },
     * "MonthToDate": {
     * "CalculatedTaxAmount": 25.26,
     * "TaxableGrossAmount": 1500,
     * "DeferredAmount": 0
     * }
     * }
     */

    @JsonIgnore
    private String employeeId;
    @JsonIgnore
    private int employeeNum;
    @JsonIgnore
    private String taxCodeDescription;
    @JsonIgnore
    private String taxAggregatedType;

    private YearToDate yearToDate;
    private QuarterToDate quarterToDate;
    private MonthToDate monthToDate;

    public AggregatedTaxAmounts(YearToDate yearToDate,
                                QuarterToDate quarterToDate,
                                MonthToDate monthToDate) {
        this.yearToDate = yearToDate;
        this.quarterToDate = quarterToDate;
        this.monthToDate = monthToDate;
    }

    public AggregatedTaxAmounts() {
        this.yearToDate = new YearToDate();
        this.quarterToDate = new QuarterToDate();
        this.monthToDate = new MonthToDate();
    }

    public AggregatedTaxAmounts(Row row) {
        this.employeeId = row.get("EmployeeId");
        this.employeeNum = Integer.parseInt(row.get("EmployeeNum"));
        this.taxCodeDescription = row.get("TaxCode");
        this.taxAggregatedType = row.get("AggregatedType");
        this.yearToDate = new YearToDate(tryParseDouble(row,"CalculatedTaxAmount"), tryParseDouble(row,"TaxableGrossAmount"), tryParseDouble(row,"DeferredAmount"));
        this.quarterToDate = new QuarterToDate(tryParseDouble(row,"CalculatedTaxAmount"), tryParseDouble(row,"TaxableGrossAmount"), tryParseDouble(row,"DeferredAmount"));
        this.monthToDate = new MonthToDate(tryParseDouble(row,"CalculatedTaxAmount"), tryParseDouble(row, "TaxableGrossAmount"), tryParseDouble(row,"DeferredAmount"));
    }

    private Double tryParseDouble(Row row, String value) {
        String contentValue = row.get(value);
        return Double.parseDouble(contentValue.replace(",", "."));
    }

    public YearToDate getYearToDate() {
        return yearToDate;
    }

    public void setYearToDate(YearToDate yearToDate) {
        this.yearToDate = yearToDate;
    }

    public QuarterToDate getQuarterToDate() {
        return quarterToDate;
    }

    public void setQuarterToDate(QuarterToDate quarterToDate) {
        this.quarterToDate = quarterToDate;
    }

    public MonthToDate getMonthToDate() {
        return monthToDate;
    }

    public void setMonthToDate(MonthToDate monthToDate) {
        this.monthToDate = monthToDate;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public int getEmployeeNum() {
        return employeeNum;
    }

    public String getTaxCodeDescription() {
        return taxCodeDescription;
    }

    public String getAggregatedType() {  return taxAggregatedType;
    }
}