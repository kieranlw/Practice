
package payroll.api.taxCalculation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import utils2.tableData.Row;

@Data

public class StateTaxInfo {
    @JsonIgnore
    private String employeeId;
    @JsonIgnore
    private int employeeNum;
    private int w4type;

    public StateTaxInfo(Row row) {
        this.employeeId = row.get("EmployeeId");
        this.employeeNum = Integer.parseInt(row.get("EmployeeNum"));
        this.w4type = Integer.parseInt(row.get("W4Type"));
    }

    public String getEmployeeId () {return employeeId;}
}
