
package payroll.api.taxCalculation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import utils2.tableData.Row;
@Data
public class PayData {
    /**
     {
     "PayPeriodsPerYear": 24,
     "CurrentPeriodNumber": 2,
     "PayDate": "2021-01-31T00:00:00",
     "IsSupplemental": false,
     "PayPeriodType": 1
     }
     */

    @JsonIgnore
    private String employeeId;
    @JsonIgnore
    private int employeeNum;

    private int payPeriodsPerYear;
    private int currentPeriodNumber;
    private String payDate;
    private boolean isSupplemental;
    private String payPeriodType;

    public PayData(int payPeriodsPerYear,
                   int currentPeriodNumber,
                   String payDate,
                   boolean isSupplemental,
                   String payPeriodType) {
        this.payPeriodsPerYear = payPeriodsPerYear;
        this.currentPeriodNumber = currentPeriodNumber;
        this.payDate = payDate;
        this.isSupplemental = isSupplemental;
        this.payPeriodType = payPeriodType;
    }

    public PayData() {
        this.payPeriodsPerYear = 24;
        this.currentPeriodNumber = 2;
        this.payDate = "2021-02-15T00:00:00";
        this.isSupplemental = false;
        this.payPeriodType = "1";
    }

    public PayData(Row row) {
        this.employeeId = row.get("EmployeeId");
        this.employeeNum = Integer.parseInt(row.get("EmployeeNum"));
        this.payPeriodsPerYear = Integer.parseInt(row.get("PaysPeriodsPerYear"));
        this.currentPeriodNumber = Integer.parseInt(row.get("CurrentPeriodNumber"));
        this.payDate = row.get("PayDate");
        this.isSupplemental = Boolean.parseBoolean(row.get("IsSupplemental"));
        this.payPeriodType = row.get("PayPeriodType");
    }

    public boolean getIsSupplemental() {
        return isSupplemental;
    }

    public String getEmployeeId () {return employeeId;}
    public void setPayDate(String payDate){this.payDate=payDate;}
    public void setPayPeriodsPerYear(int payPeriodsPerYear){this.payPeriodsPerYear=payPeriodsPerYear;}
    public void setCurrentPeriodNumber(int currentPeriodNumber){this.payPeriodsPerYear=currentPeriodNumber;}
    public void setPayPeriodType(String payPeriodType){this.payPeriodType=payPeriodType;}
}