
package payroll.api.taxCalculation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import utils2.tableData.Row;
@Data

public class EmpTaxInfo {
    /**
     * {
     * "TaxCode": {
     * "MajorLocation": 54,
     * "TaxType": 1,
     * "MinorLocation": null
     * },
     * "FileStatus": "S",
     * "NumberOfDependents": 0,
     * "AdditionalNumberOfDependents": 0,
     * "IsExempt": false,
     * "IsBlocked": false,
     * "AdditionalPercent": 8,
     * "AdditionalAmount": null,
     * "AggregatedTaxAmounts": {
     * "YearToDate": {
     * "CalculatedTaxAmount": 25.26,
     * "TaxableGrossAmount": 1500,
     * "DeferredAmount": 0
     * },
     * "QuarterToDate": {
     * "CalculatedTaxAmount": 25.26,
     * "TaxableGrossAmount": 1500,
     * "DeferredAmount": 0
     * },
     * "MonthToDate": {
     * "CalculatedTaxAmount": 25.26,
     * "TaxableGrossAmount": 1500,
     * "DeferredAmount": 0
     * }
     * },
     * "FederalTaxInfo": {
     * "W4Type": 2,
     * "AdditionalDeductions": 500,
     * "DependentsClaimAmount": 1200,
     * "OtherIncome": 2500,
     * "HasSimilarPayingJobs": false,
     * "RateScheduleType": 2,
     * "ExemptReasonId": null,
     * "IsNonResidentAlien": false
     * },
     * "StateTaxData": null
     * }
     */

    @JsonIgnore
    private String employeeId;
    @JsonIgnore
    private int employeeNum;
    @JsonIgnore
    private String taxCodeDescription;
    @JsonIgnore
    private String taxTypeDescription;

    private TaxCode taxCode;
    private String fileStatus;
    private int numberOfDependents;
    private int additionalNumberOfDependents;
    private boolean isExempt;
    private boolean isBlocked;
    private double additionalPercent;
    private double additionalAmount;
    private AggregatedTaxAmounts aggregatedTaxAmounts;
    private FederalTaxInfo federalTaxInfo;
    private StateTaxInfo stateTaxInfo;

    public EmpTaxInfo(TaxCode taxCode,
                      String fileStatus,
                      int numberOfDependents,
                      int additionalNumberOfDependents,
                      boolean isExempt,
                      boolean isBlocked,
                      double additionalPercent,
                      double additionalAmount,
                      AggregatedTaxAmounts aggregatedTaxAmounts,
                      FederalTaxInfo federalTaxInfo,
                      StateTaxInfo stateTaxInfo) {
        this.taxCode = taxCode;
        this.fileStatus = fileStatus;
        this.numberOfDependents = numberOfDependents;
        this.additionalNumberOfDependents = additionalNumberOfDependents;
        this.isExempt = isExempt;
        this.isBlocked = isBlocked;
        this.additionalPercent = additionalPercent;
        this.additionalAmount = additionalAmount;
        this.aggregatedTaxAmounts = aggregatedTaxAmounts;
        this.federalTaxInfo = federalTaxInfo;
        this.stateTaxInfo = stateTaxInfo;
    }

    public EmpTaxInfo() {
        this.taxCode = new TaxCode();
        this.fileStatus = "S";
        this.numberOfDependents = 0;
        this.additionalNumberOfDependents = 0;
        this.isExempt = false;
        this.isBlocked = false;
        this.additionalPercent = 8;
        this.additionalAmount = 2;
        this.aggregatedTaxAmounts = new AggregatedTaxAmounts();
        this.federalTaxInfo = new FederalTaxInfo();
    }

    public EmpTaxInfo(Row row) {
        this.employeeId = row.get("EmployeeId");
        this.employeeNum = Integer.parseInt(row.get("EmployeeNum"));
        this.taxCodeDescription = row.get("TaxCode");
        this.taxCode = new TaxCode(row.get("MajorLocation"), Integer.parseInt(row.get("tax_type")), row.getNullable("MinorLocation"));
        this.fileStatus = row.getNullable("FileStatus");
        this.numberOfDependents = Integer.parseInt(row.get("NumberOfDependents"));
        this.additionalNumberOfDependents = Integer.parseInt(row.get("AdditionalNumberOfDependents"));
        this.isExempt = Boolean.parseBoolean(row.get("isExempt"));
        this.isBlocked = Boolean.parseBoolean(row.get("isBlocked"));
        this.additionalPercent = Double.parseDouble(row.get("AdditionalPercent"));
        this.additionalAmount = Double.parseDouble(row.get("AdditionalAmount"));
        this.taxTypeDescription = row.get("tax_typeDesc");
    }

    public boolean getIsExempt() {
        return isExempt;
    }

    public boolean getIsBlocked() {
        return isBlocked;
    }

    public String getEmployeeId () {return employeeId;}

    public String getTaxTypeDescription () { return taxTypeDescription;}

    public String getTaxCodeDescription () {return taxCodeDescription;}

    public void setFederalTaxInfo (FederalTaxInfo federalTaxDataOfEmployee) {this.federalTaxInfo=federalTaxDataOfEmployee;}

    public void setStateTaxInfo (StateTaxInfo stateTaxDataOfEmployee) {this.stateTaxInfo = stateTaxDataOfEmployee;}

    public void setAggregatedTaxAmounts (AggregatedTaxAmounts aggregatedTaxAmountsOfEmployee) { this.aggregatedTaxAmounts =aggregatedTaxAmountsOfEmployee;}

    public TaxCode getTaxCode () {
        return taxCode;
    }

    public void setTaxCode (TaxCode taxCode) {
        this.taxCode = taxCode;
    }
}
