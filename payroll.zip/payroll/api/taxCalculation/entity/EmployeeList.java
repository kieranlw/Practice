package payroll.api.taxCalculation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import utils2.tableData.Row;

@Data
public class EmployeeList {

    @JsonIgnore
    private String employeeNumber;
    private String employeeFirstName;
    private String employeeLastName;
    private String employeeName;
    private String employeeTips;
    private String employeeHours;
    private String employeeSickHours;
    private String employeeOTHours;
    private String employeeBonusHours;
    private String employeeCheckNumber;
    private String employeeCommissionHours;
    private String employeePieceRateHours;


    public EmployeeList(String employeeNumber,
                        String employeeFirstName,
                        String employeeLastName,
                        String employeeName,
                        String employeeTips,
                        String employeeHours,
                        String employeeSickHours,
                        String employeeOTHours,
                        String employeeBonusHours,
                        String employeeCheckNumber,
                        String employeeCommissionHours,
                        String employeePieceRateHours) {
        this.employeeNumber = employeeNumber;
        this.employeeFirstName = employeeFirstName;
        this.employeeLastName = employeeLastName;
        this.employeeName = employeeName;
        this.employeeTips = employeeTips;
        this.employeeHours = employeeHours;
        this.employeeOTHours = employeeOTHours;
        this.employeeSickHours = employeeSickHours;
        this.employeeOTHours = employeeOTHours;
        this.employeeBonusHours = employeeBonusHours;
        this.employeeCheckNumber = employeeCheckNumber;
        this.employeeCommissionHours = employeeCommissionHours;
        this.employeePieceRateHours = employeePieceRateHours;
    }

    public EmployeeList(Row row) {
        this.employeeNumber = row.get("Employee Number");
        this.employeeFirstName = row.get("First Name");
        this.employeeLastName = row.get("Last Name");
        this.employeeName = row.get("Employee Name");
        this.employeeTips = row.get("Tips");
        this.employeeHours = row.get("Regular Hours");
        this.employeeSickHours = row.get("Sick Leave Hours");
        this.employeeOTHours = row.get("OT Hours");
        this.employeeBonusHours = row.get("Bonus - % Other Pay Hours");
        this.employeeCheckNumber = row.get("Employee Check Number");
        this.employeeCommissionHours = row.get("Commission-% Other Pay Hours");
        this.employeePieceRateHours = row.get("Piece Rate Other Pay Hours");

    }

    public String getEmployeeNumber () {return employeeNumber;}
    public String getEmployeeFirstName () {return employeeFirstName;}
    public String getEmployeeLastName () {return employeeLastName;}
    public String getEmployeeName () {return employeeName;}
    public String getEmployeeTips () {return employeeTips;}
    public String getEmployeeHours () {return employeeHours;}
    public String getEmployeeSickHours () {return employeeSickHours;}
    public String getEmployeeOTHours () {return employeeOTHours;}
    public String getEmployeeBonusHours () {return employeeBonusHours;}
    public String getEmployeeCheckNumber () {return employeeCheckNumber;}
    public String getEmployeeCommissionHours () {return employeeCommissionHours;}
    public String getEmployeePieceRateHours () {return employeePieceRateHours;}
}