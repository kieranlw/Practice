
package payroll.api.taxCalculation.entity;

import lombok.Data;

import java.util.Collections;
import java.util.List;

import static rp.com.google.common.collect.ImmutableList.of;
@Data
public class CalculatedTaxInfo {

    private List<CalculatedTaxAmounts> calculatedTaxAmounts;
    private String employeeId;

    public CalculatedTaxInfo (List<CalculatedTaxAmounts> calculatedTaxAmounts, String employeeId) {
        this.calculatedTaxAmounts = calculatedTaxAmounts;
        this.employeeId = employeeId;
    }

    public CalculatedTaxInfo () {
        this.calculatedTaxAmounts = of (new CalculatedTaxAmounts ());
        this.employeeId = "employeeId";
    }

    public String getEmployeeId () {return employeeId;}

    public List<CalculatedTaxAmounts> getCalculatedTaxAmounts () {
        return this.calculatedTaxAmounts;
    }
}