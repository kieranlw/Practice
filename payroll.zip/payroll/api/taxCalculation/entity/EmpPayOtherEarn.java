
package payroll.api.taxCalculation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import utils2.tableData.Row;

@Data

public class EmpPayOtherEarn {
    @JsonIgnore
    private String employeeId;
    @JsonIgnore
    private int employeeNum;
    private String taxLocationId;
    private double hours;
    private double amount;
    private boolean isExemptFicam;
    private boolean isExemptFicas;
    private boolean isExemptFit;
    private boolean isExemptSit;
    private boolean isExemptFuta;
    private boolean isExemptSuta;
    private boolean doNotWithholdFit;
    private boolean doNotWithholdSit;
    private boolean doNotWithholdLocal;
    private boolean isGroupTermOver50k;
    private boolean isTaxabilityOverridden;
    private String  otherEarnClass;

    public EmpPayOtherEarn () {
        this.taxLocationId= taxLocationId;
        this.hours= hours;
        this.amount= amount;
        this.isExemptFicam= isExemptFicam;
        this.isExemptFicas= isExemptFicas;
        this.isExemptFit= isExemptFit;
        this.isExemptSit=isExemptSit;
        this.isExemptFuta=isExemptFuta;
        this.isExemptSuta=isExemptSuta;
        this.doNotWithholdFit= doNotWithholdFit;
        this.doNotWithholdSit= doNotWithholdSit;
        this.doNotWithholdLocal= doNotWithholdLocal;
        this.isGroupTermOver50k= isGroupTermOver50k;
        this.isTaxabilityOverridden= isTaxabilityOverridden;
        this.otherEarnClass= otherEarnClass;
    }

    public EmpPayOtherEarn (Row row) {
        this.employeeId = row.get("EmployeeId");
        this.employeeNum = Integer.parseInt(row.get("EmployeeNum"));
        this.taxLocationId = row.get("TaxLocationId");;
        this.hours = tryParseDouble(row,"Hours");
        this.amount = tryParseDouble(row,"Amount");
        this.isExemptFicam = Boolean.parseBoolean(row.get("IsExemptFicam"));
        this.isExemptFicas = Boolean.parseBoolean(row.get("IsExemptFicas"));
        this.isExemptFit = Boolean.parseBoolean(row.get("IsExemptFit"));
        this.isExemptSit = Boolean.parseBoolean(row.get("IsExemptSit"));
        this.isExemptFuta = Boolean.parseBoolean(row.get("IsExemptFuta"));
        this.isExemptSuta = Boolean.parseBoolean(row.get("IsExemptSuta"));
        this.doNotWithholdFit = Boolean.parseBoolean(row.get("DoNotWithholdFit"));
        this.doNotWithholdSit = Boolean.parseBoolean(row.get("DoNotWithholdSit"));
        this.doNotWithholdLocal = Boolean.parseBoolean(row.get("DoNotWithholdLocal"));
        this.isGroupTermOver50k = Boolean.parseBoolean(row.get("IsGroupTermOver50k"));
        this.isTaxabilityOverridden= Boolean.parseBoolean(row.get("IsTaxabilityOverridden"));
        this.otherEarnClass= row.getNullable("OtherEarnClass");
    }

    private EmpPayOtherEarn(Builder builder) {
        taxLocationId=builder.taxLocationId;
        hours= builder.hours;
        amount= builder.amount;
        isExemptFicam= builder.isExemptFicam;
        isExemptFicas= builder.isExemptFicas;
        isExemptFit= builder.isExemptFit;
        isExemptSit=builder.isExemptSit;
        isExemptFuta=builder.isExemptFuta;
        isExemptSuta=builder.isExemptSuta;
        doNotWithholdFit= builder.doNotWithholdFit;
        doNotWithholdSit= builder.doNotWithholdSit;
        doNotWithholdLocal= builder.doNotWithholdLocal;
        isGroupTermOver50k= builder.isGroupTermOver50k;
        isTaxabilityOverridden= builder.isTaxabilityOverridden;
        otherEarnClass= builder.otherEarnClass;

    }
    public EmpPayOtherEarn(String taxLocationId, double hours, double amount, boolean isExemptFicam,
                           boolean isExemptFicas, boolean isExemptFit, boolean isExemptSit, boolean isExemptFuta,
                           boolean isExemptSuta, boolean doNotWithholdFit, boolean doNotWithholdSit, boolean doNotWithholdLocal,
                           boolean isGroupTermOver50k, boolean isTaxabilityOverridden, String  otherEarnClass) {
        this.taxLocationId=taxLocationId;
        this.hours= hours;
        this.amount= amount;
        this.isExemptFicam= isExemptFicam;
        this.isExemptFicas= isExemptFicas;
        this.isExemptFit= isExemptFit;
        this.isExemptSit=isExemptSit;
        this.isExemptFuta=isExemptFuta;
        this.isExemptSuta=isExemptSuta;
        this.doNotWithholdFit= doNotWithholdFit;
        this.doNotWithholdSit= doNotWithholdSit;
        this.doNotWithholdLocal= doNotWithholdLocal;
        this.isGroupTermOver50k= isGroupTermOver50k;
        this.isTaxabilityOverridden= isTaxabilityOverridden;
        this.otherEarnClass= otherEarnClass;
    }

    private Double tryParseDouble(Row row, String value) {
        String contentValue = row.get(value);
        return Double.parseDouble(contentValue.replace(",", "."));
    }
    public String getEmployeeId () {return employeeId;}
    public double getHours() {return hours;}
    public double getAmount() {return amount;}
    public boolean getIsExemptFicam() {return isExemptFicam;}
    public boolean getIsExemptFicas() {return isExemptFicas;}
    public boolean getIsExemptFit() {return isExemptFit;}
    public boolean getIsExemptSit() {return isExemptSit;}
    public boolean getIsExemptFuta() {return isExemptFuta;}
    public boolean getIsExemptSuta() {return isExemptSuta;}
    public boolean getDoNotWithholdFit() {return doNotWithholdFit;}
    public boolean getDoNotWithholdSit() {return doNotWithholdSit;}
    public boolean getDoNotWithholdLocal() {return doNotWithholdLocal;}
    public boolean getIsTaxabilityOverridden() {return isTaxabilityOverridden;}
    public boolean getIsGroupTermOver50k() {return isGroupTermOver50k;}
    public String getOtherEarnClass() {return otherEarnClass;}
    public String getTaxLocationId() {return taxLocationId;}
    public void setAmount(double amount){this.amount=amount;}
    public void setTaxLocationId(String taxLocationId){this.taxLocationId = taxLocationId;}

    public static EmpPayOtherEarn.Builder builder() {
        return new EmpPayOtherEarn.Builder();
    }

    public static class Builder {
        private String taxLocationId;
        private double hours;
        private double amount;
        private boolean isExemptFicam;
        private boolean isExemptFicas;
        private boolean isExemptFit;
        private boolean isExemptSit;
        private boolean isExemptFuta;
        private boolean isExemptSuta;
        private boolean doNotWithholdFit;
        private boolean doNotWithholdSit;
        private boolean doNotWithholdLocal;
        private boolean isGroupTermOver50k;
        private boolean isTaxabilityOverridden;
        private String  otherEarnClass;

        public Builder SetTaxLocationId(String taxLocationId) {
            this.taxLocationId = taxLocationId;
            return this;
        }

        public Builder setAmount(double amount) {
            this.amount = amount;
            return this;
        }

        public Builder setHours(double hours) {
            this.hours = hours;
            return this;
        }
        public Builder SetIsExemptFicam(Boolean isExemptFicam) {
            this.isExemptFicam = isExemptFicam;
            return this;
        }
        public Builder SetIsExemptFicas(Boolean isExemptFicas) {
            this.isExemptFicas = isExemptFicas;
            return this;
        }

        public Builder SetIsExemptFit(Boolean isExemptFit) {
            this.isExemptFit = isExemptFit;
            return this;
        }

        public Builder SetIsExemptSit(Boolean isExemptSit) {
            this.isExemptSit = isExemptSit;
            return this;
        }

        public Builder SetIsExemptFuta(Boolean isExemptFuta) {
            this.isExemptFuta = isExemptFuta;
            return this;
        }

        public Builder SetIsExemptSuta(Boolean isExemptSuta) {
            this.isExemptSuta = isExemptSuta;
            return this;
        }

        public Builder SetDoNotWithholdFit(Boolean doNotWithholdFit) {
            this.doNotWithholdFit = doNotWithholdFit;
            return this;
        }

        public Builder SetDoNotWithholdSit(Boolean doNotWithholdSit) {
            this.doNotWithholdSit = doNotWithholdSit;
            return this;
        }

        public Builder SetDoNotWithholdLocal(Boolean doNotWithholdLocal) {
            this.doNotWithholdLocal = doNotWithholdLocal;
            return this;
        }

        public Builder SetIsGroupTermOver50k(Boolean isGroupTermOver50k) {
            this.isGroupTermOver50k = isGroupTermOver50k;
            return this;
        }

        public Builder SetIsTaxabilityOverridden(Boolean isTaxabilityOverridden) {
            this.isTaxabilityOverridden = isTaxabilityOverridden;
            return this;
        }

        public Builder SetOtherEarnClass(String otherEarnClass) {
            this.otherEarnClass = otherEarnClass;
            return this;
        }
        private Builder() {}
        public EmpPayOtherEarn build() {return new EmpPayOtherEarn(this);}

    }
}
