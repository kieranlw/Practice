
package payroll.api.taxCalculation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import utils2.tableData.Row;

public class FederalTaxInfo {
    /**
     * {
     * "W4Type": 2,
     * "AdditionalDeductions": 500,
     * "DependentsClaimAmount": 1200,
     * "OtherIncome": 2500,
     * "HasSimilarPayingJobs": false,
     * "RateScheduleType": 2,
     * "ExemptReasonId": null,
     * "IsNonResidentAlien": false
     * }
     */

    @JsonIgnore
    private String employeeId;
    @JsonIgnore
    private int employeeNum;
    private String w4Type;
    private double additionalDeductions;
    private double dependentsClaimAmount;
    private double otherIncome;
    private boolean hasSimilarPayingJobs;
    private String exemptReasonId;
    private boolean isNonResidentAlien;

    public FederalTaxInfo(String w4Type,
                          double additionalDeductions,
                          double dependentsClaimAmount,
                          double otherIncome,
                          boolean hasSimilarPayingJobs,
                          String exemptReasonId,
                          boolean isNonResidentAlien) {
        this.w4Type = w4Type;
        this.additionalDeductions = additionalDeductions;
        this.dependentsClaimAmount = dependentsClaimAmount;
        this.otherIncome = otherIncome;
        this.hasSimilarPayingJobs = hasSimilarPayingJobs;
        this.exemptReasonId = exemptReasonId;
        this.isNonResidentAlien = isNonResidentAlien;
    }

    public FederalTaxInfo() {
        this.w4Type = "2";
        this.additionalDeductions = 500;
        this.dependentsClaimAmount = 1200;
        this.otherIncome = 2500;
        this.hasSimilarPayingJobs = false;
        this.exemptReasonId = null;
        this.isNonResidentAlien = false;
    }

    public FederalTaxInfo(Row row) {
        this.employeeId = row.get("EmployeeId");
        this.employeeNum = Integer.parseInt(row.get("EmployeeNum"));
        this.w4Type = row.get("W4Type");
        this.additionalDeductions = tryParseDouble(row,"AdditionalDeductions");
        this.dependentsClaimAmount = tryParseDouble(row,"DependentsClaimAmount");
        this.otherIncome = tryParseDouble(row,"OtherIncome");
        this.hasSimilarPayingJobs = Boolean.parseBoolean(row.get("HasSimilarPayingJobs"));
        this.exemptReasonId = row.getNullable("ExemptReasonId");
        this.isNonResidentAlien = Boolean.parseBoolean(row.get("IsNonResidentAlien"));
    }

    private Double tryParseDouble(Row row, String value) {
        String contentValue = row.get(value);
        return Double.parseDouble(contentValue.replace(",", "."));
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public int getEmployeeNum() {
        return employeeNum;
    }

    public String getW4Type() {
        return w4Type;
    }

    public void setW4Type(String w4Type) {
        this.w4Type = w4Type;
    }

    public double getAdditionalDeductions() {
        return additionalDeductions;
    }

    public void setAdditionalDeductions(double additionalDeductions) { this.additionalDeductions = additionalDeductions; }

    public double getDependentsClaimAmount() {
        return dependentsClaimAmount;
    }

    public void setDependentsClaimAmount(double dependentsClaimAmount) { this.dependentsClaimAmount = dependentsClaimAmount; }

    public double getOtherIncome() {
        return otherIncome;
    }

    public void setOtherIncome(double otherIncome) {
        this.otherIncome = otherIncome;
    }

    public boolean getHasSimilarPayingJobs() {
        return hasSimilarPayingJobs;
    }

    public void setHasSimilarPayingJobs(boolean hasSimilarPayingJobs) { this.hasSimilarPayingJobs = hasSimilarPayingJobs; }

    public String getExemptReasonId() {
        return exemptReasonId;
    }

    public void setExemptReasonId(String exemptReasonId) {
        this.exemptReasonId = exemptReasonId;
    }

    public boolean getIsNonResidentAlien() {
        return isNonResidentAlien;
    }

    public void setIsNonResidentAlien(boolean isNonResidentAlien) { this.isNonResidentAlien = isNonResidentAlien; }
}