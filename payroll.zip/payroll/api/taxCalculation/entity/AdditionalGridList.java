package payroll.api.taxCalculation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import utils2.tableData.Row;

@Data
public class AdditionalGridList {
    

    private String gridCategory;
    private String gridValue;

    public AdditionalGridList(String gridCategory, String gridValue) {
        this.gridCategory = gridCategory;
        this.gridValue = gridValue;
    }

    public AdditionalGridList(Row row) {
        this.gridCategory = row.get("GridCategory");
        this.gridValue = row.get("GridValue");
    }

    public String getGridCategory () {return gridCategory;}
    public String getGridValue () {return gridValue;}
}
