
package payroll.api.taxCalculation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import utils2.tableData.Row;
@Data
public class EmployeeData {
    /**
     * {
     * "EmployeeId": "8cb6501c-b027-422a-9680-2c7a795ade6c",
     * "Tips": 0,
     * "Is943": false,
     * "IsFFCRAEligible": false,
     * "IsDualState": false
     * }
     */

    @JsonIgnore
    private String employeeNumber;
    private String employeeId;
    private double tips;
    private boolean is943;
    private boolean isFFCRAEligible;
    private boolean isDualState;

    public EmployeeData(String employeeId,
                        String employeeNumber,
                        double tips,
                        boolean is943,
                        boolean isFFCRAEligible,
                        boolean isDualState) {
        this.employeeId = employeeId;
        this.tips = tips;
        this.is943 = is943;
        this.isFFCRAEligible = isFFCRAEligible;
        this.isDualState = isDualState;
    }

    public EmployeeData() {
        this("092435FD-AFDE-F4E9-F689-39FA761B0999","1924", 0, false, false, false);
    }

    public EmployeeData(Row row) {
        this.employeeId = row.get("EmployeeId");
        this.employeeNumber = row.get("EmployeeNum");
        this.tips = Double.parseDouble(row.get("Tips"));
        this.is943 = Boolean.parseBoolean(row.get("Is943"));
        this.isFFCRAEligible = Boolean.parseBoolean(row.get("IsFFCRAEligible"));
        this.isDualState = Boolean.parseBoolean(row.get("IsDualState"));
    }

    public boolean getIs943() {
        return is943;
    }

    public boolean getIsFFCRAEligible() {
        return isFFCRAEligible;
    }

    public boolean getIsDualState() {
        return isDualState;
    }

    public String getEmployeeId () {return employeeId;}

    public void setEmployeeId(String employeeId){this.employeeId=employeeId;}

    public String getEmployeeNumber () {return employeeNumber;}
}