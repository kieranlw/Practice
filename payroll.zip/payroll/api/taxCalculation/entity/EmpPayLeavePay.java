
package payroll.api.taxCalculation.entity;

public class EmpPayLeavePay {
    /**
     {
     "TaxLocationId": "28c9b80d-1007-4318-86f7-886f8d89e58b",
     "Amount": 500,
     "Hours": 8,
     "IsExemptEmployerFicas": false
     }
     */

    private String taxLocationId;
    private double hours;
    private double amount;
    private boolean isExemptEmployerFicas;

    public EmpPayLeavePay(String taxLocationId,
                          int amount,
                          int hours,
                          boolean isExemptEmployerFicas) {
        this.taxLocationId = taxLocationId;
        this.amount = amount;
        this.hours = hours;
        this.isExemptEmployerFicas = isExemptEmployerFicas;
    }

    public EmpPayLeavePay() {
        this("28c9b80d-1007-4318-86f7-886f8d89e58b",500,8,false);
    }

    public String getTaxLocationId() {
        return taxLocationId;
    }
    public void setTaxLocationId(String taxLocationId) {
        this.taxLocationId = taxLocationId;
    }
    public double getAmount() {
        return amount;
    }
    public void setAmount(int amount) {
        this.amount = amount;
    }
    public double getHours() {
        return hours;
    }
    public void setHours(int hours) {
        this.hours = hours;
    }
    public boolean getIsExemptEmployerFicaS() {
        return isExemptEmployerFicas;
    }
    public void setIsExemptEmployerFicaS(boolean overtimeHours) {
        this.isExemptEmployerFicas = isExemptEmployerFicas;
    }
}