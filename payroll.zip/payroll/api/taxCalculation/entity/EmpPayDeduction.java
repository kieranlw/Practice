
package payroll.api.taxCalculation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import utils2.tableData.Row;

@Data
public class EmpPayDeduction {
    @JsonIgnore
    private String employeeId;
    @JsonIgnore
    private int employeeNum;
    private double amount;
    private int adjustmentClass;

    public double getAmount() {
        return amount;
    }

    public int getAdjustmentClass() {
        return adjustmentClass;
    }

    private EmpPayDeduction(Builder builder) {
        amount = builder.amount;
        adjustmentClass = builder.adjustmentClass;

    }

    public EmpPayDeduction(double amount,
                            int adjustmentClass) {
        this.amount = amount;
        this.adjustmentClass = adjustmentClass;
    }
    public EmpPayDeduction() {
        this(225, 1);
    }

    public EmpPayDeduction(Row row) {
        this.employeeId = row.get("EmployeeId");
        this.employeeNum = Integer.parseInt(row.get("EmployeeNum"));
        this.amount = Double.parseDouble(row.get("Amount"));
        this.adjustmentClass = Integer.parseInt(row.get("AdjustmentClass"));;
    }

   // public double amount () {return amount;}
   // public int adjustmentClass () {return adjustmentClass;}
    public String getEmployeeId () {return employeeId;}
    public void setAmount(double amount){this.amount=amount;}
    public void setAdjustmentClass(int adjustmentClass){this.adjustmentClass = adjustmentClass;}


    public static EmpPayDeduction.Builder builder() {
        return new EmpPayDeduction.Builder();
    }


    public static class Builder {
        private double amount;
        private int adjustmentClass;

        public Builder setAmount(double amount) {
            this.amount = amount;
            return this;
        }

        public Builder setAdjustmentClass(int adjustmentClass) {
            this.adjustmentClass = adjustmentClass;
            return this;
        }

        private Builder() {
        }

        public EmpPayDeduction build() {
            return new EmpPayDeduction(this);
        }

    }

}

