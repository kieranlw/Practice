package payroll.api.taxCalculation.dataDriven;

import utils2.tableData.Row;

public class LocationType {
    private String state;
    private String zip;
    private Integer locationType;
    private String payDate;
    private String expectedLocationVerificationType;

    public LocationType(String state, String zip, Integer locationType, String payDate, String expectedLocationVerificationType) {
        this.state = state;
        this.zip = zip;
        this.locationType = locationType;
        this.payDate = payDate;
        this.expectedLocationVerificationType = expectedLocationVerificationType;
    }

    public LocationType(Row row) {
        this.state = row.get("State");
        this.zip = row.get("Zip");
        this.locationType = Integer.parseInt(row.get("LocationType"));
        this.payDate = row.get("PayDate");
        this.expectedLocationVerificationType = row.get("ExpectedLocationVerificationType");
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public Integer getLocationType() {
        return locationType;
    }

    public void setLocationType(Integer locationType) {
        this.locationType = locationType;
    }

    public String getPayDate() {
        return payDate;
    }

    public void setPayDate(String payDate) {
        this.payDate = payDate;
    }

    public String getExpectedLocationVerificationType() {
        return expectedLocationVerificationType;
    }

    public void setExpectedLocationVerificationType(String expectedLocationVerificationType) {
        this.expectedLocationVerificationType = expectedLocationVerificationType;
    }

    @Override
    public String toString() {
        return "LocationType{" +
                "state='" + state + '\'' +
                ", zip='" + zip + '\'' +
                ", locationType='" + locationType + '\'' +
                ", payDate='" + payDate + '\'' +
                ", ExpectedLocationVerificationType='" + expectedLocationVerificationType + '\'' +
                '}';
    }
}
