package payroll.api.taxCalculation.dataDriven;

public class TaxCalcPayloadCsvBuilderObj {
    private final String employeeFile;
    private final String payDataFile;
    private final String locationsFile;
    private final String empTaxFile;
    private final String aggregatesTaxAmountsFile;
    private final String federalTaxDataFile;
    private final String companyTaxRatesFile;
    private final String empPayDetailsFile;
    private final String empPayDeductionsFile;
    private final String empPayOtherEarnsFile;
    private final String stateTaxFile;

    public TaxCalcPayloadCsvBuilderObj (String employeeFile,
                                        String payDataFile,
                                        String locationsFile,
                                        String empTaxFile,
                                        String aggregatesTaxAmountsFile,
                                        String federalTaxDataFile,
                                        String companyTaxRatesFile,
                                        String empPayDetailsFile,
                                        String empPayDeductionsFile,
                                        String empPayOtherEarnsFile,
                                        String stateTaxFile) {
        this.employeeFile = employeeFile;
        this.payDataFile = payDataFile;
        this.locationsFile = locationsFile;
        this.empTaxFile = empTaxFile;
        this.aggregatesTaxAmountsFile = aggregatesTaxAmountsFile;
        this.federalTaxDataFile = federalTaxDataFile;
        this.companyTaxRatesFile = companyTaxRatesFile;
        this.empPayDetailsFile = empPayDetailsFile;
        this.empPayDeductionsFile = empPayDeductionsFile;
        this.empPayOtherEarnsFile = empPayOtherEarnsFile;
        this.stateTaxFile = stateTaxFile;
    }

    public String getEmployeeFile() {
        return employeeFile;
    }

    public String getPayDataFile() {
        return payDataFile;
    }

    public String getLocationsFile() {
        return locationsFile;
    }

    public String getEmpTaxFile() {
        return empTaxFile;
    }

    public String getAggregatesTaxAmountsFile() {
        return aggregatesTaxAmountsFile;
    }

    public String getFederalTaxDataFile() {
        return federalTaxDataFile;
    }

    public String getCompanyTaxRatesFile() {
        return companyTaxRatesFile;
    }

    public String getEmpPayDetailsFile() {
        return empPayDetailsFile;
    }

    public String getEmpPayDeductionsFile() {
        return empPayDeductionsFile;
    }

    public String getEmpPayOtherEarnsFile() {
        return empPayOtherEarnsFile;
    }

    public String getStateTaxFile() {
        return stateTaxFile;
    }
}
