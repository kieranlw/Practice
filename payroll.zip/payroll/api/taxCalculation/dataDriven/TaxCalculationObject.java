package payroll.api.taxCalculation.dataDriven;

import utils2.tableData.Row;

public class TaxCalculationObject {
    private String amount;
    private String taxLocationId;
    private String regularRate;
    private String overtimeRate;
    private String regularHours;
    private String overtimeHours;

    public TaxCalculationObject(String amount, String taxLocationId, String regularRate, String overtimeRate, String regularHours, String overtimeHours) {
        this.amount = amount;
        this.taxLocationId = taxLocationId;
        this.regularRate = regularRate;
        this.overtimeRate = overtimeRate;
        this.regularHours = regularHours;
        this.overtimeHours = overtimeHours;
    }

    public TaxCalculationObject(Row row) {
        this.amount = row.get("Amount");
        this.taxLocationId = row.get("TaxLocationId");
        this.regularRate = row.get("RegularRate");
        this.overtimeRate = row.get("OvertimeRate");
        this.regularHours = row.get("RegularHours");
        this.overtimeHours = row.get("OvertimeHours");
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getTaxLocationId() {
        return taxLocationId;
    }

    public void setTaxLocationId(String taxLocationId) {
        this.taxLocationId = taxLocationId;
    }

    public String getRegularRate() {
        return regularRate;
    }

    public void setRegularRate(String regularRate) {
        this.regularRate = regularRate;
    }

    public String getOvertimeRate() {
        return overtimeRate;
    }

    public void setOvertimeRate(String overtimeRate) {
        this.overtimeRate = overtimeRate;
    }

    public String getRegularHours() {
        return regularHours;
    }

    public void setRegularHours(String regularHours) {
        this.regularHours = regularHours;
    }

    public String getOvertimeHours() {
        return overtimeHours;
    }

    public void setOvertimeHours(String overtimeHours) {
        this.overtimeHours = overtimeHours;
    }
}
