package payroll.api.taxCalculation.request_api;

import payroll.api.taxCalculation.entity.Location;

public class LocationPayload {
    /**
     {
     "Location":{
         "State": "Md",
         "Zip": "21057-1234",
         "LocationType": 1
     },
     {
     "PayDate": "2021-01-15T00:00:00"
     }
     **/

    private Location Location;
    private String PayDate;

    public LocationPayload(Location location,
                           String payDate) {
        this.Location = location;
        this.PayDate = payDate;
    }
    public LocationPayload(Location location) { this.Location = location; }
    public LocationPayload(String payDate) { this.PayDate = payDate; }
    public Location getLocation() {
        return Location;
    }
    public void setLocation(Location location) {
        this.Location = location;
    }
    public String getPayDate() {
        return PayDate;
    }
    public void setPayDate(String payDate) {
        this.PayDate = payDate;
    }
}
