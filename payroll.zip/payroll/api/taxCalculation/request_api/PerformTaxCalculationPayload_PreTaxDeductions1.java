package payroll.api.taxCalculation.request_api;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import payroll.api.taxCalculation.dataDriven.TaxCalcPayloadCsvBuilderObj;
import payroll.api.taxCalculation.entity.*;
import utils2.TableData2;

import java.util.List;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;
import static utils2.tableData.TableConverter.extractDataFromCsv;

@Data

public class PerformTaxCalculationPayload_PreTaxDeductions1 {

    private EmployeeData employeeData;
    private PayData payData;
    private List<TaxCalculationLocation> taxCalculationLocations;
    private List<EmpTaxInfo> empTaxInfo;
    private List<CompanyTaxInfo> companyTaxInfo;
    private List<EmpPayDetails> empPayDetails;
    private List<EmpPayDeduction> empPayDeductions;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<EmpPayLeavePay> empPayLeavePay;

    public PerformTaxCalculationPayload_PreTaxDeductions1 () {
        employeeData = new EmployeeData();
        payData = new PayData();
        taxCalculationLocations = Stream.of(new TaxCalculationLocation(), new TaxCalculationLocation("00000000-0000-0000-0000-000000000000", false, "Pa", "15008-1234", "1")).collect(toList());
        empTaxInfo = Stream.of(new EmpTaxInfo()).collect(toList());
        companyTaxInfo = Stream.of(new CompanyTaxInfo()).collect(toList());
        empPayDetails = Stream.of(new EmpPayDetails()).collect(toList());
        empPayDeductions = Stream.of(new EmpPayDeduction()).collect(toList());
        empPayLeavePay = Stream.of(new EmpPayLeavePay()).collect(toList());
    }

    public PerformTaxCalculationPayload_PreTaxDeductions1 (String employeeID, TaxCalcPayloadCsvBuilderObj taxCalcPayloadCsvBuilderObj) {
        employeeData = findEmployee(taxCalcPayloadCsvBuilderObj.getEmployeeFile(), employeeID);
        payData = findPayDataOfEmployee(taxCalcPayloadCsvBuilderObj.getPayDataFile(), employeeID);
        taxCalculationLocations = findLocationsOfEmployee(taxCalcPayloadCsvBuilderObj.getLocationsFile(), employeeID);
        empTaxInfo = findEmpTaxOfEmployee(taxCalcPayloadCsvBuilderObj.getEmpTaxFile(), taxCalcPayloadCsvBuilderObj.getAggregatesTaxAmountsFile(), taxCalcPayloadCsvBuilderObj.getFederalTaxDataFile(), taxCalcPayloadCsvBuilderObj.getStateTaxFile(), employeeID);
        companyTaxInfo = findCompanyTaxRatesOfEmployee(taxCalcPayloadCsvBuilderObj.getCompanyTaxRatesFile(), employeeID);
        empPayDetails = findEmpPayDetailsOfEmployee(taxCalcPayloadCsvBuilderObj.getEmpPayDetailsFile(), employeeID);
        empPayDeductions = findEmpPayDeductionsOfEmployee(taxCalcPayloadCsvBuilderObj.getEmpPayDeductionsFile (), employeeID);
    }

    private static EmployeeData findEmployee(String filePath, String employeeID) {
        return extractTaxCalcObjectsFromCsv(filePath, EmployeeData.class)
                .stream().filter(obj -> obj.getEmployeeId().equalsIgnoreCase(employeeID))
                .findFirst()
                .orElse(null);
    }

    private static List<TaxCalculationLocation> findLocationsOfEmployee(String filePath, String employeeID) {
        return extractTaxCalcObjectsFromCsv(filePath, TaxCalculationLocation.class)
                .stream()
                .filter(obj -> obj.getEmployeeId().equalsIgnoreCase(employeeID))
                .collect(toList());
    }

    private static PayData findPayDataOfEmployee(String filePath, String employeeID) {
        return extractTaxCalcObjectsFromCsv(filePath, PayData.class)
                .stream()
                .filter(obj -> obj.getEmployeeId().equalsIgnoreCase(employeeID))
                .findFirst()
                .orElse(null);
    }

    private static List<EmpTaxInfo> findEmpTaxOfEmployee(String filePath, String aggregatedTaxAmFilePath, String federalTaxDataFilePath, String stateTaxFilePath, String employeeID) {
        List<EmpTaxInfo> empTaxInfos = extractTaxCalcObjectsFromCsv(filePath, EmpTaxInfo.class)
                .stream()
                .filter(obj -> obj.getEmployeeId().equalsIgnoreCase(employeeID))
                .collect(toList());
        empTaxInfos
                .forEach(empTaxInfo -> {
                    empTaxInfo.setAggregatedTaxAmounts(findAggregatedTaxAmountsOfEmployee(aggregatedTaxAmFilePath, employeeID, empTaxInfo.getTaxCodeDescription()));
                    if (empTaxInfo.getTaxCode().isFITTaxType()) {
                        empTaxInfo.setFederalTaxInfo(findFederalTaxDataOfEmployee(federalTaxDataFilePath, employeeID));
                    }
                    if (empTaxInfo.getTaxCode().getMajorLocation().equals("UT") ||
                            empTaxInfo.getTaxCode().getMajorLocation().equals("NM") ||
                            empTaxInfo.getTaxCode().getMajorLocation().equals("ND") &&
                                    empTaxInfo.getTaxCode().getTaxType() == 1) {
                        empTaxInfo.setStateTaxInfo(findStateTaxDataOfEmployee(stateTaxFilePath, employeeID));
                    }
                }
        );
        return empTaxInfos;
    }

    private static AggregatedTaxAmounts findAggregatedTaxAmountsOfEmployee(String filePath, String employeeID, String taxCodeDescription) {
        AggregatedTaxAmounts aggregatedTaxAmounts=new AggregatedTaxAmounts ();
        aggregatedTaxAmounts.setMonthToDate (findMonthToDataByEmployee(filePath, employeeID, taxCodeDescription));
        aggregatedTaxAmounts.setQuarterToDate (findQuarterToDataByEmployee(filePath, employeeID, taxCodeDescription));
        aggregatedTaxAmounts.setYearToDate (findYearToDataByEmployee(filePath, employeeID, taxCodeDescription));
        return aggregatedTaxAmounts;
    }

    private static MonthToDate findMonthToDataByEmployee(String filePath, String employeeID, String taxCodeDescription) {
        return extractTaxCalcObjectsFromCsv(filePath, MonthToDate.class)
                .stream()
                .filter(obj ->
                        obj.getEmployeeId().equalsIgnoreCase(employeeID) && obj.getTaxCodeDescription().equalsIgnoreCase(taxCodeDescription)&& obj.getAggregatedType().equalsIgnoreCase("MTD"))
                .findFirst()
                .orElse(null);
    }

    private static QuarterToDate findQuarterToDataByEmployee(String filePath, String employeeID, String taxCodeDescription) {
        return extractTaxCalcObjectsFromCsv(filePath, QuarterToDate.class)
                .stream()
                .filter(obj ->
                        obj.getEmployeeId().equalsIgnoreCase(employeeID) && obj.getTaxCodeDescription().equalsIgnoreCase(taxCodeDescription)&& obj.getAggregatedType().equalsIgnoreCase("QTD"))
                .findFirst()
                .orElse(null);
    }

    private static YearToDate findYearToDataByEmployee(String filePath, String employeeID, String taxCodeDescription) {
        return extractTaxCalcObjectsFromCsv(filePath, YearToDate.class)
                .stream()
                .filter(obj ->
                        obj.getEmployeeId().equalsIgnoreCase(employeeID) && obj.getTaxCodeDescription().equalsIgnoreCase(taxCodeDescription)&& obj.getAggregatedType().equalsIgnoreCase("YTD"))
                .findFirst()
                .orElse(null);
    }

    private static FederalTaxInfo findFederalTaxDataOfEmployee(String filePath, String employeeID) {
        return extractTaxCalcObjectsFromCsv(filePath, FederalTaxInfo.class)
                .stream().filter(obj ->
                obj.getEmployeeId().equalsIgnoreCase(employeeID))
                .findFirst()
                .orElse(null);
    }

    private static List<CompanyTaxInfo> findCompanyTaxRatesOfEmployee(String filePath, String employeeID) {
        return extractTaxCalcObjectsFromCsv(filePath, CompanyTaxInfo.class)
                .stream()
                .filter(obj -> obj.getEmployeeId().equalsIgnoreCase(employeeID))
                .collect(toList());
    }

    private static List<EmpPayDetails> findEmpPayDetailsOfEmployee(String filePath, String employeeID) {
        return extractTaxCalcObjectsFromCsv(filePath, EmpPayDetails.class)
                .stream()
                .filter(obj -> obj.getEmployeeId().equalsIgnoreCase(employeeID))
                .collect(toList());
    }

    private static List<EmpPayDeduction> findEmpPayDeductionsOfEmployee(String filePath, String employeeID) {
        return extractTaxCalcObjectsFromCsv(filePath, EmpPayDeduction.class)
                .stream()
                .filter(obj -> obj.getEmployeeId().equalsIgnoreCase(employeeID))
                .collect(toList());
    }

    private static StateTaxInfo findStateTaxDataOfEmployee(String filePath, String employeeID) {
        return extractTaxCalcObjectsFromCsv(filePath, StateTaxInfo.class)
                .stream()
                .filter(obj -> obj.getEmployeeId().equalsIgnoreCase(employeeID))
                .findFirst()
                .orElse(null);
    }

    public static <T> List<T> extractTaxCalcObjectsFromCsv(String filePath, Class<T> cls) {
        TableData2 tableData2 = extractDataFromCsv(filePath, ";");
        tableData2.format().table.replaceValuesIgnoringCase("null", "");
        return tableData2.getDataAs(cls);
    }

    public List<EmpTaxInfo> getEmpTaxInfo () { return empTaxInfo;}
    public void setPayData(PayData payData){this.payData = payData;}
}
