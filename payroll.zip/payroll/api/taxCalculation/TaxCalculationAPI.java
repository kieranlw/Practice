package payroll.api.taxCalculation;

import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import payroll.api.APICredentials;
import payroll.api.Token;
import payroll.api.taxCalculation.request_api.LocationPayload;
import payroll.api.taxCalculation.request_api.PerformTaxCalculationPayload_Federal;
import payroll.api.taxCalculation.request_api.PerformTaxCalculationPayload_FederalOtherEarn;
import payroll.api.taxCalculation.request_api.PerformTaxCalculationPayload_PreTaxDeductions1;
import payroll.api.taxCalculation.response_api.LocationVerificationResp;
import payroll.api.taxCalculation.response_api.PerformTaxCalculationResp;
import payroll.data.DataImport;
import payroll.data.SessionVariables;

import static io.restassured.RestAssured.config;
import static io.restassured.RestAssured.given;

public class TaxCalculationAPI {
    private final RequestSpecification globalRequestSpec;
    private final APICredentials credentials = new APICredentials()
            .setClientId("TaxCalculationAPI")
            .setGrantType("client_credentials")
            .setScope("TaxCalculationAPI")
            .setClientSecretPassword("cS=8Xj<D9}ZVU=UxgjLFcpcTA4pr[u");

    private static final String GET_TOKEN = "/connect/token";
    private static final String POST_PERFORM_TAX_CALCULATION = "/api/TaxCalculation/PerformTaxCalculation";
    private static final String POST_LOCATION_VERIFICATION_TYPE = "/api/TaxCalculation/GetRequiredLocationVerificationType";

    public TaxCalculationAPI() {
        DataImport.retrieve_EnvironmentData();
        RestAssured.baseURI = SessionVariables.getEnvironment().taxcCalculationService;
        globalRequestSpec = getRequest();
    }

    private String getAccessToken() {
        RequestSpecification request = given()
                .config(config().encoderConfig(
                        EncoderConfig.encoderConfig().encodeContentTypeAs("x-www-form-urlencoded", ContentType.URLENC)))
                .contentType("x-www-form-urlencoded")
                .formParam("grant_type", credentials.getGrantType())
                .formParam("scope", credentials.getScope())
                .formParam("client_id", credentials.getClientId())
                .formParam("client_secret", credentials.getClientSecretPassword())
                .header("accept", "application/json")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .request();
        return request
                .baseUri(SessionVariables.getEnvironment().tokenService)
                .post(GET_TOKEN)
                .as(Token.class).access_token;
    }

    private RequestSpecification getRequest() {
        return given()
                .header("Authorization", "Bearer " + getAccessToken())
                .request();
    }

    public LocationVerificationResp getRequiredLocationVerificationType(int statusCode, LocationPayload locationPayload) {
        return given().log().all()
                .spec(globalRequestSpec)
                .when()
                .contentType("application/json")
                .body(locationPayload)
                .post(POST_LOCATION_VERIFICATION_TYPE)
                .then().log().all()
                .statusCode(statusCode)
                .extract()
                .as(LocationVerificationResp.class);
    }

    public PerformTaxCalculationResp performPreTaxDeductionsTaxCalculations(int statusCode, PerformTaxCalculationPayload_PreTaxDeductions1 taxCalculationPayload) {
        return given().log().all()
                .spec(globalRequestSpec)
                .when()
                .contentType("application/json")
                .body(taxCalculationPayload)
                .post(POST_PERFORM_TAX_CALCULATION)
                .then().log().all()
                .statusCode(statusCode)
                .extract().as(PerformTaxCalculationResp.class);
    }

    public PerformTaxCalculationResp performFederalTaxCalculations(int statusCode, PerformTaxCalculationPayload_Federal taxCalculationPayload) {
        return given().log().all()
                .spec(globalRequestSpec)
                .when()
                .contentType("application/json")
                .body(taxCalculationPayload)
                .post(POST_PERFORM_TAX_CALCULATION)
                .then().log().all()
                .statusCode(statusCode)
                .extract().as(PerformTaxCalculationResp.class);
    }

    public PerformTaxCalculationResp performFederalOtherEarnTaxCalculations(int statusCode, PerformTaxCalculationPayload_FederalOtherEarn taxCalculationPayload) {
        return given().log().all()
                .spec(globalRequestSpec)
                .when()
                .contentType("application/json")
                .body(taxCalculationPayload)
                .post(POST_PERFORM_TAX_CALCULATION)
                .then().log().all()
                .statusCode(statusCode)
                .extract().as(PerformTaxCalculationResp.class);
    }
}
