
package payroll.api.taxCalculation.response_api;

import payroll.api.taxCalculation.entity.CalculatedTaxInfo;
import utils2.tableData.Row;

import java.util.List;

public class PerformTaxCalculationResp {

    public String message;
    public List<String> errors;
    /**
     {
     "CalculatedTaxes": {
     "TaxAmounts": [
     {
     "TaxCode": {
     "MajorLocation": 54,
     "TaxType": 1,
     "MinorLocation": null
     },
     "TaxAmount": 0,
     "GrossAmount": 0,
     "TaxableGrossAmount": 0,
     "DeferredAmount": 0
     }
     ],
     "EmployeeId": "4ca91c4d-a650-45e0-867f-236da60c418f"
     }
     }
     */

    private CalculatedTaxInfo calculatedTaxInfo;

    public PerformTaxCalculationResp() {
    }

    public PerformTaxCalculationResp(CalculatedTaxInfo calculatedTaxInfo) {
        this.calculatedTaxInfo = calculatedTaxInfo;
    }

    public CalculatedTaxInfo getCalculatedTaxInfo() {
        return calculatedTaxInfo;
    }

    public void setCalculatedTaxInfo(CalculatedTaxInfo calculatedTaxInfo) {
        this.calculatedTaxInfo = calculatedTaxInfo;
    }

}
