package payroll.api.taxCalculation.response_api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import payroll.api.taxCalculation.entity.EmpPayLeavePay;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LocationVerificationResp {

    public String locationVerificationType;
    public int statusCode;
    public String message;
    public String type;
    public int status;
    public List<String> errors;

    public LocationVerificationResp(String locationVerificationType, int statusCode) {
        this.locationVerificationType = locationVerificationType;
        this.statusCode = statusCode;
    }

    public LocationVerificationResp(String locationVerificationType, String type, String title, int status, List<String> errors) {
        this.locationVerificationType = locationVerificationType;
        this.message = message;
        this.status = status;
        this.type = type;
        this.errors = errors;
    }

    public LocationVerificationResp() {
        this.locationVerificationType = null;
        this.statusCode = 0;
        this.type = null;
        this.status = 0;
        this.message = null;
        this.errors = null;
    }
}
