package payroll.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.UUID;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeeEmergencyContact 
{
    public UUID id;
    public String contactName;
    public String phone;
    public String workPhone;
    public String cellPhone;
    public String email;
    public String notes;
}
