package payroll.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.time.LocalDate;
import java.util.Date;
import java.util.UUID;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Employee
{
	public UUID id;
	public String employeeNumber;
	public String payFrequency;
	public LocalDate hiredDate;
	public EmployeePayInfo[] payInfo; 
	public EmployeeAcaData[] acaData;
	public EmployeeDependent[] dependents;
	public EmployeeEmergencyContact[] emergencyContacts;
	public EmployeeJobTitle[] jobTitles;
	public String firstName; 
	public String middleName; 
	public String lastName; 
	public String suffix; 
	public String address1;
	public String address2;
	public String city;
	public String state;
	public String zip;
	public String foreignAddress1;
	public String foreignAddress2;
	public String foreignAddress3;
	public String phone;
	public String gender;
	public String ssn;
	public String status;
	public String maritalStatus;
	public String email;
	public LocalDate birthDate;
	public LocalDate terminationDate;
	public LocalDate reHiredDate;

	public Employee setEmail(String email) {
		this.email = email;
		return this;
	}

	public Employee setMiddleName(String middleName) {
		this.middleName = middleName;
		return this;
	}
}
