package payroll.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Department {
    public String id;
    public String num;
    public String descr;
    public boolean isActive;
}