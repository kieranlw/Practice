package payroll.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.UUID;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeeDependent 
{
    public UUID id;
    public String firstName;
    public String middleName;
    public String lastName;
    public String suffix;
    public String ssn;
    public String birthDate;
    public String acaCoverageType;
    public String relationshipType;
    public String legalGender;
    public Boolean tobaccoUser;
    public Boolean fulltimeStudent;
    public Boolean isDisabled;
}
