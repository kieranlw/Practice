package payroll.api.mis.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import utils2.LogInfo;

import static io.restassured.RestAssured.given;

public class MISStatusAccessor {

    private String version;
    private String baseUri;
    private String accessToken;

    public MISStatusAccessor(String version, String baseUri) {
        this.version = version;
        this.baseUri = baseUri;
    }

    public Response get()
    {
        RequestSpecification request = given()
                .relaxedHTTPSValidation()
                .contentType("x-www-form-urlencoded")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .pathParam("version", version)
                .request();
        LogInfo.log_Status("MIS_URL:" + baseUri + "/v"+version+"/system/status");

        return request.get(baseUri + "/v{version}/system/status");
    }
}