package payroll.api.mis.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.given;

public class SSOGocoAccessor {

    private String version;
    private String baseUri;
    private String accessToken;

    public SSOGocoAccessor(String version, String baseUri, String accessToken) {
        this.version = version;
        this.baseUri = baseUri;
        this.accessToken = accessToken;
    }

    public Response delete(String gocoUserId)
    {
        RequestSpecification request = given()
                .relaxedHTTPSValidation()
                .contentType("x-www-form-urlencoded")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .header("Authorization", "Bearer "+ accessToken)
                .pathParam("version", version)
                .pathParam("gocoUserId", gocoUserId)
                .request();

        return request.delete(baseUri + "/v{version}/integration/sso/goco/users/{gocoUserId}");
    }
}