package payroll.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDate;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DepartmentDetails {
    public String id;
    public String num;
    public String descr;
    public boolean isActive;
    public String name;
    public String addr1;
    public String addr2;
    public String addr3;
    public String divisionName;
    public String wotcLocation;
    public String dfltUcStateCode;
    public double dfltRate;
    public String workCompNum;
    public String workCompNum2;
    public double workCompRate;
    public String workCompState;
    public boolean doExcludeFromWC;
    public String empTipTypeCode;
    public String altImportNum;
    public String defaultWorkLocationName;
    public String glMemoDescr;
    public boolean doHideSalariedHoursOnStub;
    public double empWorkCompRate;
    public LocalDate workCompEffectiveDate;
}
