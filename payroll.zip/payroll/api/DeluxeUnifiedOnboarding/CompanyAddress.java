package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompanyAddress
{
    private String addressType;

    private String addressLine1;

    private String addressLine2;

    private String city;

    private String state;

    private String zip;

    private String phone;

    private String companyId;

    @JsonIgnore
    private String id;

    @JsonIgnore
    private String fein;


    public static CompanyAddress createDefaultAddress(Company company) {
        return builder()
                .addressType("FilingAddress")
                .addressLine1("1 Georgia Dome Drive")
                .city("Atlanta")
                .state("GA")
                .zip("30303")
                .phone("1234567890")
                .companyId(company.getId())
                .fein(company.getFein())
                .build();
    }


    public static CompanyAddress createDefaultAddress(Company company, String addressType) {
        return builder()
                .addressType(addressType)
                .addressLine1("1 Georgia Dome Drive")
                .city("Atlanta")
                .state("GA")
                .zip("30303")
                .phone("1234567890")
                .companyId(company.getId())
                .fein(company.getFein())
                .build();
    }

    public static CompanyAddress createUpdatedAddress(CompanyAddress address) {
        return builder()
                .addressType(address.getAddressType())
                .addressLine1("1 Fenway Drive")
                .city("Boston")
                .state("MA")
                .zip("12121")
                .phone("9876543210")
                .companyId(address.getCompanyId())
                .fein(address.getFein())
                .id(address.getId())
                .build();
    }
}
