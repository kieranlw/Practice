package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.Random;

@Data
@Builder(toBuilder = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreditAuthorizationForm {

    private String companyId;

    private String companyName;

    private String fein;

    private String businessStructure;

    private String address;

    private String addressLine2;

    private String city;

    private String state;

    private String zip;

    private String phone;

    private String primaryContactName;

    private String emailAddress;

    private String creditRequestDate;

    private String creditApproved;

    private String fundingRequirement;

    private String ofacStatus;

    private Boolean authorizationCommercialCreditCheck;

    private Boolean authenticityAgreementCheck;

    private String creditStatus;

    @JsonProperty("individualAuthorizationFormData")
    private IndividualAuthorizationForm individualAuthorizationForm;

    public enum CreditApproved {
        NA("NA"),
        PENDING("Pending"),
        APPROVED("Approved"),
        SHOWEMAILPAGE("ShowEmailPage"),
        SHOWGENERICPAGE("ShowGenericPage");

        public final String label;

        CreditApproved(String label) {
            this.label = label;
        }
    }

    public enum FundingRequirement {
        NA("NA"),
        DENIED("Denied"),
        THREEDAYFUNDING("ThreeDayFunding"),
        FIVEDAYFUNDING("FiveDayFunding"),
        WIREONLY("WireOnly");

        public final String label;

        FundingRequirement(String label) {
            this.label = label;
        }
    }

    public enum BusinessStructure {
        CCORPORATION("CCorporation"),
        SCORPORATION("SCorporation"),
        SOLEPROPRIETOR("SoleProprietor"),
        LLC("LLC"),
        LLP("LLP"),
        LIMITEDPARTNERSHIP("LimitedPartnership"),
        COOWNERSHIP("CoOwnership"),
        ASSOCIATION("Association"),
        TRUSTEESHIP("Trusteeship"),
        GENERALPARTNERSHIP("GeneralPartnership"),
        JOINTVENTURE("JointVenture"),
        NONPROFIT("NonProfit");

        public final String label;

        BusinessStructure(String label) {
            this.label = label;
        }
    }

    public static String getRandomBusinessStructure() {
        BusinessStructure[] array = BusinessStructure.values();
        int index = new Random().nextInt(array.length);
        return array[index].label;
    }

    public static CreditAuthorizationForm createDefault(Company company) {
        return CreditAuthorizationForm.builder()
                .companyId(company.getId())
                .companyName(company.getCompanyLegalName())
                .fein(company.getFein())
                .businessStructure(getRandomBusinessStructure())
                .address("Corner Street")
                .city("Washington")
                .state("WA")
                .zip("10012")
                .phone(company.getCompanyPhone())
                .primaryContactName("John")
                .emailAddress("test123@test.io")
                .creditRequestDate("2021-08-31T09:50:42.994Z")
                .creditApproved(getRandomCreditApproved())
                .fundingRequirement(getRandomFundingRequirement())
                .authorizationCommercialCreditCheck(true)
                .authenticityAgreementCheck(true)
                .businessStructure(BusinessStructure.CCORPORATION.label)
                .individualAuthorizationForm(IndividualAuthorizationForm.createDefaultIndividualAuthorizationForm())
                .build();
    }

    public static CreditAuthorizationForm updateDefaultCreditAuthorizationForm(Company company) {
        return createDefault(company).toBuilder()
                .address("New street")
                .city("Updated")
                .state("UP")
                .zip("22253")
                .primaryContactName("UpdatedJohn")
                .emailAddress("uptest123@test.io")
                .creditRequestDate("2019-08-31T09:50:42.882Z")
                .creditApproved(getRandomCreditApproved())
                .fundingRequirement(getRandomFundingRequirement())
                .authorizationCommercialCreditCheck(false)
                .authenticityAgreementCheck(false)
                .individualAuthorizationForm(IndividualAuthorizationForm.updateDefaultIndividualAuthorizationForm())
                .build();
    }

    public static String getRandomCreditApproved() {
        CreditApproved[] array = CreditApproved.values();
        int index = new Random().nextInt(array.length);
        return array[index].label;
    }

    public static String getRandomFundingRequirement() {
        FundingRequirement[] array = FundingRequirement.values();
        int index = new Random().nextInt(array.length);
        return array[index].label;
    }
}
