package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.util.Random;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Company {

    private String fein;

    private String companyLegalName;

    private String companyPhone;

    private Employee [] employees;

    private String id;

    public static String generateRandomFein() {
        Random random = new Random();
        return ((random.nextInt(90) + 10) + "-" + (random.nextInt(9000000) + 1000000));
    }

    public static Company createDefaultCompany() {
        return builder()
                .fein(generateRandomFein())
                .companyLegalName("Test Company")
                .companyPhone("1234567890")
                .employees(new Employee [] {Employee.createDefaultEmployee()})
                .build();
    }

    public static Company createDefaultCompany(Account account) {
        return builder()
                .fein(generateRandomFein())
                .companyLegalName("Test Company")
                .companyPhone("1234567890")
                .employees(Employee.setEmployeeFromAccount(account))
                .build();
    }

    public static Company createUpdatedCompany(Company company) {
        return builder()
                .fein(company.getFein())
                .companyLegalName("New Company Legal Name")
                .companyPhone("9876543210")
                .id(company.getId())
                .employees(company.employees)
                .build();
    }
}

