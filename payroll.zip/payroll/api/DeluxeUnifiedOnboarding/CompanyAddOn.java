package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.util.Random;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompanyAddOn {

    private Boolean benefitsAdministration;

    private Boolean unlimitedWorkFlows;

    private Boolean posters;

    private String ats;

    private String hrSolutionCenter;

    private String hrTrainingModule;

    private String hrHandbookCreation;

    private String companyId;

    @JsonIgnore
    private String fein;

    @JsonIgnore
    private String id;

    public enum ATS {
        HeroBasePackage,
        Plus,
        Pro;
    }

    public enum HRSolutionCenter {
        Support,
        OnDemand,
        Complete;
    }

    public enum HRTrainingModule {
        Learn1,
        Learn2,
        Learn3;
    }

    public enum HRHandbookCreation {
        HRHandbookCreation,
        HRHandbookReview,
        HRWizardHandbookCreation
    }

    public enum TimeSolutions {
        TimeTrackingandProjectCodes,
        TimeWorkswithMobileManagement,
        TimeworkswithScheduling
    }

    public static CompanyAddOn createDefaultCompanyAddOn(Company company) {
        return builder()
                .benefitsAdministration(true)
                .unlimitedWorkFlows(true)
                .posters(true)
                .ats(getRandomATS())
                .hrSolutionCenter(getRandomHRSolutionCenter())
                .hrTrainingModule(getRandomHRTrainingModule())
                .hrHandbookCreation(getRandomHRHandbookCreation())
                .companyId(company.getId())
                .fein(company.getFein())
                .build();
    }

    public static CompanyAddOn createUpdatedCompanyAddOn(CompanyAddOn companyAddOn) {
        return builder()
                .benefitsAdministration(false)
                .unlimitedWorkFlows(false)
                .posters(false)
                .ats(getRandomATS())
                .hrSolutionCenter(getRandomHRSolutionCenter())
                .hrTrainingModule(getRandomHRTrainingModule())
                .hrHandbookCreation(getRandomHRHandbookCreation())
                .id(companyAddOn.getId())
                .companyId(companyAddOn.getCompanyId())
                .fein(companyAddOn.getFein())
                .build();
    }

    public static String getRandomATS() {
        CompanyAddOn.ATS [] array = CompanyAddOn.ATS.values();
        Random random = new Random();
        return array[random.nextInt(array.length)].name();
    }

    public static String getRandomHRSolutionCenter() {
        CompanyAddOn.HRSolutionCenter [] array = CompanyAddOn.HRSolutionCenter.values();
        Random random = new Random();
        return array[random.nextInt(array.length)].name();
    }

    public static String getRandomHRTrainingModule() {
        CompanyAddOn.HRTrainingModule [] array = CompanyAddOn.HRTrainingModule.values();
        Random random = new Random();
        return array[random.nextInt(array.length)].name();
    }

    public static String getRandomHRHandbookCreation() {
        CompanyAddOn.HRHandbookCreation [] array = CompanyAddOn.HRHandbookCreation.values();
        Random random = new Random();
        return array[random.nextInt(array.length)].name();
    }
}
