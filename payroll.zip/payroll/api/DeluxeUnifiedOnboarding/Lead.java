package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Builder(toBuilder = true)
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Lead {
    private String firstName;

    private String lastName;

    private String companyName;

    private String state;

    private String zipCode;

    private String phone;

    private int numberOfEmployees;

    private String lastNotifiedDate;

    private String leadStatus;

    private String productFamilyInterest;

    private String leadSource;

    private String leadSourceDescription;

    private String fromURL;

    private String salesMethod;

    private String contactMethod;

    private String email;

    private String leadCreationDate;

    private String leadKey;

    private String id;

    private String packageName;

    private String packageType;

    private String bankRoutingNumber;

    private String referringPartner;

    private String contactEmail;

    public static Lead createDefaultLead() {
        return Lead.builder()
                .firstName("leadFirst")
                .lastName("leadLast")
                .companyName("LeadCompany")
                .state("AL")
                .zipCode("49082")
                .phone("0972530851")
                .numberOfEmployees(10)
                .leadStatus("Registered")
                .productFamilyInterest("Payments")
                .leadSource("Website")
                .leadSourceDescription("PAYCE PAYRL HR Solutions")
                .fromURL("https://preprod.deluxe.com/business-operations/hr/pricing/")
                .salesMethod("DIY")
                .contactMethod("Phone")
                .packageName("HR")
                .build();
    }

    public static Lead createLeadWithoutSalesAndContactMethod() {
        return Lead.builder()
                .firstName("leadFirst1")
                .lastName("leadLast1")
                .companyName("LeadCompany1")
                .state("al")
                .zipCode("55344")
                .phone("0972530851")
                .numberOfEmployees(10)
                .leadStatus("Preregistered")
                .productFamilyInterest("Payments")
                .leadSource("Website")
                .leadSourceDescription("PAYCE PAYRL HR Solutions")
                .fromURL("https://preprod.deluxe.com/business-operations/hr/pricing/")
                .build();
    }

    public static Lead createLeadWithoutCompanyName() {
        return Lead.builder()
                .firstName("leadFirst")
                .lastName("leadLast")
                .state("NY")
                .zipCode("55340")
                .phone("0972530851")
                .numberOfEmployees(50)
                .leadStatus("Registered")
                .productFamilyInterest("Payments")
                .leadSource("Website")
                .leadSourceDescription("PAYCE PAYRL HR Solutions")
                .fromURL("https://preprod.deluxe.com/business-operations/hr/pricing/")
                .salesMethod("DIY")
                .contactMethod("Phone")
                .packageName("Payroll")
                .build();
    }

    public static Lead updateDefaultLead() {
        return Lead.builder()
                .firstName("UpdateFirstName")
                .lastName("UpdateLastName")
                .companyName("UpdateLeadCompany")
                .state("GA")
                .zipCode("30050")
                .phone("8972530888")
                .numberOfEmployees(41)
                .lastNotifiedDate("2021-06-26T09:15:40.004Z")
                .leadStatus("CompletedOnboarding")
                .productFamilyInterest("Payments")
                .leadSource("Website")
                .leadSourceDescription("Update PAYCE PAYRL HR Solutions")
                .fromURL("https://www.deluxe.com")
                .salesMethod("TTS")
                .contactMethod("Email")
                .packageType("HR")
                .build();
    }
}