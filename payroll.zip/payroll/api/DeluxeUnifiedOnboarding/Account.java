package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.util.Objects;
import java.util.Random;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Account {

    private String firstName;

    private String lastName;

    private String emailAddress;

    private String password;

    private String companyName;

    private String state;

    private String zip;

    private String companyPhone;

    private int numberOfEmployees;

    private Boolean consent;

    @JsonIgnore
    private String verificationToken;

    @JsonIgnore
    private Boolean emailVerified;

    public static String generateRandomEmailAddress() {
        Random random = new Random();
        Integer randomNumber = random.nextInt(2000000) + 1;
        return "apiautomation" + randomNumber + "@deluxe.com";
    }

    public static Account createDefaultAccount() {

        return builder()
                .firstName("Test")
                .lastName("User")
                .emailAddress(generateRandomEmailAddress())
                .password("@Welcome1")
                .companyName("Deluxe")
                .state("GA")
                .zip("12345")
                .companyPhone("1234567890")
                .numberOfEmployees(1000)
                .consent(true)
                .build();
    }

    public static Account createUpdatedAccount(Account account) {

        return builder()
                .firstName("Updated")
                .lastName("Name")
                .emailAddress(account.getEmailAddress())
                .password(null)
                .companyName("New Company")
                .state("NY")
                .zip("54321")
                .companyPhone("9876543210")
                .numberOfEmployees(10)
                .consent(false)
                .verificationToken(account.getVerificationToken())
                .build();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Account account = (Account) o;
        return numberOfEmployees == account.numberOfEmployees && consent == account.consent && Objects.equals(firstName, account.firstName) && Objects.equals(lastName, account.lastName) && Objects.equals(emailAddress, account.emailAddress) && Objects.equals(password, account.password) && Objects.equals(companyName, account.companyName) && Objects.equals(state, account.state) && Objects.equals(companyPhone, account.companyPhone);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, emailAddress, password, companyName, state, companyPhone, numberOfEmployees, consent);
    }
}