package payroll.api.DeluxeUnifiedOnboarding.ResponseModels;

import com.fasterxml.jackson.annotation.JsonProperty;
import common.Is;
import common.Verify;
import io.restassured.response.Response;

import java.util.Map;

public class ErrorResponseModel {

    @JsonProperty ("type") // updated after account creation
    private String type;

    @JsonProperty ("title") // updated after account creation
    private String title;

    @JsonProperty ("status")// updated after account creation
    private String status;

    @JsonProperty("errors")
    private Map<String, Object> errors;

    public enum ErrorMessages {
        VALIDATION_RESPONSE("The replace field is required."),
        MAX_LENGTH_ERROR("The field replaceField must be a string or array type with a maximum length of 'replaceLength'."),
        MIN_LENGTH_ERROR("The field replaceField must be a string or array type with a minimum length of 'replaceLength'."),
        WRONG_FORMAT("The value 'WrongFormat' is not valid."),
        EMAIL_FORMAT("The replace field is not a valid e-mail address."),
        PHONE_FORMAT("The replace field is not a valid phone number."),
        FEIN_FORMAT("The replace field is not a valid FEIN"),
        GUID_FORMAT("The replace field is not a valid GUID."),
        DUPLICATE_VALUE("Duplicate Value Error"),
        DUPLICATE_OBJECT("Only one replace allowed"),
        FILE_NAME_VALIDATION("Only PDF, JPG, or PNGs allowed."),
        OFAC_FORMAT("OFAC Status must be either 'N', 'O', or 'E'."),
        OFAC_LENGTH("The OFAC status must be replaceLength character length."),
        IPADDRESS_VALIDATION("IP Address is required."),
        WITHHOLDING_STATUS_VALIDATION("Withholding status NA is not allowed for this state");

        public final String message;

        ErrorMessages(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }

    public static void verifyValidationError(Response res, ErrorMessages expectedErrorMessage, String fieldName) {
        ErrorResponseModel error = res.as(ErrorResponseModel.class);
        Verify.that(res.statusCode(), Is.equalTo(400));
        Verify.that(error.getErrors().get(fieldName).toString(),
                Is.stringContaining(expectedErrorMessage.getMessage()
                        .replaceAll("replace", fieldName.replaceAll("\\w+\\.", ""))));
    }

    public static void verifyLengthValidationError(Response res, ErrorMessages expectedErrorMessage, String fieldName, String length) {
        ErrorResponseModel error = res.as(ErrorResponseModel.class);
        Verify.that(res.statusCode(), Is.equalTo(400));
        Verify.that(error.getErrors().get(fieldName).toString(),
                Is.stringContaining(expectedErrorMessage.getMessage()
                        .replaceAll("replaceField", fieldName.replaceAll("\\w+\\.", ""))
                        .replaceAll("replaceLength", length)));
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Map<String, Object> getErrors() {
        return errors;
    }



}
