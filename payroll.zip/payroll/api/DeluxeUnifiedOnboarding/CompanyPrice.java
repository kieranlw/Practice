package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompanyPrice {

    private String pricingPackageCode;

    private String companyId;

    private String fein;

    private String id;


    public static CompanyPrice createDefaultCompanyPrice(Company company) {
        return builder()
                .pricingPackageCode("Package1")
                .companyId(company.getId())
                .fein(company.getFein())
                .build();
    }

    public static CompanyPrice createUpdatedCompanyPrice(CompanyPrice companyPrice) {
        return builder()
                .pricingPackageCode("Package2")
                .id(companyPrice.getId())
                .companyId(companyPrice.getCompanyId())
                .fein(companyPrice.getFein())
                .build();
    }
}

