package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TokenInfoIntrospectObject {

    private String iss;

    private String nbf;

    private String exp;

    private ArrayList<String> aud;

    private String clientId;

    private String sub;

    private int authTime;

    private String email;

    private String company;

    private String email_verified;

    private String sid;

    private String idp;

    private String amr;

    private String jti;

    private int iat;

    private boolean active;

    private String scope;
}
