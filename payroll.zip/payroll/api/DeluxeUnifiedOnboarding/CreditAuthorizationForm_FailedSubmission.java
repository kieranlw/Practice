package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder(toBuilder = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreditAuthorizationForm_FailedSubmission {

    private String companyId;

    private String ipAddress;

    private Boolean canRetry;

    public static CreditAuthorizationForm_FailedSubmission createDefault(Company company){
        return CreditAuthorizationForm_FailedSubmission.builder()
                .companyId(company.getId())
                .ipAddress("169.251.201.198")
                .build();
    }

    public static CreditAuthorizationForm_FailedSubmission updateDefaultCreditAuthorizationFormFailedSubmission(Company company){
        return CreditAuthorizationForm_FailedSubmission.builder()
                .companyId(company.getId())
                .ipAddress("543.461.561.198")
                .build();
    }
}
