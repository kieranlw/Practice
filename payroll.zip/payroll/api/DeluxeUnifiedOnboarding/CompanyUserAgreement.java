package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompanyUserAgreement {

    private Boolean agreedToAuthorizedSignature;

    private Boolean agreedToTermsAndConditions;

    private String companyId;

    private String fein;

    private String id;

    private String userAgreementActionDateTime;

    public static CompanyUserAgreement createDefaultCompanyUserAgreement(Company company) {
        return builder()
                .companyId(company.getId())
                .fein(company.getFein())
                .agreedToAuthorizedSignature(true)
                .agreedToTermsAndConditions(true)
                .build();
    }

    public static CompanyUserAgreement createUpdatedCompanyUserAgreement(CompanyUserAgreement companyUserAgreement) {
        return builder()
                .companyId(companyUserAgreement.getCompanyId())
                .fein(companyUserAgreement.getFein())
                .id(companyUserAgreement.getId())
                .agreedToAuthorizedSignature(false)
                .agreedToTermsAndConditions(false)
                .userAgreementActionDateTime(companyUserAgreement.getUserAgreementActionDateTime())
                .build();
    }
}