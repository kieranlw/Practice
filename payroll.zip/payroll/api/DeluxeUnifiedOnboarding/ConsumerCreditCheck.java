package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.util.Random;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ConsumerCreditCheck {

    private String companyId;

    private String ssn;

    private String birthDate;

    private String lastName;

    private String firstName;

    private String middleName;

    private String suffix;

    private String emailAddress;

    private String phone;

    private String houseNumber;

    private String streetName;

    private String streetType;

    private String apartmentNumber;

    private String city;

    private String state;

    private String zip;

    private Boolean authorizationConsumerCreditCheck;

    private String id;

    private Integer consumerCreditScore;

    private String rety;

    private String creditApproved;

    private String fundingRequirement;

    public static ConsumerCreditCheck createAbove580ConsumerCreditCheck(Company company) {

        return builder()
                .companyId(company.getId())
                .ssn("666498687")
                .birthDate("05271981")
                .lastName("ttjwzxy")
                .firstName("shandra")
                .emailAddress(Account.generateRandomEmailAddress())
                .phone("1234567890")
                .houseNumber("714")
                .streetName("axjer")
                .streetType("rd")
                .city("gillete")
                .state("wy")
                .zip("82731")
                .authorizationConsumerCreditCheck(true)
                .build();
    }

    public static ConsumerCreditCheck createBetween579And501ConsumerCreditCheck(Company company) {

        return builder()
                .companyId(company.getId())
                .ssn("666739610")
                .birthDate("10062002")
                .lastName("nnarcissus")
                .firstName("opal")
                .emailAddress(Account.generateRandomEmailAddress())
                .phone("1234567890")
                .houseNumber("2233444")
                .streetName("mammoth")
                .streetType("wy")
                .city("south fulton")
                .state("tn")
                .zip("38257")
                .authorizationConsumerCreditCheck(true)
                .build();
    }

    public static ConsumerCreditCheck createBelow500ConsumerCreditCheck(Company company) {

        return builder()
                .companyId(company.getId())
                .ssn("666001879")
                .birthDate("08091954")
                .lastName("ykpdgm")
                .firstName("mark")
                .emailAddress(Account.generateRandomEmailAddress())
                .phone("1234567890")
                .houseNumber("2044")
                .streetName("djuttip")
                .streetType("st")
                .city("kansas city")
                .state("mo")
                .zip("64101")
                .authorizationConsumerCreditCheck(true)
                .build();
    }

    public static ConsumerCreditCheck createNotFoundConsumerCreditCheck(Company company) {

        return builder()
                .companyId(company.getId())
                .ssn("123456789")
                .birthDate("01012000")
                .lastName("LastName")
                .firstName("FirstName")
                .emailAddress(Account.generateRandomEmailAddress())
                .phone("1234567890")
                .houseNumber("1")
                .streetName("Atlanta")
                .streetType("str")
                .city("Atlanta")
                .state("ga")
                .zip("30303")
                .authorizationConsumerCreditCheck(true)
                .build();
    }

}