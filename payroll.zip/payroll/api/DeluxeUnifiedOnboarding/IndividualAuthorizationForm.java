package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IndividualAuthorizationForm {

    private String firstName;

    private String middleName;

    private String lastName;

    private String suffix;

    private String ssn;

    private String houseNumber;

    private String streetName;

    private String streetType;

    private String apartmentNumber;

    private String city;

    private String state;

    private String zip;

    private String phone;

    private String birthDate;

    private String emailAddress;

    private Boolean authorizationConsumerCreditCheck;

    public static IndividualAuthorizationForm createDefaultIndividualAuthorizationForm() {
        return builder()
                .firstName("James")
                .lastName("Bond")
                .ssn("123456789")
                .houseNumber("221B")
                .streetName("Baker")
                .streetType("st")
                .city("New-York")
                .state("NY")
                .zip("10001")
                .phone("1234567890")
                .birthDate("2021-08-30T16:52:52.223Z")
                .emailAddress("test@test.io")
                .authorizationConsumerCreditCheck(true)
                .build();
    }

    public static IndividualAuthorizationForm updateDefaultIndividualAuthorizationForm() {
        return builder()
                .firstName("UpdatedJames")
                .lastName("UpdatedBond")
                .ssn("987654321")
                .houseNumber("Up221B")
                .streetName("UpBaker")
                .streetType("ln")
                .city("UpdatedNew-York")
                .state("UP")
                .zip("12369")
                .phone("0987654321")
                .birthDate("1994-08-30T16:52:52.223Z")
                .emailAddress("uptest@test.io")
                .authorizationConsumerCreditCheck(false)
                .build();
    }
}
