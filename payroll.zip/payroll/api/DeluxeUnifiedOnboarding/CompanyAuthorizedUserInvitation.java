package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder(builderMethodName = "internalbuilder")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompanyAuthorizedUserInvitation {

    private String firstName;

    private String lastName;

    private String role;

    private String otherRoleText;

    private String emailAddress;

    private String companyId;

    private String companyName;

    private String id;

    private String contactInvitationLinkId;

    private String status;


    public static CompanyAuthorizedUserInvitation builder(Company company) {
        return internalbuilder().firstName("Test")
                .lastName("User")
                .role("CEO")
                .emailAddress(Account.createDefaultAccount().getEmailAddress())
                .companyId(company.getId())
                .build();
    }




}

