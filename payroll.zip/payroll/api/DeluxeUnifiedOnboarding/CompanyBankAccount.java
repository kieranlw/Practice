package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompanyBankAccount {

    private String bankName;

    private String nickname;

    private String accountType;

    private String routingNumber;

    private String accountNumber;

    private String [] accountUses;

    private Boolean authorizationHold;

    private String companyId;

    private String fein;

    @JsonIgnore
    private String id;

    @JsonIgnore
    private String verificationStatus;


    public static CompanyBankAccount createDefaultBankAccount(Company company) {
        return builder()
                .bankName("Bank of Deluxe")
                .nickname("Test Nickname")
                .accountType("Checking")
                .routingNumber("061000052")
                .accountNumber("1122334455667788")
                .accountUses(new String []{"Payroll"})
                .authorizationHold(true)
                .companyId(company.getId())
                .fein(company.getFein())
                .build();
    }

    public static CompanyBankAccount createDefaultBankAccountAllUses(Company company) {
        return builder()
                .bankName("Bank of Deluxe")
                .nickname("Test Nickname")
                .accountType("Checking")
                .routingNumber("061000052")
                .accountNumber("1122334455667788")
                .accountUses(new String []{"Payroll", "Taxes"})
                .authorizationHold(true)
                .companyId(company.getId())
                .fein(company.getFein())
                .build();
    }

    public static CompanyBankAccount createUpdatedAccount(CompanyBankAccount bankAccount) {
        return builder()
                .bankName("New Bank")
                .nickname("Updated Nickname")
                .accountType("Savings")
                .routingNumber("061000227")
                .accountNumber("9988776655443322")
                .accountUses(bankAccount.getAccountUses())
                .authorizationHold(true)
                .id(bankAccount.getId())
                .companyId(bankAccount.getCompanyId())
                .fein(bankAccount.getFein())
                .build();
    }
}
