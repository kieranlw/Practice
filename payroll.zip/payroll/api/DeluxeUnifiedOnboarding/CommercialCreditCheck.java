package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.util.Objects;
import java.util.Random;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CommercialCreditCheck {

    private String companyId;

    private String companyName;

    private String fein;

    private String businessStructure;

    private String address;

    private String city;

    private String state;

    private String zip;

    private String emailAddress;

    private String phone;

    private String ownerFirstName;

    private String ownerLastName;

    private Boolean authorizationCommercialCreditCheck;

    private String id;

    private String retry;

    private String creditApproved;

    private String fundingRequirement;

    private Boolean emailSent;

    public enum BusinessStructure {
        CCORPORATION("CCorporation"),
        SCORPORATION("SCorporation"),
        SOLEPROPRIETOR("SoleProprietor"),
        LLC("LLC"),
        LLP("LLP"),
        LIMITEDPARTNERSHIP("LimitedPartnership"),
        COOWNERSHIP("CoOwnership"),
        ASSOCIATION("Association"),
        TRUSTEESHIP("Trusteeship"),
        GENERALPARTNERSHIP("GeneralPartnership"),
        JOINTVENTURE("JointVenture"),
        NONPROFIT("NonProfit");

        public final String label;

        BusinessStructure(String label) {
            this.label = label;
        }
    }

    public static String getRandomBusinessStructure() {
        CreditAuthorizationForm.BusinessStructure[] array = CreditAuthorizationForm.BusinessStructure.values();
        int index = new Random().nextInt(array.length);
        return array[index].label;
    }

    public static CommercialCreditCheck createAbove375CommercialCreditCheck(Company company) {

        return builder()
                .companyId(company.getId())
                .companyName("zurbrigen orthidontics lallet 714116 tucker")
                .fein(company.getFein())
                .businessStructure(getRandomBusinessStructure())
                .address("15-1580 lusterview blvd")
                .city("newport news")
                .state("va")
                .zip("23602-5560")
                .emailAddress(Account.generateRandomEmailAddress())
                .phone(company.getCompanyPhone())
                .ownerFirstName("FirstName")
                .ownerLastName("LastName")
                .authorizationCommercialCreditCheck(true)
                .build();
    }

    public static CommercialCreditCheck createBelow375CommercialCreditCheck(Company company) {

        return builder()
                .companyId(company.getId())
                .companyName("ZEDZIAN 30-1818 12126,")
                .fein(company.getFein())
                .businessStructure(getRandomBusinessStructure())
                .address("5114 w decatur plaza shopping")
                .city("chico")
                .state("ca")
                .zip("95926-7236")
                .emailAddress(Account.generateRandomEmailAddress())
                .phone(company.getCompanyPhone())
                .ownerFirstName("FirstName")
                .ownerLastName("LastName")
                .authorizationCommercialCreditCheck(true)
                .build();
    }

    public static CommercialCreditCheck createNotFoundCommercialCreditCheck(Company company) {

        return builder()
                .companyId(company.getId())
                .companyName(company.getCompanyLegalName())
                .fein(company.getFein())
                .businessStructure(getRandomBusinessStructure())
                .address("1 Atlanta Street")
                .city("Atlanta")
                .state("ga")
                .zip("30303")
                .emailAddress(Account.generateRandomEmailAddress())
                .phone(company.getCompanyPhone())
                .ownerFirstName("FirstName")
                .ownerLastName("LastName")
                .authorizationCommercialCreditCheck(true)
                .build();
    }

}