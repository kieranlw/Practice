package payroll.api.DeluxeUnifiedOnboarding;

import io.restassured.RestAssured;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.decisions.Environment;
import utils2.LogInfo;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DigitalOnboardingAPI {

    private Environment environment;

    private String authorizationToken = "13CA7C4E9FF0CA695DF3F10D8BC0F872123812B00D06B61B1348DDE1305EF754";
    private String apiKey = "UMiCrPhLnKU4Dlw";

    private String accountURL = "https://qa.account-api.enroll.deluxe.com/api/";
    private String accountExtensionURL = "AccountManager/Accounts/{email}";
    private String tokenGenerationURL = "Registrations/GenerateVerificationToken/{email}";
    private String tokenVerificationURL = "Registrations/ConfirmRegistrationEmail";
    private String resetPasswordTokenGenerationURL = "ResetPassword/token/{email}";
    private String resetPasswordTokenVerificationURL = "ResetPassword/reset";
    private String changePasswordURL = "AccountPreference/ChangePassword";
    private String accountRegistrationURL_Heroku = "https://https://qa.enroll.deluxe.com/register";

    private String companiesURL = "https://qa.company-api.enroll.deluxe.com/api/";
    private String companiesExtensionURL = "Companies/{id}";
    private String companyAddressesExtensionURL = "CompanyAddresses/{id}";
    private String bankAccountsExtensionURL = "CompanyBankAccounts/{id}";
    private String bankAccountVerificationExtensionURL = "/api/CompanyBankAccountVerification/FinishVerification";
    private String companyPricingExtensionURL = "CompanyPricing/{id}";
    private String companyFederalTaxesExtensionURL = "CompanyFederalTaxes/{id}";
    private String companyStateTaxesExtensionURL = "CompanyStateTaxes/{id}";
    private String companyAuthorizationFormsExtensionURL = "CompanyAuthorizationForms/{id}";
    private String companyUserAgreementsExtensionURL = "CompanyUserAgreements/{id}";
    private String companyAddOnExtensionURL = "CompanyAddOns/{id}";
    private String companySummaryExtensionURL = "CompanySummaries/{id}";
    private String companyAuthorizedUserInvitationURL = "Companies/CompanyAuthorizedUserInvitations";
    private String companyEmployeesURL = "CompanyEmployees/{id}";

    private String leadsURL = "https://qa.company-api.enroll.deluxe.com//api/Leads/";
    private String leadOverwriteOrGenerateURL = "{email}/GenerateOrOverwrite";
    private String leadExtensionURL = "{id}";


    public DigitalOnboardingAPI(Environment environment) {
        this.environment = environment;
    }

    public DigitalOnboardingAPI() {
    }

    public void setAuthorizationToken(String authorizationToken) {
        this.authorizationToken = authorizationToken;
    }

    public RequestSpecification createDefaultApi() {
        RestAssured.defaultParser = Parser.JSON;
        RequestSpecification res = RestAssured.given().log().all()
                .header("Content-Type", "application/json")
                .header("Api-Key", apiKey)
                .header("Authorization", "Bearer " + authorizationToken);

        return res;
    }

    public RequestSpecification createApiWithAuthToken() {
        RestAssured.defaultParser = Parser.JSON;
        RequestSpecification res = RestAssured.given().log().all()
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + authorizationToken);
        return res;
    }

    public RequestSpecification createApiWithoutApiKeyAndAuthToken() {
        RestAssured.defaultParser = Parser.JSON;
        RequestSpecification res = RestAssured.given().log().all()
                .header("Content-Type", "application/json");
        return res;
    }

    public RequestSpecification createApiWithApiKey() {
        RestAssured.defaultParser = Parser.JSON;
        RequestSpecification res = RestAssured.given().log().all()
                .header("Content-Type", "application/json")
                .header("Api-Key", apiKey);
        return res;
    }

    public RequestSpecification createApiWithWrongApiKey() {
        RestAssured.defaultParser = Parser.JSON;
        RequestSpecification res = RestAssured.given().log().all()
                .header("Content-Type", "application/json")
                .header("Api-Key", "wrongapikey");
        return res;
    }

    public Response postAccountRegistration(Account account) {
        Response res = createApiWithApiKey()
                .body(account)
                .post(accountURL + "Registrations")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postAccountRegistrationWithoutAuthTokenAndApiKey(Account account) {
        Response res = createApiWithoutApiKeyAndAuthToken()
                .body(account)
                .post(accountURL + "Registrations")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postAccountRegistrationWithWrongApiKey(Account account) {
        Response res = createApiWithWrongApiKey()
                .body(account)
                .post(accountURL + "Registrations")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postAccountRegistrationWithAuthTokenAndWithoutApiKey(Account account) {
        Response res = createApiWithAuthToken()
                .body(account)
                .post(accountURL + "Registrations")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getAccountByEmail(Account account) {
        Response res = createDefaultApi()
                .get(accountURL + accountExtensionURL, account.getEmailAddress())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response putAccountUpdate(Account account) {
        Response res = createDefaultApi()
                .body(account)
                .put(accountURL + accountExtensionURL, account.getEmailAddress())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response deleteAccountByEmail(String email) {
        Response res = createDefaultApi()
                .delete(accountURL + accountExtensionURL, email)
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete account is " + res.getStatusCode());
        return res;
    }

    public Response deleteAccountByEmail(Account account) {
        Response res = createDefaultApi()
                .delete(accountURL + accountExtensionURL, account.getEmailAddress())
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete account is " + res.getStatusCode());
        return res;
    }

    public Response postEmailVerificationTokenGeneration(Account account) {
        Response res = createApiWithApiKey()
                .post(accountURL + tokenGenerationURL, account.getEmailAddress())
                .then().extract().response();
        if (res.statusCode() == 200)
            account.setVerificationToken(res.path("data"));
        res.print();
        return res;
    }

    public void verifyAccountCreatedFromUIUsingApi(String emailAddress) {
        Response generateTokenRes = createApiWithApiKey()
                .post(accountURL + tokenGenerationURL, emailAddress)
                .then().extract().response();
        String generatedToken = generateTokenRes.path("data");

        TokenVerification token = TokenVerification.builder().build();
        token.setVerificationToken(generatedToken);
        token.setEmailAddress(emailAddress);
        Response confirmRegEmailRes = createApiWithApiKey()
                .body(token)
                .post(accountURL + tokenVerificationURL)
                .then().extract().response();
    }

    public Response postEmailVerificationTokenGenerationWithoutAuthTokenAndApiKey(Account account) {
        Response res = createApiWithoutApiKeyAndAuthToken()
                .post(accountURL + tokenGenerationURL, account.getEmailAddress())
                .then().extract().response();
        if (res.statusCode() == 200)
            account.setVerificationToken(res.path("data"));
        res.print();
        return res;
    }

    public Response postEmailVerificationTokenGenerationWithWrongApiKey(Account account) {
        Response res = createApiWithWrongApiKey()
                .post(accountURL + tokenGenerationURL, account.getEmailAddress())
                .then().extract().response();
        if(res.statusCode() == 200)
            account.setVerificationToken(res.path("data"));
        res.print();
        return res;
    }

    public Response postEmailVerificationTokenGenerationWithAuthTokenAndWithoutApiKey(Account account) {
        Response res = createApiWithAuthToken()
                .post(accountURL + tokenGenerationURL, account.getEmailAddress())
                .then().extract().response();
        if(res.statusCode() == 200)
            account.setVerificationToken(res.path("data"));
        res.print();
        return res;
    }

    public Response getLeadsById(String leadId) {
        Response res = createDefaultApi()
                .get(leadsURL + "?Id=" + leadId)
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getLeadsByEmail(String email) {
        Response res =createDefaultApi()
                .get(leadsURL + "?Email=" + email)
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getLeadsByKey(String key) {
        Response res = createDefaultApi()
                .get(leadsURL + "GetByKey?key=" + key)
                .then().extract().response();
        res.print();
        return res;
    }


    public Response postGenerateOrOverwriteLeads(Lead lead, String email){
        Response res = createDefaultApi()
                .body(lead)
                .when().post(leadsURL + leadOverwriteOrGenerateURL, email)
                .then().extract().response();
        lead.setId(res.path("data.id"));
        res.print();
        return res;
    }


    public void deleteLeadByIdUsingGivenToken(String leadId, String token) {
      Objects.requireNonNull(leadId, "leadId must not be null");
      RestAssured.defaultParser = Parser.JSON;
      Response res = RestAssured.given().log().all()
                    .header("Authorization", "Bearer " + token)
                    .header("Content-Type", "application/json")
                    .delete(leadsURL + leadExtensionURL, leadId)
                    .then().extract().response();
      System.out.println("The delete status code is " + res.getStatusCode());
    }

    public Response deleteLeadById(String leadId) {
        Objects.requireNonNull(leadId, "leadId must not be null");
        Response res = createDefaultApi()
                .delete(leadsURL + leadExtensionURL, leadId)
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete lead is " + res.getStatusCode());
        return res;
    }

    public Response deleteLeadByIdWithoutAuthToken(String leadId) {
        Objects.requireNonNull(leadId, "leadId must not be null");
        Response res = createApiWithApiKey()
                .delete(leadsURL + leadExtensionURL, leadId)
                .then().extract().response();
        LogInfo.log_Status("The status code of delete lead is " + res.getStatusCode());
        return res;
    }

    public Response postEmailVerificationTokenVerification(Account account) {
        TokenVerification token = TokenVerification.builder().build();
        token.setVerificationToken(account.getVerificationToken());
        token.setEmailAddress(account.getEmailAddress());

        Response res = createApiWithApiKey()
                .body(token)
                .post(accountURL + tokenVerificationURL)
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postEmailVerificationTokenVerificationWithoutAuthTokenAndApiKey(Account account) {
        TokenVerification token = TokenVerification.builder().build();
        token.setVerificationToken(account.getVerificationToken());
        token.setEmailAddress(account.getEmailAddress());

        Response res = createApiWithoutApiKeyAndAuthToken()
                .body(token)
                .post(accountURL + tokenVerificationURL)
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postEmailVerificationTokenVerificationWithWrongApiKey(Account account) {
        TokenVerification token = TokenVerification.builder().build();
        token.setVerificationToken(account.getVerificationToken());
        token.setEmailAddress(account.getEmailAddress());

        Response res = createApiWithWrongApiKey()
                .body(token)
                .post(accountURL + tokenVerificationURL)
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postEmailVerificationTokenVerificationWithAuthTokenAndWithoutApiKey(Account account) {
        TokenVerification token = TokenVerification.builder().build();
        token.setVerificationToken(account.getVerificationToken());
        token.setEmailAddress(account.getEmailAddress());

        Response res = createApiWithAuthToken()
                .body(token)
                .post(accountURL + tokenVerificationURL)
                .then().extract().response();
        res.print();
        return res;
    }

    public void createAccountAndVerifyEmail(Account account){
      postAccountRegistration(account);
      postEmailVerificationTokenGeneration(account);
      postEmailVerificationTokenVerification(account);
    }

    public void resetPassword(Account account) {
        postResetPasswordTokenGeneration(account);
        postResetPasswordTokenVerification(account);
    }

    public Response postResetPasswordTokenGeneration(Account account) {
        Response res = createDefaultApi()
                .post(accountURL + resetPasswordTokenGenerationURL, account.getEmailAddress())
                .then().extract().response();
        if(res.statusCode() == 200)
            account.setVerificationToken(res.path("data"));
        res.print();
        return res;
    }

    public Response postResetPasswordTokenVerification(Account account) {
        String newPassword = "new" + account.getPassword();

        TokenVerification token = TokenVerification.builder().build();
        token.setVerificationToken(account.getVerificationToken());
        token.setPassword(newPassword);

        account.setPassword(newPassword);

        Response res = createDefaultApi()
                .body(token)
                .post(accountURL + resetPasswordTokenVerificationURL)
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postChangePassword(Account account) {
        Response res = createDefaultApi()
                .body(ChangePassword.builder(account))
                .post(accountURL + changePasswordURL)
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postChangePassword(ChangePassword changePassword) {
        Response res = createDefaultApi()
                .body(changePassword)
                .post(accountURL + changePasswordURL)
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postCompaniesSetup(Company company) {
        Response res = createDefaultApi()
                .body(company)
                .post(companiesURL + "Companies")
                .then().extract().response();
        if(res.statusCode() == 200) {
            company.setId(res.path("data.id"));
            Employee employee = company.getEmployees()[0];
            employee.setId(res.path("data.employees[0].id"));
            company.setEmployees(new Employee[]{employee});
        }
        res.print();
        return res;
    }

    public Company postCompaniesSetup(Account account) {
        Company company = Company.createDefaultCompany(account);
        Response res = createDefaultApi()
                .body(company)
                .post(companiesURL + "Companies")
                .then().extract().response();
        if(res.statusCode() == 200) {
            company.setId(res.path("data.id"));
            Employee employee = company.getEmployees()[0];
            employee.setId(res.path("data.employees[0].id"));
            company.setEmployees(new Employee[]{employee});
        }
        res.print();
        return company;
    }

    public Response getCompany(Company company) {
        Response res = createDefaultApi()
                .get(companiesURL + "Companies")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getCompanyByCompanyId(Company company) {
        Response res = createDefaultApi()
                .get(companiesURL + companiesExtensionURL, company.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getCompanyByCompanyFein(Company company) {
        Response res = createDefaultApi()
                .get(companiesURL + "Companies?FEIN=" + company.getFein())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getCompanyByCompanyEmail(String email) {
        Response res = createDefaultApi()
                .get(companiesURL + "Companies?EmployeeEmail=" + email)
                .then().extract().response();
        res.print();
        return res;
    }

    public String getCompanyIdByEmployeeEmail(String email) {
        String companyID = "";
        Response res = createDefaultApi()
                .get(companiesURL + "Companies?EmployeeEmail=" + email)
                .then().extract().response();
        res.print();
        if(res.statusCode() == 200){
            companyID = res.path("data.id").toString().replaceAll("[\\[w+\\]]","");
        }
        return companyID;
    }

    public Response putCompanyUpdate(Company company) {
        Response res = createDefaultApi()
                .body(company)
                .put(companiesURL + companiesExtensionURL, company.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response deleteCompanyByCompanyId(Company company) {
        return deleteCompanyByCompanyId(company.getId());
    }

    public Response deleteCompanyByCompanyId(String companyId) {
        Response res = createDefaultApi()
                .delete(companiesURL + companiesExtensionURL, companyId)
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company is " + res.getStatusCode());
        return res;
    }

    public Response postCompanyAddress(CompanyAddress address) {
        Response res = createDefaultApi()
                .body(address)
                .post(companiesURL + "CompanyAddresses")
                .then().extract().response();
        address.setId(res.path("data.id"));
        res.print();
        return res;
    }

    public Response getCompanyAddresses(String queryKey, String queryValue) {
        Response res = createDefaultApi()
                .queryParam(queryKey, queryValue)
                .get(companiesURL + "CompanyAddresses")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getCompanyAddress(CompanyAddress address) {
        Response res = createDefaultApi()
                .get(companiesURL + companyAddressesExtensionURL, address.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response putCompanyAddressUpdate(CompanyAddress address) {
        Response res = createDefaultApi()
                .body(address)
                .put(companiesURL + companyAddressesExtensionURL, address.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response deleteCompanyAddress(CompanyAddress address) {
        Response res = createDefaultApi()
                .delete(companiesURL + companyAddressesExtensionURL, address.getId())
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company Address is " + res.getStatusCode());
        return res;
    }

    public Response postBankAccount(CompanyBankAccount bankAccount) {
        Response res = createDefaultApi()
                .body(bankAccount)
                .post(companiesURL + "CompanyBankAccounts")
                .then().extract().response();
        bankAccount.setId(res.path("data.id"));
        res.print();
        return res;
    }

    public Response getBankAccounts(String queryKey, String queryValue) {
        Response res = createDefaultApi()
                .queryParam(queryKey, queryValue)
                .get(companiesURL + "CompanyBankAccounts")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getBankAccount(CompanyBankAccount bankAccount) {
        Response res = createDefaultApi()
                .get(companiesURL + bankAccountsExtensionURL, bankAccount.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response putBankAccount(CompanyBankAccount bankAccount) {
        Response res = createDefaultApi()
                .body(bankAccount)
                .put(companiesURL + bankAccountsExtensionURL, bankAccount.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response deleteBankAccount(CompanyBankAccount bankAccount) {
        Response res = createDefaultApi()
                .delete(companiesURL + bankAccountsExtensionURL, bankAccount.getId())
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company Bank Account is " + res.getStatusCode());
        return res;
    }

    public Response postBankAccountVerification(CompanyBankAccountVerification bankAccountVerification) {
        Response res = createDefaultApi()
                .body(bankAccountVerification)
                .post(companiesURL + "CompanyBankAccountVerification/FinishVerification")
                .then().extract().response();
        res.print();
        System.out.println("response above");
        return res;
    }

    public Response postCompanyPricing(CompanyPrice companyPrice) {
        Response res = createDefaultApi()
                .body(companyPrice)
                .post(companiesURL + "CompanyPricing")
                .then().extract().response();

        companyPrice.setId(res.path("data.id"));
        res.print();
        return res;
    }

    public Response getCompanyPricing(String queryKey, String queryValue) {
        Response res = createDefaultApi()
                .queryParam(queryKey, queryValue)
                .get(companiesURL + "CompanyPricing")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getCompanyPricing(CompanyPrice companyPrice) {
        Response res = createDefaultApi()
                .get(companiesURL + companyPricingExtensionURL, companyPrice.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response putCompanyPricing(CompanyPrice companyPrice) {
        Response res = createDefaultApi()
                .body(companyPrice)
                .put(companiesURL + companyPricingExtensionURL, companyPrice.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response deleteCompanyPricing(CompanyPrice companyPrice) {
        Response res = createDefaultApi()
                .delete(companiesURL + companyPricingExtensionURL, companyPrice.getId())
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company Pricing is " + res.getStatusCode());
        return res;
    }

    public Response deleteCompanyPricingByCompanyId(String companyPriceId) {
        Response res = createDefaultApi()
                .delete(companiesURL + companyPricingExtensionURL, companyPriceId)
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company Pricing is " + res.getStatusCode());
        return res;
    }

    public Response postCompanyFederalTaxes(CompanyFederalTaxes companyFederalTaxes) {
        Response res = createDefaultApi()
                .body(companyFederalTaxes)
                .post(companiesURL + "CompanyFederalTaxes")
                .then().extract().response();

        companyFederalTaxes.setId(res.path("data.id"));
        res.print();
        return res;
    }

    public Response getCompanyFederalTaxes(String queryKey, String queryValue) {
        Response res = createDefaultApi()
                .queryParam(queryKey, queryValue)
                .get(companiesURL + "CompanyFederalTaxes")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getCompanyFederalTaxes(CompanyFederalTaxes companyFederalTaxes) {
        Response res = createDefaultApi()
                .get(companiesURL + companyFederalTaxesExtensionURL, companyFederalTaxes.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response putCompanyFederalTaxes(CompanyFederalTaxes companyFederalTaxes) {
        Response res = createDefaultApi()
                .body(companyFederalTaxes)
                .put(companiesURL + companyFederalTaxesExtensionURL, companyFederalTaxes.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response deleteCompanyFederalTaxes(CompanyFederalTaxes companyFederalTaxes) {
        Response res = createDefaultApi()
                .delete(companiesURL + companyFederalTaxesExtensionURL, companyFederalTaxes.getId())
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company Federal Taxes is " + res.getStatusCode());
        return res;
    }

    public Response postCompanyStateTaxes(CompanyStateTaxes companyStateTaxes) {
        Response res = createDefaultApi()
                .body(companyStateTaxes)
                .post(companiesURL + "CompanyStateTaxes")
                .then().extract().response();

        companyStateTaxes.setId(res.path("data.id"));
        res.print();
        return res;
    }

    public Response getCompanyStateTaxes(String queryKey, String queryValue) {
        Response res = createDefaultApi()
                .queryParam(queryKey, queryValue)
                .get(companiesURL + "CompanyStateTaxes")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getCompanyStateTaxes(CompanyStateTaxes companyStateTaxes) {
        Response res = createDefaultApi()
                .get(companiesURL + companyStateTaxesExtensionURL, companyStateTaxes.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response putCompanyStateTaxes(CompanyStateTaxes companyStateTaxes) {
        Response res = createDefaultApi()
                .body(companyStateTaxes)
                .put(companiesURL + companyStateTaxesExtensionURL, companyStateTaxes.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response deleteCompanyStateTaxes(CompanyStateTaxes companyStateTaxes) {
        Response res = createDefaultApi()
                .delete(companiesURL + companyStateTaxesExtensionURL, companyStateTaxes.getId())
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company State Taxes is " + res.getStatusCode());
        return res;
    }

    public Response postCompanyAuthorizationForms(CompanyAuthorizationForm companyAuthorizationForm) {
        Response res = createDefaultApi()
                .body(companyAuthorizationForm)
                .post(companiesURL + "CompanyAuthorizationForms")
                .then().extract().response();

        companyAuthorizationForm.setId(res.path("data.id"));
        res.print();
        return res;
    }

    public Response getCompanyAuthorizationForms(String queryKey, String queryValue) {
        Response res = createDefaultApi()
                .queryParam(queryKey, queryValue)
                .get(companiesURL + "CompanyAuthorizationForms")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getCompanyAuthorizationForms(CompanyAuthorizationForm companyAuthorizationForm) {
        Response res = createDefaultApi()
                .get(companiesURL + companyAuthorizationFormsExtensionURL, companyAuthorizationForm.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response putCompanyAuthorizationForms(CompanyAuthorizationForm companyAuthorizationForm) {
        Response res = createDefaultApi()
                .body(companyAuthorizationForm)
                .put(companiesURL + companyAuthorizationFormsExtensionURL, companyAuthorizationForm.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response deleteCompanyAuthorizationForms(CompanyAuthorizationForm companyAuthorizationForm) {
        Response res = createDefaultApi()
                .delete(companiesURL + companyAuthorizationFormsExtensionURL, companyAuthorizationForm.getId())
                .then().extract().response();
        res.print();

        LogInfo.log_Status("The status code of delete Company Authorization Form is " + res.getStatusCode());
        return res;
    }

    public Response deleteCompanyAuthorizationFormsWithoutApiKey(CompanyAuthorizationForm companyAuthorizationForm) {
        Response res = createApiWithAuthToken()
                .delete(companiesURL + companyAuthorizationFormsExtensionURL, companyAuthorizationForm.getId())
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company Authorization Form is " + res.getStatusCode());
        return res;
    }

    public Response deleteCompanyAuthorizationFormsWithoutAuthToken(CompanyAuthorizationForm companyAuthorizationForm) {
        Response res = createApiWithApiKey()
                .delete(companiesURL + companyAuthorizationFormsExtensionURL, companyAuthorizationForm.getId())
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company Authorization Form is " + res.getStatusCode());
        return res;
    }

    public Response postCompanyUserAgreements(CompanyUserAgreement companyUserAgreement) {
        Response res = createDefaultApi()
                .body(companyUserAgreement)
                .post(companiesURL + "CompanyUserAgreements")
                .then().extract().response();

        res.print();
        if(res.statusCode()==200){
            companyUserAgreement.setId(res.path("data.id"));
            companyUserAgreement.setUserAgreementActionDateTime(res.path("data.userAgreementActionDateTime"));
        }
        return res;
    }

    public Response getCompanyUserAgreements(String queryKey, String queryValue) {
        Response res = createDefaultApi()
                .queryParam(queryKey, queryValue)
                .get(companiesURL + "CompanyUserAgreements")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getCompanyUserAgreements(CompanyUserAgreement companyUserAgreement) {
        Response res = createDefaultApi()
                .get(companiesURL + companyUserAgreementsExtensionURL, companyUserAgreement.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response putCompanyUserAgreements(CompanyUserAgreement companyUserAgreement) {
        Response res = createDefaultApi()
                .body(companyUserAgreement)
                .put(companiesURL + companyUserAgreementsExtensionURL, companyUserAgreement.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response deleteCompanyUserAgreements(CompanyUserAgreement companyUserAgreement) {
        Response res = createDefaultApi()
                .delete(companiesURL + companyUserAgreementsExtensionURL, companyUserAgreement.getId())
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company User Agreement is " + res.getStatusCode());
        return res;
    }

    public Response deleteCompanyUserAgreementsWithoutAuthToken(CompanyUserAgreement companyUserAgreement) {
        Response res = createApiWithApiKey()
                .delete(companiesURL + companyUserAgreementsExtensionURL, companyUserAgreement.getId())
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company User Agreement is " + res.getStatusCode());
        return res;
    }

    public Response deleteCompanyUserAgreementsWithoutApiKey(CompanyUserAgreement companyUserAgreement) {
        Response res = createApiWithAuthToken()
                .delete(companiesURL + companyUserAgreementsExtensionURL, companyUserAgreement.getId())
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company User Agreement is " + res.getStatusCode());
        return res;
    }

    public Response postCompanyAddOns(CompanyAddOn companyAddOn) {
        Response res = createDefaultApi()
                .body(companyAddOn)
                .post(companiesURL + "CompanyAddOns")
                .then().extract().response();

        companyAddOn.setId(res.path("data.id"));
        res.print();
        return res;
    }

    public Response getCompanyAddOns(String queryKey, String queryValue) {
        Response res = createDefaultApi()
                .queryParam(queryKey, queryValue)
                .get(companiesURL + "CompanyAddOns")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getCompanyAddOnWithoutQueryParameter(CompanyAddOn companyAddOn) {
        Response res = createDefaultApi()
                .get(companiesURL + "CompanyAddOns")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getCompanyAddOn(CompanyAddOn companyAddOn) {
        Response res = createDefaultApi()
                .get(companiesURL + companyAddOnExtensionURL, companyAddOn.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response putCompanyAddOns(CompanyAddOn companyAddOn) {
        Response res = createDefaultApi()
                .body(companyAddOn)
                .put(companiesURL + companyAddOnExtensionURL, companyAddOn.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postLeadCreation(String token, Lead body, String URL) {
        Response res = RestAssured.given().log().all()
                .relaxedHTTPSValidation()
                .contentType("application/json")
                .header("Authorization", "Bearer " + token)
                .body(body)
                .header("accept", "application/json")
                .header("Content-Type", "application/json")
                .when().post(URL)
                .then().extract().response();
        res.print();
        return res;
    }



    public Response deleteCompanyAddOns(CompanyAddOn companyAddOn) {
        Response res = createDefaultApi()
                .delete(companiesURL + companyAddOnExtensionURL, companyAddOn.getId())
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company Addon is " + res.getStatusCode());
        return res;
    }

    public Response getCompanySummary(CompanySummary companySummary) {
        Response res = createDefaultApi()
                .get(companiesURL + companySummaryExtensionURL, companySummary.getCompanyInfo().getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getAccountAuthorizationPage() {
        Response res = RestAssured.given().log().all()
                .header("Content-Type", "application/json")
                .queryParam("client_id", "spa")
                .queryParam("scope", "openid accounts companies decisions")
                .queryParam("response_type", "code")
                .queryParam("redirect_uri", "https://dlx-cob-spa-uat.herokuapp.com/signin-oidc")
                .queryParam("code_challenge", "QVp10y0NrlQ1LFGe_8cyXv-BMKZJ738RY9L-1e0KQ7c")
                .queryParam("code_challenge_method", "S256")
                .get(environment.getDO_IdentityServer_URL() + "/connect/authorize")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postGetAccountToken(String code) {
        Response res = RestAssured.given().log().all()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .formParams("grant_type", "authorization_code")
                .formParams("client_id", "0oa1phdp2bGVGczbh1d7")
                .formParams("code", code)
                .formParams("scope", "openid accounts companies")
                .formParams("code_verifier", "xNA_ZIPovvFBPVZFtSPWyb6aHewYJAS1YZ1vqs2Cq8xx0Nl2izCP-10~SMFIQeeztfzfJXGiHmeCNy-9BfW008I3DLklZgxe6R4d3YdAfG01N_e8ISU.amBnhPJyQ9dN")
                .formParams("redirect_uri", "https://dlx-cob-spa-qa.herokuapp.com/login/callback")
                .post("https://login-duo.dev.deluxe.com/oauth2/default/v1/token")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postGetAccountTokenIntrospect(String token) {
        Response res = RestAssured.given().log().all()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .auth().preemptive().basic("decisions", "TeamGroguPayce1579")
                .formParams("token", token)
                .post(environment.getDO_IdentityServer_URL() + "/connect/introspect")
                .then().extract().response();
        res.print();
        return res;
    }

    public String getCode(String url) {
        Pattern pattern = Pattern.compile("(?<=code=).*(?=&state)");
        Matcher matcher = pattern.matcher(url);
        matcher.find();
        return matcher.group(0);
    }

    public String postAdminAuthorization() {
        Response res = RestAssured.given().log().all()
                .header("Content-Type", "application/x-www-form-urlencoded")
                .formParam("grant_type", "client_credentials")
                .formParam("client_id", "0oa1qilis1nv1hhLX1d7")
                .formParam("client_secret", "p0Pkn0r-BtaZANrEli7vgiiEZMhwSXSTO0l9-Jcm")
                .formParam("scope", "accounts companies")
                .post("https://login-duo.dev.deluxe.com/oauth2/default/v1/token")
                .then().extract().response();
        res.print();
        String token = res.path("access_token");
        return token;
    }

    public Response postCompanyAuthorizedUserInvitation(CompanyAuthorizedUserInvitation invitation) {
        Response res = createDefaultApi()
                .body(invitation)
                .post(companiesURL + companyAuthorizedUserInvitationURL)
                .then().extract().response();
        if(res.statusCode() == 200) {
            invitation.setId(res.path("data.id"));
            invitation.setContactInvitationLinkId(res.path("data.contactInvitationLinkId"));
            invitation.setStatus(res.path("data.status"));
            invitation.setCompanyName(res.path("data.companyName"));
            invitation.setOtherRoleText(res.path("data.otherRoleText"));
        }
        res.print();
        return res;
    }

    public Response getCompanyAuthorizedUserInvitationByLinkId(CompanyAuthorizedUserInvitation invitation) {
        Response res = createDefaultApi()
                .queryParam("InvitationLinkId", invitation.getContactInvitationLinkId())
                .get(companiesURL + companyAuthorizedUserInvitationURL + "/ReturnInvitationFromLinkId")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getCompanyAuthorizedUserInvitationByCompanyId(CompanyAuthorizedUserInvitation invitation) {
        Response res = createDefaultApi()
                .queryParam("CompanyId", invitation.getCompanyId())
                .get(companiesURL + companyAuthorizedUserInvitationURL + "/GetInvitationFromCompanyId")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getEmployeeById(Employee employee) {
        Response res = createDefaultApi()
                .get(companiesURL + companyEmployeesURL, employee.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response deleteEmployeeById(Employee employee) {
        Response res = createDefaultApi()
                .delete(companiesURL + companyEmployeesURL, employee.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response putUpdateEmployeeById(Employee employee) {
        Response res = createDefaultApi()
                .body(employee)
                .put(companiesURL + companyEmployeesURL, employee.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postConsumeAuthorizedUserInvite(CompanyAuthorizedUserInvitation invitation) {
        CompanyAuthorizedUserInvitation body = CompanyAuthorizedUserInvitation.internalbuilder().contactInvitationLinkId(invitation.getContactInvitationLinkId()).build();
        Response res = createDefaultApi()
                .body(body)
                .post(companiesURL + "CompanyEmployees/ConsumeInvitationLink")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getCreditAuthorizationFormByCompanyId(Company company){
        Response res = createDefaultApi()
                .get(companiesURL + "Companies/CreditAuthorizationForm/{id}", company.getId())
                .then().extract().response();
        res.print();
        return res;
    }

    public Response deleteCreditAuthorizationFormByCompanyId(Company company){
        Response res = createDefaultApi()
                .delete(companiesURL + "Companies/CreditAuthorizationForm/{id}", company.getId())
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company Credit Authorization is " + res.getStatusCode());
        return res;
    }

    public Response deleteCreditAuthorizationFormByCompanyId(String id){
        Response res = createDefaultApi()
                .delete(companiesURL + "Companies/CreditAuthorizationForm/{id}", id)
                .then().extract().response();
        res.print();
        LogInfo.log_Status("The status code of delete Company Credit Authorization is " + res.getStatusCode());
        return res;
    }

    public Response postCommercialCreditCheck(CommercialCreditCheck creditCheck){
        Response res = createDefaultApi()
                .body(creditCheck)
                .post(companiesURL + "Companies/CommercialCreditCheck")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postConsumerCreditCheck(ConsumerCreditCheck creditCheck){
        Response res = createDefaultApi()
                .body(creditCheck)
                .post(companiesURL + "Companies/ConsumerCreditCheck")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response postCreditAuthorizationForm(CreditAuthorizationForm creditAuthorizationForm){
        Response res = createDefaultApi()
                .body(creditAuthorizationForm)
                .post(companiesURL + "Companies/CreditAuthorizationForm")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response putCreditAuthorizationForm(CreditAuthorizationForm creditAuthorizationForm){
        Response res = createDefaultApi()
                .body(creditAuthorizationForm)
                .put(companiesURL + "Companies/CreditAuthorizationForm")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response putCompanyAuthorizedUserInvitation(CompanyAuthorizedUserInvitation invitation) {
        CompanyAuthorizedUserInvitation body = CompanyAuthorizedUserInvitation.internalbuilder().id(invitation.getId()).build();
        Response res = createDefaultApi()
                .body(body)
                .put(companiesURL + "Companies/CompanyAuthorizedUserInvitations/InactivateActiveUserInvitation")
                .then().extract().response();
        res.print();
        return res;
    }

    public Response getCreditAuthorizationFormByFailedSubmission(CreditAuthorizationForm_FailedSubmission creditAuthorizationFormFailedSubmission){
        Response res = createDefaultApi()
                .queryParam("CompanyId", creditAuthorizationFormFailedSubmission.getCompanyId())
                .queryParam("IpAddress", creditAuthorizationFormFailedSubmission.getIpAddress())
                .get(companiesURL + "Companies/CreditAuthorizationForm/CreditSubmission")
                .then().extract().response();
        res.print();
        return res;
    }


    public Response postCreditAuthorizationFormFailedSubmission(CreditAuthorizationForm_FailedSubmission creditAuthorizationFormFailedSubmission){
        Response res = createDefaultApi()
                .body(creditAuthorizationFormFailedSubmission)
                .post(companiesURL + "Companies/CreditAuthorizationForm/FailedSubmission")
                .then().extract().response();
        res.print();
        return res;
    }
}