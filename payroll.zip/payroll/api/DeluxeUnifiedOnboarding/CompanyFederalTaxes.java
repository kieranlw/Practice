package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.util.Random;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompanyFederalTaxes {

    private String federalFilingForm;

    private Boolean isSeasonalEmployer;

    private String federalDepositFrequency;

    private String naicsCode;

    private String workerTypesPaying;

    private Boolean charity501C3;

    private String fileName;

    private String companyId;

    private String fein;

    private String id;

    public enum FederalFilingForm {
        FederalFilingForm941("941 Employer's QUARTERLY Federal Tax Return"),
        FederalFilingForm943("943 Employer's ANNUAL Federal Tax Return for Agricultural Employees"),
        FederalFilingForm944("944 Employer's ANNUAL Federal Tax Return");

        public final String message;

        FederalFilingForm(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }

    public enum FederalDepositFrequency {
        PerPaySemiWeekly("Per Pay (Semi-Weekly)"),
        Monthly("Monthly");

        public final String message;

        FederalDepositFrequency(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }

    public enum TenNinetyNineContractor {
        W2Only("W-2 employees only"),
        W2And1099("W-2 and 1099 employes"),
        Only1099("1099 employees only");

        public final String message;

        TenNinetyNineContractor(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }


    public static CompanyFederalTaxes createDefaultCompanyFederalTaxes(Company company) {
        return builder()
                .federalFilingForm(getRandomFederalFilingForm())
                .isSeasonalEmployer(true)
                .federalDepositFrequency(getRandomFederalDepositFrequency())
                .naicsCode("123456")
                .workerTypesPaying(getRandom1099Contractor())
                .charity501C3(true)
                .fileName("irsProof3.pdf")
                .companyId(company.getId())
                .fein(company.getFein())
                .build();
    }

    public static CompanyFederalTaxes createUpdatedCompanyFederalTaxes(CompanyFederalTaxes companyFederalTaxes) {
        return builder()
                .federalFilingForm(getRandomFederalFilingForm())
                .isSeasonalEmployer(false)
                .federalDepositFrequency(getRandomFederalDepositFrequency())
                .naicsCode("654321")
                .workerTypesPaying(getRandom1099Contractor())
                .charity501C3(false)
                .fileName("updatedTestFile.pdf")
                .id(companyFederalTaxes.getId())
                .companyId(companyFederalTaxes.getCompanyId())
                .fein(companyFederalTaxes.getFein())
                .build();
    }

    public static String getRandomFederalFilingForm() {
        FederalFilingForm [] array = FederalFilingForm.values();
        Random random = new Random();
        return array[random.nextInt(array.length)].name();
    }

    public static String getRandomFederalDepositFrequency() {
        FederalDepositFrequency [] array = FederalDepositFrequency.values();
        Random random = new Random();
        return array[random.nextInt(array.length)].name();
    }

    public static String getRandom1099Contractor() {
        TenNinetyNineContractor [] array = TenNinetyNineContractor.values();
        Random random = new Random();
        return array[random.nextInt(array.length)].name();
    }
}
