package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.util.Random;

@Data
@Builder(toBuilder = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompanyStateTaxes {

    private String state;

    private String withholdingStatus;

    private String withholdingStatusWaiverFileName;

    private String withholdingId;

    private String sitFrequency;

    private String stateWithholdingProofFileName;

    private String unemploymentStatus;

    private String unemploymentId;

    private String unemploymentSuiRate;

    private String unemploymentProofFileName;

    private String companyId;

    @JsonIgnore
    private String fein;

    @JsonIgnore
    private String id;

    public enum Statuses {
        Active,
        AppliedForPending,
        Exempt,
        Inactive,
        NA
    }


    public static CompanyStateTaxes createDefaultCompanyStateTaxes(Company company) {
        return CompanyStateTaxes.builder().state("GA")
                                      .withholdingStatus(Statuses.Active.name())
                                      .withholdingId("0123456789")
                                      .sitFrequency("SIT Frequency")
                                      .stateWithholdingProofFileName("withholdingFileName.pdf")
                                      .unemploymentStatus(Statuses.Active.name())
                                      .unemploymentId("Unemployment ID")
                                      .unemploymentSuiRate("SUI Rate")
                                      .unemploymentProofFileName("unemploymentFileName.pdf")
                                      .companyId(company.getId())
                                      .fein(company.getFein())
                                      .build();
    }

    public static CompanyStateTaxes createUpdatedCompanyStateTaxes(CompanyStateTaxes companyStateTaxes) {
        return CompanyStateTaxes.builder().state("MN")
                                      .withholdingStatus(Statuses.Active.name())
                                      .withholdingId("9876543210")
                                      .sitFrequency("Updated SIT Frequency")
                                      .stateWithholdingProofFileName("updatedWithholdingFileName.pdf")
                                      .unemploymentStatus(Statuses.Active.name())
                                      .unemploymentId("Updated Unemployment ID")
                                      .unemploymentSuiRate("Updated SUI Rate")
                                      .unemploymentProofFileName("updatedUnemploymentFileName.pdf")
                                      .id(companyStateTaxes.getId())
                                      .companyId(companyStateTaxes.getCompanyId())
                                      .fein(companyStateTaxes.getFein())
                                      .build();
    }

    public static String getRandomStatus() {
        CompanyStateTaxes.Statuses [] statusArray = CompanyStateTaxes.Statuses.values();
        Random random = new Random();
        return statusArray[random.nextInt(statusArray.length)].name();
    }
}
