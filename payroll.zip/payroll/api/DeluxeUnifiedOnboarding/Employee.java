package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Employee
{
    private String firstName;

    private String lastName;

    private String emailAddress;

    private String role;

    private String otherRoleText;

    private Boolean originalEmployee;

    private String preferredContactMethod;

    private String id;


    public static Employee createDefaultEmployee() {
        return builder()
                .firstName("Test")
                .lastName("User")
                .emailAddress(Account.generateRandomEmailAddress())
                .role("Owner")
                .preferredContactMethod("Phone")
                .originalEmployee(true)
                .build();
    }

    public static Employee createUpdatedEmployee(Employee employee) {
        return builder()
                .firstName("Updated First")
                .lastName("Updated Last")
                .emailAddress(employee.getEmailAddress())
                .role("Other")
                .otherRoleText("The Big Boss")
                .preferredContactMethod("Email")
                .id(employee.getId())
                .build();
    }

    public static Employee [] setEmployeeFromAccount(Account account) {
        return new Employee [] {
                builder()
                        .firstName(account.getFirstName())
                        .lastName(account.getLastName())
                        .emailAddress(account.getEmailAddress())
                        .role("Owner")
                        .preferredContactMethod("Phone")
                        .originalEmployee(true)
                        .build()
        };
    }
}
