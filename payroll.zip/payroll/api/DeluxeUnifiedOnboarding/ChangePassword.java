package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder(builderMethodName = "internalBuilder")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChangePassword {

    private String emailAddress;

    private String oldPassword;

    private String newPassword;

    public static ChangePassword builder(Account account) {
        return internalBuilder().emailAddress(account.getEmailAddress())
                                   .oldPassword(account.getPassword())
                                   .newPassword("Updated***" + account.getPassword()).build();
    }

}
