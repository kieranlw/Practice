package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompanyBankAccountVerification {

    private String companyId;

    @JsonProperty("bankAccountId")
    private String id;

    private BigDecimal firstDeposit;

    private BigDecimal secondDeposit;

    @JsonIgnore
    private Boolean isSuccessful;

    @JsonIgnore
    private String deposit1Error;

    @JsonIgnore
    private String deposit2Error;

    @JsonIgnore
    private String error;


    public static CompanyBankAccountVerification createDefaultBankAccountVerification(CompanyBankAccount bankAccount) {
        return builder()
                .companyId(bankAccount.getCompanyId())
                .id(bankAccount.getId())
                .firstDeposit(new BigDecimal("0.10"))
                .secondDeposit(new BigDecimal("0.10"))
                .build();
    }
}
