package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder(builderMethodName = "internalBuilder")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AdminAuthorization {

    private String grantType;

    private String clientId;

    private String clientSecret;

    private String scope;

    public static AdminAuthorization builder() {
        return internalBuilder().grantType("client_credentials")
                .clientId("client_credentials")
                .clientSecret("MscYUvHGexyckz8can4MQz8np")
                .scope("companies")
                .build();
    }



}
