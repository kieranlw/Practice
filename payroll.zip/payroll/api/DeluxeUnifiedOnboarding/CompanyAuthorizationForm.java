package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompanyAuthorizationForm {

    private String form8655FileName;

    private String form8832FileName;

    private String directDepositAuthorizationFormFileName;

    private String personalGuaranteeFormFileName;

    private String beneficialOwnershipFormFileName;

    private String companyId;

    @JsonIgnore
    private String fein;

    @JsonIgnore
    private String id;

    public static CompanyAuthorizationForm createDefaultCompanyAuthorizationForm(Company company) {
        return builder()
                .companyId(company.getId())
                .fein(company.getFein())
                .form8655FileName("form8655.pdf")
                .form8832FileName("form8832.pdf")
                .directDepositAuthorizationFormFileName("directDepositAuthorization.pdf")
                .personalGuaranteeFormFileName("personalGuarantee.pdf")
                .beneficialOwnershipFormFileName("beneficialOwnership.pdf")
                .build();
    }

    public static CompanyAuthorizationForm createUpdatedCompanyAuthorizationForm(CompanyAuthorizationForm companyAuthorizationForm) {
        return builder()
                .id(companyAuthorizationForm.getId())
                .companyId(companyAuthorizationForm.getCompanyId())
                .fein(companyAuthorizationForm.getFein())
                .form8655FileName("updatedForm8655.pdf")
                .form8832FileName("updatedForm8832.pdf")
                .directDepositAuthorizationFormFileName("updatedDirectDepositAuthorization.pdf")
                .personalGuaranteeFormFileName("updatedPersonalGuarantee.pdf")
                .beneficialOwnershipFormFileName("updatedBeneficialOwnership.pdf")
                .build();
    }
}
