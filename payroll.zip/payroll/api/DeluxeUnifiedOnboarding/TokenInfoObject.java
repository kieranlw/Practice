package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TokenInfoObject {

    private String id_token;

    private String scope;

    private String access_token;

    private String expires_in;

    private String token_type;
}
