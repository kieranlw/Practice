package payroll.api.DeluxeUnifiedOnboarding;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompanySummary {

    private Company companyInfo;

    private CompanyPrice packageSelection;

    private CompanyAddOn companyAddOns;

    private CompanyAddress [] companyAddresses;

    private CreditAuthorizationForm creditAuthorization;

    private CompanyBankAccount [] bankAccounts;

    private CompanyFederalTaxes federalTaxInfo;

    private CompanyStateTaxes [] stateTaxInfo;

    private CompanyAuthorizationForm authorizationForms;

    private Employee employee;


    public enum PackageAddOnPrices {
        None("None--None"),
        Package1("Lite: The Payroll Package--$39/month\n$7/employee monthly"),
        Package2("Blended: The HR Package--$49/month\n$7/employee monthly"),
        Package3("The Works: All-Access Package--$39/month\n$12/employee monthly"),
        BenefitsAdministration("+$5/employee monthly"),
        UnlimitedWorkFlows("+$5/employee monthly"),
        TimeTrackingAndProjectFlows("+$3/employee monthly"),
        PTOAccrualPolicies("+$3/employee monthly"),
        Posters("+$30 one-time fee"),
        HeroBasePackage("Hero base Package--+$49/month"),
        Plus("Plus--+$229/month"),
        Pro("Pro--+$339/month"),
        Support("Support--Free"),
        OnDemand("On demand--+$20/month"),
        Complete("Complete--+$450/month"),
        Learn1("Learn 1--+$2/employee monthly\nplus $200 one-time setup fee"),
        Learn2("Learn 2--+$3/employee monthly\nplus $200 one-time setup fee"),
        Learn3("Learn 3--+$3/employee monthly\nplus $200 one-time setup fee"),
        HRHandbookReview("HR Handbook Review--+$599 one-time fee"),
        HRHandbookCreation("HR Handbook Creation--+$799 one-time fee"),
        HRWizardHandbookCreation("HR Wizard - handbook creation--Free");

        public final String message;

        PackageAddOnPrices(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }

    public static CompanySummary createDefaultCompanySummary() {
        Company company = Company.createDefaultCompany();
        return builder()
                .companyInfo(company)
                .packageSelection(CompanyPrice.createDefaultCompanyPrice(company))
                .companyAddOns(CompanyAddOn.createDefaultCompanyAddOn(company))
                .companyAddresses(new CompanyAddress [] {CompanyAddress.createDefaultAddress(company), CompanyAddress.createDefaultAddress(company,"MailingAddress"), CompanyAddress.createDefaultAddress(company, "WorkLocationAddress")})
                .bankAccounts(new CompanyBankAccount [] {CompanyBankAccount.createDefaultBankAccountAllUses(company)})
                .federalTaxInfo(CompanyFederalTaxes.createDefaultCompanyFederalTaxes(company))
                .stateTaxInfo(new CompanyStateTaxes [] {CompanyStateTaxes.createDefaultCompanyStateTaxes(company)})
                .authorizationForms(CompanyAuthorizationForm.createDefaultCompanyAuthorizationForm(company))
                .build();
    }

    public static CompanySummary createDefaultCompanySummary(Company company) {

        return builder()
                .companyInfo(company)
                .packageSelection(CompanyPrice.createDefaultCompanyPrice(company))
                .companyAddOns(CompanyAddOn.createDefaultCompanyAddOn(company))
                .companyAddresses(new CompanyAddress [] {CompanyAddress.createDefaultAddress(company), CompanyAddress.createDefaultAddress(company,"MailingAddress"), CompanyAddress.createDefaultAddress(company, "WorkLocationAddress")})
                .bankAccounts(new CompanyBankAccount [] {CompanyBankAccount.createDefaultBankAccountAllUses(company)})
                .federalTaxInfo(CompanyFederalTaxes.createDefaultCompanyFederalTaxes(company))
                .stateTaxInfo(new CompanyStateTaxes [] {CompanyStateTaxes.createDefaultCompanyStateTaxes(company)})
                .authorizationForms(CompanyAuthorizationForm.createDefaultCompanyAuthorizationForm(company))
                .build();
    }

    public void updateCompanyInfo(Company companyInfo) {
        this.companyInfo.setId(companyInfo.getId());
        this.companyInfo.setFein(companyInfo.getFein());
        this.packageSelection.setCompanyId(companyInfo.getId());
        this.packageSelection.setFein(companyInfo.getFein());
        this.companyAddOns.setCompanyId(companyInfo.getId());
        this.companyAddOns.setFein(companyInfo.getFein());
        this.companyAddresses[0].setCompanyId(companyInfo.getId());
        this.companyAddresses[0].setFein(companyInfo.getFein());
        this.companyAddresses[1].setCompanyId(companyInfo.getId());
        this.companyAddresses[1].setFein(companyInfo.getFein());
        this.companyAddresses[2].setCompanyId(companyInfo.getId());
        this.companyAddresses[2].setFein(companyInfo.getFein());
        this.bankAccounts[0].setCompanyId(companyInfo.getId());
        this.bankAccounts[0].setFein(companyInfo.getFein());
        this.federalTaxInfo.setCompanyId(companyInfo.getId());
        this.federalTaxInfo.setFein(companyInfo.getFein());
        this.stateTaxInfo[0].setCompanyId(companyInfo.getId());
        this.stateTaxInfo[0].setFein(companyInfo.getFein());
        this.authorizationForms.setCompanyId(companyInfo.getId());
        this.authorizationForms.setFein(companyInfo.getFein());
    }
}
