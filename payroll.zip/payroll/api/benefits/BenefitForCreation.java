package payroll.api.benefits;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BenefitForCreation
{
    @JsonProperty("description")
    private String description;
    @JsonProperty("employeePortion")
    private CompanyLevelEmployeePortion employeePortion;
    @JsonProperty("employerPortion")
    private CompanyLevelEmployerPortion employerPortion;
    @JsonProperty("active")
    private boolean active;


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public CompanyLevelEmployeePortion getEmployeePortion() {
        return employeePortion;
    }

    public void setEmployeePortion(CompanyLevelEmployeePortion employeePortion) {
        this.employeePortion = employeePortion;
    }

    public CompanyLevelEmployerPortion getEmployerPortion() {
        return employerPortion;
    }

    public void setEmployerPortion(CompanyLevelEmployerPortion employerPortion) {
        this.employerPortion = employerPortion;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public static BenefitForCreation getDefaultBenefit(String description){
        BenefitForCreation benefitToCreate = new BenefitForCreation();
        benefitToCreate.setDescription(description);
        benefitToCreate.setActive(true);

        CompanyLevelEmployeePortion employeePortion = new CompanyLevelEmployeePortion();
        employeePortion.setClassOfBenefit("DeferredCompAnd401K");
        employeePortion.setFrequency("EveryPay");
        benefitToCreate.setEmployeePortion(employeePortion);

        CompanyLevelEmployerPortion employerPortion = new CompanyLevelEmployerPortion();
        employerPortion.setFrequency("EveryPay");
        employerPortion.setType("MatchPctOfDeduction");
        employerPortion.setSafeHarborContribution(true);
        employerPortion.setMaxPercentOfGross(100.0);
        employerPortion.setPercentOfDeduction(null);
        employerPortion.setTier2Match(true);
        employerPortion.setTier2MaxGrossPercent(3.00);
        employerPortion.setTier2Percent(1.0);
        employerPortion.setAnnualMax("5000.00");
        benefitToCreate.setEmployerPortion(employerPortion);

        return benefitToCreate;
    }


}
