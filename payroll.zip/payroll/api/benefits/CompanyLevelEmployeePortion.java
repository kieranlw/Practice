package payroll.api.benefits;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyLevelEmployeePortion
{
    @JsonProperty("class")
    private String classOfBenefit;
    @JsonProperty("frequency")
    private String frequency;

    public String getClassOfBenefit() {
        return classOfBenefit;
    }

    public void setClassOfBenefit(String classOfBenefit) {
        this.classOfBenefit = classOfBenefit;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }
}
