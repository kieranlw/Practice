package payroll.api.benefits.enroll;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.LocalDate;
import java.util.UUID;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DependentForUpdate {

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("middleName")
    private String middleName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("birthDate")
    private String birthDate;

    @JsonProperty("acaCoverageType")
    private String acaCoverageType;

    @JsonProperty("relationshipType")
    private String relationshipType;

    @JsonProperty("legalGender")
    private String legalGender;

    @JsonProperty("tobaccoUser")
    private Boolean tobaccoUser;

    @JsonProperty("fulltimeStudent")
    private Boolean fulltimeStudent;

    @JsonProperty("isDisabled")
    private Boolean isDisabled;

    @JsonProperty("suffix")
    private String suffix;

    @JsonProperty("effectiveFromDate")
    private String effectiveFromDate;

    @JsonProperty("effectiveToDate")
    private String effectiveToDate;

    public String getFirstName() {
        return firstName;
    }

    public DependentForUpdate setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public String getMiddleName() {
        return middleName;
    }

    public DependentForUpdate setMiddleName(String middleName) {
        this.middleName = middleName;
        return this;
    }

    public String getLastName() {
        return lastName;
    }

    public DependentForUpdate setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public DependentForUpdate setBirthDate(String birthDate) {
        this.birthDate = birthDate;
        return this;
    }

    public String getAcaCoverageType() {
        return acaCoverageType;
    }

    public DependentForUpdate setAcaCoverageType(String acaCoverageType) {
        this.acaCoverageType = acaCoverageType;
        return this;
    }

    public String getRelationshipType() {
        return relationshipType;
    }

    public DependentForUpdate setRelationshipType(String relationshipType) {
        this.relationshipType = relationshipType;
        return this;
    }

    public String getLegalGender() {
        return legalGender;
    }

    public DependentForUpdate setLegalGender(String legalGender) {
        this.legalGender = legalGender;
        return this;
    }

    public Boolean getTobaccoUser() {
        return tobaccoUser;
    }

    public DependentForUpdate setTobaccoUser(Boolean tobaccoUser) {
        this.tobaccoUser = tobaccoUser;
        return this;
    }

    public Boolean getFulltimeStudent() {
        return fulltimeStudent;
    }

    public DependentForUpdate setFulltimeStudent(Boolean fulltimeStudent) {
        this.fulltimeStudent = fulltimeStudent;
        return this;
    }

    public Boolean getIsDisabled() {
        return isDisabled;
    }

    public DependentForUpdate setIsDisabled(Boolean isDisabled) {
        this.isDisabled = isDisabled;
        return this;
    }

    public String getSuffix() {
        return suffix;
    }

    public DependentForUpdate setSuffix(String suffix) {
        this.suffix = suffix;
        return this;
    }

    public String getEffectiveFromDate() {
        return effectiveFromDate;
    }

    public DependentForUpdate setEffectiveFromDate(String effectiveFromDate) {
        this.effectiveFromDate = effectiveFromDate;
        return this;
    }

    public String getEffectiveToDate() {
        return effectiveToDate;
    }

    public DependentForUpdate setEffectiveToDate(String effectiveToDate) {
        this.effectiveToDate = effectiveToDate;
        return this;
    }

}
