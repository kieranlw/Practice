package payroll.api.benefits.enroll;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import utils2.JavaTimeUtils;

import java.time.LocalDate;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeeForUpdate {

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("middleName")
    private String middleName;

    @JsonProperty("suffix")
    private String suffix;

    @JsonProperty("address1")
    private String address1;

    @JsonProperty("address2")
    private String address2;

    @JsonProperty("city")
    private String city;

    @JsonProperty("state")
    private String state;

    @JsonProperty("zip")
    private String zip;

    @JsonProperty("phone")
    private String phone;

    @JsonProperty("gender")
    private String gender;

    @JsonProperty("Email")
    private String email;

    @JsonProperty("birthDate")
    private String birthDate;

    @JsonProperty("maritalStatus")
    private String maritalStatus;

    @JsonProperty("status")
    private String status;

    @JsonProperty("ssn")
    private String ssn;

    public String getFirstName() {
        return firstName;
    }

    public EmployeeForUpdate setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public String getLastName() {
        return lastName;
    }

    public EmployeeForUpdate setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public String getMiddleName() {
        return middleName;
    }

    public EmployeeForUpdate setMiddleName(String middleName) {
        this.middleName = middleName;
        return this;
    }

    public String getSuffix() {
        return suffix;
    }

    public EmployeeForUpdate setSuffix(String suffix) {
        this.suffix = suffix;
        return this;
    }

    public String getAddress1() {
        return address1;
    }

    public EmployeeForUpdate setAddress1(String address1) {
        this.address1 = address1;
        return this;
    }

    public String getAddress2() {
        return address2;
    }

    public EmployeeForUpdate setAddress2(String address2) {
        this.address2 = address2;
        return this;
    }

    public String getCity() {
        return city;
    }

    public EmployeeForUpdate setCity(String city) {
        this.city = city;
        return this;
    }

    public String getState() {
        return state;
    }

    public EmployeeForUpdate setState(String state) {
        this.state = state;
        return this;
    }

    public String getZip() {
        return zip;
    }

    public EmployeeForUpdate setZip(String zip) {
        this.zip = zip;
        return this;
    }

    public String getPhone() {
        return phone;
    }

    public EmployeeForUpdate setPhone(String phone) {
        this.phone = phone;
        return this;
    }

    public String getGender() {
        return gender;
    }

    public EmployeeForUpdate setGender(String gender) {
        this.gender = gender;
        return this;
    }

    public String getEmail() {
        return email;
    }

    public EmployeeForUpdate setEmail(String email) {
        this.email = email;
        return this;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public EmployeeForUpdate setBirthDate(LocalDate birthDate) {
        this.birthDate = JavaTimeUtils.getLocalDateString(birthDate, "MM/dd/yyyy");
        return this;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public EmployeeForUpdate setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
        return this;
    }

    public String getStatus() {
        return status;
    }

    public EmployeeForUpdate setStatus(String status) {
        this.status = status;
        return this;
    }

    public String getSsn() {
        return ssn;
    }

    public EmployeeForUpdate setSsn(String ssn) {
        this.ssn = ssn;
        return this;
    }
}
