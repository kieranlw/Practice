package payroll.api.benefits.enroll;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeeBenefitUpdate
{
	//https://qa-ess.mypaycenter.com:998/api/Help/Api/POST-api-vversion-Employees-employeeId-Benefits-Enroll

	@JsonProperty("benefits")
	private BenefitEnrollment[] benefits;

	@JsonProperty("employeeForUpdate")
	private EmployeeForUpdate employeeForUpdate;

	@JsonProperty("dependents")
	private DependentForUpdate[] dependents;

	public EmployeeForUpdate getEmployeeForUpdate() {
		return employeeForUpdate;
	}

	public EmployeeBenefitUpdate setEmployeeForUpdate(EmployeeForUpdate employeeForUpdate) {
		this.employeeForUpdate = employeeForUpdate;
		return this;
	}

	public BenefitEnrollment[] getBenefits() {
		return benefits;
	}

	public EmployeeBenefitUpdate setBenefits(BenefitEnrollment... benefits) {
		this.benefits = benefits;
		return this;
	}

	public DependentForUpdate[] getDependents() { return dependents; }

	public EmployeeBenefitUpdate setDependents(DependentForUpdate... dependents) {
		this.dependents = dependents;
		return this;
	}
}
