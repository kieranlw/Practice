package payroll.api.benefits.enroll;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import payroll.api.benefits.CompanyLevelEmployeePortion;
import payroll.api.benefits.CompanyLevelEmployerPortion;
import utils2.JavaTimeUtils;

import java.time.LocalDate;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BenefitEnrollment
{
    @JsonProperty("id")
    private String id;

    @JsonProperty("benefitId")
    private String benefitId;

    @JsonProperty("status")
    private String status;

    @JsonProperty("startDate")
    private String startDate;

    @JsonProperty("memo")
    private String memo;

    @JsonProperty("bankTypeCode")
    private String bankTypeCode;

    @JsonProperty("employeePortion")
    public EmployeePortion employeePortion;

    @JsonProperty("employerPortion")
    public EmployerPortion employerPortion;

    public EmployerPortion getEmployerPortion() {
        return employerPortion;
    }

    public BenefitEnrollment setStartDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    public String getBankTypeCode() {
        return bankTypeCode;
    }

    public BenefitEnrollment setBankTypeCode(String bankTypeCode) {
        this.bankTypeCode = bankTypeCode;
        return this;
    }

    public BenefitEnrollment setEmployerPortion(EmployerPortion employerPortion) {
        this.employerPortion = employerPortion;
        return this;
    }

    public String getId() {
        return id;
    }

    public BenefitEnrollment setId(String id) {
        this.id = id;
        return this;
    }

    public String getBenefitId() {
        return benefitId;
    }

    public BenefitEnrollment setBenefitId(String benefitId) {
        this.benefitId = benefitId;
        return this;
    }

    public String getStatus() {
        return status;
    }

    public BenefitEnrollment setStatus(String status) {
        this.status = status;
        return this;
    }

    public String getStartDate() {
        return startDate;
    }

    public BenefitEnrollment setStartDate(LocalDate startDate) {
        this.startDate = JavaTimeUtils.getLocalDateString(startDate, "yyyy-MM-dd");
        return this;
    }

    public String getMemo() {
        return memo;
    }

    public BenefitEnrollment setMemo(String memo) {
        this.memo = memo;
        return this;
    }

    public EmployeePortion getEmployeePortion() {
        return employeePortion;
    }

    public BenefitEnrollment setEmployeePortion(EmployeePortion employeePortion) {
        this.employeePortion = employeePortion;
        return this;
    }
}
