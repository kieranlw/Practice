package payroll.api.benefits.enroll;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployerPortion {

    @JsonProperty("perPayAmount")
    private Double perPayAmount;

    @JsonProperty("accruedAmount")
    private Double accruedAmount;

    @JsonProperty("maxAmount")
    private Double maxAmount;

    @JsonProperty("percentage")
    private Double percentage;


    @JsonProperty("useMasterDefaults")
    private Boolean useMasterDefaults;

    @JsonProperty("doAccrue")
    private Boolean doAccrue;

    public Double getPerPayAmount() {
        return perPayAmount;
    }

    public EmployerPortion setPerPayAmount(Double perPayAmount) {
        this.perPayAmount = perPayAmount;
        return this;
    }

    public Boolean getUseMasterDefaults() {
        return useMasterDefaults;
    }

    public EmployerPortion setUseMasterDefaults(Boolean useMasterDefaults) {
        this.useMasterDefaults = useMasterDefaults;
        return this;
    }

    public Double getAccruedAmount() {
        return accruedAmount;
    }

    public EmployerPortion setAccruedAmount(Double accruedAmount) {
        this.accruedAmount = accruedAmount;
        return this;
    }

    public Double getMaxAmount() {
        return maxAmount;
    }

    public EmployerPortion setMaxAmount(Double maxAmount) {
        this.maxAmount = maxAmount;
        return this;
    }

    public Double getPercentage() {
        return percentage;
    }

    public EmployerPortion setPercentage(Double percentage) {
        this.percentage = percentage;
        return this;
    }

    public Boolean getDoAccrue() {
        return doAccrue;
    }

    public EmployerPortion setDoAccrue(Boolean doAccrue) {
        this.doAccrue = doAccrue;
        return this;
    }
}
