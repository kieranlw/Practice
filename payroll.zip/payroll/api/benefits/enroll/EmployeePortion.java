package payroll.api.benefits.enroll;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeePortion {

    @JsonProperty("perPayAmount")
    private Double perPayAmount;

    @JsonProperty("accruedAmount")
    private Double accruedAmount;

    @JsonProperty("maxAmount")
    private Double maxAmount;

    @JsonProperty("percentage")
    private Double percentage;

    @JsonProperty("doAccrue")
    private Boolean doAccrue;

    public Double getPerPayAmount() {
        return perPayAmount;
    }

    public EmployeePortion setPerPayAmount(Double perPayAmount) {
        this.perPayAmount = perPayAmount;
        return this;
    }

    public Double getAccruedAmount() {
        return accruedAmount;
    }

    public EmployeePortion setAccruedAmount(Double accruedAmount) {
        this.accruedAmount = accruedAmount;
        return this;
    }

    public Double getMaxAmount() {
        return maxAmount;
    }

    public EmployeePortion setMaxAmount(Double maxAmount) {
        this.maxAmount = maxAmount;
        return this;
    }

    public Double getPercentage() {
        return percentage;
    }

    public EmployeePortion setPercentage(Double percentage) {
        this.percentage = percentage;
        return this;
    }

    public Boolean getDoAccrue() {
        return doAccrue;
    }

    public EmployeePortion setDoAccrue(Boolean doAccrue) {
        this.doAccrue = doAccrue;
        return this;
    }
}
