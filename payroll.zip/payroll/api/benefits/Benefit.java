package payroll.api.benefits;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.UUID;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Benefit
{
    @JsonProperty("id")
    private String id;
    @JsonProperty("number")
    private String number;
    @JsonProperty("description")
    private String description;
    @JsonProperty("employeePortion")
    private CompanyLevelEmployeePortion employeePortion;
    @JsonProperty("employerPortion")
    private CompanyLevelEmployerPortion employerPortion;
    @JsonProperty("active")
    private boolean active;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public CompanyLevelEmployeePortion getEmployeePortion() {
        return employeePortion;
    }

    public void setEmployeePortion(CompanyLevelEmployeePortion employeePortion) {
        this.employeePortion = employeePortion;
    }

    public CompanyLevelEmployerPortion getEmployerPortion() {
        return employerPortion;
    }

    public void setEmployerPortion(CompanyLevelEmployerPortion employerPortion) {
        this.employerPortion = employerPortion;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

}
