package payroll.api.benefits;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyLevelEmployerPortion
{
    @JsonProperty("type")
    private String type;
    @JsonProperty("frequency")
    private String frequency;
    @JsonProperty("isSafeHarborContribution")
    private boolean isSafeHarborContribution;
    @JsonProperty("percentOfDeduction")
    private Double percentOfDeduction;
    @JsonProperty("maxPercentOfGross")
    private double maxPercentOfGross;
    @JsonProperty("isTier2Match")
    private boolean isTier2Match;
    @JsonProperty("tier2MaxGrossPercent")
    private double tier2MaxGrossPercent;
    @JsonProperty("tier2Percent")
    private double tier2Percent;
    @JsonProperty("annualMax")
    private String annualMax;

    public String getAnnualMax() {
        return annualMax;
    }

    public void setAnnualMax(String annualMax) {
        this.annualMax = annualMax;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public boolean isSafeHarborContribution() {
        return isSafeHarborContribution;
    }

    public void setSafeHarborContribution(boolean safeHarborContribution) {
        isSafeHarborContribution = safeHarborContribution;
    }

    public Double getPercentOfDeduction() {
        return percentOfDeduction;
    }

    public void setPercentOfDeduction(Double percentOfDeduction) {
        this.percentOfDeduction = percentOfDeduction;
    }

    public double getMaxPercentOfGross() {
        return maxPercentOfGross;
    }

    public void setMaxPercentOfGross(double maxPercentOfGross) {
        this.maxPercentOfGross = maxPercentOfGross;
    }

    public boolean isTier2Match() {
        return isTier2Match;
    }

    public void setTier2Match(boolean tier2Match) {
        isTier2Match = tier2Match;
    }

    public double getTier2MaxGrossPercent() {
        return tier2MaxGrossPercent;
    }

    public void setTier2MaxGrossPercent(double tier2MaxGrossPercent) {
        this.tier2MaxGrossPercent = tier2MaxGrossPercent;
    }

    public double getTier2Percent() {
        return tier2Percent;
    }

    public void setTier2Percent(double tier2Percent) {
        this.tier2Percent = tier2Percent;
    }
}
