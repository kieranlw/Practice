package payroll.api.dpaPayroll;


public enum TestAccount {
    AUTOCAT1("688DC027-A4E8-EA11-8154-00155D001935"),
    ANDERSON("42E0CA1F-EB37-E211-B9E3-78E7D193CE1E"),
    AUTPAYSU("5C74E182-FE6A-EB11-9282-00505690F979"),
    AUTTEST1("7482B159-3D6D-EB11-9282-00505690F979"),
    AUTTEST2("DE64C6C1-3D6D-EB11-9282-00505690F979"),
    AUTWCOM2("0eb55edd-574d-ec11-928a-00505690f979"),
    // We use this AUTTEST3 DB to prevent creating, updating and deleting records via DPA when payroll has been submitted and is pending review
    // SO PLEASE DO NOT submit payroll or reopen it for this account
    AUTTEST3("0BB03C1E-3E6D-EB11-9282-00505690F979"),
    AUTTEST5("88e45e53-408e-eb11-9283-00505690f979"),
    AUTJRAT1("699cb6b9-7cd3-eb11-9286-00505690f979"),
    AUTJRAT2("ACC299EB-9C1F-EC11-9288-E36115D0006D"),
    AUTCAL1("26907708-88fb-eb11-9288-e36115d0006d"),
    AUTNEB1("7f24f6ec-2b0f-ec11-9288-e36115d0006d"),
    AUTCAL2("3f8db921-2904-ec11-9288-e36115d0006d"),
    AUTCAL3("3bd72e61-2904-ec11-9288-e36115d0006d"),
    AUTNE3("cee9d641-eb0f-ec11-9288-e36115d0006d"),
    AUTOR3("e1a42884-eb0f-ec11-9288-e36115d0006d"),
    AUTND3("9c7a9be2-eb0f-ec11-9288-e36115d0006d"),
    AUTAZ3("9da741c0-ec0f-ec11-9288-e36115d0006d"),
    AUTO1099("93e32caf-b359-e611-9394-78e7d193ce24"),
    AUTT1099("4719c25b-af48-ec11-928a-00505690f979"),
    //Don't do any post/put/delete, this is sample DB for XUAT/GoCo Team
    SAMPLEMV("fcf6a1ca-e1f5-e511-ae29-78e7d193ce24");

    private final String accountId;

    TestAccount(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountId() {
        return accountId;
    }
}