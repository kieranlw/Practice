package payroll.api.dpaPayroll.environment;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import payroll.api.dpaPayroll.http.token.BearerTokenSourceFactory;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;

@Getter
@Builder
@Data
@With
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Environment {

    @JsonProperty("baseURL")
    private String baseURL;

    @JsonProperty("name")
    private String name;

    @JsonProperty("version")
    private String version;

    @JsonProperty("tokenBaseURI")
    private String tokenBaseURI;

    @JsonProperty("clientId")
    private String clientId;

    @JsonProperty("clientSecret")
    private String clientSecret;

    @JsonProperty("uiEnvironment")
    private String uiEnvironment;

    @JsonProperty("defaultUser")
    private String defaultUser;

    @JsonProperty("defaultPassword")
    private String defaultPassword;

    @JsonProperty("scope")
    private String scope;

}

