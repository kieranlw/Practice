package payroll.api.dpaPayroll.environment;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface EnvironmentData {

    String API_PROD() default "";
    String API_QA() default "";
    String API_XUAT() default "";
    String DEFAULT() default "";
}
