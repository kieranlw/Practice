package payroll.api.dpaPayroll.environment;

import common.ReadableFile;
import common.ResourceFile;

public class GetEnvironmentData {

    private static final ReadableFile ENVIRONMENT_DATA =  new ResourceFile("payroll/data/newAPI/environmentConfig.json");

    private static Environments getEnvironments() {
        return ENVIRONMENT_DATA.readJsonAs(Environments.class);
    }

    public static Environment getCurrentEnvironment() {
        return getEnvironments().getEnvironment(System.getProperty("currentEnvironment"));
    }

    public static Environment getTimeQaEnvironment() {
        return getEnvironments().getEnvironment("API_TIME_QA");
    }

}
