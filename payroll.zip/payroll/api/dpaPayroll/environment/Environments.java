package payroll.api.dpaPayroll.environment;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import utils2.LogInfo;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Environments {

    @JsonProperty("environments")
    private Environment[] environments;

    public Environment getEnvironment(String environmentName){
        for(Environment environment : environments){
            if(environment.getName().equals(environmentName)){
                return environment;
            }
        }

        LogInfo.log_AndFail("Could not find environment " + environmentName);

        return null;
    }


}

