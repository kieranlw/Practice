package payroll.api.dpaPayroll.environment;

import common.ResourceFile;
import utils2.LogInfo;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class EnvironmentDecorator {

    public static void initDataManage(Environment environment, Object classToUpdate) {
        Class<?> proxyIn = classToUpdate.getClass();
        Field[] fields = proxyIn.getDeclaredFields();
        for (Field field : fields) {
            updateFieldIfApplicable(environment, classToUpdate, field);
        }
    }

    private static void updateFieldIfApplicable(Environment environment, Object classToUpdate, Field field) {
        field.setAccessible(true);
        EnvironmentData environmentDataManager = field.getAnnotation(EnvironmentData.class);
        if (environmentDataManager != null) {
            try {
                String fieldValue = getCorrectEnvironmentValue(environment, environmentDataManager);
                fieldValue = fieldValue.equals("") ? environmentDataManager.DEFAULT() : fieldValue;

                field.setAccessible(true);
                if (field.getType().isAssignableFrom(ResourceFile.class)) {
                    field.set(classToUpdate, new ResourceFile(fieldValue));
                } else {
                    field.set(classToUpdate, fieldValue);
                }
            } catch (IllegalAccessException e) {
                LogInfo.log_AndFail("Unable to update field " + field.getName());
            }
        }
    }

    private static String getCorrectEnvironmentValue(Environment environment, EnvironmentData environmentDataManager) throws IllegalAccessException {
        try {
            Method fieldMethod = environmentDataManager.getClass().getDeclaredMethod(environment.getName());
            return fieldMethod.invoke(environmentDataManager).toString();
        } catch (NoSuchMethodException e) {
            LogInfo.log_AndFail("Could not find decorator for field '" + environment.getName() + "'");
        } catch (InvocationTargetException e1) {
            LogInfo.log_AndFail("Encountered error while trying to get data for environment '" + environment.getName() + "'");
        }
        return null;
    }
}
