package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.models.PayInfo;
import payroll.api.dpaPayroll.models.PayInfoForCreate;
import payroll.api.dpaPayroll.models.PayInfoForUpdate;
import payroll.api.dpaPayroll.models.PayrollForCreate;

public class PayRollResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public PayRollResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response create(PayrollForCreate payrollToCreate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(payrollToCreate)
                .post("/payroll");
        return response;
    }

    public Response delete() {
        Response response = getAccountRequestSpec()
                .delete("/payroll/current");
        return response;
    }

    public Response get() {
        Response response = getAccountRequestSpec()
                .get("/payroll/current");
        return response;
    }

    public Response getAll() {
        Response response = getAccountRequestSpec()
                .get("/payroll");
        return response;
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }
}