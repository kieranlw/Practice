package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.models.DirectDeposit;
import payroll.api.dpaPayroll.models.DirectDepositEmployeeCoverageReportRequest;

public class DirectDepositResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public DirectDepositResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response getAll(String employeeId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .queryParam("employeeId", employeeId)
                .get("/direct-deposits");
        return response;
    }

    public Response get(String directDepositId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParams("deposit", directDepositId)
                .get("/direct-deposits/{deposit}");
        return response;
    }

    public Response create(DirectDeposit directDeposit) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(directDeposit)
                .post("/direct-deposits/");
        return response;
    }

    public Response delete(String directDepositId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParams("deposit", directDepositId)
                .delete("/direct-deposits/{deposit}");
        return response;
    }

    public void tryDeleteAllForEmployee(String employeeId) {
        DirectDeposit[] directDeposits = getAll(employeeId).as(DirectDeposit[].class);

        for(DirectDeposit deposit : directDeposits){
            delete(deposit.getId());
        }
    }

    public Response update(String directDepositId, DirectDeposit directDeposit) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(directDeposit)
                .pathParams("deposit", directDepositId)
                .put("/direct-deposits/{deposit}");
        return response;
    }

    public Response employeeCoverageReport(DirectDepositEmployeeCoverageReportRequest directDepositEmployeeCoverageReportRequest) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(directDepositEmployeeCoverageReportRequest)
                .post("/direct-deposits/employee-coverage-report");
        return response;
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }
}