package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.models.Departments;
import payroll.api.dpaPayroll.models.DepartmentsForCreate;

public class DepartmentsResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public DepartmentsResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }
    public Response getAll() {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .get("/departments");
        return response;
    }

    public Response get(String departmentId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParams("departmentId", departmentId)
                .get("/departments/{departmentId}");
        return response;
    }

    public Response post(DepartmentsForCreate department) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(department)
                .post("/departments");
        return response;
    }

    public Response put(String departmentId, Departments department) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParams("departmentId", departmentId)
                .body(department)
                .put("/departments/{departmentId}");
        return response;
    }

    public Response delete(String departmentId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParams("departmentId", departmentId)
                .delete("/departments/{departmentId}");
        return response;
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }
}
