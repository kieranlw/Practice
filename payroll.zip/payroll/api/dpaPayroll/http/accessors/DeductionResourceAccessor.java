package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.models.*;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class DeductionResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public DeductionResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response getAllForEmployee(String employeeId) {
        return getAccountRequestSpec()
                .queryParam("employeeId", employeeId)
                .get("/deductions");
    }

    public Response get(String deductionId) {
        return getAccountRequestSpec()
                .pathParam("deductionId", deductionId)
                .get("/deductions/{deductionId}");
    }


    public Response getConfigurations() {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .get("/deduction-configs");
        return response;
    }

    public Response getClasifications() {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .get("/deduction-classifications");
        return response;
    }

    public Response getConfiguration(String deductionConfigurationId){
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("deductionConfigurationId", deductionConfigurationId)
                .get("/deduction-configs/{deductionConfigurationId}");
        return response;
    }

    public Response getClassification(String deductionClassificationId){
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("deductionClassificationId", deductionClassificationId)
                .get("/deduction-classifications/{deductionClassificationId}");
        return response;
    }

    public Response createConfigurations(DeductionConfigForCreate deductionConfigForCreate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(deductionConfigForCreate)
                .post("/deduction-configs");
        return response;
    }

    public Response updateConfiguration(String deductionConfigurationGuid, DeductionConfigForUpdate deductionConfigForUpdate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("deductionConfigurationId", deductionConfigurationGuid)
                .body(deductionConfigForUpdate)
                .put("/deduction-configs/{deductionConfigurationId}");
        return response;
    }

    public Response deleteConfiguration(String deductionConfigurationId){
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("deductionConfigurationId", deductionConfigurationId)
                .delete("/deduction-configs/{deductionConfigurationId}");
        return response;
    }

    /**
     * Useful when you're already holding a path to the resource. Ex. Maybe
     * your create endpoint returned a location header and you want to see
     * what was just created.
     *
     * @param path
     * @return
     */
    public Response getByPath(String path) {
        return RequestHelper.setupRootedRequest(data.getBaseUri(), tokenSource.getBearerToken())
                .get(path);
    }

    public Response create(DeductionForCreate deductionData) {
        return getAccountRequestSpec()
                .contentType("application/json")
                .body(deductionData)
                .post("/deductions");
    }

    public Response update(String deductionId, DeductionForCreate deductionData) {
        return getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("deductionId", deductionId)
                .body(deductionData)
                .put("/deductions/{deductionId}");
    }

    public Response delete(String deductionId) {
        return getAccountRequestSpec()
                .pathParam("deductionId", deductionId)
                .delete("/deductions/{deductionId}");
    }

    public void deleteAllForEmployee(String employeeId) throws Exception {
        // TODO: This is going to get tricky because some deductions cannot
        // be deleted when they are referenced by other deductions. How to
        // handle state management?

        //Get the deduction type ID for garnishment fee. We assume that the string used for the description is the same for all db and accounts.
        final String GarnishmentFeeDescription = "Garnish Fee";
        DeductionConfiguration[] deductionConfigurations = getAccountRequestSpec()
                .get("/deduction-configs").as(DeductionConfiguration[].class);

        DeductionConfiguration garnishmentFeeDeduction =
                Arrays.stream(deductionConfigurations)
                        .filter(deduction -> GarnishmentFeeDescription.equals(deduction.getDescription())).findFirst().orElse(null);

        Deduction[] deductions = getAllForEmployee(employeeId).as(Deduction[].class);

        List<Deduction> deductionsList = new LinkedList<Deduction>(Arrays.asList(deductions));

        //Delete garnishment fee first
        if (garnishmentFeeDeduction != null) {
            for (Deduction deduction : deductionsList) {
                if (deduction.getDeductionTypeId().equals(garnishmentFeeDeduction.getId())) {
                    tryEnsureDelete(deduction.getId());
                    deductionsList.remove(deduction);
                }
            }
        }

        //Delete remaining deductions.
        for (Deduction deduction : deductionsList) {
            tryEnsureDelete(deduction.getId());
        }
    }

    private void tryEnsureDelete(String deductionId) throws Exception {
        Response deleteResponse = delete(deductionId);
        int statusCode = deleteResponse.getStatusCode();
        if (statusCode != 204 || statusCode != 404)
            throw new Exception("Unable to delete deduction '" + deductionId + "'. Got HTTP status code '" + statusCode + "'");
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }
}