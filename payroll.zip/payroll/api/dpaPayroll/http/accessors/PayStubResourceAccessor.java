package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;
import utils.FileOperations;
import utils2.LogInfo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class PayStubResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public PayStubResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }


    public Response getAllForEmployee(String employeeId) {
        Response response = getAccountRequestSpec()
                .queryParam("employeeId", employeeId)
                .get("/Paystubs");
        return response;
    }

    public Response get(String payId) {
        Response response = getAccountRequestSpec()
                .pathParam("paystub", payId)
                .get("/Paystubs/{paystub}");
        return response;
    }

    public Response getPDF(String payId) {
        Response response = getAccountRequestSpec()
                .contentType("application/pdf")
                .pathParam("paystub", payId)
                .get("/Paystubs/{paystub}/pdf");
        return response;
    }

    public void getPDFFile(String payId, File fileLocation) {
        FileOperations.delete_SpecificFile(fileLocation.getAbsolutePath());

        byte[] pdfByteArray = getPDF(payId).asByteArray();
        downloadLocally(pdfByteArray, fileLocation);
    }

    private void downloadLocally(byte[] pdfFile, File fileToDownloadTo) {
        FileOutputStream fos = null;

        try {
            fos = new FileOutputStream(fileToDownloadTo.getAbsolutePath());
            fos.write(pdfFile);

        } catch (IOException e) {
            LogInfo.log_AndFail(e.getMessage());
        }finally{
            try {
                if (fos != null) {
                    fos.close();
                }
            }catch(IOException ioe){
                LogInfo.log_Warning("Failed to Close File Output Stream");
            }
        }
    }


    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }
}