package payroll.api.dpaPayroll.http.accessors;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;

public class MasterItemGroupsResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;
    private static final String baseMasterItemGroupsPath = "/master-item-groups";
    private static final String specificMasterItemGroupsPath = "/master-item-groups/{masterItemGroupsId}";

    public MasterItemGroupsResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId()).contentType(ContentType.JSON).log().all();
    }

    public Response getAll() {
        return getAccountRequestSpec()
                .get(baseMasterItemGroupsPath);
    }

    public Response get(String masterItemGroupsId) {
        return getAccountRequestSpec()
                .pathParam("masterItemGroupsId", masterItemGroupsId)
                .get(specificMasterItemGroupsPath);
    }
}
