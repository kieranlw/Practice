package payroll.api.dpaPayroll.http.accessors;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.models.CompanyContactsObject;

public class ContactsResourceAccessor {
    private final AccountResourceCallSetupData data;
    private final IBearerTokenSource tokenSource;
    private static final String baseContactsPath = "/contacts";
    private static final String specificContactPath = "/contacts/{id}";

    public ContactsResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response post(CompanyContactsObject contactsForCreate, int statusCode) {
        return getAccountRequestSpec().
                when().
                body(contactsForCreate).
                post(baseContactsPath).
                then().
                log().all().
                statusCode(statusCode).
                extract().response();
    }

    public Response put(CompanyContactsObject contactsForCreate, String contactId, int statusCode) {
        return getAccountRequestSpec().
                when().
                body(contactsForCreate).
                pathParam("id", contactId).
                put(specificContactPath).
                then().
                log().all().
                statusCode(statusCode).
                extract().response();
    }

    public Response getAll(int statusCode) {
        return getAccountRequestSpec().
                when().
                get(baseContactsPath).
                then().
                log().all().
                statusCode(statusCode).
                extract().response();
    }

    public Response get(String id, int statusCode) {
        return getAccountRequestSpec().
                pathParam("id", id).
                get(specificContactPath).
                then().
                log().all().
                statusCode(statusCode).
                extract().response();
    }

    public Response delete(String id, int statusCode) {
        return getAccountRequestSpec().
                pathParam("id", id).
                delete(specificContactPath).
                then().
                log().all().
                statusCode(statusCode).
                extract().response();
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId()).contentType(ContentType.JSON).log().all();
    }
}
