package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.models.EmployeeQueryParams;
import payroll.api.dpaPayroll.models.Employee_PersonalInfo;
import utils2.ModelUtils;

import java.util.Arrays;
import java.util.List;

public class EmployeeResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public EmployeeResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response create(Employee_PersonalInfo employeePersonalInfo) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(employeePersonalInfo)
                .post("/employees/");
        return response;
    }

    public Response getAll() {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .get("/employees/");
        return response;
    }

    public Response getAll(EmployeeQueryParams queryParams) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .queryParams(ModelUtils.getFieldMap(queryParams, null))
                .get("/employees/");
        return response;
    }

    public Response update(String employeeId, Employee_PersonalInfo employeeUpdateInfo) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("employee", employeeId)
                .body(employeeUpdateInfo)
                .put("/employees/{employee}");
        return response;
    }

    public Response get(String employeeId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("employee", employeeId)
                .get("/employees/{employee}");
        return response;
    }

    public Employee_PersonalInfo get_ByTaxId(String taxId) {
        Employee_PersonalInfo[] employees = getAll().as(Employee_PersonalInfo[].class);
        return Arrays.stream(employees).filter(employee -> employee.getTaxId().equals(taxId)).findAny().orElse(null);
    }

    public Employee_PersonalInfo[] getMultiple_ByTaxId(String... taxId) {
        List<String> taxIdList = Arrays.asList(taxId);
        Employee_PersonalInfo[] employees = getAll().as(Employee_PersonalInfo[].class);
        employees = Arrays.stream(employees).filter(employee -> taxIdList.contains(employee.getTaxId())).toArray(Employee_PersonalInfo[]::new);

        return employees;
    }

    public Response getTax(String employeeId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("employeeId", employeeId)
                .get("/employees/{employeeId}/tax");
        return response;
    }

    public Response replaceTax(String employeeId, Object employeeTaxSetupForReplace) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("employeeId", employeeId)
                .body(employeeTaxSetupForReplace)
                .put("/employees/{employeeId}/tax");
        return response;
    }

    public Response deleteTax(String employeeId) {
        Response response = getAccountRequestSpec()
                .pathParam("employeeId", employeeId)
                .delete("/employees/{employeeId}/tax");
        return response;
    }

    public Response delete(String employeeId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("employee", employeeId)
                .delete("/employees/{employee}");
        return response;
    }

    public void deleteAllByTaxId(String... taxIds) {
        Employee_PersonalInfo[] employeesToDelete = getMultiple_ByTaxId(taxIds);
        for (Employee_PersonalInfo employee : employeesToDelete) {
            delete(employee.getId());
        }
    }

    public Response verifyAddress(Object employeeAddress, int statusCode) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(employeeAddress)
                .post("/address-verification")
                .then().log().all()
                .statusCode(statusCode)
                .extract().response();
        return response;
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }
}