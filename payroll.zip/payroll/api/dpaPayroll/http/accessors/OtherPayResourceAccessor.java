package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.models.*;

public class OtherPayResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public OtherPayResourceAccessor (AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response getAllConfigurations() {
        Response response = getAccountRequestSpec()
                .get("/other-pay-configs");
        return response;
    }

    public Response getConfigurationById(String otherPayTypeId) {
        Response response = getAccountRequestSpec()
                .pathParam("Id", otherPayTypeId)
                .get("/other-pay-configs/{Id}");
        return response;
    }

    public Response getAllOtherPaysByEmployee(String employeeId) {
        Response response = getAccountRequestSpec()
                .queryParam("employeeId", employeeId)
                .get("/other-pays/");
        return response;
    }

    public Response getOtherPayById(String otherPayId) {
        Response response = getAccountRequestSpec()
                .pathParam("otherPay", otherPayId)
                .get("/other-pays/{otherPay}");
        return response;
    }

    public Response delete(String otherPayId) {
        Response response = getAccountRequestSpec()
                .pathParam("otherPayId", otherPayId)
                .delete("/other-pays/{otherPayId}");
        return response;
    }

    public Response deleteConfiguration(String otherPayConfigurationId) {
        Response response = getAccountRequestSpec()
                .pathParam("otherPayConfigurationId", otherPayConfigurationId)
                .delete("/other-pay-configs/{otherPayConfigurationId}");
        return response;
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }

    public Response create(OtherPayForCreate otherPayForCreate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(otherPayForCreate)
                .post("/other-pays");
        return response;
    }

    public Response createConfiguration(OtherPayConfigForCreate otherPayConfigForCreate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(otherPayConfigForCreate)
                .post("/other-pay-configs");
        return response;
    }

    public Response update(OtherPayForUpdate otherpayForUpdate, String otherPayId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("otherPayId", otherPayId)
                .body(otherpayForUpdate)
                .put("/other-pays/{otherPayId}");
        return response;
    }

    public void deleteAll(String employeeId) {
        OtherPay[] otherpays = getAllOtherPaysByEmployee(employeeId).as(OtherPay[].class);
        for(OtherPay otherPay : otherpays){
            delete(otherPay.getId());
        }
    }

    public Response updateConfiguration(OtherPayConfigForUpdate otherPayConfig, String otherPayConfigId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("otherPayConfigId", otherPayConfigId)
                .body(otherPayConfig)
                .put("/other-pay-configs/{otherPayConfigId}");
        return response;
    }
}