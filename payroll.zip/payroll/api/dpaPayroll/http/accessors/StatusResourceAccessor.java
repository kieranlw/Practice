package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;

public class StatusResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public StatusResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response get() {
        return getRequestSpec().contentType("application/json")
                .pathParam("version", data.getVersion())
                .basePath("/v{version}")
                .get("/system/status");
    }


    private RequestSpecification getRequestSpec() {
        return RequestHelper.setupRootedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken());
    }
}