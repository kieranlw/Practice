package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import utils.FileOperations;
import utils2.LogInfo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class AnnualTaxFormsAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public AnnualTaxFormsAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response get(String employeeId,Integer year) {
        return getAccountRequestSpec()
                .queryParam("employeeId", employeeId)
                .queryParam("year", year)
                .get("/annual-tax-forms/pdf");
    }

    public Response getPDFFile(String employeeId, Integer year, File fileLocation) {
        FileOperations.delete_SpecificFile(fileLocation.getAbsolutePath());

        byte[] pdfByteArray = get(employeeId,year).asByteArray();
        downloadLocally(pdfByteArray, fileLocation);
        return get(employeeId,year);
    }

    private void downloadLocally(byte[] pdfFile, File fileToDownloadTo) {
        FileOutputStream fos = null;

        try {
            fos = new FileOutputStream(fileToDownloadTo.getAbsolutePath());
            fos.write(pdfFile);

        } catch (IOException e) {
            LogInfo.log_AndFail(e.getMessage());
        }finally{
            try {
                if (fos != null) {
                    fos.close();
                }
            }catch(IOException ioe){
                LogInfo.log_Warning("Failed to Close File Output Stream");
            }
        }
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }

}