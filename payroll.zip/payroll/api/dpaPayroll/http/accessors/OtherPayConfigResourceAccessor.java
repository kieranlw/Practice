package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.models.OtherPayConfigForCreate;


public class OtherPayConfigResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public OtherPayConfigResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response delete(String otherPayConfiguration) {
        Response response = getAccountRequestSpec()
                .pathParam("otherPayConfigurationId", otherPayConfiguration)
                .delete("/other-pay-configs/{otherPayConfigurationId}");
        return response;
    }

    public Response create(OtherPayConfigForCreate otherPayConfigForCreate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(otherPayConfigForCreate)
                .post("/other-pay-configs");
        return response;
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }


}