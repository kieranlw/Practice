package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.models.PayInfo;
import payroll.api.dpaPayroll.models.PayInfoForCreate;
import payroll.api.dpaPayroll.models.PayInfoForUpdate;

public class PayInfoResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public PayInfoResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response get(String payInfoId) {
        Response response = getAccountRequestSpec()
                .pathParam("payInfoId", payInfoId)
                .get("/pay-info/{payInfoId}");
        return response;
    }

    public Response getAll(String employeeId) {
        Response response = getAccountRequestSpec()
                .queryParam("employeeId", employeeId)
                .get("/pay-info");
        return response;
    }

    public Response delete(String payInfoId) {
        Response response = getAccountRequestSpec()
                .pathParam("payInfoId", payInfoId)
                .delete("/pay-info/{payInfoId}");
        return response;
    }

    public Response create(PayInfoForCreate payInfoToCreate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(payInfoToCreate)
                .post("/pay-info");
        return response;
    }

    public Response update(PayInfoForUpdate payInfoToUpdate, String payInfoId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("payInfoId", payInfoId)
                .body(payInfoToUpdate)
                .put("/pay-info/{payInfoId}");
        return response;
    }

    public void deleteAll(String employeeId) {
        PayInfo[] payInfos = getAll(employeeId).as(PayInfo[].class);
        for(PayInfo payInfo : payInfos){
            delete(payInfo.getId());
        }
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }
}