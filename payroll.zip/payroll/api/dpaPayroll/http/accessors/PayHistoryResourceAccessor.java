package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;

public class PayHistoryResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public PayHistoryResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response getPayByEmployeeId(String employeeId, String startDate, String endDate) {
        Response response = getAccountRequestSpec()
                .pathParam("employeeId", employeeId)
                .pathParam("startDate", startDate)
                .pathParam("endDate", endDate)
                .get("/pay?employeeId={employeeId}&startDate={startDate}&endDate={endDate}");
        return response;
    }

    public Response getPayById(String payId) {
        Response response = getAccountRequestSpec()
                .pathParam("payId", payId)
                .get("/pay/{payId}");
        return response;
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }
}
