package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.EnvironmentResourceCallSetupData;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;

public class EnvironmentAccessor {
    private EnvironmentResourceCallSetupData data;
    private IBearerTokenSource tokenSource;
    private static final String SYSTEM_STATUS = "/v1/system/status";

    public EnvironmentAccessor(EnvironmentResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    private RequestSpecification getDpaEnvironmentRequestSpec() {
        return RequestHelper.setupRootedRequest(
                data.getDpaUri(),
                tokenSource.getBearerToken());
    }

    private RequestSpecification getMpcEnvironmentRequestSpec() {
        return RequestHelper.setupRootedRequest(
                data.getMpcUri(),
                tokenSource.getBearerToken());
    }

    public Response getTheDpaEnvironmentStatus() {
        return getDpaEnvironmentRequestSpec()
                .get(SYSTEM_STATUS);
    }

    public Response getTheMpcEnvironmentStatus() {
        return getMpcEnvironmentRequestSpec()
                .get(SYSTEM_STATUS);
    }
}


