package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.models.StandardReport.ReportRequest;

public class StandardReportAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public StandardReportAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;

    }

    public Response getAll() {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .get("/standard-reports/");
        return response;
    }

    public Response get(int reportId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("reportId", reportId)
                .get("/standard-reports/{reportId}");
        return response;
    }

    public Response post(ReportRequest reportRequest) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(reportRequest)
                .post("/standard-reports");
        return response;
    }

    public Response post(Object reportRequest) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(reportRequest)
                .post("/standard-reports");
        return response;
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }
}