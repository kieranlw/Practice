package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;

public class AgenciesConfigurationsResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public AgenciesConfigurationsResourceAccessor (AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }


    public Response get() {
        Response response = getAccountRequestSpec()
                .get("/agencies");
        return response;
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }
}