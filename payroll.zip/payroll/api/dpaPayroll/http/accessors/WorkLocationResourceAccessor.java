package payroll.api.dpaPayroll.http.accessors;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.models.WorkLocationForCreate;
import payroll.api.dpaPayroll.models.WorkLocationForUpdate;

public class WorkLocationResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;
    private static final String baseWorkLocationsPath = "/work-locations";
    private static final String specificWorkLocationsPath = "/work-locations/{workLocationId}";

    public WorkLocationResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId()).contentType(ContentType.JSON).log().all();
    }

    public Response getAll() {
        return getAccountRequestSpec()
                .get(baseWorkLocationsPath);
    }

    public Response get(String workLocationId) {
        return getAccountRequestSpec()
                .pathParam("workLocationId", workLocationId)
                .get(specificWorkLocationsPath);
    }

    public Response post(WorkLocationForCreate location, int statusCode) {
        return getAccountRequestSpec().
                body(location).
                post(baseWorkLocationsPath).
                then().
                log().all().
                statusCode(statusCode).
                extract().response();
    }
    public Response update(String workLocationId, WorkLocationForUpdate workLocationForUpdateInfo) {
        return getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("workLocationId", workLocationId)
                .body(workLocationForUpdateInfo)
                .put(specificWorkLocationsPath)
                .then()
                .log().all()
                .extract().response();
    }

    public Response delete(String workLocationId, int statusCode) {
        return getAccountRequestSpec().
                pathParam("workLocationId", workLocationId).
                delete(specificWorkLocationsPath).
                then().
                log().all().
                statusCode(statusCode).
                extract().response();
    }

}


