package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.models.JobCodeForCreate;
import payroll.api.dpaPayroll.models.JobCodeForUpdate;

public class JobCodesResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public JobCodesResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response get(String jobCodeId) {
        Response response = getAccountRequestSpec()
                .pathParam("jobCodeId", jobCodeId)
                .get("/job-codes/{jobCodeId}");
        return response;
    }

    public Response getAll() {
        Response response = getAccountRequestSpec()
                .get("/job-codes");
        return response;
    }

    public Response create(JobCodeForCreate jobCodeForCreate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(jobCodeForCreate)
                .post("/job-codes");
        return response;
    }

    public Response update(String jobCodeId, JobCodeForUpdate jobCodeForUpdate){
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("jobCodeId", jobCodeId)
                .body(jobCodeForUpdate)
                .put("/job-codes/{jobCodeId}");
        return response;
    }

    public Response delete(String jobCodeId) {
        Response response = getAccountRequestSpec()
                .pathParam("jobCodeId", jobCodeId)
                .delete("/job-codes/{jobCodeId}");
        return response;
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }
}