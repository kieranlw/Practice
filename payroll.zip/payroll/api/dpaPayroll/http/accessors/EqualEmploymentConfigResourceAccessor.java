package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.models.EqualEmploymentConfigs;
import payroll.api.dpaPayroll.models.JobCodeForCreate;
import payroll.api.dpaPayroll.models.JobCodeForUpdate;

public class EqualEmploymentConfigResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public EqualEmploymentConfigResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response get_jobCode(String jobCodeId) {
        Response response = getAccountRequestSpec()
                .pathParam("jobCodeId", jobCodeId)
                .get("/equal-employment-config/jobs/{jobCodeId}");
        return response;
    }

    public Response getAll_jobCodes() {
        Response response = getAccountRequestSpec()
                .get("/equal-employment-config/jobs");
        return response;
    }

    public Response create_jobCode(EqualEmploymentConfigs jobCodeToCreate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(jobCodeToCreate)
                .post("/equal-employment-config/jobs");
        return response;
    }

    public Response update_jobCode(String jobCodeId, EqualEmploymentConfigs jobCodeToUpdate){
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("jobCodeId", jobCodeId)
                .body(jobCodeToUpdate)
                .put("/equal-employment-config/jobs/{jobCodeId}");
        return response;
    }

    public Response delete_jobCode(String jobCodeId) {
        Response response = getAccountRequestSpec()
                .pathParam("jobCodeId", jobCodeId)
                .delete("/equal-employment-config/jobs/{jobCodeId}");
        return response;
    }

    public Response get_minorityCode(String minorityCodeId) {
        Response response = getAccountRequestSpec()
                .pathParam("minorityCodeId", minorityCodeId)
                .get("/equal-employment-config/minorities/{minorityCodeId}");
        return response;
    }

    public Response getAll_minorityCodes() {
        Response response = getAccountRequestSpec()
                .get("/equal-employment-config/minorities");
        return response;
    }

    public Response create_minorityCode(EqualEmploymentConfigs minorityCodeToCreate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(minorityCodeToCreate)
                .post("/equal-employment-config/minorities");
        return response;
    }

    public Response update_minorityCode(String minorityCodeId, EqualEmploymentConfigs minorityCodeToUpdate){
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("minorityCodeId", minorityCodeId)
                .body(minorityCodeToUpdate)
                .put("/equal-employment-config/minorities/{minorityCodeId}");
        return response;
    }

    public Response delete_minorityCode(String minorityCodeId) {
        Response response = getAccountRequestSpec()
                .pathParam("minorityCodeId", minorityCodeId)
                .delete("/equal-employment-config/minorities/{minorityCodeId}");
        return response;
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }
}