package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.models.BenefitConfigurationForCreate;
import payroll.api.dpaPayroll.models.BenefitConfigurationForUpdate;
import payroll.api.dpaPayroll.models.BenefitToCreate;
import payroll.api.dpaPayroll.models.BenefitToUpdate;

public class BenefitsResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public BenefitsResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response getAllForEmployee(String employeeId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .queryParam("employeeId", employeeId)
                .get("/benefits");
        return response;
    }

    public Response get(String employeeId, String benefitId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .queryParam("employeeId", employeeId)
                .pathParam("benefit", benefitId)
                .get("/benefits/{benefit}");
        return response;
    }

    public Response delete(String benefitId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("benefit", benefitId)
                .delete("/benefits/{benefit}");
        return response;
    }

    public Response create(BenefitToCreate benefitToCreate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(benefitToCreate)
                .post("/benefits");
        return response;
    }

    public Response update(BenefitToUpdate benefitToUpdate, String benefitId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("benefit", benefitId)
                .body(benefitToUpdate)
                .put("/benefits/{benefit}");
        return response;
    }

    public Response getConfigurations() {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .get("/benefit-configs");
        return response;
    }

    public Response getConfiguration(String benefitConfigurationId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("benefitConfigurationId", benefitConfigurationId)
                .get("/benefit-configs/{benefitConfigurationId}");
        return response;
    }

    public Response deleteConfiguration(String benefitConfigurationId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("benefitConfigurationId", benefitConfigurationId)
                .delete("/benefit-configs/{benefitConfigurationId}");
        return response;
    }

    public Response createConfiguration(BenefitConfigurationForCreate benefitConfigToCreate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(benefitConfigToCreate)
                .post("/benefit-configs");
        return response;
    }

    public Response updateConfiguration(String benefitConfigurationId, BenefitConfigurationForUpdate benefitConfigToUpdate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("benefitConfigurationId", benefitConfigurationId)
                .body(benefitConfigToUpdate)
                .put("/benefit-configs/{benefitConfigurationId}");
        return response;
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }
}