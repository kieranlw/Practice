package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.models.DependentInfoForCreate;
import payroll.api.dpaPayroll.models.DependentInfoForUpdate;
public class DependentInfoAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public DependentInfoAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response create(DependentInfoForCreate dependentsCreate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(dependentsCreate)
                .post("/dependent-info");
        return response;
    }

    public Response getAllForEmployee(String employeeId) {
        return getAccountRequestSpec()
                .queryParam("employeeId", employeeId)
                .get("/dependent-info");
    }

    public Response get(String dependentInfoId) {
        return getAccountRequestSpec()
                .pathParam("dependentInfoId", dependentInfoId)
                .get("/dependent-info/{dependentInfoId}");
    }

    public Response del(String dependentInfoId) {
        return getAccountRequestSpec()
                .pathParam("dependentInfoId", dependentInfoId)
                .delete("/dependent-info/{dependentInfoId}");
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }

    public Response update(String dependentInfoId, DependentInfoForUpdate dependentUpdateInfo) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("dependentInfoId", dependentInfoId)
                .body(dependentUpdateInfo)
                .put("/dependent-info/{dependentInfoId}");
        response.print();
        return response;
    }
}

