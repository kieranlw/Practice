package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.models.DeductionConfigForCreate;
import payroll.api.dpaPayroll.models.DeductionConfigForUpdate;
import payroll.api.dpaPayroll.models.LeavePay;
import payroll.api.dpaPayroll.models.LeavePayConfigForCreate;

import java.util.Arrays;

public class LeavePayResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public LeavePayResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }


    public Response getAllForEmployee(String employeeId) {
        Response response = getAccountRequestSpec()
                .queryParam("employeeId", employeeId)
                .get("/leave-pays/");
        return response;
    }

    public Response getConfigurations() {
        Response response = getAccountRequestSpec()
                .get("/leave-pay-configs");
        return response;
    }

    public Response getConfiguration(String leavePayConfigId){
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("leavePayConfigId", leavePayConfigId)
                .get("/leave-pay-configs/{leavePayConfigId}");
        return response;
    }

    public Response createConfiguration(LeavePayConfigForCreate leavePayConfigForCreate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(leavePayConfigForCreate)
                .post("/leave-pay-configs");
        return response;
    }

    public Response updateConfiguration(String  leavePayConfigurationId,LeavePayConfigForCreate leavePayConfigForCreate) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("leavePayConfigurationId", leavePayConfigurationId)
                .body(leavePayConfigForCreate)
                .put("/leave-pay-configs/{leavePayConfigurationId}");
        return response;
    }

    public Response deleteConfiguration(String  leavePayConfigurationId) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("leavePayConfigurationId", leavePayConfigurationId)
                .delete("/leave-pay-configs/{leavePayConfigurationId}");
        return response;
    }


    public Response get(String employeeLeavePayId) {
        Response response = getAccountRequestSpec()
                .pathParam("employeeLeavePay", employeeLeavePayId)
                .get("/leave-pays/{employeeLeavePay}");
        return response;
    }

    public Response create(LeavePay leavePay) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .body(leavePay)
                .post("/leave-pays");
        return response;
    }

    public Response update(String employeeLeavePayId, LeavePay leavePayUpdateBody) {
        Response response = getAccountRequestSpec()
                .contentType("application/json")
                .pathParam("employeeLeavePay", employeeLeavePayId)
                .body(leavePayUpdateBody)
                .put("/leave-pays/{employeeLeavePay}");
        return response;
    }

    public Response delete(String employeeLeavePayId) {
        Response response = getAccountRequestSpec()
                .pathParam("employeeLeavePay", employeeLeavePayId)
                .delete("/leave-pays/{employeeLeavePay}");
        return response;
    }

    public void deleteAllForEmployee(String employeeId) {
        LeavePay[] leavePays = getAllForEmployee(employeeId).as(LeavePay[].class);
        Arrays.stream(leavePays).forEach(leavePay -> delete(leavePay.getId()));
    }

    private RequestSpecification getAccountRequestSpec() {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                data.getAccountId());
    }
}