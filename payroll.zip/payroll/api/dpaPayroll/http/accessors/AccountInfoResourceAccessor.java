package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.http.RequestHelper;
import payroll.api.dpaPayroll.models.AccountInfoForUpdate;

public class AccountInfoResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public AccountInfoResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response get(String accountId) {
        return getAccountRequestSpec(accountId)
                .get("/info");
    }

    public Response put(String accountId, AccountInfoForUpdate accountInfoForUpdate) {
        return getAccountRequestSpec(accountId)
                .contentType("application/json")
                .body(accountInfoForUpdate)
                .put("/info");
    }

    private RequestSpecification getAccountRequestSpec(String accountId) {
        return RequestHelper.setupCommonAccountScopedRequest(
                data.getBaseUri(),
                tokenSource.getBearerToken(),
                data.getVersion(),
                accountId);
    }
}