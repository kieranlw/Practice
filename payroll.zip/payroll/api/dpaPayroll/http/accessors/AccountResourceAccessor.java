package payroll.api.dpaPayroll.http.accessors;

import io.restassured.response.Response;
import payroll.api.dpaPayroll.http.AccountResourceCallSetupData;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;
import payroll.api.dpaPayroll.models.AccountForCreate;

import static io.restassured.RestAssured.given;

public class AccountResourceAccessor {
    private AccountResourceCallSetupData data;
    private IBearerTokenSource tokenSource;

    public AccountResourceAccessor(AccountResourceCallSetupData data, IBearerTokenSource tokenSource) {
        this.data = data;
        this.tokenSource = tokenSource;
    }

    public Response post(AccountForCreate accountForCreate) {
        return given().log().all()
                .baseUri(data.getBaseUri())
                .basePath("/v{version}/accounts")
                .header("Authorization", "Bearer " + tokenSource.getBearerToken())
                .pathParam("version", data.getVersion())
                .relaxedHTTPSValidation()
                .contentType("application/json")
                .body(accountForCreate)
                .post();
    }
}
