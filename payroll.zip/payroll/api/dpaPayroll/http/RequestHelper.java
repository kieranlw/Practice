package payroll.api.dpaPayroll.http;

import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.given;

public class RequestHelper {
    /**
     * Sets a number of parameters commonly used in our HTTP requests. If you don't like
     * what this method is doing by default plz setup the request manually. This is meant
     * to be a convenience.
     * @param
     * @return
     */
    public static RequestSpecification setupCommonAccountScopedRequest(
            String baseUri,
            String bearerToken,
            String version,
            String accountId) {

        return given().log().all()
                .baseUri(baseUri)
                .basePath("/v{version}/accounts/{accountId}")
                .header("Authorization", "Bearer " + bearerToken)
                .pathParam("version", version)
                .pathParam("accountId", accountId)
                .relaxedHTTPSValidation(); // Turn this off when we actually have valid certs!
    }

    /**
     * Sets up a request with only a base path and authorization.
     * @param
     * @return
     */
    public static RequestSpecification setupRootedRequest(
            String baseUri,
            String bearerToken) {

        return given().log().all()
                .baseUri(baseUri)
                .header("Authorization", "Bearer " + bearerToken)
                .relaxedHTTPSValidation(); // Turn this off when we actually have valid certs!
    }
}
