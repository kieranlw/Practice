package payroll.api.dpaPayroll.http;

import payroll.api.dpaPayroll.environment.Environment;
import payroll.api.dpaPayroll.http.accessors.*;
import payroll.api.dpaPayroll.http.token.BearerTokenSourceFactory;
import payroll.api.dpaPayroll.http.token.IBearerTokenSource;

/**
 * Creates resource accessors scoped to a specific account. The factory itself
 * is setup with an account which it passes on to the accessors it creates.
 */
public class AccountScopedResourceAccessorFactory {
    private AccountResourceCallSetupData commonCallSetupData;
    private IBearerTokenSource commonBearerTokenSource;
    private EnvironmentResourceCallSetupData environmentCallSetupData;

    private AccountScopedResourceAccessorFactory(String accountId, Environment environment) {
        this.commonCallSetupData = new AccountResourceCallSetupData(
                environment.getBaseURL(),
                accountId,
                environment.getVersion());
        this.environmentCallSetupData = new EnvironmentResourceCallSetupData(environment.getBaseURL(),
                environment.getTokenBaseURI(),
                accountId,
                environment.getVersion());
        this.commonBearerTokenSource =(System.getProperty("grantType").equalsIgnoreCase("password"))?
                BearerTokenSourceFactory.authenticationWithPassword(environment):
                BearerTokenSourceFactory.authenticationWithClientCredentials(environment);
    }

    public JobCodesResourceAccessor getJobCodesAccessor(){
        return new JobCodesResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public BenefitsResourceAccessor getBenefitsAccessor(){
        return new BenefitsResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public EmployeeResourceAccessor getEmployeeResourceAccessor(){
        return new EmployeeResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public EqualEmploymentConfigResourceAccessor getEqualEmploymentConfigAccessor(){
        return new EqualEmploymentConfigResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public DeductionResourceAccessor getDeductionsAccessor(){
        return new DeductionResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public ContactsResourceAccessor getContactsAccessor(){
        return new ContactsResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public WorkLocationResourceAccessor getWorkLocationAccessor(){
        return new WorkLocationResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public static AccountScopedResourceAccessorFactory fromEnvironmentConfig(String accountId, Environment environment)
    {
        return new AccountScopedResourceAccessorFactory(accountId, environment);
    }

    public OtherPayResourceAccessor getOtherPayAccessor(){
        return new OtherPayResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public AccountResourceAccessor getAccountResourceAccessor(){
        return new AccountResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public AccountInfoResourceAccessor getAccountInfoResourceAccessor(){
        return new AccountInfoResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public AccrualFrequenciesResourceAccessor getAccrualFrequenciesResourceAccessor(){
        return new AccrualFrequenciesResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public AgenciesConfigurationsResourceAccessor getAgenciesConfigurationsResourceAccessor(){
        return new AgenciesConfigurationsResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public DepartmentsResourceAccessor getDepartmentsResourceAccessor(){
        return new DepartmentsResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public DependentInfoAccessor getDependentInfoAccessor(){
        return new DependentInfoAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public DirectDepositResourceAccessor getDirectDepositResourceAccessor(){
        return new DirectDepositResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public StatusResourceAccessor getStatusResourceAccessor(){
        return new StatusResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public LeavePayResourceAccessor getLeavePayResourceAccessor(){
        return new LeavePayResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public PayInfoResourceAccessor getPayInfoResourceAccessor(){
        return new PayInfoResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public PayStubResourceAccessor getPayStubResourceAccessor(){
        return new PayStubResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public PayHistoryResourceAccessor getPayHistoryResourceAccessor(){
        return new PayHistoryResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public EnvironmentAccessor getEnvironmentAccessor(){
        return new EnvironmentAccessor(environmentCallSetupData, commonBearerTokenSource);
    }

    public PayRollDataResourceAccessor getPayRollDataResourceAccessor(){
        return new PayRollDataResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public PayRollResourceAccessor getPayRollResourceAccessor(){
        return new PayRollResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public ScheduledPayrollResourceAccessor getScheduledPayrollResourceAccessor(){
        return new ScheduledPayrollResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public MasterItemGroupsResourceAccessor getMasterItemGroupsResourceAccessorResourceAccessor(){
        return new MasterItemGroupsResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public AnnualTaxFormsAccessor getAnnualTaxFormsAccessor(){
        return new AnnualTaxFormsAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public StandardReportAccessor getStandardReportAccessor(){
        return new StandardReportAccessor(commonCallSetupData, commonBearerTokenSource);
    }

    public PayDataResourceAccessor getPayDataResourceAccessor(){
        return new PayDataResourceAccessor(commonCallSetupData, commonBearerTokenSource);
    }
}
