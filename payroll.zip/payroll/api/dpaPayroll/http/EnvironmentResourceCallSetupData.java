package payroll.api.dpaPayroll.http;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public class EnvironmentResourceCallSetupData {

    @Getter
    private String dpaUri;

    @Getter
    private String mpcUri;

    @Getter
    private String accountId;

    @Getter
    private String version;

}
