package payroll.api.dpaPayroll.http;

import lombok.Getter;

public class AccountResourceCallSetupData {
    public final String DefaultVersion = "1.0";

    @Getter
    private String baseUri;

    @Getter
    private String accountId;

    @Getter
    private String version;

    public AccountResourceCallSetupData(String baseUri, String accountId) {
        this.baseUri = baseUri;
        this.accountId = accountId;
        this.version = DefaultVersion;
    }

    public AccountResourceCallSetupData(String baseUri, String accountId, String version) {
        this.baseUri = baseUri;
        this.accountId = accountId;
        this.version = version;
    }
}
