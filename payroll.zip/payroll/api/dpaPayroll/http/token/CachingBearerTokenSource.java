package payroll.api.dpaPayroll.http.token;

/**
 * A kind of bearer token source that just wraps whatever bearer token you
 * set it up to wrap. It adds caching behaviour so that once a token has
 * been obtained by the wrapped instance, it doesn't actually invoke the
 * wrapped instance any more on future token requests. This is an
 * optimization that improves unit test performance and reduces load on
 * the Authorization server.
 */
public class CachingBearerTokenSource implements IBearerTokenSource {
    private IBearerTokenSource wrapped;
    private String token;

    public CachingBearerTokenSource(IBearerTokenSource wrapped) {
        this.wrapped = wrapped;
    }

    @Override
    public String getBearerToken() {

        // TODO: If you wanted to get fancy, you could check
        // the token's expiry time and use that to determine whether
        // or not to get a new one. We don't do that here because
        // a token's lifetime is unlikely to expire while unit
        // tests are using it.

        // If there's already a token, return it instead of actually
        // getting a new one.
        if (token != null)
            return token;

        // There's not already a token. Go get one.
        token = wrapped.getBearerToken();

        return token;
    }
}
