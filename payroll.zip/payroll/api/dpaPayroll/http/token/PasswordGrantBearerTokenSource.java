package payroll.api.dpaPayroll.http.token;

import io.restassured.filter.log.LogDetail;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payroll.api.Token;
import utils2.LogInfo;

import static io.restassured.RestAssured.given;

/**
 * A kind of bearer token source that gets access tokens via the password grant.
 */
public class PasswordGrantBearerTokenSource implements IBearerTokenSource {

    private PasswordGrantTokenCallSetupData data;

    public PasswordGrantBearerTokenSource(PasswordGrantTokenCallSetupData data) {
        this.data = data;
    }

    @Override
    public String getBearerToken() {
        // Go get a token
        LogInfo.log_Status("authentication with grant_type:Password ");
        RequestSpecification request = given()
                .relaxedHTTPSValidation()
                .auth().preemptive().basic(data.getClientId(), data.getClientSecret())
                .contentType("x-www-form-urlencoded")
                .formParam("grant_type", "password")
                .formParam("username", data.getUsername())
                .formParam("password", data.getPassword())
                .formParam("scope", data.getScope())
                .header("accept", "application/json")
                .header("Connection", "keep-alive")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .request();

        Response res = request.post(data.getBaseUri() + "/connect/token");
        return res.as(Token.class).access_token;
    }
}
