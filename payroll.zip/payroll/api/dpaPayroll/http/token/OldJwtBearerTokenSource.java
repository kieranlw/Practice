package payroll.api.dpaPayroll.http.token;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import payroll.api.Token;
import payroll.api.dpaPayroll.jwt.JWTCallSetupData;
import payroll.api.dpaPayroll.jwt.OldJwtCallSetupData;

import static io.restassured.RestAssured.given;

public class OldJwtBearerTokenSource implements IBearerTokenSource {

    private OldJwtCallSetupData data;

    public OldJwtBearerTokenSource(OldJwtCallSetupData data) {
        this.data = data;
    }

    @Override
    public String getBearerToken() {

        Response res = create();
        return res.as(Token.class).access_token;
    }

    public Response create(){
        RequestSpecification request = given()
                .relaxedHTTPSValidation()
                .auth().preemptive().basic(data.getClientId(), data.getClientSecret())
                .contentType("x-www-form-urlencoded")
                .formParam("grant_type", "urn:ietf:params:oauth:grant-type:jwt-bearer")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .formParam("assertion", create_JWT_AuthenticationToken())
                .formParam("scope", data.getScope())
                .formParam("accountId", data.getAccount())
                .request();

        return request.post(data.getBaseUri() + "/connect/token");
    }

    /**
     * Sends a token request excluding the accountId
     */
    public Response createNoAccountId(){
        RequestSpecification request = given()
                .relaxedHTTPSValidation()
                .auth().preemptive().basic(data.getClientId(), data.getClientSecret())
                .contentType("x-www-form-urlencoded")
                .formParam("grant_type", "urn:ietf:params:oauth:grant-type:jwt-bearer")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .formParam("assertion", create_JWT_AuthenticationToken())
                .formParam("scope", data.getScope())
                .request();

        return request.post(data.getBaseUri() + "/connect/token");
    }


    // Sample method to construct a JWT
    //Uses a default JwtBuilder
    private String create_JWT_AuthenticationToken() {
        SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.RS256;

        JSONObject payload1 = new JSONObject(data.getPayload());
        String payloadJson = payload1.toString();

        JwtBuilder builder = Jwts.builder()
                .setPayload(payloadJson)
                .setHeaderParam("typ", data.getJwtHeader().getTyp())
                .setHeaderParam("alg", data.getJwtHeader().getAlg())
                .setHeaderParam("kid", data.getJwtHeader().getKid())
                .signWith(signatureAlgorithm, data.getPrivateKey());

        return builder.compact();
    }
}