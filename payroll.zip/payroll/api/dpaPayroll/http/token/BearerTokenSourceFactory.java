package payroll.api.dpaPayroll.http.token;

import payroll.api.dpaPayroll.TestAccount;
import payroll.api.dpaPayroll.environment.Environment;
import payroll.api.dpaPayroll.jwt.JWTCallSetupData;

public class BearerTokenSourceFactory {

    /**
     * You can create a bearer token source yourself but this factory method
     * will make things easier for you by automatically ripping common values
     * out of the environment config.
     *
     * @return Returns a client credentials bearer token source by default.
     */
    public static IBearerTokenSource authenticationWithClientCredentials(Environment environment) {

        // This is essentially an implementation of the strategy pattern. At the time
        // of writing this there are 3 ways to get an access token: client_credentials,
        // password, jwt-bearer. This factory is choosing to use the client_credentials
        // strategy but it could just as easily use password or jwt-bearer.

        return new CachingBearerTokenSource(
                new ClientCredentialsGrantBearerTokenSource(
                        new ClientCredentialsGrantTokenCallSetupData(
                                environment.getTokenBaseURI(),
                                environment.getClientId(),
                                environment.getClientSecret(),
                                environment.getScope()
                        )));
    }

    public static IBearerTokenSource authenticationWithPassword(Environment environment) {
        return  new PasswordGrantBearerTokenSource(new PasswordGrantTokenCallSetupData(
                environment.getTokenBaseURI(),
                environment.getClientId(),
                environment.getClientSecret(),
                environment.getDefaultUser(),
                environment.getDefaultPassword(),
                environment.getScope()
        ));
    }
}
