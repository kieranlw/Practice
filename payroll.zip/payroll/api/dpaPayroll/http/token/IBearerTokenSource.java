package payroll.api.dpaPayroll.http.token;

/**
 * An abstract way of getting an access token. Depending on this
 * abstraction rather than a concretion is like saying "I don't
 * care where the access token comes from". This is the loosely
 * coupled relationship you generally want to see in code.
 */
public interface IBearerTokenSource {
    public String getBearerToken();
}
