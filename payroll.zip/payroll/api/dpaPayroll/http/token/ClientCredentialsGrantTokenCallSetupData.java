package payroll.api.dpaPayroll.http.token;

import lombok.Getter;

public class ClientCredentialsGrantTokenCallSetupData {

    @Getter
    private String baseUri;
    @Getter
    private String clientId;
    @Getter
    private String clientSecret;
    @Getter
    private String scope;

    public ClientCredentialsGrantTokenCallSetupData(String baseUri, String clientId, String clientSecret, String scope) {

        this.baseUri = baseUri;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.scope = scope;
    }
}
