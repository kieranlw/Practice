package payroll.api.dpaPayroll.http.token;

import lombok.Getter;

public class PasswordGrantTokenCallSetupData {

    @Getter
    private String baseUri;
    @Getter
    private String clientId;
    @Getter
    private String clientSecret;
    @Getter
    private String username;
    @Getter
    private String password;
    @Getter
    private String scope;

    public PasswordGrantTokenCallSetupData(String baseUri, String clientId, String clientSecret, String username, String password, String scope) {

        this.baseUri = baseUri;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.username = username;
        this.password = password;
        this.scope = scope;
    }
}
