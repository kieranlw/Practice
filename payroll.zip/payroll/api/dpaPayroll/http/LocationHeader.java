package payroll.api.dpaPayroll.http;

import io.restassured.http.Headers;
import io.restassured.response.Response;

public class LocationHeader {

    /**
     * Extract from the location header the GUID of a resource created with a POST
     * Use when the GUID is the last element of the path
     * @param response from server with a location header
     * @return GUID
     */
    public static String extractResourceId(Response response) {
        Headers headers = response.getHeaders();
        String headerLocation = headers.get("Location").toString();
        return headerLocation.substring(headerLocation.lastIndexOf("/") + 1);
    }
}