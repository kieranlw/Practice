package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompanyContactsObject {

    @JsonProperty("id")
    public String id;
    @JsonProperty("contactType")
    public String contactType;
    @JsonProperty("name")
    public String name;
    @JsonProperty("email")
    public String email;
    @JsonProperty("title")
    public String title;
    @JsonProperty("mobilePhone")
    public String mobilePhone;
    @JsonProperty("phone")
    public String phone;
    @JsonProperty("fax")
    public String fax;
    @JsonProperty("useAccountDefaultContactInfo")
    public Boolean useAccountDefaultContactInfo;
    @JsonProperty("sendEmailNotifications")
    public Boolean sendEmailNotifications;
    @JsonProperty("marketingOptOut")
    public Boolean marketingOptOut;

    public static CompanyContactsObject createDefaultCompanyContactsForCreate() {
        return new CompanyContactsObject(
                null,
                "Other",
                "string",
                "email@test.com",
                "string",
                "string",
                "string",
                "string",
                false,
                true,
                true);
    }
}
