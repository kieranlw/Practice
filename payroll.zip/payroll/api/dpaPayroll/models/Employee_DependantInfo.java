package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class Employee_DependantInfo {

    @JsonProperty("employeeId")
    private String employeeId;

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("middleName")
    private String middleName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("suffix")
    private String suffix;

    @JsonProperty("ssn")
    private String ssn;

    @JsonProperty("acaCoverageType")
    private String acaCoverageType;
    @JsonProperty("birthDate")
    private String birthDate;

    @JsonProperty("startDate")
    private String startDate;

    @JsonProperty("endDate")
    private String endDate;

    public static Employee_DependantInfo getEmployee_DependantInfo_FromFile(ReadableFile employeeFile) {
        return employeeFile.readJsonAs(Employee_DependantInfo.class);
    }
}
