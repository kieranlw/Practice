package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
@AllArgsConstructor
public class Departments {

    @JsonProperty("id")
    public String id;
    @JsonProperty("code")
    public String code;
    @JsonProperty("description")
    public String description;
    @JsonProperty("isActive")
    public Boolean isActive;
    @JsonProperty("hideSalaryHoursOnStubs")
    public Boolean hideSalaryHoursOnStubs;
    @JsonProperty("checkOverrideName")
    public String checkOverrideName;
    @JsonProperty("checkOverrideAddress1")
    public String checkOverrideAddress1;
    @JsonProperty("checkOverrideAddress2")
    public String checkOverrideAddress2;
    @JsonProperty("checkOverrideAddress3")
    public String checkOverrideAddress3;
    @JsonProperty("defaultUnemploymentState")
    public String defaultUnemploymentState;
    @JsonProperty("defaultWorkLocationId")
    public String defaultWorkLocationId;
    @JsonProperty("workersCompensationCode1")
    public String workersCompensationCode1;
    @JsonProperty("workersCompensationCode2")
    public String workersCompensationCode2;
    @JsonProperty("excludeFromWorkersCompensation")
    public Boolean excludeFromWorkersCompensation;
    @JsonProperty("workersCompensationRate")
    public Double workersCompensationRate;
    @JsonProperty("workersCompensationState")
    public String workersCompensationState;

}
