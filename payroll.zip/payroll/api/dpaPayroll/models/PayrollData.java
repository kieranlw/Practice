package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class PayrollData {

    @JsonProperty("employeePayData")
    private EmployeePayData[] employeePayData;

    public static PayrollData getEmployeePayDataFromFile(ReadableFile file) {
        return file.readJsonAs(PayrollData.class);
    }

}
