package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.BankAccountType;
import payroll.api.dpaPayroll.models.enums.DeductionStatus;
import payroll.api.dpaPayroll.models.enums.DeductionType;

import java.util.Date;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class DeductionForCreate {

    @JsonProperty("isElectronicallyFundedAccount")
    private boolean isElectronicallyFundedAccount;

    @JsonProperty("employeeId")
    private String employeeId;

    @JsonProperty("deductionTypeId")
    private String deductionTypeId;

    @JsonProperty("status")
    private DeductionStatus status;

    @JsonProperty("flatAmount")
    private Double flatAmount;

    @JsonProperty("percentage")
    private Double percentage;

    @JsonProperty("type")
    private DeductionType type;

    @JsonProperty("maxPercentageOfGrossPay")
    private Double maxPercentageOfGrossPay;

    @JsonProperty("minimumPay")
    private Double minimumPay;

    @JsonProperty("maxAmountPerPay")
    private Double maxAmountPerPay;

    @JsonProperty("accruedAmount")
    private Double accruedAmount;

    @JsonProperty("maxAccruedAmount")
    private Double maxAccruedAmount;

    @JsonProperty("startDate")
    private Date startDate;

    @JsonProperty("endDate")
    private Date endDate;

    @JsonProperty("systemStartDate")
    private Date systemStartDate;

    @JsonProperty("systemEndDate")
    private Date systemEndDate;

    @JsonProperty("deductionPriority")
    private Integer deductionPriority;

    @JsonProperty("disposableIncomePriority")
    private Integer disposableIncomePriority;

    @JsonProperty("agencyId")
    private String agencyId;

    @JsonProperty("agencyMemo")
    private String agencyMemo;

    @JsonProperty("bankRoutingNumber")
    private String bankRoutingNumber;

    @JsonProperty("bankAccountNumber")
    private String bankAccountNumber;

    @JsonProperty("bankAccountType")
    private BankAccountType bankAccountType;

    @JsonProperty("associatedDeductionId")
    private String associatedDeductionId;

    @JsonProperty("requiresGarnishmentFee")
    private boolean requiresGarnishmentFee;

    @JsonProperty("ignoreAllocations")
    private boolean ignoreAllocations;

    public static DeductionForCreate getDirectDepositFromFile(ReadableFile file) {
        return file.readJsonAs(DeductionForCreate.class);
    }
}
