package payroll.api.dpaPayroll.models.StandardReport;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Builder
@Data
@AllArgsConstructor
public class ReportParameter {
    @JsonProperty
    private String daterange;
    @JsonProperty
    private String paydate;
    @JsonProperty
    private String startdate;
    @JsonProperty
    private String enddate;
    @JsonProperty
    private String year;
    @JsonProperty
    private String paymenttype;
    @JsonProperty
    private String employeestatus;
    @JsonProperty
    private String quarter;
    @JsonProperty
    private String summarization;
    @JsonProperty
    private String groupby;
    @JsonProperty
    private String deferredcompbenefit1;
    @JsonProperty
    private String firstperiodenddate;
    @JsonProperty
    private String turnovergoal;
    @JsonProperty
    private String jobcode;
    @JsonProperty
    private String preview;

    private Map<String, Object> parameters;

    public ReportParameter() {
        parameters = new HashMap<>();
    }

    @JsonAnySetter
    public void add(String property, Object value) {
        parameters.put(property, value);
    }

    @JsonAnyGetter
    public Map<String, Object> get() {
        return parameters;
    }
}
