package payroll.api.dpaPayroll.models.StandardReport;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class StandardReport {

    @JsonProperty("reportName")
    private String reportName;
    @JsonProperty("reportId")
    private int reportId;
    @JsonProperty("reportParameters")
    private List<StandardReportParameter> reportParameters;

}
