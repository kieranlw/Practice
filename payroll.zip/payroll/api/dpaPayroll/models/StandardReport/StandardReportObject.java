package payroll.api.dpaPayroll.models.StandardReport;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import org.testng.annotations.DataProvider;
import payroll.api.dpaPayroll.models.enums.StandartReportTypes;
import static payroll.api.dpaPayroll.models.enums.StandartReportTypes.*;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class StandardReportObject {
    @JsonProperty("reportId")
    private int reportId;

    @JsonProperty("reportParameters")
    private ReportParameter reportParameters;

    @DataProvider(name = "ReportSuccess")
    protected Object[] createReports() {
        Object[] testData = new Object[]{
                StandardReportObject.builder().reportId(THIRD_PARTY_SICK_REPORT).reportParameters(ReportParameter.builder().year("2021").build()).build(),
                StandardReportObject.builder().reportId(ACCOUNT_RECONCILIATION_BY_QUARTER).reportParameters(ReportParameter.builder().year("2021").build()).build(),
                StandardReportObject.builder().reportId(AGENCY_PAYEE_REPORT).reportParameters(ReportParameter.builder().daterange("Custom").startdate("2021-11-01").enddate("2021-12-21").build()).build(),
                StandardReportObject.builder().reportId(AMTRUST_WORKERS_COMP).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(AUDIT_LOG).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(CERTIFIED_PAYROLL).reportParameters(ReportParameter.builder().paydate("2021-12-06").build()).build(),
                StandardReportObject.builder().reportId(CHECK_RECONCILIATION).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(DEFERRED_COMP_401K_REPORT).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(DEPARTMENT_SUMMARY).reportParameters(ReportParameter.builder().daterange("SpecificPay").paydate("2021-12-06").build()).build(),
                StandardReportObject.builder().reportId(DIRECT_DEPOSIT).reportParameters(ReportParameter.builder().paydate("2021-12-06").build()).build(),
                StandardReportObject.builder().reportId(DIRECT_DEPOSIT_SETUP).reportParameters(ReportParameter.builder().build()).build(),
                StandardReportObject.builder().reportId(EARNINGS_STATEMENT).reportParameters(ReportParameter.builder().paydate("2021-12-06").paymenttype("All").build()).build(),
                StandardReportObject.builder().reportId(EMPLOYEE_BENEFIT).reportParameters(ReportParameter.builder().build()).build(),
                StandardReportObject.builder().reportId(EMPLOYEE_LEAVE_PAY).reportParameters(ReportParameter.builder().build()).build(),
                StandardReportObject.builder().reportId(EMPLOYEE_STATUS).reportParameters(ReportParameter.builder().employeestatus("All").build()).build(),
                StandardReportObject.builder().reportId(EXPENSE_ALLOCATION).reportParameters(ReportParameter.builder().daterange("SpecificPay").paydate("2021-12-06").groupby("None").build()).build(),
                StandardReportObject.builder().reportId(FUTA_SUTA_QUARTERLY_DETAIL).reportParameters(ReportParameter.builder().year("2021").quarter("4").build()).build(),
                StandardReportObject.builder().reportId(GUARD_WORKERS_COMP).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(INSURELINX_WORKERS_COMP).reportParameters(ReportParameter.builder().daterange("SpecificPay").paydate("2021-12-06").build()).build(),
                StandardReportObject.builder().reportId(JOB_CODE_SUMMARY_REPORT).reportParameters(ReportParameter.builder().paydate("2021-12-06").build()).build(),
                StandardReportObject.builder().reportId(LABOR_DISTRIBUTION).reportParameters(ReportParameter.builder().paydate("2021-12-06").summarization("Average").build()).build(),
                StandardReportObject.builder().reportId(LABOR_GROWTH).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(LABOR_TURNOVER).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(NEW_HIRE_REPORT).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(PAY_EXCEPTIONS).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(PAYROLL_SUMMARY).reportParameters(ReportParameter.builder().daterange("SpecificPay").paydate("2021-12-06").build()).build(),
                StandardReportObject.builder().reportId(PAYROLL_SUMMARY_BY_DEPARTMENT).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(PER_PAY_AUDIT_REPORT).reportParameters(ReportParameter.builder().build()).build(),
                StandardReportObject.builder().reportId(RAM_FUND_WORKERS_COMP).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(RECEIVED_CHECK_LOG).reportParameters(ReportParameter.builder().paydate("2021-12-06").build()).build(),
                StandardReportObject.builder().reportId(SELECTIVE_WORKERS_COMP).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(SMARTPAY_WORKERS_COMP).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(STANDARD_DEDUCTION_REPORT).reportParameters(ReportParameter.builder().build()).build(),
                StandardReportObject.builder().reportId(TRUPAY_WORKERS_COMP).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(WAGE_SUMMARY).reportParameters(ReportParameter.builder().daterange("SpecificPay").paydate("2021-12-06").build()).build(),
                StandardReportObject.builder().reportId(WORKERS_COMP_EARNINGS_REPORT).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(WORKSHEET).reportParameters(ReportParameter.builder().build()).build(),
                StandardReportObject.builder().reportId(YTD_EARNINGS).reportParameters(ReportParameter.builder().daterange("CurrentPay").groupby("None").build()).build(),
                StandardReportObject.builder().reportId(PAYROLL_REGISTER).reportParameters(ReportParameter.builder().paydate("2021-12-06").build()).build(),
                StandardReportObject.builder().reportId(ACCOUNT_AUDIT).reportParameters(ReportParameter.builder().build()).build(),
                StandardReportObject.builder().reportId(DEFERRED_COMP_401K_DETAIL_REPORT).reportParameters(ReportParameter.builder().daterange("CurrentPay").deferredcompbenefit1("b355d8ab-1ea7-7573-d796-3a0064667061").build()).build(),
                StandardReportObject.builder().reportId(EMPLOYER_W3).reportParameters(ReportParameter.builder().year("2021").build()).build(),
                StandardReportObject.builder().reportId(TACO_BELL_TURNOVER_REPORT).reportParameters(ReportParameter.builder().firstperiodenddate("10-02-2021").turnovergoal("100").jobcode("728b6ab1-5042-31a8-61b7-3a0064666fb5").build()).build(),
                StandardReportObject.builder().reportId(PMA_WORKERS_COMP).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(EMPLOYER_1095C).reportParameters(ReportParameter.builder().year("2021").preview("yes").build()).build(),
                StandardReportObject.builder().reportId(EMPLOYER_1094C).reportParameters(ReportParameter.builder().year("2021").preview("yes").build()).build(),

                // TODO ACCOUNT_SEPARATOR_PAGE error 500 no parameter in report
//                 StandardReportObject.builder().reportId(ACCOUNT_SEPARATOR_PAGE).reportParameters(ReportParameter.builder().build()).build(),

                //TODO: errors in UI
                //Exclusive 'Charles Schwab Transmittal' is not active.
                // StandardReportObject.builder().reportId(CHARLES_SCHWAB_TRANSMITTAL).reportParameters(ReportParameter.builder().paydate("2021-12-06").build()).build(),
                //76 is an unknown report Id
                // StandardReportObject.builder().reportId(PAYROLL_SHIPPING_LABEL).reportParameters(ReportParameter.builder().build()).build(),

                //TODO: no data present for current account
               // StandardReportObject.builder().reportId(ANNUAL_ALLOCATED_TIP_REPORT).reportParameters(ReportParameter.builder().year("2021").build()).build(),
                // StandardReportObject.builder().reportId(EMPLOYER_W2).reportParameters(ReportParameter.builder().year("2021").build()).build(),
                // StandardReportObject.builder().reportId(MARYLAND_TIP_CREDIT_STATEMENT).reportParameters(ReportParameter.builder().paydate("2021-12-06").build()).build(),
                // StandardReportObject.builder().reportId(PROJECTED_TIP_CREDIT_REPORT).reportParameters(ReportParameter.builder().year("2021").quarter("1").build()).build(),
                // StandardReportObject.builder().reportId(TIP_VOUCHER).reportParameters(ReportParameter.builder().paydate("2021-12-06").build()).build(),

        };
        return testData;
    }

    @DataProvider(name = "ReportSuccess_Auttest2")
    protected Object[] createReports_auttest2() {
        Object[] testData = new Object[]{
                StandardReportObject.builder().reportId(ANNUAL_ALLOCATED_TIP_REPORT).reportParameters(ReportParameter.builder().year("2021").build()).build(),
                StandardReportObject.builder().reportId(TIP_VOUCHER).reportParameters(ReportParameter.builder().paydate("2021-07-02").build()).build(),
                StandardReportObject.builder().reportId(PROJECTED_TIP_CREDIT_REPORT).reportParameters(ReportParameter.builder().year("2021").quarter("1").build()).build(),
                StandardReportObject.builder().reportId(EMPLOYER_W2).reportParameters(ReportParameter.builder().year("2019").build()).build(),
        };
        return testData;
    }

    @DataProvider(name = "ReportSuccess_Auto1099")
    protected Object[] createReports_auto1099() {
        Object[] testData = new Object[]{
                StandardReportObject.builder().reportId(PAYROLL_REGISTER).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(ACCOUNT_AUDIT).reportParameters(ReportParameter.builder().build()).build(),
                StandardReportObject.builder().reportId(YTD_EARNINGS).reportParameters(ReportParameter.builder().daterange("CurrentPay").groupby("None").build()).build(),
                StandardReportObject.builder().reportId(CHECK_RECONCILIATION).reportParameters(ReportParameter.builder().daterange("SpecificPay").paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(DEPARTMENT_SUMMARY).reportParameters(ReportParameter.builder().daterange("SpecificPay").paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(DIRECT_DEPOSIT).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(DIRECT_DEPOSIT_SETUP).reportParameters(ReportParameter.builder().build()).build(),
                StandardReportObject.builder().reportId(EARNINGS_STATEMENT).reportParameters(ReportParameter.builder().paydate("2019-03-08").paymenttype("All").build()).build(),
                StandardReportObject.builder().reportId(EMPLOYEE_STATUS).reportParameters(ReportParameter.builder().employeestatus("All").build()).build(),
                StandardReportObject.builder().reportId(EXPENSE_ALLOCATION).reportParameters(ReportParameter.builder().daterange("SpecificPay").paydate("2019-03-08").groupby("None").build()).build(),
                StandardReportObject.builder().reportId(JOB_CODE_SUMMARY_REPORT).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(LABOR_DISTRIBUTION).reportParameters(ReportParameter.builder().paydate("2019-03-08").summarization("Average").build()).build(),
                StandardReportObject.builder().reportId(LABOR_GROWTH).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(LABOR_TURNOVER).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(NEW_HIRE_REPORT).reportParameters(ReportParameter.builder().daterange("SpecificPay").paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(PAY_EXCEPTIONS).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(PAYROLL_SUMMARY).reportParameters(ReportParameter.builder().daterange("SpecificPay").paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(PAYROLL_SUMMARY_BY_DEPARTMENT).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(RECEIVED_CHECK_LOG).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(STANDARD_DEDUCTION_REPORT).reportParameters(ReportParameter.builder().build()).build(),
                StandardReportObject.builder().reportId(WAGE_SUMMARY).reportParameters(ReportParameter.builder().daterange("SpecificPay").paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(WORKERS_COMP_EARNINGS_REPORT).reportParameters(ReportParameter.builder().daterange("CurrentPay").build()).build(),
                StandardReportObject.builder().reportId(WORKSHEET).reportParameters(ReportParameter.builder().build()).build(),
        };
        return testData;
    }

    @DataProvider(name = "ReportIncorrectReportType1099acc")
    protected Object[] createReportsData() {
        Object[] testData = new Object[]{
                StandardReportObject.builder().reportId(EMPLOYEE_LEAVE_PAY).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(TIP_VOUCHER).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(PROJECTED_TIP_CREDIT_REPORT).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(ANNUAL_ALLOCATED_TIP_REPORT).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(THIRD_PARTY_SICK_REPORT).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(FUTA_SUTA_QUARTERLY_DETAIL).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(EMPLOYER_W2).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(EMPLOYEE_BENEFIT).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(EMPLOYER_W3).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(EMPLOYER_1095C).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build(),
                StandardReportObject.builder().reportId(EMPLOYER_1094C).reportParameters(ReportParameter.builder().paydate("2019-03-08").build()).build()
        };
        return testData;
    }

    public static class StandardReportObjectBuilder {
        private int reportId;

        public StandardReportObjectBuilder reportId(StandartReportTypes type) {
            this.reportId = type.getReportNumber();
            return this;
        }
    }
}
