package payroll.api.dpaPayroll.models.StandardReport;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class ReportRequest {

    @JsonProperty("reportId")
    private int reportId;

    @JsonProperty("reportParameters")
    private ReportParameter reportParameters;

    public static ReportRequest createDefault(int id) {
        ReportParameter reportParameter = new ReportParameter();
        reportParameter.add("paydate", "2021-07-02");
        reportParameter.add("employeeblankforall", "");
        reportParameter.add("paymenttype", "All");
        reportParameter.add("hidesalaryhours", true);
        reportParameter.add("hideleavepaytaken", true);
        reportParameter.add("hidechargetips", true);
        reportParameter.add("hideforcedtips", true);
        reportParameter.add("groupbyleaveclassification", true);
        reportParameter.add("hideotherearningshours", true);
        reportParameter.add("showaveragegross", true);
        reportParameter.add("empcustomfield", "");

        return new ReportRequestBuilder()
                .reportId(id)
                .reportParameters(reportParameter)
                .build();
    }

    public static ReportRequest createNotValid(int id) {
        String testValue = "Test";
        ReportParameter reportParameter = new ReportParameter();
        reportParameter.add("paydate", testValue);
        reportParameter.add("employeeblankforall", testValue);
        reportParameter.add("paymenttype", testValue);
        reportParameter.add("hidesalaryhours", testValue);
        reportParameter.add("hideleavepaytaken", testValue);
        reportParameter.add("hidechargetips", testValue);
        reportParameter.add("hideforcedtips", testValue);
        reportParameter.add("groupbyleaveclassification", testValue);
        reportParameter.add("hideotherearningshours", testValue);
        reportParameter.add("showaveragegross", testValue);
        reportParameter.add("empcustomfield", testValue);

        return new ReportRequestBuilder()
                .reportId(id)
                .reportParameters(reportParameter)
                .build();
    }
}