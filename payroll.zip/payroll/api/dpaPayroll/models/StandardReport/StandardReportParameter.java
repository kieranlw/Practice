package payroll.api.dpaPayroll.models.StandardReport;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.ReportType;

import java.util.List;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class StandardReportParameter {

    @JsonProperty("name")
    private String name;

    @JsonProperty("values")
    private String values;

    @JsonProperty("required")
    private boolean required;

    @JsonProperty("type")
    private ReportType type;

}
