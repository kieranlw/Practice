package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class EmployeeQueryParams {

    @JsonProperty("ssn")
    private String ssn;


}
