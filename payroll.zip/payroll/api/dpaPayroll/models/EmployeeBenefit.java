package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class EmployeeBenefit {

    @JsonProperty("id")
    private String id;
    @JsonProperty("employeeId")
    private String employeeId;
    @JsonProperty("benefitConfigId")
    private String benefitConfigId;
    @JsonProperty("benefitTypeCode")
    private Integer benefitTypeCode;
    @JsonProperty("benefitDescription")
    private String benefitDescription;
    @JsonProperty("bankAccountType")
    private String bankAccountType;
    @JsonProperty("bankRoutingNumber")
    private String bankRoutingNumber;
    @JsonProperty("bankAccountNumber")
    private String bankAccountNumber;
    @JsonProperty("subclassificationId")
    private String subclassificationId;
    @JsonProperty("benefitDefaultDescription")
    private String benefitDefaultDescription;
    @JsonProperty("amount")
    private Double amount;
    @JsonProperty("percentageAmount")
    private Double percentageAmount;
    @JsonProperty("status")
    private String status;
    @JsonProperty("accruedAmount")
    private Double accruedAmount;
    @JsonProperty("maxAccruedAmount")
    private Double maxAccruedAmount;
    @JsonProperty("startDate")
    private String startDate;
    @JsonProperty("endDate")
    private String endDate;
    @JsonProperty("lastStartDate")
    private String lastStartDate;
    @JsonProperty("lastEndDate")
    private String lastEndDate;
    @JsonProperty("isDefaultMaster")
    private Boolean isDefaultMaster;
    @JsonProperty("doesAccrue")
    private Boolean doesAccrue;
    @JsonProperty("isElectronicallyFunded")
    private Boolean isElectronicallyFunded;

    public static EmployeeBenefit getEmployeeBenefitFromFile(ReadableFile file) {
        return file.readJsonAs(EmployeeBenefit.class);
    }
}
