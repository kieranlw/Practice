package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class EqualEmploymentConfigCodes {

    @JsonProperty("id")
    private String id;

    @JsonProperty("code")
    private String code;

    @JsonProperty("description")
    private String description;

    public static EqualEmploymentConfigCodes[] getEqualEmploymentConfigCodes_FromFile(ReadableFile file) {
        return file.readJsonAs(EqualEmploymentConfigCodes[].class);
    }
}