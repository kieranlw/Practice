package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.OtherPayStatus;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor

public class OtherPayForCreate {
    @JsonProperty("employeeId")
    private String employeeId;

    @JsonProperty("otherPayConfigurationId")
    private String otherPayConfigurationId;

    @JsonProperty("status")
    private OtherPayStatus status;

    @JsonProperty("amount")
    private Double amount;

    @JsonProperty("hourlyAmountOverride")
    private Double hourlyAmountOverride;

    @JsonProperty("maxAccruedAmount")
    private Double maxAccruedAmount;

    @JsonProperty("startDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss") //2019-10-08T13:16:12
    private LocalDateTime startDate;

    @JsonProperty("endDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss") //2019-10-08T13:16:12
    private LocalDateTime endDate;

    @JsonProperty("ignoreAllocations")
    private Boolean ignoreAllocations;

    @JsonProperty("departmentId")
    private String departmentId;

    @JsonProperty("jobCodeId")
    private String jobCodeId;
}