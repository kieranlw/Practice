package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class DeductionClassification {
    @JsonProperty("id")
    private int id;
    @JsonProperty("description")
    private String description;
    @JsonProperty("groupDescription")
    private String groupDescription;
    @JsonProperty("typeDescription")
    private String typeDescription;
    @JsonProperty("percentageGrossTypeDescription")
    private String percentageGrossTypeDescription;
    @JsonProperty("w2Box12")
    private String w2Box12;
    @JsonProperty("w2Box14")
    private String w2Box14;
    @JsonProperty("isMemo")
    private Boolean isMemo;

    public static DeductionClassification[] getDeductionClassifications_FromFile(ReadableFile file) {
        return file.readJsonAs(DeductionClassification[].class);
    }
}
