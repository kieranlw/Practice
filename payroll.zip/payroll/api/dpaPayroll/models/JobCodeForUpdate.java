package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class JobCodeForUpdate {
    @JsonProperty("code")
    private String code;

    @JsonProperty("description")
    private String description;

    @JsonProperty("isActive")
    private boolean isActive;
}
