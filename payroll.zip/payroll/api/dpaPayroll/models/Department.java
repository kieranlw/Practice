package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;
import javax.annotation.Nullable;


@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class Department {

    @JsonProperty("id")
    private String id;

    @JsonProperty("description")
    private String description;

    @JsonProperty("code")
    private String code;

    @JsonProperty("isActive")
    private boolean isActive;

    @JsonProperty("hideSalaryHoursOnStubs")
    private boolean hideSalaryHoursOnStubs;

    @JsonProperty("checkOverrideName")
    private String checkOverrideName;

    @JsonProperty("checkOverrideAddress1")
    private String checkOverrideAddress1;

    @JsonProperty("checkOverrideAddress2")
    private String checkOverrideAddress2;

    @JsonProperty("checkOverrideAddress3")
    private String checkOverrideAddress3;

    @JsonProperty("defaultUnemploymentState")
    private String defaultUnemploymentState;

    @JsonProperty("excludeFromWorkersCompensation")
    private boolean excludeFromWorkersCompensation;

    @JsonProperty("workersCompensationCode1")
    private String workersCompensationCode1;

    @JsonProperty("workersCompensationCode2")
    private String workersCompensationCode2;

    @JsonProperty("workersCompensationRate")
    private @Nullable
    double workersCompensationRate;

    @JsonProperty("workersCompensationState")
    private String workersCompensationState;

    @JsonProperty("defaultWorkLocationId")
    private String defaultWorkLocationId;

    public static Department getDepartmentFromFile(ReadableFile file) {
        return file.readJsonAs(Department.class);
    }

    public static Department[] getDepartmentsFromFile(ReadableFile file) {
        return file.readJsonAs(Department[].class);
    }

    public boolean getIsActive() {
        return isActive;
    }

    public boolean getHideSalaryHoursOnStubs() {
        return hideSalaryHoursOnStubs;
    }

    public boolean getExcludeFromWorkersCompensation() {
        return excludeFromWorkersCompensation;
    }
}



