package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;


@Builder
@Data
@AllArgsConstructor
public class Environment_Status {

    @JsonProperty("status")
    private String status;

    @JsonProperty("version")
    private String version;
}
