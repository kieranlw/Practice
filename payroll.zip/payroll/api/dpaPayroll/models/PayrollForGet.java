package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PayrollForGet {
    @JsonProperty("payDate")
    public String payDate;

    @JsonProperty("periodEndDate")
    public String periodEndDate;

    @JsonProperty("period2EndDate")
    public String period2EndDate;

    @JsonProperty("payOfMonth")
    public Integer payOfMonth;

    @JsonProperty("payOfYear")
    public Integer payOfYear;

    @JsonProperty("unscheduledAccruesLeavePay")
    public Boolean unscheduledAccruesLeavePay;

    @JsonProperty("unscheduledBlocksFederalIncomeTaxes")
    public Boolean unscheduledBlocksFederalIncomeTaxes;

    @JsonProperty("unscheduledFederalOverrideRate")
    public Integer unscheduledFederalOverrideRate;

    @JsonProperty("unscheduledBlocksStateIncomeTaxes")
    public Boolean unscheduledBlocksStateIncomeTaxes;

    @JsonProperty("unscheduledStateOverrideRate")
    public Integer unscheduledStateOverrideRate;

    @JsonProperty("unscheduledUsesStandardDeductionsAndBenefits")
    public Boolean unscheduledUsesStandardDeductionsAndBenefits;

    @JsonProperty("unscheduledPriorYear")
    public Boolean unscheduledPriorYear;

    @JsonProperty("unscheduledSupplementalTaxCalculation")
    public Boolean unscheduledSupplementalTaxCalculation;

    @JsonProperty("isScheduled")
    public Boolean isScheduled;
}
