package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Builder
@Data
@AllArgsConstructor
public class EqualEmploymentConfigs {
    @JsonProperty("code")
    private String code;

    @JsonProperty("description")
    private String description;

    @JsonProperty("isActive")
    private boolean isActive;
}