package payroll.api.dpaPayroll.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DirectDepositInfo {

    private String routingNumber,
            accountNumber,
            convertDate,
            endDate,
            accountType;

    private boolean isActive,
            onlyDepositPortionOfAccount,
    paperCheckOnly,
    directDepositPaycard,
    voucherOnly;
}
