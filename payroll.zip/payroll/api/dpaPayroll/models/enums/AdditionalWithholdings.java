package payroll.api.dpaPayroll.models.enums;

public enum AdditionalWithholdings {
    PercentOfGross("PercentOfGross"),
    FlatAmount("FlatAmount");
    private String type;

    AdditionalWithholdings(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
