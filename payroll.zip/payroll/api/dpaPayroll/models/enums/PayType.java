package payroll.api.dpaPayroll.models.enums;

public enum PayType {
    Unknown, Hourly, Other, Shift, Salaried, InvalidForTest
}
