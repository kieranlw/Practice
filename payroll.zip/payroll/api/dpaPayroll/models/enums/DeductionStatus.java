package payroll.api.dpaPayroll.models.enums;

public enum DeductionStatus {
    Unknown, Pending, Active, Inactive, Expired, InvalidStatusToFail
}
