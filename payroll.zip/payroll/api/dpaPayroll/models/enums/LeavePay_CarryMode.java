package payroll.api.dpaPayroll.models.enums;

public enum LeavePay_CarryMode {
    Unknown, CarryAll, DoNotCarry, CarryCurrentYearHoursOnly, InvalidCarryMode
}
