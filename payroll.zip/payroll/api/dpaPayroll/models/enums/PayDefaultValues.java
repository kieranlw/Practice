package payroll.api.dpaPayroll.models.enums;

import common.ResourceFile;

public enum PayDefaultValues {
    HOURLY("payroll/data/newAPI/testData/payInfo/postHourly.json"),
    HOURLY_ALTERNATE("payroll/data/newAPI/testData/payInfo/postHourlyAlternate.json"),
    SALARIED("payroll/data/newAPI/testData/payInfo/postSalaried.json"),
    SALARIED_ALTERNATE("payroll/data/newAPI/testData/payInfo/postSalaried.json"),
    SHIFT("payroll/data/newAPI/testData/payInfo/postShift.json");

    private String filePath;

    PayDefaultValues(String filePath) {
        this.filePath = filePath;
    }

    public ResourceFile getResourceFile(){
        return new ResourceFile(filePath);
    }
}
