package payroll.api.dpaPayroll.models.enums;

public enum  BenefitType {
    FlatAmount, PctOfPay, MatchPctOfDeduction
}