package payroll.api.dpaPayroll.models.enums;

public enum OtherPayType {
    Regular,
    TaxableInAndOut,
    ReimbursementTaxable,
    NonTaxableReimbursement
}