package payroll.api.dpaPayroll.models.enums;

public enum ExemptReasonType {
    J1StudentVisa,
    F1StudentVisa,
    OtherNonResidentAlien,
    OtherExemptUSCitizen
}
