package payroll.api.dpaPayroll.models.enums;

public enum FederalWithholdingStatus {
    HeadOfHousehold,
    Married,
    Single,
    Exempt
}
