package payroll.api.dpaPayroll.models.enums;

public enum TaxRateSchedule {
    StandardOldW4,
    StandardNewW4,
    Higher
}
