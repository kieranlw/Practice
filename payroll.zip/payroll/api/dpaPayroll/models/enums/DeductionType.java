package payroll.api.dpaPayroll.models.enums;

public enum DeductionType {
    PercentOfGross, PercentOfNet, PercentOfMax, FlatAmount, Unknown,InvalidTypeToFail
}