package payroll.api.dpaPayroll.models.enums;

public enum CaliforniaWithholdingStatus {
    Single,
    Married,
    HeadOfHousehold,
    Exempt
}