package payroll.api.dpaPayroll.models.enums;

public enum BankAccountType {
    Unknown, Checking, Savings, bankAccountTypeNot
}
