package payroll.api.dpaPayroll.models.enums;

public enum OtherPayStatus {
    Active, Inactive, NotInUse, Pending
}
