package payroll.api.dpaPayroll.models.enums;

public enum OtherPayPaidType {
    FlatAmount,
    EmployeeDefault,
    HourlyRatePlus,
    HoursOnlyRateZero,
    PercentMasterItemGroupAmt,
    FixedRate
}