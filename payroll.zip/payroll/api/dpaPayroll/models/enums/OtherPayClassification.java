package payroll.api.dpaPayroll.models.enums;

public enum OtherPayClassification {
    Commission,
    MilitaryPay,
    JuryDutyPay,
    Bonus,
    Severance,
    GroupTermLife,
    SCorpInsurance,
    OtherTaxableFringe,
    ServiceCharge
}