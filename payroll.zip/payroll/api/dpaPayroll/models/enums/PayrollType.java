package payroll.api.dpaPayroll.models.enums;

public enum PayrollType {
    FirstScheduled, ExtraScheduled, Scheduled, Unscheduled
}
