package payroll.api.dpaPayroll.models.enums;

import com.fasterxml.jackson.annotation.JsonValue;

public enum ReportType {
    Boolean("Boolean"),
    DateTime("DateTime"),
    Quarter("Quarter"),
    SingleDate("Single Date"),
    DateRange("Date Range"),
    Enum("Enum"),
    Department("Department"),
    Jobcode("Jobcode"),
    Location("Location"),
    Year("Year"),
    LeavePay("Leave Pay"),
    Employee("Employee"),
    Deduction("Deduction"),
    CustomFieldName("Custom Field Name"),
    Benefit("Benefit"),
    OtherPay("Other Pay"),
    State("State"),
    ChargeTipReimbDed("Charge Tip Reimb Ded"),
    CashTipMemoDed("Cash Tip Memo Ded"),
    Text("Text"),
    DataOptionList("Data Option List"),
    DeferredCompBen("Deferred Comp Ben"),
    DeferredCompAdj("Deferred Comp Adj"),
    SortByCustomField("Sort By Custom Field"),
    IncludeReversals("Include Reversals"),
    ForcePayId("Force Pay Id"),
    InvoiceId("Invoice Id"),
    MasterItemGroup("Master Item Group"),
    EmpHistorySubtype("Emp History Subtype"),
    ChargeTipMemoDed("Charge Tip Memo Ded");

    private final String type;

    ReportType(String type) {
        this.type = type;
    }

    @JsonValue
    public String getType() {
        return type;
    }
}
