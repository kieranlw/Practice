package payroll.api.dpaPayroll.models.enums;

public enum PercentOfPayType {
    AdjustedGross,
    TrueGross,
    MasterItemGroup,
    DeferredCompGross
}