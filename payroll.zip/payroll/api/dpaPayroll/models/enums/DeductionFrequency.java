package payroll.api.dpaPayroll.models.enums;

public enum DeductionFrequency {
    EveryPay,
    FirstPayOfMonth,
    SecondPayOMonth,
    ThirdPayOfMonth,
    FourthPayOfMonth,
    First2PaysOfMonth,
    First4PaysOfMonth,
    FirstAndThirdPaysOfMonth
}
