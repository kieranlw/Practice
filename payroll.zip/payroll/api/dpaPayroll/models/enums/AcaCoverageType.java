package payroll.api.dpaPayroll.models.enums;

public enum AcaCoverageType {
    Unknown, Covered, Waived, EffectiveDates
}
