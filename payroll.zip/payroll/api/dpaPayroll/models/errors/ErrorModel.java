package payroll.api.dpaPayroll.models.errors;

import com.fasterxml.jackson.annotation.JsonProperty;
import common.Is;
import common.Verify;
import io.restassured.response.Response;
import lombok.Data;
import utils2.LogInfo;

import java.util.Map;

@Data
public class ErrorModel {

    @JsonProperty("type")
    private String type;

    @JsonProperty("title")
    private String title;

    @JsonProperty("status")
    private String status;

    @JsonProperty("traceId")
    private String traceId;

    @JsonProperty("errors")
    private Map<String, Object> errors;

    public static void verifyErrorCode(Response response, int errorCode) {
        Verify.that(response.getStatusCode(), Is.equalTo(errorCode));
    }

    public static void verifyErrorMessage(Response response, String specificErrorName, String... errorTexts) {
        for (String errorText : errorTexts) {
            String actualError1 = response.jsonPath().getString("errors");
            String actualError2 = response.jsonPath().getString("error");
            if (actualError1 == null||actualError2 != null) {
                Verify.that(actualError2, Is.stringContaining(errorText));
                Verify.that(actualError2, Is.stringContaining(specificErrorName));
            }
            if (actualError2 == null||actualError1 != null){

                Verify.that(actualError1, Is.stringContaining(errorText));
                Verify.that(actualError1, Is.stringContaining(specificErrorName));
            }

        }
    }

    public static void verifyError(Response response, int errorCode, String specificErrorName, String... errorTexts) {
        verifyErrorCode(response, errorCode);
        verifyErrorMessage(response, specificErrorName, errorTexts);
    }
}
