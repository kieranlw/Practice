package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class DependentInfoForUpdate {

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("middleName")
    private String middleName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("suffix")
    private String suffix;

    @JsonProperty("ssn")
    private String ssn;


    @JsonProperty("birthDate")
    private String birthDate;

    @JsonProperty("acaCoverageType")
    private String acaCoverageType;

    @JsonProperty("startDate")
    private String startDate;

    @JsonProperty("endDate")
    private String endDate;

    public static DependentInfoForUpdate getEmployeePersonalInfo_FromFile(ReadableFile employeeFile) {
        return employeeFile.readJsonAs(DependentInfoForUpdate.class);
    }
}
