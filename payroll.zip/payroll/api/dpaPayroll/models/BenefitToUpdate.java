package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.BankAccountType;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class BenefitToUpdate {

    @JsonProperty("status")
    private String status;
    @JsonProperty("subclassificationId")
    private String subclassificationId;
    @JsonProperty("amount")
    private Integer amount;
    @JsonProperty("percentageAmount")
    private Integer percentageAmount;
    @JsonProperty("maxAccruedAmount")
    private Integer maxAccruedAmount;
    @JsonProperty("startDate")
    private String startDate;
    @JsonProperty("endDate")
    private String endDate;
    @JsonProperty("ignoreAllocations")
    private Boolean ignoreAllocations;
    @JsonProperty("isElectronicallyFunded")
    private Boolean isElectronicallyFunded;
    @JsonProperty("bankRoutingNumber")
    private String bankRoutingNumber;
    @JsonProperty("bankAccountNumber")
    private String bankAccountNumber;
    @JsonProperty("bankAccountType")
    private BankAccountType bankAccountType;

    public static BenefitToUpdate getBenefitFromFile(ReadableFile file) {
        return file.readJsonAs(BenefitToUpdate.class);
    }
}
