package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class EmployeeAddress {

    @JsonProperty("address1")
    private String address1;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("zip")
    private String zip;
    @JsonProperty("zip4")
    private String zip4;
    @JsonProperty("county")
    private String county;
    @JsonProperty("country")
    private String country;

    public static EmployeeAddress createDefaultMapquestAddress () {
        return new EmployeeAddress(
                "1060 W Addison St",
                "Chicago",
                "IL",
                "60613",
                "4305",
                "Cook County",
                "US"
        );
    }

    public static EmployeeAddress createDefaultVertexAddress () {
        return new EmployeeAddress(
                "1060 W Addison St",
                "Chicago",
                "IL",
                "60613",
                "4566",
                "Cook",
                "US"
        );
    }

    public static EmployeeAddress createDefaultWrongEmployeeAddress () {
        return new EmployeeAddress(
                "711-2880 Nulla St.",
                "Mankato",
                "Mississippi",
                "96522",
                null,
                null,
                "US"
        );
    }
}
