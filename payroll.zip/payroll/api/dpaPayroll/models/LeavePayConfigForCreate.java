package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import common.ReadableFile;
import lombok.*;

import java.util.Random;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor

public class LeavePayConfigForCreate {
    @JsonProperty("number")
    private String number;

    @JsonProperty("description")
    private String description;

    @JsonProperty("isActive")
    private Boolean isActive;

    @JsonProperty("doesAccrue")
    private Boolean doesAccrue;

    @JsonProperty("masterItemGroupId")
    private String masterItemGroupId;

    @JsonProperty("minimumHoursForAccrual")
    private double minimumHoursForAccrual;

    @JsonProperty("rateMultiplier")
    private double rateMultiplier;

    @JsonProperty("warningLimit")
    private double warningLimit;

    @JsonProperty("showOnReports")
    private Boolean showOnReports;

    @JsonProperty("isMemoOnly")
    private Boolean isMemoOnly;

    @JsonProperty("excludeFromFullBlend")
    private Boolean excludeFromFullBlend;

    @JsonProperty("usePeriodEndForResetAndAccrual")
    private Boolean usePeriodEndForResetAndAccrual;

    @JsonProperty("useEmployeePeriodStartForResetAndAccrual")
    private Boolean useEmployeePeriodStartForResetAndAccrual;

    @JsonProperty("accrueOnlyIfPaid")
    private Boolean accrueOnlyIfPaid;

    @JsonProperty("doesMaximumUseBeginningBalance")
    private Boolean doesMaximumUseBeginningBalance;

    @JsonProperty("doesMaximumUseEndingBalance")
    private Boolean doesMaximumUseEndingBalance;

    @JsonProperty("doesReduceSalary")
    private Boolean doesReduceSalary;

    @JsonProperty("doesNotReduceSalaryHours")
    private Boolean doesNotReduceSalaryHours;

    @JsonProperty("doesNotResetAmountTaken")
    private Boolean doesNotResetAmountTaken;

    @JsonProperty("capOnHoursUsedToAccrue")
    private double capOnHoursUsedToAccrue;

    @JsonProperty("hideHoursTaken")
    private Boolean hideHoursTaken;

    @JsonProperty("preventNegativeAvailableHours")
    private Boolean preventNegativeAvailableHours;

    @JsonProperty("useMinimumWageAsRate")
    private Boolean useMinimumWageAsRate;

    @JsonProperty("showOnPaystub")
    private Boolean showOnPaystub;

    @JsonProperty("showCurrentAccrualOnPaystub")
    private Boolean showCurrentAccrualOnPaystub;

    @JsonProperty("showYearToDateAccrualOnPaystub")
    private Boolean showYearToDateAccrualOnPaystub;

    @JsonProperty("showBeginningBalanceOnPaystub")
    private Boolean showBeginningBalanceOnPaystub;

    @JsonProperty("showCurrentPayStartingBalanceOnPaystub")
    private Boolean showCurrentPayStartingBalanceOnPaystub;

    @JsonProperty("type")
    private String type;

    @JsonProperty("hourlyAccrualType")
    private String hourlyAccrualType;

    @JsonProperty("resetType")
    private String resetType;

    public static LeavePayConfigForCreate getLeavePayConfiguration_FromFile(ReadableFile file) {
        return file.readJsonAs(LeavePayConfigForCreate.class);
    }

    public static LeavePayConfigForCreate createDefaultLeavePayConfiguration() {
        return LeavePayConfigForCreate.builder()
                .number(String.valueOf(100000 + new Random().nextInt(900000)))
                .description("Test" + (100000 + new Random().nextInt(900000)))
                .isActive(true)
                .doesAccrue(false)
                .minimumHoursForAccrual(2.00)
                .rateMultiplier(1.00)
                .warningLimit(5.00)
                .showOnReports(false)
                .isMemoOnly(false)
                .useEmployeePeriodStartForResetAndAccrual(false)
                .doesNotReduceSalaryHours(false)
                .doesNotResetAmountTaken(false)
                .capOnHoursUsedToAccrue(10.00)
                .hideHoursTaken(false)
                .preventNegativeAvailableHours(false)
                .useMinimumWageAsRate(false)
                .showOnPaystub(false)
                .showYearToDateAccrualOnPaystub(false)
                .type("JuryDuty")
                .hourlyAccrualType("Regular")
                .resetType("OnFirstPayrollOfYear")
                .build();
    }
}