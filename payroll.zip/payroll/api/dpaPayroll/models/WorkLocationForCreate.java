package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Builder
@Data
@AllArgsConstructor
public class WorkLocationForCreate {
    @JsonProperty("Description")
    public String description;
    @JsonProperty("State")
    public String state;
    @JsonProperty("Address1")
    public String address1;
    @JsonProperty("Address2")
    public String address2;
    @JsonProperty("City")
    public String city;
    @JsonProperty("Zip")
    public String zip;
    @JsonProperty("Zip4")
    public String zip4;
    @JsonProperty("DefaultEarnedIncomeTax")
    public String defaultEarnedIncomeTax;
    @JsonProperty("DefaultLocalServicesTax")
    public String defaultLocalServicesTax;
    @JsonProperty("DefaultWorkPoliticalSubdivision")
    public String defaultWorkPoliticalSubdivision;

    public static WorkLocationForCreate createDefaultWorkLocationForCreateObject() {
        return new WorkLocationForCreate(
                "TestDescription",
                "PA",
                "Address 1 Street",
                "Address 2 Street",
                "TestCity",
                "12345",
                "1234",
                "PA-EIT-7001R",
                "PA-LST-1620L",
                "");
    }

    public WorkLocationForCreate setZip(String zip) {
        this.zip = zip;
        return this;
    }

    public WorkLocationForCreate setDescription(String description) {
        this.description = description;
        return this;
    }

    public WorkLocationForCreate setState(String state) {
        this.state = state;
        return this;
    }

    public WorkLocationForCreate setAddress1(String address1) {
        this.address1 = address1;
        return this;
    }

    public WorkLocationForCreate setAddress2(String address2) {
        this.address2 = address2;
        return this;
    }

    public WorkLocationForCreate setCity(String city) {
        this.city = city;
        return this;
    }

    public WorkLocationForCreate setZip4(String zip4) {
        this.zip4 = zip4;
        return this;
    }

    public WorkLocationForCreate setDefaultEarnedIncomeTax(String defaultEarnedIncomeTax) {
        this.defaultEarnedIncomeTax = defaultEarnedIncomeTax;
        return this;
    }

    public WorkLocationForCreate setDefaultLocalServicesTax(String defaultLocalServicesTax) {
        this.defaultLocalServicesTax = defaultLocalServicesTax;
        return this;
    }

    public WorkLocationForCreate setDefaultWorkPoliticalSubdivision(String defaultWorkPoliticalSubdivision) {
        this.defaultWorkPoliticalSubdivision = defaultWorkPoliticalSubdivision;
        return this;
    }
}
