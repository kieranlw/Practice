package payroll.api.dpaPayroll.models.PayData;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class Taxes {

    @JsonProperty("code")
    private String code;

    @JsonProperty ("tax")
    private double tax;

    @JsonProperty ("gross")
    private double gross;

    @JsonProperty ("taxableAmount")
    private double taxableAmount;

    @JsonProperty ("deferredAmount")
    private double deferredAmount;

    @JsonProperty ("creditTaxableAmount")
    private int creditTaxableAmount;

    @JsonProperty ("creditAmount")
    private int creditAmount;

}
