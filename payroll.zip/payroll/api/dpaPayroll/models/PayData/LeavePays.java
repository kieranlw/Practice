package payroll.api.dpaPayroll.models.PayData;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class LeavePays {
    @JsonProperty("amount")
    private double amount;

    @JsonProperty ("hours")
    private double hours;

    @JsonProperty("departmentDescription")
    private String departmentDescription;

    @JsonProperty ("description")
    private String description;
}
