package payroll.api.dpaPayroll.models.PayData;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import common.ReadableFile;
import lombok.*;
import payroll.api.dpaPayroll.PayDateDeserializer;
import payroll.api.dpaPayroll.PaystubDateSerializer;
import payroll.api.dpaPayroll.models.PayrollForCreate;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class PayData {

    @JsonProperty("employeeId")
    private String employeeId;

    @JsonProperty("payDate")
    @JsonDeserialize(using = PayDateDeserializer.class)
    @JsonSerialize(using = PaystubDateSerializer.class)
    private LocalDateTime payDate;

    @JsonProperty("periodEndDate")
    @JsonDeserialize(using = PayDateDeserializer.class)
    @JsonSerialize(using = PaystubDateSerializer.class)
    private LocalDateTime periodEndDate;

    @JsonProperty("period2EndDate")
    @JsonDeserialize(using = PayDateDeserializer.class)
    @JsonSerialize(using = PaystubDateSerializer.class)
    private LocalDateTime period2EndDate;

    @JsonProperty("status")
    private String status;

    @JsonProperty ("regularHours")
    private double regularHours;

    @JsonProperty ("regularGross")
    private double regularGross;

    @JsonProperty ("overtimeHours")
    private double overtimeHours;

    @JsonProperty ("earnedPay")
    private double earnedPay;

    @JsonProperty ("pretaxGross")
    private double pretaxGross;

    @JsonProperty("netPay")
    private double netPay;

    @JsonProperty ("taxes")
    private List <Taxes> taxes;

    @JsonProperty ("otherPays")
    private List <OtherPays> otherPays;

    @JsonProperty ("leavePays")
    private List <LeavePays> leavePays;

    @JsonProperty ("deductions")
    private List <Deductions> deductions;

    @JsonProperty ("benefits")
    private List <Benefits> benefits;

    @JsonProperty ("sales")
    private double sales;

    @JsonProperty ("tips")
    private double tips;

    @JsonProperty ("chargeTips")
    private double chargeTips;

    @JsonProperty ("makeupAmount")
    private double makeupAmount;

    @JsonProperty ("memoAmount")
    private double memoAmount;

    @JsonProperty ("checkNumber")
    private int checkNumber;

    @JsonProperty ("uncollectedFica")
    private double uncollectedFica;

    @JsonProperty ("paystubPdf")
    private String paystubPdf;

    public static PayData getPayDataInfo_FromFile(ReadableFile payDataFile) {
        return payDataFile.readJsonAs(PayData.class);
    }
}
