package payroll.api.dpaPayroll.models.PayData;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class Benefits {

    @JsonProperty("isOneTime")
    private boolean isOneTime;

    @JsonProperty ("amount")
    private double amount;

    @JsonProperty ("description")
    private String description;
}
