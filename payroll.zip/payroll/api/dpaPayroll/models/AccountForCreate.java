package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.Random;

@Builder
@Data
@AllArgsConstructor
public class AccountForCreate {

    @JsonProperty("name")
    public String name;

    @JsonProperty("shortName")
    public String shortName;

    @JsonProperty("fein")
    public String fein;

    public static AccountForCreate createDefaultAccountForCreate() {
        Random rnd = new Random();
        String randomPart = Integer.toString(rnd.nextInt(99999 - 99) + 99);
        return new AccountForCreate("test co" + randomPart, "NEW" + randomPart, "11-1234567");
    }
}
