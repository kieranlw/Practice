package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class WorkLocation {

    @JsonProperty("id")
    private String id;

    @JsonProperty("description")
    private String description;

    @JsonProperty("state")
    private String state;

    @JsonProperty("address1")
    private String address1;

    @JsonProperty("address2")
    private String address2;

    @JsonProperty("city")
    private String city;

    @JsonProperty("zip")
    private String zip;

    @JsonProperty("zip4")
    private String zip4;

    @JsonProperty("defaultEITTaxCode")
    private String defaultEITTaxCode;

    @JsonProperty("defaultLSTTaxCode")
    private String defaultLSTTaxCode;

    @JsonProperty("defaultWorkPSDTaxCode")
    private String defaultWorkPSDTaxCode;

    @JsonProperty("defaultEarnedIncomeTax")
    private String defaultEarnedIncomeTax;

    @JsonProperty("defaultLocalServicesTax")
    private String defaultLocalServicesTax;

    @JsonProperty("defaultWorkPoliticalSubdivision")
    private String defaultWorkPoliticalSubdivision;

    public static WorkLocation[] getWorkLocationsFromFile(ReadableFile file) {
        return file.readJsonAs(WorkLocation[].class);
    }


}
