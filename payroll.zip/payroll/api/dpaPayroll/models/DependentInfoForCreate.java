package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
@AllArgsConstructor

public class DependentInfoForCreate {
    @JsonProperty("employeeId")
    private String employeeId;

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("middleName")
    private String middleName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("suffix")
    private String suffix;

    @JsonProperty("ssn")
    private String ssn;

    @JsonProperty("birthDate")
    private String birthDate;

    @JsonProperty("acaCoverageType")
    private String acaCoverageType;

    @JsonProperty("startDate")
    private String startDate;

    @JsonProperty("endDate")
    private String endDate;

    public static DependentInfoForCreate createDefaultEmployeeDependent() {
        return new DependentInfoForCreate("","QE", "Test", "Account", "Suff", "111-11-1111", "2009-06-26", "EffectiveDates", "2021-06-26", "2023-06-26");
    }
}
