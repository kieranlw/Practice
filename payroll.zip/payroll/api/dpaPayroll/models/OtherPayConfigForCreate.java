package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.AdjustmentFrequency;
import payroll.api.dpaPayroll.models.enums.OtherPayClassification;
import payroll.api.dpaPayroll.models.enums.OtherPayPaidType;
import payroll.api.dpaPayroll.models.enums.OtherPayType;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class OtherPayConfigForCreate {

    @JsonProperty("code")
    private String code;

    @JsonProperty("description")
    private String description;

    @JsonProperty("isActive")
    private Boolean isActive;

    @JsonProperty("includeIn401k")
    private Boolean IncludeIn401k;

    @JsonProperty("includeFullBlend")
    private Boolean includeFullBlend;

    @JsonProperty("isFullBlendRegularHoursOnly")
    private Boolean isFullBlendRegularHoursOnly;

    @JsonProperty("includeInWorkersCompensation")
    private Boolean includeInWorkersCompensation;

    @JsonProperty("isTaxableFringe")
    private Boolean isTaxableFringe;

    @JsonProperty("isPieceWork")
    private Boolean isPieceWork;

    @JsonProperty("hourlyPercentage")
    private Double hourlyPercentage;

    @JsonProperty("hourlyAmount")
    private Double hourlyAmount;

    @JsonProperty("doMultiplyThenAdd")
    private Boolean doMultiplyThenAdd;

    @JsonProperty("masterItemGroupId")
    private String masterItemGroupId;

    @JsonProperty("masterItemGroupPercentage")
    private Double masterItemGroupPercentage;

    @JsonProperty("otherPayType")
    private OtherPayType otherPayType;

    @JsonProperty("otherPayClassification")
    private OtherPayClassification otherPayClassification;

    @JsonProperty("adjustmentFrequency")
    private AdjustmentFrequency adjustmentFrequency;

    @JsonProperty("otherPayPaidType")
    private OtherPayPaidType otherPayPaidType;

    public static OtherPayConfigForCreate getConfig_FromFile(ReadableFile file) {
        return file.readJsonAs(OtherPayConfigForCreate.class);
    }
}
