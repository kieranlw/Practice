package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.AdjustmentFrequency;
import payroll.api.dpaPayroll.models.enums.OtherPayClassification;
import payroll.api.dpaPayroll.models.enums.OtherPayPaidType;
import payroll.api.dpaPayroll.models.enums.OtherPayType;

import javax.annotation.Nullable;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class OtherPayConfig {

    @JsonProperty("id")
    private String Id;
    @JsonProperty("description")
    private String description;
    @JsonProperty("isActive")
    private Boolean isActive;
    @JsonProperty("code")
    private String code;
    @JsonProperty("isFullBlendRegularHoursOnly")
    private Boolean isFullBlendRegularHoursOnly;
    @JsonProperty("isTaxableFringe")
    private Boolean isTaxableFringe;
    @JsonProperty("isPieceWork")
    private Boolean isPieceWork;
    @JsonProperty("hourlyPercentage")
    private Double hourlyPercentage;
    @JsonProperty("hourlyAmount")
    private Double hourlyAmount;
    @JsonProperty("doMultiplyThenAdd")
    private Boolean doMultiplyThenAdd;
    @JsonProperty("masterItemGroupId")
    private String masterItemGroupId;
    @JsonProperty("masterItemGroupPercentage")
    private Double masterItemGroupPercentage;
    @JsonProperty("otherPayType")
    private OtherPayType otherPayType;
    @JsonProperty("otherPayClassification")
    private @Nullable
    OtherPayClassification otherPayClassification;
    @JsonProperty("adjustmentFrequency")
    private AdjustmentFrequency adjustmentFrequency;
    @JsonProperty("otherPayPaidType")
    private OtherPayPaidType otherPayPaidType;
    @JsonProperty("includeIn401k")
    private Boolean IncludeIn401k;
    @JsonProperty("includeFullBlend")
    private Boolean includeFullBlend;
    @JsonProperty("includeInWorkersCompensation")
    private Boolean includeInWorkersCompensation;


    public static OtherPayConfig[] getConfigInfo_FromFile(ReadableFile file) {
        return file.readJsonAs(OtherPayConfig[].class);
    }
}