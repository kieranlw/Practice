package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class JobCodes {

    @JsonProperty("id")
    private String id;

    @JsonProperty("code")
    private String code;

    @JsonProperty("description")
    private String description;

    @JsonProperty("isActive")
    private boolean isActive;

    @JsonProperty("workClassifications")
    private JobCodeWorkClassification[] workClassifications;

    public static JobCodes[] getJobCodes_FromFile(ReadableFile file) {
        return file.readJsonAs(JobCodes[].class);
    }
}