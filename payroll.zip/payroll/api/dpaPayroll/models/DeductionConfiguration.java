package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class DeductionConfiguration {
    @JsonProperty("id")
    private String id;
    @JsonProperty("number")
    private String number;
    @JsonProperty("description")
    private String description;
    @JsonProperty("isActive")
    private Boolean isActive;
    @JsonProperty("classificationId")
    private String classificationId;
    @JsonProperty("frequency")
    private String frequency;
    @JsonProperty("isAcaCompliant")
    private Boolean isAcaCompliant;
    @JsonProperty("isAcaSelfInsuredPlan")
    private Boolean isAcaSelfInsuredPlan;
    @JsonProperty("defaultPriority")
    private int defaultPriority;
}
