package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.PayType;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class PayInfoForCreate {

    @JsonProperty("employeeId")
    private String employeeId;

    @JsonProperty("isPrimary")
    private Boolean isPrimary;

    @JsonProperty("payType")
    private PayType payType;

    @JsonProperty("departmentId")
    private String departmentId;

    @JsonProperty("workClassification")
    private String workClassification;

    @JsonProperty("jobCodeId")
    private String jobCodeId;

    @JsonProperty("rate")
    private Double rate;

    @JsonProperty("hoursPerShiftOverride")
    private Double hoursPerShiftOverride;

    @JsonProperty("cashFringe")
    private Double cashFringe;

    @JsonProperty("overtimeFactor")
    private Double overtimeFactor;

    @JsonProperty("minimumWageOverride")
    private Double minimumWageOverride;

    @JsonProperty("defaultHoursOverride")
    private Double defaultHoursOverride;

    @JsonProperty("newRateEffectiveStartDate")
    private String newRateEffectiveStartDate;

    @JsonProperty("newRate")
    private Double newRate;

    public static PayInfoForCreate getPayInfo_FromFile(ReadableFile file) {
        return file.readJsonAs(PayInfoForCreate.class);
    }

}
