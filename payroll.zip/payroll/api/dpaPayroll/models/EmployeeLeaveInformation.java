package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class EmployeeLeaveInformation {

    @JsonProperty("employeeLeavePayId")
    private String employeeLeavePayId;
    @JsonProperty("hoursTaken")
    private double hoursTaken;

}
