package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import common.ReadableFile;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.LeavePay_CarryMode;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class LeavePay {

    @JsonProperty("id")
    private String id;

    @JsonProperty("description")
    private String description;

    @JsonProperty("leavePayConfigurationId")
    private String leavePayConfigurationId;

    @JsonProperty("employeeId")
    private String employeeId;

    @JsonProperty("accrualFrequencyId")
    private String accrualFrequencyId;

    @JsonProperty("currentHoursAllowedPerYear")
    private Double currentHoursAllowedPerYear;

    @JsonProperty("maximumAccrualHours")
    private Double maximumAccrualHours;

    @JsonProperty("accrualStartDate")
    private String accrualStartDate;

    @JsonProperty("accrualEndDate")
    private String accrualEndDate;

    @JsonProperty("terminationDate")
    private String terminationDate;

    @JsonProperty("carryMode")
    private LeavePay_CarryMode carryMode;

    @JsonProperty("nextHoursAllowedPerYear")
    private Double nextHoursAllowedPerYear;

    @JsonProperty("nextEffectiveDate")
    private String nextEffectiveDate;

    @JsonProperty("calculationBeginHours")
    private Double calculationBeginHours;

    @JsonProperty("calculationHoursAccrued")
    private Double calculationHoursAccrued;

    @JsonProperty("calculationHoursTaken")
    private Double calculationHoursTaken;

    @JsonProperty("availableHours")
    private Double availableHours;

    @JsonProperty("status")
    private String status;

    public static LeavePay[] getLeavePays_FromFile(ReadableFile file) {
        return file.readJsonAs(LeavePay[].class);
    }

    public static LeavePay getLeavePay_FromFile(ReadableFile file) {
        return file.readJsonAs(LeavePay.class);
    }

    public static LeavePay createDefaultLEavePay(String newEmployeeIdToDelete, String isActiveLeavePayConfig, String accrualFrequencyId) {
        return LeavePay.builder()
                .employeeId(newEmployeeIdToDelete)
                .leavePayConfigurationId(isActiveLeavePayConfig)
                .carryMode(LeavePay_CarryMode.DoNotCarry)
                .calculationHoursTaken(0.0)
                .calculationBeginHours(0.0)
                .nextHoursAllowedPerYear(0.0)
                .maximumAccrualHours(0.0)
                .calculationHoursAccrued(0.0)
                .accrualFrequencyId(accrualFrequencyId)
                .currentHoursAllowedPerYear(0.0)
                .build();
    }
}
