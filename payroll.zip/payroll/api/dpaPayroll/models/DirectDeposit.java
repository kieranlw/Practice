package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import common.ReadableFile;
import lombok.*;
import payroll.api.dpaPayroll.EmployeeDateDeserializer;
import payroll.api.dpaPayroll.EmployeeDateSerializer;
import payroll.api.dpaPayroll.models.enums.BankAccountType;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class DirectDeposit {

    @JsonProperty("id")
    private String id;

    @JsonProperty("employeeId")
    private String employeeId;

    @JsonProperty("isActive")
    private Boolean isActive;

    @JsonProperty("bankRoutingNumber")
    private String bankRoutingNumber;

    @JsonProperty("bankAccountNumber")
    private String bankAccountNumber;

    @JsonProperty("bankAccountType")
    private BankAccountType bankAccountType;

    @JsonProperty("startDate")
    @JsonDeserialize(using = EmployeeDateDeserializer.class)
    @JsonSerialize(using = EmployeeDateSerializer.class)
    private LocalDateTime startDate;

    @JsonProperty("endDate")
    @JsonDeserialize(using = EmployeeDateDeserializer.class)
    @JsonSerialize(using = EmployeeDateSerializer.class)
    private LocalDateTime endDate;

    @JsonProperty("fixedAmount")
    private Double fixedAmount;

    @JsonProperty("fixedPercentage")
    private Double fixedPercentage;

    public static DirectDeposit getDirectDepositFromFile(ReadableFile file) {
        return file.readJsonAs(DirectDeposit.class);
    }

    public static DirectDeposit createDefaultDirectDeposit(String employeeId) {
        return DirectDeposit.builder()
                .id("c0dadb08-6bbd-e711-8108-00155d001915")
                .employeeId(employeeId)
                .isActive(true)
                .bankRoutingNumber("333333334")
                .bankAccountNumber("4488888888")
                .bankAccountType(BankAccountType.Checking)
                .startDate(LocalDateTime.parse("2020-10-30T00:00:00"))
                .fixedAmount(10.00)
                .fixedPercentage(0.0)
                .build();
    }
}
