package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;


@Builder
@Data
@AllArgsConstructor
public class EmployeePayrollResult {

    @JsonProperty("employeeId")
    private String employeeId;
    @JsonProperty("status")
    private String status;
    @JsonProperty("message")
    private String message;

}
