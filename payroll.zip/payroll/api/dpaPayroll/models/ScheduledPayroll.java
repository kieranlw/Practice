package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class ScheduledPayroll {

    @JsonProperty("id")
    private String id;

    @JsonProperty("payDate")
    private String payDate;

    @JsonProperty("periodEndDate")
    private String periodEndDate;

    @JsonProperty("period2EndDate")
    private String period2EndDate;

    @JsonProperty("processDate")
    private String processDate;
}
