package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import common.ReadableFile;
import lombok.*;
import payroll.api.dpaPayroll.PayDateDeserializer;
import payroll.api.dpaPayroll.PaystubDateSerializer;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class Paystub {

    @JsonProperty("id")
    private String id;

    @JsonProperty("employeeId")
    private String employeeId;

    @JsonProperty("netPay")
    private double netPay;

    @JsonProperty("payDate")
    //JsonFormat worked some of the time, left this comment in here so I can come back to it
    // @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssz", shape = JsonFormat.Shape.STRING)
    @JsonDeserialize(using = PayDateDeserializer.class)
    @JsonSerialize(using = PaystubDateSerializer.class)
    private LocalDateTime payDate;

    @JsonProperty("payPeriodStartDate")
    @JsonDeserialize(using = PayDateDeserializer.class)
    @JsonSerialize(using = PaystubDateSerializer.class)
    private LocalDateTime payPeriodStartDate;

    @JsonProperty("payPeriodEndDate")
    @JsonDeserialize(using = PayDateDeserializer.class)
    @JsonSerialize(using = PaystubDateSerializer.class)
    private LocalDateTime payPeriodEndDate;

    @JsonProperty("pdf")
    private String pdf;


    public static Paystub getPaystubFromFile(ReadableFile file) {
        return file.readJsonAs(Paystub.class);
    }


}
