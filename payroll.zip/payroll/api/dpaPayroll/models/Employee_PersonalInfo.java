package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class    Employee_PersonalInfo {

    @JsonProperty("id")
    private String id;

    @JsonProperty("num")
    private String employeeNumber;

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("middleName")
    private String middleName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("gender")
    private String gender;

    @JsonProperty("suffix")
    private String suffix;

    @JsonProperty("address1")
    private String address1;

    @JsonProperty("address2")
    private String address2;

    @JsonProperty("addr1")
    private String addr1;

    @JsonProperty("addr2")
    private String addr2;

    @JsonProperty("city")
    private String city;

    @JsonProperty("state")
    private String state;

    @JsonProperty("zip")
    private String zip;

    @JsonProperty("zip4")
    private String zip4;

    @JsonProperty("foreignAddress1")
    private String foreignAddress1;

    @JsonProperty("foreignAddress2")
    private String foreignAddress2;

    @JsonProperty("foreignAddress3")
    private String foreignAddress3;

    @JsonProperty("phone")
    private String phone;

    @JsonProperty("employmentStatus")
    private String employmentStatus;

    @JsonProperty("birthDate")
    private String birthDate;

    @JsonProperty("hireDate")
    private String hireDate;

    @JsonProperty("terminationDate")
    private String terminationDate;

    @JsonProperty("rehireDate")
    private String rehireDate;

    @JsonProperty("maritalStatus")
    private String maritalStatus;

    @JsonProperty("email")
    private String email;

    @JsonProperty("payFrequency")
    private String payFrequency;

    @JsonProperty("managerEmployeeId")
    private String managerEmployeeId;

    @JsonProperty("primaryDepartmentId")
    private String primaryDepartmentId;

    @JsonProperty("primaryJobcodeId")
    private String primaryJobcodeId;

    @JsonProperty("isTobaccoUser")
    private Boolean isTobaccoUser;

    @JsonProperty("equalEmploymentJobId")
    private String equalEmploymentJobId;

    @JsonProperty("equalEmploymentMinorityId")
    private String equalEmploymentMinorityId;

    @JsonProperty("taxId")
    private String taxId;

    public static Employee_PersonalInfo getEmployeePersonalInfo_FromFile(ReadableFile employeeFile) {
        return employeeFile.readJsonAs(Employee_PersonalInfo.class);
    }

    public static Employee_PersonalInfo createDefaultEmployeePersonalInfoObject() {
        return Employee_PersonalInfo.builder()
                .state("OR")
                .hireDate("2019-02-24T17:12:14")
                .gender("Male")
                .payFrequency("Weekly")
                .maritalStatus("Single")
                .employmentStatus("PartTime")
                .lastName("Adams")
                .firstName("John")
                .middleName("Royce")
                .addr1("123 Memory Lane")
                .address1("123 Memory Lane")
                .addr2("Apartment 4")
                .address2("Apartment 4")
                .city("Snellville")
                .zip("54401")
                .zip4("0401")
                .foreignAddress1("1st Foreign Home")
                .foreignAddress2("2nd Foreign Home")
                .foreignAddress3("3rd Foreign Home")
                .phone("(444)822-8410")
                .taxId("949-45-9432")
                .birthDate("2020-08-19T00:00:00")
                .email("something@deluxe.com")
                .managerEmployeeId("df3effe1-52ab-be50-30aa-39fed212747c")
                .primaryDepartmentId("041d5afb-8023-fb62-5e89-39fed212747c")
                .primaryJobcodeId("7d3d3a29-b211-ec11-9288-e36115d0006d")
                .isTobaccoUser(false)
                .build();
    }

    public static Employee_PersonalInfo createOtherPayEmployeePersonalInfoObject() {
        return Employee_PersonalInfo.builder()
                .state("OR")
                .hireDate("2019-02-24T17:12:14")
                .gender("Male")
                .payFrequency("Weekly")
                .maritalStatus("Single")
                .employmentStatus("PartTime")
                .lastName("Adams")
                .firstName("John")
                .middleName("Royce")
                .addr1("123 Memory Lane")
                .address1("123 Memory Lane")
                .addr2("Apartment 4")
                .address2("Apartment 4")
                .city("Snellville")
                .zip("54401")
                .zip4("0401")
                .foreignAddress1("1st Foreign Home")
                .foreignAddress2("2nd Foreign Home")
                .foreignAddress3("3rd Foreign Home")
                .phone("(444)822-8410")
                .taxId("949-45-9432")
                .birthDate("2020-08-19T00:00:00")
                .email("something@deluxe.com")
                .isTobaccoUser(false)
                .build();
    }
    public static Employee_PersonalInfo createEqualEmployment_1099Employee_PersonalInfoObject() {
        return Employee_PersonalInfo.builder()
                .employeeNumber("12345")
                .firstName("John")
                .middleName("1099")
                .lastName("Adams")
                .gender("Male")
                .suffix("Sr.")
                .addr1("123 Memory Lane")
                .address1("123 Memory Lane")
                .addr2("Apartment 4")
                .address2("Apartment 4")
                .city("Wausau")
                .state("WI")
                .zip("54401")
                .zip4("0401")
                .foreignAddress1("1st Foreign Home")
                .foreignAddress2("2nd Foreign Home")
                .foreignAddress3("3rd Foreign Home")
                .phone("(444)822-8410")
                .taxId("399-99-9999")
                .employmentStatus("PartTime")
                .maritalStatus("Single")
                .email("something@deluxe.com")
                .hireDate("2019-02-24T17:12:14")
                .birthDate("2020-08-19T00:00:00")
                .payFrequency("Weekly")
                .managerEmployeeId("9284da27-d243-ec11-928a-00505690f979")
                .primaryDepartmentId("37f5bf35-d143-ec11-928a-00505690f979")
                .primaryJobcodeId("65ab76f4-d043-ec11-928a-00505690f979")
                .equalEmploymentJobId("0b2a448d-ed2e-5c9f-6843-39d963476d9d")
                .equalEmploymentMinorityId("90a3b6bb-477a-2d0b-4a9a-39d963476d9d")
                .isTobaccoUser(false)
                .build();
    }

    public static Employee_PersonalInfo createEqualEmployment_EEOEmployee_PersonalInfoObject() {
        return Employee_PersonalInfo.builder()
                .employeeNumber("12345")
                .firstName("John")
                .middleName("1099")
                .lastName("Adams")
                .gender("Male")
                .suffix("Sr.")
                .addr1("123 Memory Lane")
                .address1("123 Memory Lane")
                .addr2("Apartment 4")
                .address2("Apartment 4")
                .city("Wausau")
                .state("WI")
                .zip("54401")
                .zip4("0401")
                .foreignAddress1("1st Foreign Home")
                .foreignAddress2("2nd Foreign Home")
                .foreignAddress3("3rd Foreign Home")
                .phone("(444)822-8410")
                .taxId("388-99-7777")
                .employmentStatus("PartTime")
                .maritalStatus("Single")
                .email("something@deluxe.com")
                .hireDate("2019-02-24T17:12:14")
                .birthDate("2020-08-19T00:00:00")
                .payFrequency("Weekly")
                .managerEmployeeId("df99b925-096b-eb11-9282-00505690f979")
                .primaryDepartmentId("59d7b74e-0ce9-b913-33ee-39fa99016c24")
                .primaryJobcodeId("e623e471-57aa-9106-b8b4-39fa99016c24")
                .equalEmploymentJobId("c48aac23-d36c-b930-1b71-39fa99016c24")
                .equalEmploymentMinorityId("e235db24-9f44-adb2-5bc3-39fa99016c24")
                .isTobaccoUser(false)
                .build();

    }

    public static Employee_PersonalInfo create_TerminateEmployee_PersonalInfoObject() {
        return Employee_PersonalInfo.builder()
                .employeeNumber("1234567")
                .firstName("Georgia")
                .middleName("Lopeez")
                .lastName("Forewoman")
                .gender("Female")
                .suffix("Sr")
                .addr1(null)
                .address1("12 AB Sesame St")
                .addr2(null)
                .address2("Apartment 3")
                .city("Schofield")
                .state("CA")
                .zip("54403")
                .zip4("0402")
                .foreignAddress1("1st Foreign Home")
                .foreignAddress2("2nd Foreign Home")
                .foreignAddress3("3rd Foreign Home")
                .phone("(444)822-8410")
                .taxId("399-99-9910")
                .employmentStatus("PartTime")
                .maritalStatus("Married")
                .email("something@deluxe.com")
                .hireDate("2019-02-23T17:12:14")
                .birthDate("2020-08-14T00:00:00")
                .rehireDate("2020-10-21T00:00:00")
                .payFrequency("BiWeekly")
                .managerEmployeeId("e75c53ab-a797-4fb1-cd44-39fa99016c43")
                .primaryDepartmentId("59d7b74e-0ce9-b913-33ee-39fa99016c24")
                .primaryJobcodeId("e623e471-57aa-9106-b8b4-39fa99016c24")
                .equalEmploymentJobId("5a23c572-39b8-5c83-33b7-39fa99016c24")
                .equalEmploymentMinorityId("a88759bc-12e9-6d5a-ba50-39fa99016c24")
                .isTobaccoUser(false)
                .build();

    }

    public static Employee_PersonalInfo create_AddrEmployee_PersonalInfoObject() {
        return Employee_PersonalInfo.builder()
                .employeeNumber("1234567")
                .firstName("Georgia")
                .middleName("Lopeez")
                .lastName("Forewoman")
                .gender("Female")
                .suffix("Sr")
                .addr1("123 Sesame St")
                .address1("12 AB Sesame St")
                .addr2("Apartment 2")
                .address2("Apartment 3")
                .city("Schofield")
                .state("CA")
                .zip("54403")
                .zip4("0402")
                .foreignAddress1("1st Foreign Home")
                .foreignAddress2("2nd Foreign Home")
                .foreignAddress3("3rd Foreign Home")
                .phone("(444)822-8410")
                .taxId("399-99-9910")
                .employmentStatus("PartTime")
                .maritalStatus("Married")
                .email("something@deluxe.com")
                .hireDate("2019-02-23T17:12:14")
                .birthDate("2020-08-14T00:00:00")
                .payFrequency("BiWeekly")
                .managerEmployeeId("e75c53ab-a797-4fb1-cd44-39fa99016c43")
                .primaryDepartmentId("59d7b74e-0ce9-b913-33ee-39fa99016c24")
                .primaryJobcodeId("e623e471-57aa-9106-b8b4-39fa99016c24")
                .equalEmploymentJobId("5a23c572-39b8-5c83-33b7-39fa99016c24")
                .equalEmploymentMinorityId("a88759bc-12e9-6d5a-ba50-39fa99016c24")
                .isTobaccoUser(false)
                .build();
    }

    public static Employee_PersonalInfo createEmployeeInfoForAssignLeavePayConf() {
        return Employee_PersonalInfo.builder()
                .state("OR")
                .hireDate("2019-02-24T17:12:14")
                .gender("Male")
                .payFrequency("Weekly")
                .maritalStatus("Single")
                .employmentStatus("PartTime")
                .lastName("Silver")
                .firstName("John")
                .middleName("Royce")
                .addr1("123 Memory Lane")
                .address1("123 Memory Lane")
                .addr2("Apartment 4")
                .address2("Apartment 4")
                .city("Snellville")
                .zip("54401")
                .zip4("0401")
                .foreignAddress1("1st Foreign Home")
                .foreignAddress2("2nd Foreign Home")
                .foreignAddress3("3rd Foreign Home")
                .phone("(444)822-8410")
                .taxId("235-31-9627")
                .birthDate("2020-08-19T00:00:00")
                .email("something@deluxe.com")
                .managerEmployeeId("f25b7b59-0b96-67fd-6cf9-39f742f1be1e")
                .primaryDepartmentId("9527bf95-5d61-5f10-55c6-39f742f1bcd5")
                .primaryJobcodeId("22701e7b-b0b8-eb11-9286-00505690f979")
                .isTobaccoUser(false)
                .build();
    }
}
