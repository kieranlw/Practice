package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class EmployeeTimeInformation {

    @JsonProperty("employeePayInfoId")
    private String employeePayInfoId;
    @JsonProperty("regularHours")
    private double regularHours;
    @JsonProperty("overTimeHours")
    private double overTimeHours;
    @JsonProperty("doubleOverTimeHours")
    private double doubleOverTimeHours;
    @JsonProperty("payRate")
    private double payRate;
}
