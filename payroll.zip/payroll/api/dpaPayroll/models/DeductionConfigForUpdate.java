package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.DeductionFrequency;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor

public class DeductionConfigForUpdate {
    @JsonProperty("number")
    private String number;

    @JsonProperty("description")
    private String description;

    @JsonProperty("isActive")
    private Boolean isActive;

    @JsonProperty("classificationId")
    private Integer classificationId;

    @JsonProperty("isAcaCompliant")
    private Boolean isAcaCompliant;

    @JsonProperty("isAcaSelfInsuredPlan")
    private Boolean isAcaSelfInsuredPlan;

    @JsonProperty("defaultPriority")
    private Integer defaultPriority;

    @JsonProperty("frequency")
    private DeductionFrequency frequency;
}
