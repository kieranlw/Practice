package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.AdjustmentFrequency;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor

public class BenefitSubclassification {
    @JsonProperty("id")
    private String id;

    @JsonProperty("description")
    private String description;

    @JsonProperty("amount")
    private Double amount;
}