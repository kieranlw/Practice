package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import common.ResourceFile;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.AcaCoverageType;
import payroll.api.dpaPayroll.models.enums.BankAccountType;
import payroll.api.dpaPayroll.models.enums.DeductionStatus;

import java.util.Date;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class DependentInfo {

    @JsonProperty("id")
    private String id;

    @JsonProperty("employeeId")
    private String employeeId;

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("middleName")
    private String middleName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("suffix")
    private String suffix;

    @JsonProperty("ssn")
    private String ssn;

    @JsonProperty("acaCoverageType")
    private AcaCoverageType acaCoverageType;

    @JsonProperty("birthDate")
    private Date birthDate;

    @JsonProperty("startDate")
    private Date startDate;

    @JsonProperty("endDate")
    private Date endDate;

    public static DependentInfo[] getDependentsInfo_FromFile(ReadableFile file) {
        return file.readJsonAs(DependentInfo[].class);
    }
}
