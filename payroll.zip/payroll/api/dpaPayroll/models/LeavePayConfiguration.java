package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class LeavePayConfiguration {
    @JsonProperty("number")
    private String number;

    @JsonProperty("description")
    private String description;

    @JsonProperty("isActive")
    private Boolean isActive;

    @JsonProperty("doesAccrue")
    private Boolean doesAccrue;

    @JsonProperty("masterItemGroupId")
    private String masterItemGroupId;

    @JsonProperty("minimumHoursForAccrual")
    private double minimumHoursForAccrual;

    @JsonProperty("rateMultiplier")
    private double rateMultiplier;

    @JsonProperty("warningLimit")
    private double warningLimit;

    @JsonProperty("showOnReports")
    private Boolean showOnReports;

    @JsonProperty("isMemoOnly")
    private Boolean isMemoOnly;

    @JsonProperty("excludeFromFullBlend")
    private Boolean excludeFromFullBlend;

    @JsonProperty("usePeriodEndForResetAndAccrual")
    private Boolean usePeriodEndForResetAndAccrual;

    @JsonProperty("useEmployeePeriodStartForResetAndAccrual")
    private Boolean useEmployeePeriodStartForResetAndAccrual;

    @JsonProperty("accrueOnlyIfPaid")
    private Boolean accrueOnlyIfPaid;

    @JsonProperty("doesMaximumUseBeginningBalance")
    private Boolean doesMaximumUseBeginningBalance;

    @JsonProperty("doesMaximumUseEndingBalance")
    private Boolean doesMaximumUseEndingBalance;

    @JsonProperty("doesReduceSalary")
    private Boolean doesReduceSalary;

    @JsonProperty("doesNotReduceSalaryHours")
    private Boolean doesNotReduceSalaryHours;

    @JsonProperty("doesNotResetAmountTaken")
    private Boolean doesNotResetAmountTaken;

    @JsonProperty("capOnHoursUsedToAccrue")
    private double capOnHoursUsedToAccrue;

    @JsonProperty("hideHoursTaken")
    private Boolean hideHoursTaken;

    @JsonProperty("preventNegativeAvailableHours")
    private Boolean preventNegativeAvailableHours;

    @JsonProperty("useMinimumWageAsRate")
    private Boolean useMinimumWageAsRate;

    @JsonProperty("showOnPaystub")
    private Boolean showOnPaystub;

    @JsonProperty("showCurrentAccrualOnPaystub")
    private Boolean showCurrentAccrualOnPaystub;

    @JsonProperty("showYearToDateAccrualOnPaystub")
    private Boolean showYearToDateAccrualOnPaystub;

    @JsonProperty("showBeginningBalanceOnPaystub")
    private Boolean showBeginningBalanceOnPaystub;

    @JsonProperty("showCurrentPayStartingBalanceOnPaystub")
    private Boolean showCurrentPayStartingBalanceOnPaystub;

    @JsonProperty("id")
    private String id;

    @JsonProperty("type")
    private String type;

    @JsonProperty("hourlyAccrualType")
    private String hourlyAccrualType;

    @JsonProperty("resetType")
    private String resetType;

    public static LeavePayConfiguration[] getLeaveConfigurations_FromFile(ReadableFile file) {
        return file.readJsonAs(LeavePayConfiguration[].class);
    }
}
