package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.*;
import payroll.api.dpaPayroll.PayDateDeserializer;
import payroll.api.dpaPayroll.PaystubDateSerializer;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class Pay {

    @JsonProperty("id")
    private String id;

    @JsonProperty("employeeId")
    private String employeeId;

    @JsonProperty("netPay")
    private double netPay;

    @JsonProperty("payDate")
    @JsonDeserialize(using = PayDateDeserializer.class)
    @JsonSerialize(using = PaystubDateSerializer.class)
    private LocalDateTime payDate;

    @JsonProperty("payPeriodStartDate")
    @JsonDeserialize(using = PayDateDeserializer.class)
    @JsonSerialize(using = PaystubDateSerializer.class)
    private LocalDateTime payPeriodStartDate;

    @JsonProperty("payPeriodEndDate")
    @JsonDeserialize(using = PayDateDeserializer.class)
    @JsonSerialize(using = PaystubDateSerializer.class)
    private LocalDateTime payPeriodEndDate;
}
