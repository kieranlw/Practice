package payroll.api.dpaPayroll.models.EmployeeTax;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter

@AllArgsConstructor
@NoArgsConstructor
public class LouisianaSutaTaxInfo extends SutaTaxInfo {

    @JsonProperty("stateCode")
    private String stateCode;

    @JsonProperty("standardOccupationalClassification")
    private String standardOccupationalClassification;

    public static LouisianaSutaTaxInfo createOnlyRequired(String stateCode, String soc) {
        return new LouisianaSutaTaxInfo(stateCode, soc);
    }
}
