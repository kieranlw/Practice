package payroll.api.dpaPayroll.models.EmployeeTax;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.AdditionalWithholdings;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class StateTaxInfo {
    @JsonProperty("workLocation")
    private String workLocation;
    @JsonProperty("additionalWithholdings")
    private String additionalWithholdings;
    @JsonProperty("additionalWithholdingsAmount")
    private Double additionalWithholdingsAmount;
    @JsonProperty("additionalWithholdingsPercent")
    private Integer additionalWithholdingsPercent;
    @JsonProperty("additionalWithholdingsType")
    private AdditionalWithholdings additionalWithholdingsType;
    @JsonProperty("isDualState")
    private Boolean isDualState;
    @JsonProperty("isExemptFromSuta")
    private Boolean isExemptFromSuta;
    @JsonProperty("stateIncomeTaxInfo")
    @Builder.Default
    private SitTaxInfo stateIncomeTaxInfo = new SitTaxInfo();
    @JsonProperty("stateUnemploymentTaxInfo")
    @Builder.Default
    private SutaTaxInfo stateUnemploymentTaxInfo = new SutaTaxInfo();

    public static StateTaxInfo createOnlyRequired(String workLocation, SitTaxInfo sit, SutaTaxInfo sut) {
        return new StateTaxInfo.StateTaxInfoBuilder()
                .workLocation(workLocation)
                .stateUnemploymentTaxInfo(sut)
                .stateIncomeTaxInfo(sit)
                .build();
    }

    public static StateTaxInfo createAll(String workLocation, SitTaxInfo sit, SutaTaxInfo sut, AdditionalWithholdings type) {
        StateTaxInfo stateTaxInfo = new StateTaxInfo();
        switch (type) {

            case PercentOfGross:
                stateTaxInfo = new StateTaxInfo.StateTaxInfoBuilder()
                        .isDualState(false)
                        .additionalWithholdingsType(type)
                        .additionalWithholdingsPercent(2)
                        .workLocation(workLocation)
                        .stateUnemploymentTaxInfo(sut)
                        .stateIncomeTaxInfo(sit)
                        .build();
                break;
            case FlatAmount:
                stateTaxInfo = new StateTaxInfo.StateTaxInfoBuilder()
                        .isDualState(false)
                        .additionalWithholdingsType(type)
                        .additionalWithholdingsAmount(300.0)
                        .workLocation(workLocation)
                        .stateUnemploymentTaxInfo(sut)
                        .stateIncomeTaxInfo(sit)
                        .build();
                break;
        }
        return stateTaxInfo;
    }
}