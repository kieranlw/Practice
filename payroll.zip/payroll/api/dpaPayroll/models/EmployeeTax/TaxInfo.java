package payroll.api.dpaPayroll.models.EmployeeTax;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import payroll.api.dpaPayroll.models.enums.AdditionalWithholdings;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TaxInfo {

    @JsonProperty("federal")
    private FederalTaxInfo federal;
    @JsonProperty("state")
    private StateTaxInfo state;

    public static TaxInfo createOnlyRequired(String state, String rateSchedule, String withholdingStatus, String fillingStatus,String federalWithholdingPercentage) {
        FederalTaxInfo fti = FederalTaxInfo.createOnlyRequired(rateSchedule, withholdingStatus);
        SitTaxInfo sit = SitTaxInfo.createOnlyRequired(state, fillingStatus, 0,federalWithholdingPercentage);
        SutaTaxInfo sut = ("LA".equals(state)) ? LouisianaSutaTaxInfo.createOnlyRequired(state, "40-3000") : SutaTaxInfo.createOnlyRequired(state);
        StateTaxInfo sti = StateTaxInfo.createOnlyRequired(state, sit, sut);
        return new TaxInfoBuilder()
                .federal(fti)
                .state(sti)
                .build();
    }

    public static TaxInfo createAll(String state, String rateSchedule, String withholdingStatus, String fillingStatus, String federalWithholdingPercentage, AdditionalWithholdings type) {
        FederalTaxInfo fti = FederalTaxInfo.createAll(rateSchedule, withholdingStatus);
        SitTaxInfo sit = SitTaxInfo.createAll(state, fillingStatus, federalWithholdingPercentage, rateSchedule);
        SutaTaxInfo sut = ("LA".equals(state)) || ("IN".equals(state)) ? LouisianaSutaTaxInfo.createOnlyRequired(state, "40-3000")
                : ("AK".equals(state)) ? SutaTaxInfo.createOnlyRequired(state, "10", "40-3001")
                : SutaTaxInfo.createOnlyRequired(state);
        StateTaxInfo sti = StateTaxInfo.createAll(state, sit, sut, type);
        return new TaxInfoBuilder()
                .federal(fti)
                .state(sti)
                .build();
    }

    public static TaxInfo createAll(String state, String rateSchedule, String withholdingStatus, String fillingStatus,String federalWithholdingPercentage, String mdCountyCode, AdditionalWithholdings type) {
        FederalTaxInfo fti = FederalTaxInfo.createAll(rateSchedule, withholdingStatus);
        SitTaxInfo sit = SitTaxInfo.createAll(state, fillingStatus, federalWithholdingPercentage, rateSchedule, mdCountyCode);
        SutaTaxInfo sut = SutaTaxInfo.createOnlyRequired(state);
        StateTaxInfo sti = StateTaxInfo.createAll(state, sit, sut, type);
        return new TaxInfoBuilder()
                .federal(fti)
                .state(sti)
                .build();
    }

    public static TaxInfo createDefault() {
        FederalTaxInfo fti = FederalTaxInfo.createOnlyRequired("StandardOldW4", "Married");
        SitTaxInfo sit = SitTaxInfo.createOnlyRequired("NE", "Married", 0,null);
        SutaTaxInfo sut = SutaTaxInfo.createOnlyRequired("NE");
        StateTaxInfo sti = StateTaxInfo.createOnlyRequired("NE", sit, sut);
        return new TaxInfoBuilder()
                .federal(fti)
                .state(sti)
                .build();
    }

    public static TaxInfo createDefault(SutaTaxInfo sutaTaxInfo) {
        TaxInfo updatedObject = createDefault();
        updatedObject.getState().setStateUnemploymentTaxInfo(sutaTaxInfo);
        return updatedObject;
    }

    public static TaxInfo createDefault(SutaTaxInfo sutaTaxInfo, SitTaxInfo sitTaxInfo) {
        TaxInfo updatedObject = createDefault();
        updatedObject.getState().setStateUnemploymentTaxInfo(sutaTaxInfo);
        updatedObject.getState().setStateIncomeTaxInfo(sitTaxInfo);
        return updatedObject;
    }

    public static TaxInfo createDefault(FederalTaxInfo federalTaxInfo) {
        TaxInfo updatedObject = createDefault();
        updatedObject.setFederal(federalTaxInfo);
        return updatedObject;
    }
}
