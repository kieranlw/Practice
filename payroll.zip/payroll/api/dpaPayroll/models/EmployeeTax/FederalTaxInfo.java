package payroll.api.dpaPayroll.models.EmployeeTax;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import payroll.api.dpaPayroll.EmployeeDateDeserializer;
import payroll.api.dpaPayroll.EmployeeDateSerializer;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FederalTaxInfo {
    @JsonProperty("rateSchedule")
    private String rateSchedule;
    @JsonProperty("withholdingStatus")
    private String withholdingStatus;
    @JsonProperty("dependents")
    private Integer dependents;
    @JsonProperty("additionalWithholdings")
    private String additionalWithholdings;
    @JsonProperty("additionalAmount")
    private Double additionalAmount;
    @JsonProperty("additionalPercent")
    private Double additionalPercent;
    @JsonProperty("isFicasDeferralOptIn")
    private Boolean isFicasDeferralOptIn;
    @JsonProperty("ficaDeferralStartDate")
    @JsonDeserialize(using = EmployeeDateDeserializer.class)
    @JsonSerialize(using = EmployeeDateSerializer.class)
    private LocalDateTime ficaDeferralStartDate;
    @JsonProperty("ficaDeferralEndDate")
    @JsonDeserialize(using = EmployeeDateDeserializer.class)
    @JsonSerialize(using = EmployeeDateSerializer.class)
    private LocalDateTime ficaDeferralEndDate;
    @JsonProperty("isExemptFromSocialSecurity")
    private Boolean isExemptFromSocialSecurity;
    @JsonProperty("isExemptFromSocialSecurityAndMedicare")
    private Boolean isExemptFromSocialSecurityAndMedicare;
    @JsonProperty("isExemptFromFuta")
    private Boolean isExemptFromFuta;
    @JsonProperty("exemptReasonType")
    private String exemptReasonType;
    @JsonProperty("exemptReason")
    private String exemptReason;
    @JsonProperty("hasSimilarPayingJob")
    private Boolean hasSimilarPayingJob;
    @JsonProperty("dependentsClaimAmount")
    private Double dependentsClaimAmount;
    @JsonProperty("additionalDeductions")
    private Double additionalDeductions;
    @JsonProperty("otherIncome")
    private Double otherIncome;

    public FederalTaxInfo (String rateSchedule, String withholdingStatus, String exemptReasonType, boolean hasSimilarPayingJob){
        this.rateSchedule = rateSchedule;
        this.withholdingStatus = withholdingStatus;
        this.exemptReasonType = exemptReasonType;
        this.hasSimilarPayingJob = hasSimilarPayingJob;
    }

    public static FederalTaxInfo createOnlyRequired(String rateSchedule, String withholdingStatus) {
        return new FederalTaxInfo.FederalTaxInfoBuilder()
                .dependents(0)
                .rateSchedule(rateSchedule)
                .withholdingStatus(withholdingStatus)
                .hasSimilarPayingJob(false)
                .build();
    }

    public static FederalTaxInfo createAll(String rateSchedule, String withholdingStatus) {
        return new FederalTaxInfo.FederalTaxInfoBuilder()
                .dependents(0)
                .rateSchedule(rateSchedule)
                .withholdingStatus(withholdingStatus)
                .exemptReasonType("OtherExemptUSCitizen")
                .additionalAmount(0.0)
                .additionalPercent(0.0)
                .isFicasDeferralOptIn(false)
                .exemptReason("Some Exempt Reason")
                .hasSimilarPayingJob(false)
                .dependentsClaimAmount(0.0)
                .additionalDeductions(0.0)
                .otherIncome(0.0)
                .build();
    }
}
