package payroll.api.dpaPayroll.models.EmployeeTax;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SutaTaxInfo {

    @JsonProperty("stateCode")
    private String stateCode;
    @JsonProperty("standardOccupationalClassification")
    private String standardOccupationalClassification;
    @JsonProperty("geographicalCode")
    private String geographicalCode;
    @JsonProperty("occupationalCode")
    private String occupationalCode;

    public static SutaTaxInfo createOnlyRequired(String stateCode) {
        return new SutaTaxInfoBuilder()
                .stateCode(stateCode)
                .build();
    }

    public static SutaTaxInfo createOnlyRequired(String stateCode, String geographicalCode, String occupationalCode) {
        return new SutaTaxInfoBuilder()
                .stateCode(stateCode)
                .geographicalCode(geographicalCode)
                .occupationalCode(occupationalCode)
                .build();
    }
}
