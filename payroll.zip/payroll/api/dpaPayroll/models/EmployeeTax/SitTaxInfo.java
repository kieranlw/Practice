package payroll.api.dpaPayroll.models.EmployeeTax;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SitTaxInfo {
    @JsonProperty("stateCode")
    private String stateCode;
    @JsonProperty("filingStatus")
    private String filingStatus;
    @JsonProperty("federalWithholdingPercentage")
    private String federalWithholdingPercentage;
    @JsonProperty("rateSchedule")
    private String rateSchedule;
    @JsonProperty("dependents")
    private Integer dependents;
    @JsonProperty("additionalNumberOfDependents")
    private Integer additionalNumberOfDependents;
    @JsonProperty("exemptionsforBlindness")
    private Integer exemptionsforBlindness;
    @JsonProperty("dependentsClaimAmount")
    private Integer dependentsClaimAmount;
    @JsonProperty("mdCountyCode")
    private String mdCountyCode;
    @JsonProperty("rateCode")
    private String rateCode;
    @JsonProperty("yonkersAdditionalWithholding")
    private Double yonkersAdditionalWithholding;
    @JsonProperty("newYorkCityAdditionalWithholding")
    private Double newYorkCityAdditionalWithholding;
    @JsonProperty("yonkersDependents")
    private Integer yonkersDependents;
    @JsonProperty("newYorkCityDependents")
    private Integer newYorkCityDependents;
    @JsonProperty("nonResidentExempt")
    private Boolean nonResidentExempt;
    @JsonProperty("additionalWithholdingsAmount")
    private Double additionalWithholdingsAmount;
    @JsonProperty("additionalWithholdingsPercent")
    private Double additionalWithholdingsPercent;
    @JsonProperty("isDualState")
    private Boolean isDualState;
    @JsonProperty("isExemptFromSuta")
    private Boolean isExemptFromSuta;

    public static SitTaxInfo createOnlyRequired(String stateCode, String filingStatus, Integer dependents) {
        return new SitTaxInfoBuilder()
                .stateCode(stateCode)
                .filingStatus(filingStatus)
                .dependents(dependents)
                .build();
    }

    public static SitTaxInfo createOnlyRequired(String stateCode, String filingStatus, Integer dependents, String federalWithholdingPercentage) {
        return new SitTaxInfoBuilder()
                .stateCode(stateCode)
                .filingStatus(filingStatus)
                .federalWithholdingPercentage(federalWithholdingPercentage)
                .dependents(dependents)
                .build();
    }

    public static SitTaxInfo createAll(String stateCode, String filingStatus, String federalWithholdingPercentage, String rateSchedule) {
        return new SitTaxInfoBuilder()
                .stateCode(stateCode)
                .filingStatus(filingStatus)
                .federalWithholdingPercentage(federalWithholdingPercentage)
                .dependents(0)
                .rateSchedule(rateSchedule)
                .additionalNumberOfDependents(0)
                .build();
    }

    public static SitTaxInfo createAll(String stateCode, String filingStatus, String federalWithholdingPercentage, String rateSchedule, String mdCountyCode) {
        return new SitTaxInfoBuilder()
                .stateCode(stateCode)
                .filingStatus(filingStatus)
                .federalWithholdingPercentage(federalWithholdingPercentage)
                .dependents(0)
                .rateSchedule(rateSchedule)
                .additionalNumberOfDependents(0)
                .mdCountyCode(mdCountyCode)
                .build();
    }
}