package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class AccrualFrequency {

    @JsonProperty("id")
    private String id;
    @JsonProperty("description")
    private String description;
    @JsonProperty("type")
    private String type;


    public static AccrualFrequency[] getAccrualFrequencies_FromFile(ReadableFile file) {
        return file.readJsonAs(AccrualFrequency[].class);
    }
}
