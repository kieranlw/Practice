package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.Random;

@Builder
@Data
@AllArgsConstructor
public class DepartmentsForCreate {

    @JsonProperty("code")
    public String code;
    @JsonProperty("description")
    public String description;
    @JsonProperty("isActive")
    public Boolean isActive;
    @JsonProperty("hideSalaryHoursOnStubs")
    public Boolean hideSalaryHoursOnStubs;
    @JsonProperty("checkOverrideName")
    public String checkOverrideName;
    @JsonProperty("checkOverrideAddress1")
    public String checkOverrideAddress1;
    @JsonProperty("checkOverrideAddress2")
    public String checkOverrideAddress2;
    @JsonProperty("checkOverrideAddress3")
    public String checkOverrideAddress3;
    @JsonProperty("defaultUnemploymentState")
    public Object defaultUnemploymentState;
    @JsonProperty("defaultWorkLocationId")
    public String defaultWorkLocationId;
    @JsonProperty("workersCompensationCode1")
    public Object workersCompensationCode1;
    @JsonProperty("workersCompensationCode2")
    public Object workersCompensationCode2;
    @JsonProperty("excludeFromWorkersCompensation")
    public Boolean excludeFromWorkersCompensation;
    @JsonProperty("workersCompensationRate")
    public Integer workersCompensationRate;
    @JsonProperty("workersCompensationState")
    public Object workersCompensationState;

    public static DepartmentsForCreate createDefaultDepartmentForCreate () {
        Random random = new Random();
        String code = Integer.toString(random.nextInt(1000000000 - 10000) + 10000);
        String desc = "description" + code;
        return new DepartmentsForCreate(
                code,
                desc,
                true,
                false,
                "string",
                "string",
                "string",
                "string",
                null,
                null,
                null,
                null,
                false,
                0,
                null
        );
    }

    public static DepartmentsForCreate getDepartmentFromFile(ReadableFile file) {
        return file.readJsonAs(DepartmentsForCreate.class);
    }

}