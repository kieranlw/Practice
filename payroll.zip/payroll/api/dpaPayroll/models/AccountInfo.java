package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
@EqualsAndHashCode
public class AccountInfo {

    @JsonProperty("id")
    private String id;

    @JsonProperty("fein")
    private String fein;

    @JsonProperty("name")
    private String name;

    @JsonProperty("address1")
    private String address1;

    @JsonProperty("address2")
    private String address2;

    @JsonProperty("city")
    private String city;

    @JsonProperty("state")
    private String state;

    @JsonProperty("zip")
    private String zip;

    @JsonProperty("phone")
    private String phone;

    @JsonProperty("country")
    private String country;

    public static AccountInfo getAccountInfo_FromFile(ReadableFile file) {
        return file.readJsonAs(AccountInfo.class);
    }
}