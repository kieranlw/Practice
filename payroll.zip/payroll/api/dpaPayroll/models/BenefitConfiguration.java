package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class BenefitConfiguration {
    @JsonProperty("id")
    private String id;

    @JsonProperty("number")
    private String number;

    @JsonProperty("description")
    private String description;

    @JsonProperty("isActive")
    private Boolean isActive;

    @JsonProperty("relatedDeductionId")
    private String relatedDeductionId;

    @JsonProperty("secondRelatedDeductionId")
    private String secondRelatedDeductionId;

    @JsonProperty("useRelatedDeductionsMax")
    private Boolean useRelatedDeductionsMax;

    @JsonProperty("masterItemGroupId")
    private String masterItemGroupId;

    @JsonProperty("relatedDeductionsMaxAmount")
    private Double relatedDeductionsMaxAmount;

    @JsonProperty("amount")
    private Double amount;

    @JsonProperty("defaultMaxAmount")
    private Double defaultMaxAmount;

    @JsonProperty("useDefaultMax")
    private Boolean useDefaultMax;

    @JsonProperty("maxPercentOfGross")
    private Double maxPercentOfGross;

    @JsonProperty("percentOfDeduction")
    private Double percentOfDeduction;

    @JsonProperty("percentOfPay")
    private Double percentOfPay;

    @JsonProperty("type")
    private String type;

    @JsonProperty("adjustmentFrequency")
    private String adjustmentFrequency;

    @JsonProperty("percentOfPayType")
    private String percentOfPayType;

    @JsonProperty("subclassifications")
    private BenefitSubclassification[] subclassifications;
}