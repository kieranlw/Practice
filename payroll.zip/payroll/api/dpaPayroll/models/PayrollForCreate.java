package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.PayrollType;

@Builder
@Data
@AllArgsConstructor
public class PayrollForCreate {

    @JsonProperty("payDate")
    private String payDate;

    @JsonProperty("periodEndDate")
    private String periodEndDate;

    @JsonProperty("period2EndDate")
    private String periodEnd2Date;

    @JsonProperty("payOfMonth")
    private Integer payOfMonth;

    @JsonProperty("payOfYear")
    private Integer payOfYear;

    @JsonProperty("payrollType")
    private PayrollType payrollType;

    @JsonProperty("scheduledPayrollOverrideId")
    private String scheduledPayrollOverrideId;

    @JsonProperty("unscheduledAccruesLeavePay")
    private Boolean unscheduledAccruesLeavePay;

    @JsonProperty("unscheduledBlocksFederalIncomeTaxes")
    private Boolean unscheduledBlocksFederalIncomeTaxes;

    @JsonProperty("unscheduledBlocksStateIncomeTaxes")
    private Boolean unscheduledBlocksStateIncomeTaxes;

    @JsonProperty("unscheduledUsesStandardDeductionsAndBenefits")
    private Boolean unscheduledUsesStandardDeductionsAndBenefits;

    @JsonProperty("unscheduledPriorYear")
    private Boolean unscheduledPriorYear;

    @JsonProperty("unscheduledSupplementalTaxCalculation")
    private Boolean unscheduledSupplementalTaxCalculation;

    @JsonProperty("unscheduledFederalOverrideRate")
    private Double unscheduledFederalOverrideRate;

    @JsonProperty("unscheduledStateOverrideRate")
    private Double unscheduledStateOverrideRate;

    public static PayrollForCreate getPayrollInfo_FromFile(ReadableFile payrollFile) {
        return payrollFile.readJsonAs(PayrollForCreate.class);
    }

    public static PayrollForCreate getPayrollInfoScheduled() {
        return PayrollForCreate.builder().payrollType(PayrollType.Scheduled).build();
    }
}



