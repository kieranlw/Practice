package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.OtherPayStatus;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor

public class OtherPayForUpdate {
    @JsonProperty("status")
    private OtherPayStatus status;

    @JsonProperty("amount")
    private Double amount;

    @JsonProperty("hourlyAmountOverride")
    private Double hourlyAmountOverride;

    @JsonProperty("maxAccruedAmount")
    private Double maxAccruedAmount;

    @JsonProperty("startDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime startDate;

    @JsonProperty("endDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime endDate;

    @JsonProperty("ignoreAllocations")
    private Boolean ignoreAllocations;

    @JsonProperty("departmentId")
    private String departmentId;

    @JsonProperty("jobCodeId")
    private String jobCodeId;
}