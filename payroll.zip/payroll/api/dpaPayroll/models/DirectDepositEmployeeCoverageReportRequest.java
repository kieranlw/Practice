package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class DirectDepositEmployeeCoverageReportRequest {

   @JsonProperty("employeeId")
    private String employeeId;

    public static DirectDepositEmployeeCoverageReportRequest getEmployeeFromFile(ReadableFile file) {
        return file.readJsonAs(DirectDepositEmployeeCoverageReportRequest.class);
    }

}
