package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Builder
@Data
@AllArgsConstructor
public class AccountInfoForUpdate {

    @JsonProperty("fein")
    public String fein;

    @JsonProperty("name")
    public String name;

    @JsonProperty("address1")
    public String address1;

    @JsonProperty("address2")
    public String address2;

    @JsonProperty("state")
    public String state;

    @JsonProperty("country")
    public String country;

    @JsonProperty("city")
    public String city;

    @JsonProperty("zip")
    public String zip;

    @JsonProperty("phone")
    public String phone;

    public static AccountInfoForUpdate getAccountInfo_FromFile(ReadableFile file) {
        return file.readJsonAs(AccountInfoForUpdate.class);
    }
}
