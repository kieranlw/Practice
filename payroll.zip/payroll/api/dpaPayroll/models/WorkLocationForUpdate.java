package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import lombok.*;

@Builder
@Data
@AllArgsConstructor
public class WorkLocationForUpdate {

    @JsonProperty("description")
    private String description;

    @JsonProperty("state")
    private String state;

    @JsonProperty("address1")
    private String address1;

    @JsonProperty("address2")
    private String address2;

    @JsonProperty("city")
    private String city;

    @JsonProperty("zip")
    private String zip;

    @JsonProperty("zip4")
    private String zip4;

    @JsonProperty("defaultEarnedIncomeTax")
    private String defaultEarnedIncomeTax;

    @JsonProperty("defaultLocalServicesTax")
    private String defaultLocalServicesTax;

    @JsonProperty("defaultWorkPoliticalSubdivision")
    private String defaultWorkPoliticalSubdivision;

    public static WorkLocationForUpdate getWorkLocationsFromFile(ReadableFile file) {
        return file.readJsonAs(WorkLocationForUpdate.class);
    }

    public WorkLocationForUpdate setZip(String zip) {
        this.zip = zip;
        return this;
    }

    public WorkLocationForUpdate setDescription(String description) {
        this.description = description;
        return this;
    }

    public WorkLocationForUpdate setState(String state) {
        this.state = state;
        return this;
    }

    public WorkLocationForUpdate setAddress1(String address1) {
        this.address1 = address1;
        return this;
    }

    public WorkLocationForUpdate setAddress2(String address2) {
        this.address2 = address2;
        return this;
    }

    public WorkLocationForUpdate setCity(String city) {
        this.city = city;
        return this;
    }

    public WorkLocationForUpdate setZip4(String zip4) {
        this.zip4 = zip4;
        return this;
    }

    public WorkLocationForUpdate setDefaultEarnedIncomeTax(String defaultEarnedIncomeTax) {
        this.defaultEarnedIncomeTax = defaultEarnedIncomeTax;
        return this;
    }

    public WorkLocationForUpdate setDefaultLocalServicesTax(String defaultLocalServicesTax) {
        this.defaultLocalServicesTax = defaultLocalServicesTax;
        return this;
    }

    public static WorkLocationForUpdate createDefaultWorkLocationForUpdateObject() {
        return new WorkLocationForUpdate(
                "TestDescription",
                "PA",
                "Address 1 Street",
                "Address 2 Street",
                "TestCity",
                "12345",
                "1234",
                "PA-EIT-7001R",
                "PA-LST-1620L",
                null);
    }
}
