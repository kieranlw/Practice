package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import common.ReadableFile;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.LeavePay_CarryMode;
import payroll.api.dpaPayroll.models.enums.PayType;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class PayInfo {

    @JsonProperty("id")
    private String id;

    @JsonProperty("employeeId")
    private String employeeId;

    @JsonProperty("isPrimary")
    private Boolean isPrimary;

    @JsonProperty("payType")
    private PayType payType;

    @JsonProperty("departmentId")
    private String departmentId;

    @JsonProperty("workClassification")
    private String workClassification;

    @JsonProperty("jobCodeId")
    private String jobCodeId;

    @JsonProperty("rate")
    private Double rate;

    @JsonProperty("hoursPerShiftOverride")
    private Double hoursPerShiftOverride;

    @JsonProperty("cashFringe")
    private Double cashFringe;

    @JsonProperty("overtimeFactor")
    private Double overtimeFactor;

    @JsonProperty("minimumWageOverride")
    private Double minimumWageOverride;

    @JsonProperty("defaultHoursOverride")
    private Double defaultHoursOverride;

    public static PayInfo[] getPaysInfo_FromFile(ReadableFile file) {
        return file.readJsonAs(PayInfo[].class);
    }

}
