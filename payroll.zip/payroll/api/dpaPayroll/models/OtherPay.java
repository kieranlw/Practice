package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class OtherPay {

    @JsonProperty("id")
    private String id;
    @JsonProperty( "otherPayConfigurationId")
    private String otherPayConfigurationId;
    @JsonProperty( "employeeId")
    private String employeeId;
    @JsonProperty( "accruedAmount")
    private Double accruedAmount;
    @JsonProperty("status")
    private String status;
    @JsonProperty("amount")
    private Double amount;
    @JsonProperty("startDate")
    private String startDate;
    @JsonProperty("endDate")
    private String endDate;
    @JsonProperty("departmentId")
    private String departmentId;
    @JsonProperty("ignoreAllocations")
    private Boolean ignoreAllocations;
    @JsonProperty("doesAccrue")
    private Boolean doesAccrue;
    @JsonProperty("jobCodeId")
    private String jobCodeId;
    @JsonProperty("hourlyAmountOverride")
    private Double hourlyAmountOverride;
    @JsonProperty("maxAccruedAmount")
    private Double maxAccruedAmount;

}
