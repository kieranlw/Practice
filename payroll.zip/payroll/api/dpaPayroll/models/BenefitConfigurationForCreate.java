package payroll.api.dpaPayroll.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import payroll.api.dpaPayroll.models.enums.AdjustmentFrequency;
import payroll.api.dpaPayroll.models.enums.BenefitType;
import payroll.api.dpaPayroll.models.enums.PercentOfPayType;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class BenefitConfigurationForCreate {
    @JsonProperty("number")
    private String number;

    @JsonProperty("description")
    private String description;

    @JsonProperty("isActive")
    private Boolean isActive;

    @JsonProperty("adjustmentFrequency")
    private AdjustmentFrequency adjustmentFrequency;

    @JsonProperty("percentOfPayType")
    private PercentOfPayType percentOfPayType;

    @JsonProperty("type")
    private BenefitType type;

    @JsonProperty("relatedDeductionId")
    private String relatedDeductionId;

    @JsonProperty("secondRelatedDeductionId")
    private String secondRelatedDeductionId;

    @JsonProperty("useRelatedDeductionsMax")
    private Boolean useRelatedDeductionsMax;

    @JsonProperty("relatedDeductionsMaxAmount")
    private Double relatedDeductionsMaxAmount;

    @JsonProperty("percentOfDeduction")
    private Double percentOfDeduction;

    @JsonProperty("maxPercentOfGross")
    private Double maxPercentOfGross;

    @JsonProperty("percentOfPay")
    private Double percentOfPay;

    @JsonProperty("useDefaultMax")
    private Boolean useDefaultMax;

    @JsonProperty("defaultMaxAmount")
    private Double defaultMaxAmount;

    @JsonProperty("amount")
    private Double amount;

    @JsonProperty("masterItemGroupId")
    private String masterItemGroupId;
}
