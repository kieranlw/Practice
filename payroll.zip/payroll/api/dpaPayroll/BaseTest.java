package payroll.api.dpaPayroll;

import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import payroll.api.dpaPayroll.environment.Environment;
import payroll.api.dpaPayroll.environment.EnvironmentDecorator;
import payroll.api.dpaPayroll.environment.GetEnvironmentData;
import payroll.data.DataImport;
import payroll.data.SessionVariables;
import utils.FileOperations;
import utils2.DriverInfo;
import utils2.LogInfo;
import utils2.ResultWriter2;
import utils2.classGroup.GroupBy;

@GroupBy(groups = {"regression_Tests", "all_Tests"})
public class BaseTest {
    private static WebDriver driver;

    public static WebDriver getDriver() {
        return driver;
    }

    public static void setDriver(WebDriver driver) {
        BaseTest.driver = driver;
    }

    protected Environment environment;
    //https://awb03454.deluxe.com/swagger/index.html
    private DriverInfo defaultDriverInfo;

    @BeforeClass(alwaysRun = true)
    public void Test_SetUp() {
        environment = GetEnvironmentData.getCurrentEnvironment();
        EnvironmentDecorator.initDataManage(environment, this);
    }

    protected static DriverInfo createDriverInfo() {
        DataImport.retrieve_EnvironmentData();
        LogInfo.log_Status("setup DriverInfo process");
        DriverInfo driverInfo = new DriverInfo(SessionVariables.getBrowserType());
        driverInfo.setDownloadLocation("C:\\DAF\\Downloads\\");
        driverInfo.setPageLoadStrategy(PageLoadStrategy.NONE);
        driverInfo.setStartMaximized(true);
        FileOperations.create_Folder("C:\\DAF\\Downloads\\");
        return driverInfo;
    }

    @AfterMethod(alwaysRun = true)
    public void testBrowserTeardown(ITestResult result) throws Exception {
        if (getDriver() != null) {
            ResultWriter2.checkForFailureAndScreenshot(result, getDriver());
            getDriver().quit();
        }
    }
}