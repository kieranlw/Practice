package payroll.api.dpaPayroll.pages.functions;

import org.openqa.selenium.WebDriver;
import payroll.api.dpaPayroll.TestAccount;
import payroll.api.dpaPayroll.environment.Environment;
import payroll.api.dpaPayroll.http.token.OldJwtBearerTokenSource;
import payroll.api.dpaPayroll.jwt.JWTResponse;
import payroll.api.dpaPayroll.jwt.OldJwtCallSetupData;
import payroll.api.dpaPayroll.pages.SSOPage;
import payroll.pages.payroll.companyProfile.CompanyProfilePage_Payroll;
import payroll.pages.payroll.companyProfile.CompanySpecialPage_Payroll;
import payroll.pages.payroll.dashboard.DashboardPage_Payroll;
import payroll.pages.payroll.employees.EmployeeListPage_Payroll;
import payroll.pages.payroll.employees.EmployeeOverviewPage_Payroll;
import payroll.pages.payroll.payrollProcessing.PayrollProcessingPage_Payroll;
import payroll.pages.payroll.reports.CustomReportsPage_Payroll;
import payroll.pages.payroll.reports.ReportsPage_Payroll;
import utils2.page_components.*;

public class OldSsoLoginUtil {

    private TestAccount testAccount;
    private Environment environment;
    private WebDriver driver;

    public OldSsoLoginUtil(TestAccount testAccount, Environment environment, WebDriver webDriver){
        this.testAccount = testAccount;
        this.environment = environment;
        this.driver = webDriver;
    }

    public DashboardPage_Payroll loginWithUserLevel(String userLevel){
        OldJwtCallSetupData jwtCallData = OldJwtCallSetupData.getDefaultSetupData(testAccount, environment);
        jwtCallData.getPayload().setAccessLevel(userLevel);

        OldJwtBearerTokenSource jwtToken = new OldJwtBearerTokenSource(jwtCallData);
        JWTResponse jwtResponse = jwtToken.create().as(JWTResponse.class);

        return logInWithToken(jwtResponse.getAccess_token());
    }

    public DashboardPage_Payroll logInWithUserLevelAndDashBoardRedirectPath(String userLevel,String redirectPath){
        OldJwtCallSetupData jwtCallData = OldJwtCallSetupData.getDefaultSetupData(testAccount, environment);
        jwtCallData.getPayload().setAccessLevel(userLevel);

        OldJwtBearerTokenSource jwtToken = new OldJwtBearerTokenSource(jwtCallData);
        JWTResponse jwtResponse = jwtToken.create().as(JWTResponse.class);
        SSOPage ssoPage = BasePageObject.createAndLoad(SSOPage::new, driver);
        ssoPage.reDirectPathInputBox.enterText(redirectPath);
        ssoPage.ssoTextarea.enterText(jwtResponse.getAccess_token());
        DashboardPage_Payroll dashboardPage = ssoPage.beginSSOButtonToDashboard.clickToNavigate();
        dashboardPage.acceptCookiesIfPresent();

        return dashboardPage;
    }

    public EmployeeListPage_Payroll logInWithUserLevelAndEmployeeRedirectPath(String userLevel, String redirectPath){
        OldJwtCallSetupData jwtCallData = OldJwtCallSetupData.getDefaultSetupData(testAccount, environment);
        jwtCallData.getPayload().setAccessLevel(userLevel);

        OldJwtBearerTokenSource jwtToken = new OldJwtBearerTokenSource(jwtCallData);
        JWTResponse jwtResponse = jwtToken.create().as(JWTResponse.class);
        SSOPage ssoPage = BasePageObject.createAndLoad(SSOPage::new, driver);
        ssoPage.reDirectPathInputBox.enterText(redirectPath);
        ssoPage.ssoTextarea.enterText(jwtResponse.getAccess_token());
        EmployeeListPage_Payroll employeeListPage_payroll = ssoPage.beginSSOButtonToEmployee.clickToNavigate();

        return employeeListPage_payroll;
    }

    public CompanyProfilePage_Payroll logInWithUserLevelAndCompanyProfileRedirectPath(String userLevel, String redirectPath){
        OldJwtCallSetupData jwtCallData = OldJwtCallSetupData.getDefaultSetupData(testAccount, environment);
        jwtCallData.getPayload().setAccessLevel(userLevel);

        OldJwtBearerTokenSource jwtToken = new OldJwtBearerTokenSource(jwtCallData);
        JWTResponse jwtResponse = jwtToken.create().as(JWTResponse.class);
        SSOPage ssoPage = BasePageObject.createAndLoad(SSOPage::new, driver);
        ssoPage.reDirectPathInputBox.enterText(redirectPath);
        ssoPage.ssoTextarea.enterText(jwtResponse.getAccess_token());
        CompanyProfilePage_Payroll companyProfilePage_payroll = ssoPage.beginSSOButtonToCompanyProfile.clickToNavigate();

        return companyProfilePage_payroll;
    }

    public CompanySpecialPage_Payroll logInWithUserLevelAndCompanySpecialPageRedirectPath(String userLevel, String redirectPath){
        OldJwtCallSetupData jwtCallData = OldJwtCallSetupData.getDefaultSetupData(testAccount, environment);
        jwtCallData.getPayload().setAccessLevel(userLevel);

        OldJwtBearerTokenSource jwtToken = new OldJwtBearerTokenSource(jwtCallData);
        JWTResponse jwtResponse = jwtToken.create().as(JWTResponse.class);
        SSOPage ssoPage = BasePageObject.createAndLoad(SSOPage::new, driver);
        ssoPage.reDirectPathInputBox.enterText(redirectPath);
        ssoPage.ssoTextarea.enterText(jwtResponse.getAccess_token());
        CompanySpecialPage_Payroll companySpecialPage_payroll = ssoPage.beginSSOButtonToCompanyProfileSpecial.clickToNavigate();

        return companySpecialPage_payroll;
    }

    public ReportsPage_Payroll logInWithUserLevelAndReportsPage_PayrollRedirectPath(String userLevel, String redirectPath){
        OldJwtCallSetupData jwtCallData = OldJwtCallSetupData.getDefaultSetupData(testAccount, environment);
        jwtCallData.getPayload().setAccessLevel(userLevel);

        OldJwtBearerTokenSource jwtToken = new OldJwtBearerTokenSource(jwtCallData);
        JWTResponse jwtResponse = jwtToken.create().as(JWTResponse.class);
        SSOPage ssoPage = BasePageObject.createAndLoad(SSOPage::new, driver);
        ssoPage.reDirectPathInputBox.enterText(redirectPath);
        ssoPage.ssoTextarea.enterText(jwtResponse.getAccess_token());
        ReportsPage_Payroll reportsPage_payroll = ssoPage.beginSSOButtonToReportPage_Payroll.clickToNavigate();

        return reportsPage_payroll;
    }

    public CustomReportsPage_Payroll logInWithUserLevelAndCustomReportsPage_PayrollRedirectPath(String userLevel, String redirectPath){
        OldJwtCallSetupData jwtCallData = OldJwtCallSetupData.getDefaultSetupData(testAccount, environment);
        jwtCallData.getPayload().setAccessLevel(userLevel);

        OldJwtBearerTokenSource jwtToken = new OldJwtBearerTokenSource(jwtCallData);
        JWTResponse jwtResponse = jwtToken.create().as(JWTResponse.class);
        SSOPage ssoPage = BasePageObject.createAndLoad(SSOPage::new, driver);
        ssoPage.reDirectPathInputBox.enterText(redirectPath);
        ssoPage.ssoTextarea.enterText(jwtResponse.getAccess_token());
        CustomReportsPage_Payroll customReportsPage_payroll = ssoPage.beginSSOButtonToCustomReportsPage_Payroll.clickToNavigate();

        return customReportsPage_payroll;
    }

    public EmployeeOverviewPage_Payroll logInWithUserLevelAndEmployeeOverviewPage_PayrollRedirectPath(String userLevel, String redirectPath){
        OldJwtCallSetupData jwtCallData = OldJwtCallSetupData.getDefaultSetupData(testAccount, environment);
        jwtCallData.getPayload().setAccessLevel(userLevel);

        OldJwtBearerTokenSource jwtToken = new OldJwtBearerTokenSource(jwtCallData);
        JWTResponse jwtResponse = jwtToken.create().as(JWTResponse.class);
        SSOPage ssoPage = BasePageObject.createAndLoad(SSOPage::new, driver);
        ssoPage.reDirectPathInputBox.enterText(redirectPath);
        ssoPage.ssoTextarea.enterText(jwtResponse.getAccess_token());
        EmployeeOverviewPage_Payroll employeeOverviewPage_payroll = ssoPage.beginSSOButtonToEmployeeOverviewPage_Payroll.clickToNavigate();

        return employeeOverviewPage_payroll;
    }

    public PayrollProcessingPage_Payroll logInWithUserLevelAndPayrollProcessingPage_PayrollRedirectPath(String userLevel, String redirectPath){
        OldJwtCallSetupData jwtCallData = OldJwtCallSetupData.getDefaultSetupData(testAccount, environment);
        jwtCallData.getPayload().setAccessLevel(userLevel);

        OldJwtBearerTokenSource jwtToken = new OldJwtBearerTokenSource(jwtCallData);
        JWTResponse jwtResponse = jwtToken.create().as(JWTResponse.class);
        SSOPage ssoPage = BasePageObject.createAndLoad(SSOPage::new, driver);
        ssoPage.reDirectPathInputBox.enterText(redirectPath);
        ssoPage.ssoTextarea.enterText(jwtResponse.getAccess_token());
        PayrollProcessingPage_Payroll payrollProcessingPage_payroll = ssoPage.beginSSOButtonToPayrollProcessingPage_payroll.clickToNavigate();

        return payrollProcessingPage_payroll;
    }

    private DashboardPage_Payroll logInWithToken(String token){
        SSOPage ssoPage = BasePageObject.createAndLoad(SSOPage::new, driver);
        ssoPage.ssoTextarea.enterText(token);
        DashboardPage_Payroll dashboardPage = ssoPage.beginSSOButton.clickToNavigate();
        dashboardPage.acceptCookiesIfPresent();

        return dashboardPage;
    }

}
