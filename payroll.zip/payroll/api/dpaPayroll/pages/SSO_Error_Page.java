package payroll.api.dpaPayroll.pages;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

import java.time.Duration;

public class SSO_Error_Page extends BasePageObject {

    protected WebDriver driver;

    @ComponentFindBy(xpath = "//body")
    public GenericComponent errorMessage;

    @Override
    public void waitForPageToLoad() {
        errorMessage.waitUntil(Duration.ofSeconds(30)).displayed();
        ThreadUtils.sleep(200);
    }


    public SSO_Error_Page(WebDriver driver) {
        this.driver = driver;
        ComponentFactory.initElements(this.driver, this);
    }
}
