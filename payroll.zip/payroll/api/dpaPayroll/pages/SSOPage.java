package payroll.api.dpaPayroll.pages;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import payroll.pages.payroll.companyProfile.CompanyProfilePage_Payroll;
import payroll.pages.payroll.companyProfile.CompanySpecialPage_Payroll;
import payroll.pages.payroll.dashboard.DashboardPage_Payroll;
import payroll.pages.payroll.employees.EmployeeListPage_Payroll;
import payroll.pages.payroll.employees.EmployeeOverviewPage_Payroll;
import payroll.pages.payroll.payrollProcessing.PayrollProcessingPage_Payroll;
import payroll.pages.payroll.reports.CustomReportsPage_Payroll;
import payroll.pages.payroll.reports.ReportsPage_Payroll;
import utils2.page_components.*;

import java.time.Duration;

public class SSOPage extends BasePageObject {

    protected WebDriver driver;

    @ComponentFindBy(xpath = "//*[@id='ssoForm']/textarea")
    public TextBox ssoTextarea;

    @ComponentFindBy(xpath = "//input[@name='path']")
    public TextBox reDirectPathInputBox;

    @ComponentFindBy(xpath = "//input[@name='accountId']")
    public TextBox accountIdInputBox;

    @ComponentFindBy(xpath = "//input[@value='Begin SSO']")
    public NavigateTo<DashboardPage_Payroll> beginSSOButton;

    @ComponentFindBy(xpath = "//input[@value='Begin SSO']")
    public NavigateTo<DashboardPage_Payroll> beginSSOButtonToDashboard;

    @ComponentFindBy(xpath = "//input[@value='Begin SSO']")
    public NavigateTo<EmployeeListPage_Payroll> beginSSOButtonToEmployee;

    @ComponentFindBy(xpath = "//input[@value='Begin SSO']")
    public NavigateTo<CompanyProfilePage_Payroll> beginSSOButtonToCompanyProfile;

    @ComponentFindBy(xpath = "//input[@value='Begin SSO']")
    public NavigateTo<CompanySpecialPage_Payroll> beginSSOButtonToCompanyProfileSpecial;

    @ComponentFindBy(xpath = "//input[@value='Begin SSO']")
    public NavigateTo<ReportsPage_Payroll> beginSSOButtonToReportPage_Payroll;

    @ComponentFindBy(xpath = "//input[@value='Begin SSO']")
    public NavigateTo<CustomReportsPage_Payroll> beginSSOButtonToCustomReportsPage_Payroll;

    @ComponentFindBy(xpath = "//input[@value='Begin SSO']")
    public NavigateTo<EmployeeOverviewPage_Payroll> beginSSOButtonToEmployeeOverviewPage_Payroll;

    @ComponentFindBy(xpath = "//input[@value='Begin SSO']")
    public NavigateTo<PayrollProcessingPage_Payroll> beginSSOButtonToPayrollProcessingPage_payroll;

    @ComponentFindBy(xpath = "//input[@value='Begin SSO']")
    public NavigateTo<SSO_Error_Page> beginSSOButton_CausesError;

    @Override
    public void waitForPageToLoad() {
        ssoTextarea.waitUntil(Duration.ofSeconds(30)).displayed();
        ThreadUtils.sleep(200);
    }


    public SSOPage(WebDriver driver) {
        this.driver = driver;
        ComponentFactory.initElements(this.driver, this);
    }
}
