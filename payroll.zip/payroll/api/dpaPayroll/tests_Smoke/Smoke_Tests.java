package payroll.api.dpaPayroll.tests_Smoke;

import common.Is;

import common.ThreadUtils;
import common.Verify;
import io.restassured.response.Response;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import payroll.api.dpaPayroll.BaseTest;
import payroll.api.dpaPayroll.environment.EnvironmentData;
import payroll.api.dpaPayroll.http.AccountScopedResourceAccessorFactory;
import payroll.api.dpaPayroll.models.Employee_PersonalInfo;
import payroll.api.dpaPayroll.models.Environment_Status;
import payroll.api.dpaPayroll.models.Paystub;
import utils.BaseUI;
import utils.Browser;
import utils2.DriverInfo;
import utils2.DriverSetup;
import utils2.LogInfo;
import utils2.classGroup.GroupBy;

@GroupBy(groups = {"smoke_Tests", "all_Tests"})
public class Smoke_Tests extends BaseTest {

    private AccountScopedResourceAccessorFactory api;
    private static final String STATUS = "Online";
    private WebDriver driver;
    private DriverInfo defaultDriverInfo;

    @EnvironmentData(
            DEFAULT = "",
            API_PROD = "fcf6a1ca-e1f5-e511-ae29-78e7d193ce24",
            API_XUAT = "fcf6a1ca-e1f5-e511-ae29-78e7d193ce24",
            API_QA = "688DC027-A4E8-EA11-8154-00155D001935"
    )
    private String accountId;

    @EnvironmentData(
            DEFAULT = "",
            API_PROD = "b318f07f-119f-e811-8117-00155d001915",
            API_QA = "57430280-0c6b-eb11-9282-00505690f979"

    )
    private String employeeID;

    @EnvironmentData(
            DEFAULT = "",
            API_PROD = "00fb29c9-455b-712a-0664-39fb05bcbc30",
            API_QA = "57430280-0c6b-eb11-9282-00505690f979"
    )
    private String employeeWithPaystub;

    @EnvironmentData(
            DEFAULT = "",
            API_PROD = " c9adfb53-e48b-eb11-91f0-00505690ceec",
            API_QA = "81f8b4e4-0c6b-eb11-9282-00505690f979"
    )
    private String paystub;

    @EnvironmentData(
            DEFAULT = "",
            API_PROD = "https://payroll.mypaycenter.com/",
            API_XUAT = "https://xuat-payroll.mypaycenter.com/"

    )
    private String myPayCenterUrl;

    @EnvironmentData(
            DEFAULT = "",
            API_PROD = "https://workflow.mypaycenter.com/",
            API_XUAT = "https://xuat-workflow.mypaycenter.com/"
    )
    private String workflowUrl;

    @BeforeClass(alwaysRun = true)
    public void setUp() throws Exception {
        api = AccountScopedResourceAccessorFactory.fromEnvironmentConfig(
                accountId,
                environment);
        defaultDriverInfo = createDriverInfo();
    }

    public void setupDriver() {
        LogInfo.log_Status("setup driver to test");
        WebDriver webDriver = new DriverSetup(defaultDriverInfo).startDriver(StringUtils.EMPTY);
        setDriver(webDriver);
    }

    @Test(groups = "prod")
    public void ZEP38558_Employee_GetAll() {
        Response response = api.getEmployeeResourceAccessor().getAll();
        Verify.that(response.getStatusCode(), Is.equalTo(200));
        Employee_PersonalInfo[] employees = response.as(Employee_PersonalInfo[].class);
        Verify.that(employees.length > 0);
    }

    @Test(groups = "prod")
    public void ZEP38558_Employee_Get() {
        Response response1 = api.getEmployeeResourceAccessor().getAll();
        Employee_PersonalInfo[] employees = response1.as(Employee_PersonalInfo[].class);
        employeeID = employees[0].getId();
        Response response = api.getEmployeeResourceAccessor().get(employeeID);
        Verify.that(response.getStatusCode(), Is.equalTo(200));
    }

    @Test(groups = "prod")
    public void ZEP44859_VerifyTheDpaVersion() {
        Response response = api.getEnvironmentAccessor().getTheDpaEnvironmentStatus();
        Environment_Status envStatus = response.as(Environment_Status.class);
        Verify.that(response.getStatusCode(), Is.equalTo(200));
        Verify.that(envStatus.getStatus(), Is.equalTo(STATUS));
        Verify.that(envStatus.getVersion(), Is.equalTo(System.getProperty("dpaVersion")));
    }

    @Test(groups = "prod")
    public void ZEP44860_VerifyTheMpcVersion() {
        Response response = api.getEnvironmentAccessor().getTheMpcEnvironmentStatus();
        Environment_Status envStatus = response.as(Environment_Status.class);
        Verify.that(response.getStatusCode(), Is.equalTo(200));
        Verify.that(envStatus.getStatus(), Is.equalTo(STATUS));
        Verify.that(envStatus.getVersion(), Is.equalTo(System.getProperty("misVersion")));
    }

    @Test(groups = {"prod", "ZEP48318"})
    public void ZEP48318_verifyWorkFlowUp() {
        setupDriver();
        LogInfo.log_Status(":url provided by env:" + workflowUrl);
        getDriver().get(workflowUrl);
        wait_forPageToFinishLoading();
        Verify.that(getDriver().getCurrentUrl().equalsIgnoreCase(workflowUrl));
        Verify.that(getDriver().findElement(By.cssSelector("#login-username")).isDisplayed());
        Verify.that(getDriver().findElement(By.cssSelector("#login-password")).isDisplayed());
    }

    @Test(groups = {"prod", "ZEP48319"})
    public void ZEP48319_verifyMyPayCenterUp() {
        setupDriver();
        LogInfo.log_Status(":url provided by env:" + myPayCenterUrl);
        getDriver().get(myPayCenterUrl);
        wait_forPageToFinishLoading();
        Verify.that(getDriver().getCurrentUrl().equalsIgnoreCase(myPayCenterUrl));
        Verify.that(getDriver().findElement(By.cssSelector("#login-username")).isDisplayed());
        Verify.that(getDriver().findElement(By.cssSelector("#login-password")).isDisplayed());
    }

    @Test(groups = "paystab")
    public void ZEP38558_PayStub_Get() {
        Response response = api.getPayStubResourceAccessor().get(paystub);
        Verify.that(response.getStatusCode(), Is.equalTo(200));
    }

    @Test(groups = "paystab")
    public void ZEP38558_PayStub_GetAll() {
        Response response = api.getPayStubResourceAccessor().getAllForEmployee(employeeWithPaystub);
        Verify.that(response.getStatusCode(), Is.equalTo(200));
        Paystub[] paystubs = response.as(Paystub[].class);
        Verify.that(paystubs.length > 0);
    }

    @Test(groups = "paystab")
    public void ZEP38558_PayStubPDF_Get() {
        Response response = api.getPayStubResourceAccessor().getPDF(paystub);
        Verify.that(response.getStatusCode(), Is.equalTo(200));
    }

    private void wait_forPageToFinishLoading() {
        WebDriverWait wait = new WebDriverWait(getDriver(), 60);
        LogInfo.log_Status("Waiting for page to finish loading.");
        ThreadUtils.sleep(1000);
        {
            ExpectedCondition<Boolean> expectation = driver ->
                    ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
                            .equals("complete");

            try {
                wait.until(expectation);
            } catch (Exception e) {
                LogInfo.log_Status("Encountered error waiting for page to finish loading.");
            }
        }
    }
}
