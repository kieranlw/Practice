package payroll.api.dpaPayroll.jwt;

import com.fasterxml.jackson.annotation.JsonProperty;
import common.Is;
import common.Verify;

public class ErrorModel {

    @JsonProperty("error_description")
    private String error_description;
    @JsonProperty("error")
    private String error;

    public void verifyInvalidGrant(String errorType, String expectedText){
        Verify.that(error, Is.equalTo(errorType));
        Verify.that(error_description, Is.equalTo(expectedText));
    }

}
