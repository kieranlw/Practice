package payroll.api.dpaPayroll.jwt;

import common.ResourceFile;
import utils2.LogInfo;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import java.util.HashMap;

public class CertKeys {

    public static HashMap<String, Object> get(ResourceFile resourceFile, String password) {
        try {
            return get(new FileInputStream(resourceFile.getAbsolutePath()), password);
        } catch (Exception e) {
            LogInfo.log_AndFail(e.getMessage());
        }
        return null;
    }

    public static HashMap<String, Object> get(InputStream cerFileStream, String password) {
        HashMap<String, Object> keyPair = new HashMap<>();
        KeyStore keyStore = null;
        Enumeration<String> keyStoreAliasEnum = null;
        try {
            keyStore = KeyStore.getInstance("PKCS12"); //, "BC");
            keyStore.load(cerFileStream, password.toCharArray());
            keyStoreAliasEnum = keyStore.aliases();
        } catch (Exception e) {
            LogInfo.log_AndFail("Unable to create Keystore, encountered error: " + e.getMessage());
        }

        String alias = null;
        while (keyStoreAliasEnum.hasMoreElements()) {
            alias = keyStoreAliasEnum.nextElement();
            if (password != null) {
                PrivateKey privateKey = null;
                X509Certificate x509Certificate = null;
                try {
                    privateKey = (PrivateKey) keyStore.getKey(alias, password.toCharArray());
                    x509Certificate = (X509Certificate) keyStore.getCertificate(alias);
                } catch (Exception e) {
                    LogInfo.log_AndFail(e.getMessage());
                }
                PublicKey publicKey = x509Certificate.getPublicKey();

                keyPair.put("Alias", alias);
                keyPair.put("PublicKey", publicKey);
                keyPair.put("PrivateKey", privateKey);
                keyPair.put("X509Certificate", x509Certificate);
            }
        }
        return keyPair;
    }
}
