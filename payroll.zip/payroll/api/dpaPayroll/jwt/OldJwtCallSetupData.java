package payroll.api.dpaPayroll.jwt;

import common.ResourceFile;
import lombok.*;
import payroll.api.dpaPayroll.TestAccount;
import payroll.api.dpaPayroll.environment.Environment;
import utils2.LogInfo;

import java.io.FileInputStream;
import java.security.PrivateKey;
import java.util.Map;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class OldJwtCallSetupData {

    private String baseUri;
    private OldJwtPayload payload;
    private JWTHeader jwtHeader;
    private String account;
    private String scope;
    private String key;
    private PrivateKey privateKey;
    private String clientSecret;
    private String clientId;
    private String version;


    private static final String JKS_PASSWORD = "payroll";
    private static final ResourceFile PFX_FILE = new ResourceFile("payroll/data/newAPI/testData/jwt/private.pfx");

    private static final long ONE_YEAR = 31536000;

    public static OldJwtCallSetupData getDefaultSetupData(TestAccount testAccount, Environment environment) {
        Map<String, Object> cerKeys = null;
        try {
            cerKeys = CertKeys.get(new FileInputStream(PFX_FILE.getAbsolutePath()), JKS_PASSWORD);
        } catch (Exception e) {
            LogInfo.log_AndFail("Unable to get Cert Keys for file " + e.getMessage());
        }

        OldJwtPayload payload = buildPayload();
        JWTHeader jwtHeader = buildHeader();

        return OldJwtCallSetupData.builder()
                .account(testAccount.getAccountId())
                .baseUri(environment.getTokenBaseURI())
                .payload(payload)
                .jwtHeader(jwtHeader)
                .scope("dpa mpc")
                .privateKey((PrivateKey) cerKeys.get("PrivateKey"))
                .clientId(environment.getClientId())
                .clientSecret(environment.getClientSecret())
                .version(environment.getVersion())
                .build();
    }

    private static OldJwtPayload buildPayload() {
        OldJwtPayload payload = OldJwtPayload.builder()
                .exp(System.currentTimeMillis() / 1000 + ONE_YEAR)
                .iat(System.currentTimeMillis() / 1000)
                //sub and email are unique together
                .sub("5fdfde52-100c-4389-879f-0c1ea6fe6686")
                .email("gocoUser1@goco.com")
                .iss("https://dev-test.com/issuer")
                .aud("deluxe")
                .accessLevel("Admin")
                .given_name("John1")
                .family_name("Doe2")
                .build();

        return payload;
    }

    private static JWTHeader buildHeader() {
        JWTHeader jwtHeader = JWTHeader.builder()
                .alg("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256")
                .kid("3E831E6669059BC80B69E407BD5D2E97F202AC71")
                .typ("JWT")
                .build();

        return jwtHeader;
    }
}