package payroll.api.dpaPayroll.jwt;

import common.ResourceFile;
import lombok.*;
import payroll.api.dpaPayroll.TestAccount;
import payroll.api.dpaPayroll.environment.Environment;
import utils2.LogInfo;
import java.io.FileInputStream;
import java.security.PrivateKey;
import java.util.Map;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class JWTCallSetupData {

    private String baseUri;
    private JWTPayload payload;
    private JWTHeader jwtHeader;
    private String scope;
    private String key;
    private PrivateKey privateKey;
    private String clientSecret;
    private String clientId;
    private String version;
    private static String ISS_URL;

    private static final String JKS_PASSWORD = "payroll";
    private static final ResourceFile PFX_FILE = new ResourceFile("payroll/data/newAPI/testData/jwt/private.pfx");

    private static final long ONE_YEAR = 31536000;

    public static JWTCallSetupData getDefaultSetupData(TestAccount testAccount, Environment environment) {
        Map<String, Object> cerKeys = null;
        try {
            cerKeys = CertKeys.get(new FileInputStream(PFX_FILE.getAbsolutePath()), JKS_PASSWORD);
        } catch (Exception e) {
            LogInfo.log_AndFail("Unable to get Cert Keys for file " + e.getMessage());
        }

        ISS_URL = environment.getName().equalsIgnoreCase("API_XUAT")?
                 "api.goco.io":"https://dev-test.com/issuer";
        JWTPayload payload = buildPayload(testAccount.getAccountId());
        JWTHeader jwtHeader = buildHeader();

        return JWTCallSetupData.builder()
                .baseUri(environment.getTokenBaseURI())
                .payload(payload)
                .jwtHeader(jwtHeader)
                .scope("dpa mpc")
                .privateKey((PrivateKey) cerKeys.get("PrivateKey"))
                .clientId(environment.getClientId())
                .clientSecret(environment.getClientSecret())
                .version(environment.getVersion())
                .build();
    }

    private static JWTPayload buildPayload(String account) {
        JWTPayload payload = JWTPayload.builder()
                .exp(System.currentTimeMillis() / 1000 + ONE_YEAR)
                .iat(System.currentTimeMillis() / 1000)
                //sub and email are unique together
                .sub("5fdfde52-100c-4389-879f-0c1ea6fe6681")
                .email("gocoUser5@goco.com")
                .iss(ISS_URL)
                .aud("deluxe")
                .accessLevel("Admin")
                .given_name("Johnny")
                .family_name("DoeGood")
                .mpc_account(account)
                .build();

        return payload;
    }

    private static JWTHeader buildHeader() {
        JWTHeader jwtHeader = JWTHeader.builder()
                .alg("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256")
                .kid("3E831E6669059BC80B69E407BD5D2E97F202AC71")
                .typ("JWT")
                .build();

        return jwtHeader;
    }
}