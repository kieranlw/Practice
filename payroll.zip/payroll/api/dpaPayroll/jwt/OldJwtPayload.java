package payroll.api.dpaPayroll.jwt;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class OldJwtPayload {

    @JsonProperty("exp")
    private Long exp;
    @JsonProperty("nbf")
    private Long nbf;
    @JsonProperty("iat")
    private Long iat;
    //sub and email are unique together
    @JsonProperty("sub")
    private String sub;
    @JsonProperty("email")
    private String email;
    @JsonProperty("iss")
    private String iss;
    @JsonProperty("aud")
    private String aud;
    @JsonProperty("accessLevel")
    private String accessLevel;
    @JsonProperty("given_name")
    private String given_name;
    @JsonProperty("family_name")
    private String family_name;
}
