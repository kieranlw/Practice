package payroll.api.dpaPayroll.jwt;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class JWTHeader {

    @JsonProperty("alg")
    private String alg;
    @JsonProperty("kid")
    private String kid;
    @JsonProperty("typ")
    private String typ;
}
