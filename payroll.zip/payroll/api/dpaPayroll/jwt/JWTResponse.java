package payroll.api.dpaPayroll.jwt;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@Data
@AllArgsConstructor
public class JWTResponse {

    @JsonProperty("access_token")
    private String access_token;
    @JsonProperty("scope")
    private String scope;
    @JsonProperty("token_type")
    private String token_type;
    @JsonProperty("expires_in")
    private int expires_in;

}
