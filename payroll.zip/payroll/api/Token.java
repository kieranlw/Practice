package payroll.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Token 
{
	public String access_token;
	public String id_token;
	public String token_type;
	public int expires_in;
}
