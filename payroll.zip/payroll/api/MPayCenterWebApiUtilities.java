package payroll.api;

import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.http.ContentType;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.jetbrains.annotations.Nullable;
import payroll.api.benefits.Benefit;
import payroll.api.benefits.BenefitForCreation;
import payroll.api.benefits.enroll.DependentForUpdate;
import payroll.api.benefits.enroll.EmployeeBenefitUpdate;
import payroll.classObjects.EmployeeName;
import payroll.data.SessionVariables;

import static io.restassured.RestAssured.config;
import static io.restassured.RestAssured.given;

public class MPayCenterWebApiUtilities {

    public RequestSpecification globalRequestSpec;
    public String userName;
    public String password;
    private String contextUserId;
    private String environmentURL;

    public MPayCenterWebApiUtilities(String userName, String password, String contextUserId) {
        RestAssured.defaultParser = Parser.JSON;
        this.userName = userName;
        this.password = password;
        this.contextUserId = contextUserId;
        environmentURL = SessionVariables.getEnvironment().urlOnboarding;
        globalRequestSpec = getRequest();
    }

    public Response postTokenRequestGetResponse() {
        RequestSpecification request = given().log().all()
                .config(config().encoderConfig(
                        EncoderConfig.encoderConfig().encodeContentTypeAs("x-www-form-urlencoded", ContentType.URLENC)))
                .contentType("x-www-form-urlencoded")
                .formParam("grant_type", "password")
                .formParam("username", userName)
                .formParam("password", password)
                .formParam("provider", "GetHiredATS")
                .formParam("contextuserid", contextUserId)
                .header("accept", "application/json")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .request();

        Response res = request.post(environmentURL + "/oauth2/token");
        return res;
    }

    public Employee getEmployeeRequestGetEmployeeResponse(String number) {
        Response employeeResponse = getEmployeeRequestGetResponse(number);
        return employeeResponse.as(Employee.class);
    }

    public Response getEmployeeRequestGetResponse(String number) {
        Response res = globalRequestSpec
                .contentType("application/json")
                .get(environmentURL + "/api/v1/Employees/" + number + "/");
        return res;
    }

    public Response putEmployeeRequestGetResponse(String number, Employee employee) {
        Response res = globalRequestSpec
                .contentType("application/json")
                .body(employee)
                .put(environmentURL + "/api/v1/Employees/" + number + "/");
        return res;
    }

    public Benefit[] getBenefits() {
        Benefit[] benefits = globalRequestSpec
                .contentType("application/json")
                .get(environmentURL + "/api/v1/Benefits")
                .as(Benefit[].class);
        return benefits;
    }

    public Response postEnrollEmployeeInBenefitGetResponse(String employeeID, EmployeeBenefitUpdate benefitUpdateInfo) {
        Response res = globalRequestSpec
                .contentType("application/json")
                .body(benefitUpdateInfo)
                .post(environmentURL + "/api/v1/Employees/" + employeeID + "/Benefits/Enroll");
        return res;
    }

    public DependentForUpdate[] getEmployeeDependents(String employeeID, DependentForUpdate... dependents) {

        return globalRequestSpec
                .contentType("application/json")
            //    .body(dependents)
                .get(environmentURL + "/api/v1/Employees/" + employeeID + "/Dependents")
                .as(DependentForUpdate[].class);
    }

    public EmployeeBenefitUpdate postEnrollEmployeeInBenefit(String employeeID, EmployeeBenefitUpdate benefitUpdateInfo) {
        return globalRequestSpec
                .contentType("application/json")
                .body(benefitUpdateInfo)
                .post(environmentURL + "/api/v1/Employees/" + employeeID + "/Benefits/Enroll")
                .as(EmployeeBenefitUpdate.class);
    }

    public Benefit getBenefitByDescription(String description) {
        Benefit[] benefits = getBenefits();
        for (Benefit benefit : benefits) {
            if (benefit.getDescription().equals(description)) {
                return benefit;
            }
        }
        return null;
    }

    public Benefit getBenefit(String benefitId) {
        Benefit benefit = globalRequestSpec
                .contentType("application/json")
                .get(environmentURL + "/api/v1/Benefits/" + benefitId)
                .as(Benefit.class);
        return benefit;
    }

    public Response postBenefit(BenefitForCreation benefit) {
        Response response = globalRequestSpec
                .contentType("application/json")
                .body(benefit)
                .post(environmentURL + "/api/v1/Benefits");
        return response;
    }

    public Response putBenefit(String benefitId, Benefit benefit) {
        Response response = globalRequestSpec
                .contentType("application/json")
                .body(benefit)
                .put(environmentURL + "/api/v1/Benefits/" + benefitId);
        return response;
    }

    public Employee[] getEmployees() {
        return globalRequestSpec.get(environmentURL + "/api/v1/Employees/")
                .as(Employee[].class);
    }

    @Nullable
    public Employee getEmployee(EmployeeName employeeName) {
        Employee[] employees = getEmployees();
        for (Employee employee : employees) {
            if (employee.firstName.equals(employeeName.getFirstName()) && employee.lastName.equals(employeeName.getLastName())) {
                return employee;
            }
        }
        return null;
    }

    public Template getOnboardingTemplates() {
        Response res = globalRequestSpec.get(environmentURL + "/api/v1/Onboarding/Templates");
        return (res.as(Template[].class))[0];
    }

    public Template getOnboardingTemplate(String templateId) {
        Response res = globalRequestSpec.get(environmentURL + "/api/v1/Onboarding/Templates/" + templateId);
        return res.as(Template.class);
    }

    private Token postTokenRequestGetTokenResponse() {
        Response res = postTokenRequestGetResponse();
        return res.as(Token.class);
    }

    private RequestSpecification getRequest() {
        Token requestToken = postTokenRequestGetTokenResponse();
        RequestSpecification requestSpec = setupRequestWithToken(requestToken.access_token);
        return requestSpec;
    }

    private RequestSpecification setupRequestWithToken(String token) {
        RequestSpecification request = given().log().all()
                .header("Authorization", "Bearer " + token)
                .request();
        return request;
    }
}
