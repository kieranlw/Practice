package payroll.api.template;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TemplateUpdated {

    public String id;
    public String name;
    public Step[] steps;

    public Step getStep(String stepName){
        for(Step step : steps){
            if(step.name.equals(stepName)){
                return step;
            }
        }

        return null;
    }
}
