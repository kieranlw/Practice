package payroll.api.template;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Step {

    public String name;
    public String parentStep;
    public StepField[] fields;

    public StepField getField(String label){
        for (StepField field : fields){
            if(field.label.equals(label)){
                return field;
            }
        }

        return null;
    }

}
