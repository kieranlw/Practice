package payroll.api.template;

public class Dependent {

    public String firstName;
    public String middleName;
    public String lastName;
    public String suffix;
    public String birthDate;
    public String ssn;
}
