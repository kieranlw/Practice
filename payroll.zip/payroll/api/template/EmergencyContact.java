package payroll.api.template;

import utils2.tableData.Row;

public class EmergencyContact {

    private String contactName;
    private String email;
    private String phone;
    private String workPhone;
    private String cellPhone;
    private int priority;
    private String notes;

    public String getContactName() {
        return contactName;
    }

    public EmergencyContact setContactName(String contactName) {
        this.contactName = contactName;
        return this;
    }

    public String getEmail() {
        return email;
    }

    public EmergencyContact setEmail(String email) {
        this.email = email;
        return this;
    }

    public String getPhone() {
        return phone;
    }

    public EmergencyContact setPhone(String phone) {
        this.phone = phone;
        return this;
    }

    public String getWorkPhone() {
        return workPhone;
    }

    public EmergencyContact setWorkPhone(String workPhone) {
        this.workPhone = workPhone;
        return this;
    }

    public String getCellPhone() {
        return cellPhone;
    }

    public EmergencyContact setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
        return this;
    }

    public int getPriority() {
        return priority;
    }

    public EmergencyContact setPriority(int priority) {
        this.priority = priority;
        return this;
    }

    public String getNotes() {
        return notes;
    }

    public EmergencyContact setNotes(String notes) {
        this.notes = notes;
        return this;
    }

    public Row getRow() {
        Row row = Row.of(
                "Priority", String.valueOf(priority),
                "ContactName", contactName,
                "Phone", phone,
                "Work Phone", workPhone,
                "Cell Phone", cellPhone,
                "E-mail", email,
                "Notes", notes == null ? "" : notes);

        return row;
    }

    public Row getESSRow() {
        Row row = Row.of("Requested", (contactName + "\n"
                + email + "\n"
                + phone + "\n"
                + workPhone + "\n"
                + cellPhone + "\n"
                + priority + "\n"
                + (notes == null ? "" : notes)).trim());

        return row;
    }
}
