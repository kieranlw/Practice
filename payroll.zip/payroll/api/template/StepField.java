package payroll.api.template;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class StepField {

    public String name;
    public String label;
    public String type;
    public String value;
    public Dependent[] dependents;
    public EmergencyContact[] emergencyContacts;
    public String mapsTo;

}
