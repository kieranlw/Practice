package payroll.api;
public class APICredentials {

    private String grantType;
    private String scope;
    private String clientId;
    private String clientSecretPassword;

    public String getGrantType() {
        return grantType;
    }

    public APICredentials setGrantType(String grantType) {
        this.grantType = grantType;
        return this;
    }
    public String getScope() {
        return scope;
    }
    public APICredentials setScope(String scope) {
        this.scope = scope;
        return this;
    }
    public String getClientId() {
        return clientId;
    }
    public APICredentials setClientId(String clientId) {
        this.clientId = clientId;
        return this;
    }
    public String getClientSecretPassword() {
        return clientSecretPassword;
    }
    public APICredentials setClientSecretPassword(String clientSecretPassword) {
        this.clientSecretPassword = clientSecretPassword;
        return this;
    }
}
