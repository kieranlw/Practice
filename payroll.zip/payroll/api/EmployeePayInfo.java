package payroll.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;
import java.util.UUID;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeePayInfo 
{
    public String primary;
    public String payType;
    public UUID workLocationId;
    public UUID departmentId;
    public UUID jobCodeId;
    public BigDecimal rate;
}
