package payroll.data;

import common.DataFile;
import org.apache.commons.lang3.time.DateUtils;
import utils.BaseUI;
import utils2.LogInfo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LogFile_Scan {
    public static String[] getRecentLogLines(String logFilePath, Date startDate) {
        startDate = DateUtils.addMinutes(startDate, -1);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a");
        String logFile = logFilePath + "\\" + "log.txt";
        String content = new DataFile(logFile).readAllText();
        String[] lines = content.split("[\r\n]+");
        Pattern pattern = Pattern.compile("^[A-Z]+\\s*(\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}\\s\\w{2})\\s+.*$");
        ArrayList<String> results = new ArrayList<String>();

        try {
            for (String line : lines) {
                Matcher matcher = pattern.matcher(line);
                if (matcher.find()) {
                    String lineDateText = matcher.replaceAll("$1");
                    Date lineDate = formatter.parse(lineDateText);
                    if (lineDate.compareTo(startDate) >= 0) {
                        results.add(line);
                    }
                }
            }
        } catch (Exception ex) {
            BaseUI.log_Warning(ex.getMessage());
        }
        return results.toArray(new String[results.size()]);
    }

    public boolean RecentLogsForVertexMessagesExist(String logFilePath, Date startDate) {
        int logCount = 0;
        String[] logs = getRecentLogLines(logFilePath, startDate);
        for (String line : logs) {
            if (line.contains("Started - Vertex Address Cleaning Service")) {
                LogInfo.log_Status(line.toString());
                logCount++;
            }
            if (line.contains("Vertex Address Cleaning Service-Started")) {
                LogInfo.log_Status(line.toString());
                logCount++;
            }
            if (line.contains("Vertex Address Cleaning Service-Error with Address")) {
                LogInfo.log_Status(line.toString());
                logCount++;
            }
            if (line.contains(" Vertex Address Cleaning Service-Searched Address")) {
                LogInfo.log_Status(line.toString());
                logCount++;
            }
            if (line.contains("Vertex Address Cleaning Service-Found Address")) {
                LogInfo.log_Status(line.toString());
                logCount++;
            }
            if (line.contains("Vertex Address Cleaning Service-Completed")) {
                LogInfo.log_Status(line.toString());
                logCount++;
            }
        }
        if ((logCount > 0))
            return true;
        else
            return false;
    }
}

