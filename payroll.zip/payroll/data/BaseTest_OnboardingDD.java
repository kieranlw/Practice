package payroll.data;

import common.ResourceFile;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import payroll.framework.GenericPageDriver;
import payroll.pages.onboarding.Dashboard_Page;
import payroll.pages.onboarding.GenericField_Page;
import payroll.pages.onboarding.Login_Page;
import payroll.pages.onboarding.ReviewInformation_Page;
import utils2.DriverInfo;
import utils2.DriverSetup;
import utils2.ResultWriter2;
import utils2.page_components.*;

public abstract class BaseTest_OnboardingDD {

    public WebDriver driver;
    protected DriverInfo defaultDriverInfo;
    protected String url_Onboarding;

    protected Login_Page loginPage;
    protected ReviewInformation_Page reviewInformationPage;
    protected Dashboard_Page dashboardPage;

    @BeforeClass(alwaysRun = true)
    public void config_setup_method3() throws Exception {
        DataImport.retrieve_EnvironmentData();
        url_Onboarding = SessionVariables.getEnvironment().urlOnboarding;
        defaultDriverInfo = new DriverInfo(SessionVariables.getBrowserType());
        defaultDriverInfo.setStartMaximized(true);
        int maxCounter = 0;
        while (true && maxCounter < 3) {
            try {
                maxCounter++;
                driver = new DriverSetup(defaultDriverInfo).startDriver(url_Onboarding);
                loginPage = BasePageObject.createAndLoad(Login_Page::new, driver);

                break;
            } catch (Exception e) {
                driver.quit();
            }
        }
    }

    @AfterMethod(alwaysRun = true)
    public void testTeardown2(ITestResult result) throws Exception {
        if (driver != null) {
            ResultWriter2.checkForFailureAndScreenshot(result, driver);
        }

        GenericField_Page genericFieldPage = new GenericField_Page(driver);
        dashboardPage = genericFieldPage.dashboardLink.clickToNavigate_JS();
    }

    @AfterClass(alwaysRun = true)
    public void finalTestClassTeardown() throws Exception {
        if (driver != null) {
            driver.quit();
        }
    }

    protected void executeTest(ResourceFile fileLocation) throws Exception {
        dashboardPage.navigatePersonalInfoAndReset();
        GenericPageDriver genericPageDriver = new GenericPageDriver(driver);
        reviewInformationPage = genericPageDriver.fillInFields(fileLocation);
        reviewInformationPage.processCompleteBanner.verify()
                .displayed();

        //TODO: Need better assertions.  Hopefully we get API
    }
}
