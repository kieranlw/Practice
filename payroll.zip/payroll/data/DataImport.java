package payroll.data;

import common.ResourceFile;
import common.networkFileUtils.NetworkUser;
import payroll.functions.PermissionParser;
import utils.DataBuilder;
import utils2.TableData2;
import utils2.tableData.TableConverter;

import java.util.Map;

public class DataImport {

    private static final ResourceFile permissionsXML = new ResourceFile("payroll/data/Permissions.xlsm");

    public static void retrieve_EnvironmentData() {
        try {
            Map<String, String> config_Data = DataBuilder.readConfigFile(new ResourceFile("payroll/data/Config.txt"));
            retrieve_EnvironmentData(config_Data.get("environment"), config_Data.get("browser"));
            SessionVariables.setFileUser(new NetworkUser(config_Data.get("user"), config_Data.get("password"), config_Data.get("domain")));
        } catch (Exception e) {
            throw new RuntimeException("Unable to retrieve environment data.");
        }
    }

    public static void retrieve_EnvironmentData(String environmentVar, String browser) throws Exception {
        TableData2 environments = TableConverter.convertToTableData2(DataBuilder
                .returnTableData_ForComparison(new ResourceFile("payroll/data/environments.csv"), "\\|"));

        Environment environment = new Environment(
                environments.get().row().byMatchingField("Environment", environmentVar));
        SessionVariables.setEnvironment(environment);
        SessionVariables.setBrowserType(browser);
        PermissionParser permissionParser = new PermissionParser(permissionsXML);
        SessionVariables.setPermissionSets(permissionParser.getPermissionList());

    }

}
