package payroll.data;

import org.openqa.selenium.WebDriver;
import payroll.pages.payroll.dashboard.DashboardPage_Payroll;

public class PermissionsVariables {

    //TODO: remove
    //
    //

    private static InheritableThreadLocal<WebDriver> permissionsDriver = new InheritableThreadLocal<>();
    private static InheritableThreadLocal<DashboardPage_Payroll> dashboardPage = new InheritableThreadLocal<>();

    public static DashboardPage_Payroll getDashboardPage(){
        return dashboardPage.get();
    }

    public static void setDashboardPage(DashboardPage_Payroll dashboardPage){
        PermissionsVariables.dashboardPage.set(dashboardPage);
    }

    public static WebDriver getPermissionsDriver() {
        return permissionsDriver.get();
    }

    public static void setPermissionsDriver(WebDriver permissionsDriver) {
        PermissionsVariables.permissionsDriver.set(permissionsDriver);
    }
}
