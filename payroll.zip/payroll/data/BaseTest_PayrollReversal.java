package payroll.data;

import org.testng.annotations.DataProvider;
import payroll.classObjects.*;
import payroll.pages.payroll.employees.EmployeeListPage_Payroll;
import payroll.pages.payroll.companyProfile.CompanyFederalSummaryPage_Payroll;
import utils2.JavaTimeUtils;
import utils2.TableData2;
import utils2.tableData.Row;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public abstract class BaseTest_PayrollReversal extends BaseTest {

    protected static final LocalDate START_DATE = JavaTimeUtils.getLocalDate("05/28/2020", "MM/dd/yyyy");
    protected static final LocalDate PROCESS_DATE = JavaTimeUtils.getLocalDate("06/11/2020", "MM/dd/yyyy");

    protected static PaySummary_General paySummary_General = new PaySummary_General()
            .setSummaryType("Payroll")
            .setPayDate(PROCESS_DATE)
            .setNumberPaid("6")
            .setPreGross(DollarCurrency.setDollarCurrency(2721.60))
            .setTpSickPay(DollarCurrency.setDollarCurrency(0.0))
            .setSales(DollarCurrency.setDollarCurrency(0.0))
            .setProcessedDate(LocalDate.now())
            .setTotalNet(DollarCurrency.setDollarCurrency(2282.79))
            .setMemo(DollarCurrency.setDollarCurrency(0.0))
            .setTips(DollarCurrency.setDollarCurrency(0.0));

    protected static PaySummary_FederalTaxSummary federalTaxSummary = new PaySummary_FederalTaxSummary()
            .setFicaSSTaxable(DollarCurrency.setDollarCurrency(2721.60))
            .setFicaSSErTax(DollarCurrency.setDollarCurrency(70.43))
            .setFicaSSEeTax(DollarCurrency.setDollarCurrency(168.74))
            .setFicaSSErDeferredTax(DollarCurrency.setDollarCurrency(157.48))
            .setFicaMedTaxable(DollarCurrency.setDollarCurrency(2721.60))
            .setFicaMedErTax(DollarCurrency.setDollarCurrency(39.46))
            .setFicaMedEeTax(DollarCurrency.setDollarCurrency(39.46))
            .setFitTaxable(DollarCurrency.setDollarCurrency(2721.60))
            .setFitEeTax(DollarCurrency.setDollarCurrency(124.85))
            .setViFitTaxable(DollarCurrency.setDollarCurrency(0.00))
            .setViFitEeTax(DollarCurrency.setDollarCurrency(0.00))
            .setFutaTaxable(DollarCurrency.setDollarCurrency(2721.60))
            .setFutaErTax(DollarCurrency.setDollarCurrency(16.33))
            .setFicaUncollectedErTax(DollarCurrency.setDollarCurrency(0.00))
            .setFicaTpSickTaxable(DollarCurrency.setDollarCurrency(0.00))
            .setFicaTpSickErTax(DollarCurrency.setDollarCurrency(0.0))
            .setTotal941(DollarCurrency.setDollarCurrency(442.94));

    protected static PaySummary_Federal941CreditSummary federal941CreditSummary = PaySummary_Federal941CreditSummary.builder()
            .setCaresRetentionCreditTaxable(DollarCurrency.setDollarCurrency(1600.00))
            .setCaresRetentionErCredit(DollarCurrency.setDollarCurrency(800.00))
            .setFfcraFamilyLeaveCreditTaxable(DollarCurrency.setDollarCurrency(1061.00))
            .setFfcraFamilyLeaveErCredit(DollarCurrency.setDollarCurrency(1451.38))
            .setFfcraChildCareCreditTaxable(DollarCurrency.setDollarCurrency(700.60))
            .setFfcraChildCareErCredit(DollarCurrency.setDollarCurrency(910.75))
            .build();

    protected TableData2 reportData;

    protected EmployeeListPage_Payroll employeeListPagePayroll;
    protected CompanyFederalSummaryPage_Payroll fedSummaryPage;

    @DataProvider(name = "testData")
    protected Object[][] createData() throws Exception {

        Object[][] data = new Object[][]{
                {
                        EmployeeName.builder()
                                .setFirstName("Erick")
                                .setLastName("Alvarez")
                                .build()
                        ,
                        getFederalTaxCreditsTable(
                                new String[][]{
                                        {"US-ER_FICAS Taxable Amount", "700.00", "700.00"},
                                        {"US-ER_FICAS Deferred Amount", "43.40", "43.40"},
                                        {"CARES Retention Taxable Amount", "700.00", "700.00"},
                                        {"CARES Retention Credit Amount", "350.00", "350.00"},
                                }
                        ),
                        true
                },
                {
                        EmployeeName.builder()
                                .setFirstName("Kaitlyn")
                                .setLastName("Bloomer")
                                .build()
                        ,
                        getFederalTaxCreditsTable(
                                new String[][]{
                                        {"US-ER_FICAS Taxable Amount", "704.00", "704.00"},
                                        {"US-ER_FICAS Deferred Amount", "43.65", "43.65"},
                                        {"FFCRA Family Leave Taxable Amount", "110.00", "110.00"},
                                        {"FFCRA Family Leave Credit Amount", "236.59", "236.59"},
                                        {"FFCRA Child Care Taxable Amount", "66.00", "66.00"},
                                        {"FFCRA Child Care Credit Amount", "141.95", "141.95"},
                                }
                        ),
                        true
                },
                {
                        EmployeeName.builder()
                                .setFirstName("Milton")
                                .setLastName("Bright")
                                .build()
                        ,
                        getFederalTaxCreditsTable(
                                new String[][]{
                                        {"US-ER_FICAS Taxable Amount", "20.00", "20.00"},
                                        {"US-ER_FICAS Deferred Amount", "1.24", "1.24"},
                                        {"FFCRA Family Leave Taxable Amount", "101.00", "101.00"},
                                        {"FFCRA Family Leave Credit Amount", "227.46", "227.46"},
                                        {"FFCRA Child Care Taxable Amount", "60.60", "60.60"},
                                        {"FFCRA Child Care Credit Amount", "136.47", "136.47"},
                                }
                        ),
                        false
                },
                {
                        EmployeeName.builder()
                                .setFirstName("Samantha")
                                .setLastName("Brown")
                                .build()
                        ,
                        getFederalTaxCreditsTable(
                                new String[][]{
                                        {"US-ER_FICAS Taxable Amount", "1600.00", "1600.00"},
                                        {"US-ER_FICAS Deferred Amount", "99.20", "99.20"},
                                        {"CARES Retention Taxable Amount", "1600.00", "1600.00"},
                                        {"CARES Retention Taxable Amount", "800.00", "800.00"},
                                }
                        ),
                        false
                },
                {
                        EmployeeName.builder()
                                .setFirstName("Kyauna")
                                .setLastName("Conway")
                                .build()
                        ,
                        getFederalTaxCreditsTable(
                                new String[][]{
                                        {"FFCRA Family Leave Taxable Amount", "960.00", "960.00"},
                                        {"FFCRA Family Leave Credit Amount", "1223.92", "1223.92"},
                                        {"FFCRA Child Care Taxable Amount", "640.00", "640.00"},
                                        {"FFCRA Child Care Credit Amount", "774.28", "774.28"},
                                }
                        ),
                        false
                },
        };

        return data;
    }

    private TableData2 getFederalTaxCreditsTable(String[][] data) {
        List<Row> rowList = new ArrayList<>();

        for (String[] line : data) {
            Row newRow = Row.of(
                    "PayField", line[0],
                    JavaTimeUtils.getLocalDateString(PROCESS_DATE, "MM/dd/yyyy"), line[1],
                    "Total", line[1]);
        }

        return new TableData2(rowList);
    }

    protected void verify_ReversalStateSummaryTable(TableData2 stateSummaryTable) {
        Row taxCodeMDSitRow = stateSummaryTable.get().row().byMatchingField("Tax Code", "MD-SIT");
        taxCodeMDSitRow.verify().cellContains("State", "MD");
        taxCodeMDSitRow.verify().cellContains("Taxable Gross", "-$2,721.60");
        taxCodeMDSitRow.verify().cellContains("Tax", "-$130.76");

        Row taxCodeMDSutaRow = stateSummaryTable.get().row().byMatchingField("Tax Code", "MD-SUTA");
        taxCodeMDSutaRow.verify().cellContains("State", "MD");
        taxCodeMDSutaRow.verify().cellContains("Taxable Gross", "-$2,721.60");
        taxCodeMDSutaRow.verify().cellContains("Tax", "-$46.84");
    }

    protected void verify_StateSummaryTable(TableData2 stateSummaryTable) {
        Row taxCodeMDSitRow = stateSummaryTable.get().row().byMatchingField("Tax Code", "MD-SIT");
        taxCodeMDSitRow.verify().cellContains("State", "MD");
        taxCodeMDSitRow.verify().cellContains("Taxable Gross", "$2,721.60");
        taxCodeMDSitRow.verify().cellContains("Tax", "$130.76");

        Row taxCodeMDSutaRow = stateSummaryTable.get().row().byMatchingField("Tax Code", "MD-SUTA");
        taxCodeMDSutaRow.verify().cellContains("State", "MD");
        taxCodeMDSutaRow.verify().cellContains("Taxable Gross", "$2,721.60");
        taxCodeMDSutaRow.verify().cellContains("Tax", "$46.84");
    }
}
