package payroll.data;

import common.Lazy;
import common.networkFileUtils.NetworkFileUtils;
import io.restassured.response.Response;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import payroll.api.DeluxeUnifiedOnboarding.Account;
import payroll.api.DeluxeUnifiedOnboarding.DigitalOnboardingAPI;
import payroll.api.DeluxeUnifiedOnboarding.TokenInfoObject;
import payroll.decisions.Environment;
import payroll.decisions.GetEnvironmentData;
import payroll.pages.DeluxeUnifiedOnboarding.DUO_OKTA_SignIn_Page;
import utils.FileOperations;
import utils2.DriverInfo;
import utils2.DriverSetup;
import utils2.DriverUtils;
import utils2.ResultWriter2;
import utils2.page_components.*;

public abstract class BaseTest {

    public WebDriver driver;
    protected DriverInfo defaultDriverInfo;
    protected String url_SBA;
    protected String url_Onboarding;
    protected String url_Payroll;
    protected String url_Workflow;
    protected DriverUtils driverUtils;
    protected NetworkFileUtils networkFileUtils;
    private static final Lazy<DigitalOnboardingAPI> digitalOnboardingApiCache = new Lazy<>(BaseTest::logIntoDigitalOnboardingApi);

    private static DigitalOnboardingAPI logIntoDigitalOnboardingApi() {
        try {
            Environment environment = GetEnvironmentData.getCurrentEnvironment();
            DigitalOnboardingAPI api = new DigitalOnboardingAPI(environment);
            String authToken = "";
            authToken = api.postAdminAuthorization();
            api.setAuthorizationToken(authToken);
            return api;
        }
        catch(Exception e) {
            return null;
        }
    }
    protected static DigitalOnboardingAPI getDigitalOnboardingAPI() {
        return digitalOnboardingApiCache.get();
    }

    protected static DigitalOnboardingAPI getUserAuthorization(Account account) throws Exception {
        Environment environment = GetEnvironmentData.getCurrentEnvironment();
        DigitalOnboardingAPI api = new DigitalOnboardingAPI(environment);
        DriverInfo driverInfo = createDriverInfo();
        String digitalOnboardingLoginLink = "https://login-duo.dev.deluxe.com/oauth2/default/v1/authorize?client_id=0oa1phdp2bGVGczbh1d7&scope=openid accounts companies&response_type=code&redirect_uri=https://dlx-cob-spa-qa.herokuapp.com/login/callback&state=Ra58RHwThOn8372vkaXFEJXwMEY6fvZ8vVDtEQEQfGD3NO75nkilHghP0FcQ52LO&code_challenge=tLlFj3VS6fW_1wTq_H5mdHykJc1ICBOKugh-lM1rCOQ&code_challenge_method=S256";
        WebDriver driver = new DriverSetup(driverInfo).startDriver(digitalOnboardingLoginLink);
        BasePageObject.createAndLoad(DUO_OKTA_SignIn_Page::new, driver)
                .fillInFields(account)
                .signInButton.click();
        Thread.sleep(2000);

        String authorizationCode = api.getCode(driver.getCurrentUrl());
        driver.quit();
        Response res = api.postGetAccountToken(authorizationCode);
        TokenInfoObject tokenInfoObject = res.as(TokenInfoObject.class);
        String tokenCode = tokenInfoObject.getAccess_token();
        api.setAuthorizationToken(tokenCode);
        return api;
    }

    @BeforeClass(alwaysRun = true)
    public void config_setup_method2() throws Exception {
        DataImport.retrieve_EnvironmentData();
        networkFileUtils = new NetworkFileUtils(SessionVariables.getFileUser());
        url_Onboarding = SessionVariables.getEnvironment().urlOnboarding;
        url_Payroll = SessionVariables.getEnvironment().urlPayroll;
        url_Workflow = SessionVariables.getEnvironment().urlWorkflow;
        url_SBA = SessionVariables.getEnvironment().urlSBA;
        defaultDriverInfo = createDriverInfo();
    }

    protected static DriverInfo createDriverInfo() {
        DriverInfo driverInfo = new DriverInfo(SessionVariables.getBrowserType());
        driverInfo.setDownloadLocation("C:\\DAF\\Downloads\\");
        driverInfo.setPageLoadStrategy(PageLoadStrategy.NONE);
        driverInfo.setStartMaximized(true);
        FileOperations.create_Folder("C:\\DAF\\Downloads\\");
        return driverInfo;
    }

    @AfterMethod(alwaysRun = true)
    public void testTeardown(ITestResult result) throws Exception {

        if (driver != null) {
            ResultWriter2.checkForFailureAndScreenshot(result, driver);
        }


        testCleanup();
    }

    @AfterClass(alwaysRun = true)
    public void finalTestClassTeardown() throws Exception {
        if (driver != null) {
            driver.quit();
        }
    }

    public void testCleanup() throws Exception {
    }

    public String getNameOfActiveElement() {
        return driver.switchTo().activeElement().getText();
    }
}
