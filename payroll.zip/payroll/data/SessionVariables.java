package payroll.data;

import common.networkFileUtils.NetworkUser;
import payroll.classObjects.PermissionSet;

import java.util.List;

public class SessionVariables {

    private static InheritableThreadLocal<String> browserType = new InheritableThreadLocal<>();
    private static InheritableThreadLocal<Environment> environment = new InheritableThreadLocal<>();
    private static InheritableThreadLocal<List<PermissionSet>> permissionSets = new InheritableThreadLocal<>();
    private static InheritableThreadLocal<NetworkUser> remoteFileUser = new InheritableThreadLocal<>();

    public static List<PermissionSet> getPermissionSets() {
        return permissionSets.get();
    }

    public static void setPermissionSets(List<PermissionSet> permissions) {
        permissionSets.set(permissions);
    }

    public static String getBrowserType() {
        return browserType.get();
    }

    public static Environment getEnvironment() {
        return environment.get();
    }

    public static NetworkUser getFileUser() { return remoteFileUser.get();}

    public static void setFileUser(NetworkUser fileNetworkUser) { remoteFileUser.set(fileNetworkUser);}

    public static void setBrowserType(String browserType) {
        SessionVariables.browserType.set(browserType);
    }

    public static boolean isMobile() {
        return browserType.get().equals("android") || browserType.get().equals("iphonesimulated");
    }

    public static void setEnvironment(Environment environment) {
        SessionVariables.environment.set(environment);
    }
}
