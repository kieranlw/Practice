package payroll.data;

public class GlobalVariables {
    private static String environment = "qa";
    public static String url1 = "https://dlx-cob-spa-" + environment + ".herokuapp.com/company/start";
    public static String url2 = "https://dlx-cob-spa-" + environment + ".herokuapp.com/company/packages";
    public static String url3 = "https://dlx-cob-spa-" + environment + ".herokuapp.com/company/pricing-addons";
    public static String url4 = "https://dlx-cob-spa-" + environment + ".herokuapp.com/company/addresses";
    public static String url5 = "https://dlx-cob-spa-" + environment + ".herokuapp.com/company/bank-accounts";
    public static String url6 = "https://dlx-cob-spa-" + environment + ".herokuapp.com/company/federal-tax-info";
    public static String url7 = "https://dlx-cob-spa-" + environment + ".herokuapp.com/company/authorization-forms";
    public static String url8 = "https://dlx-cob-spa-" + environment + ".herokuapp.com/company/state-taxes";
    public static String url9 = "https://dlx-cob-spa-" + environment + ".herokuapp.com/company/summary";
    public static String url10 = "https://dlx-cob-spa-" + environment + ".herokuapp.com/company/user-agreement";
    public static String url11 = "https://dlx-cob-spa-" + environment + ".herokuapp.com/company/success";
}
