package payroll.data;

import org.jetbrains.annotations.NotNull;
import utils2.tableData.Row;

public class Environment {

    @NotNull
    public final String environmentName;

    @NotNull
    public final String urlOnboarding;

    @NotNull
    public final String urlPayroll;

    @NotNull
    public final String urlWorkflow;

    @NotNull
    public final String urlSBA;

    @NotNull
    public final String outputLocation;

    @NotNull
    public final String emailLocation;

    @NotNull
    public final String rtsLocation;

    @NotNull
    public final String ptsLocation;

    @NotNull
    public final String taxLocation;

    @NotNull
    public final String collectorsLocation;

    @NotNull
    public final String quarterlyPackageLocation;

    @NotNull
    public final String tokenService;

    @NotNull
    public final String taxcCalculationService;

    public Environment(Row row) {
        environmentName = getValueOrEmptyString(row, "Environment");
        urlOnboarding = getValueOrEmptyString(row, "ESS_URL");
        urlPayroll = getValueOrEmptyString(row, "PAYROLL_URL");
        urlWorkflow = getValueOrEmptyString(row, "WORKFLOW_URL");
        urlSBA = getValueOrEmptyString(row, "SBA_URL");
        outputLocation = getValueOrEmptyString(row, "OUTPUT_LOCATION");
        emailLocation = getValueOrEmptyString(row, "EMAIL_LOCATION");
        ptsLocation = getValueOrEmptyString(row, "PTS_LOCATION");
        collectorsLocation = getValueOrEmptyString(row, "COLLECTORS");
        quarterlyPackageLocation = getValueOrEmptyString(row, "QuarterlyPackage_Location");
        tokenService = getValueOrEmptyString(row, "TOKEN_SERVICE");
        taxcCalculationService = getValueOrEmptyString(row, "TAX_CALC_SERVICE");
        taxLocation = getValueOrEmptyString(row, "TAX");
        rtsLocation = getValueOrEmptyString(row, "RTS_LOCATION");
    }

    private String getValueOrEmptyString(Row row, String key) {
        String value = row.get(key);
        return value != null ? value : "";
    }
}
