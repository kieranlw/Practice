package payroll.data;

import org.openqa.selenium.WebDriver;
import org.testng.ITest;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import utils2.DriverInfo;
import utils2.ResultWriter2;

import java.lang.reflect.Method;

public abstract class BaseTest_Permissions implements ITest {

    //
    //TODO: remove
    //



    protected DriverInfo defaultDriverInfo;
    protected String url_Onboarding;
    protected String url_Payroll;
    protected String url_Workflow;

    @BeforeClass(alwaysRun = true)
    public void config_setup_method2() throws Exception {

        url_Onboarding = SessionVariables.getEnvironment().urlOnboarding;
        url_Payroll = SessionVariables.getEnvironment().urlPayroll;
        url_Workflow = SessionVariables.getEnvironment().urlWorkflow;
        defaultDriverInfo = new DriverInfo(SessionVariables.getBrowserType());
        defaultDriverInfo.setDownloadLocation("C:\\DAF\\Downloads\\");
    }

    @AfterMethod(alwaysRun = true)
    public void testTeardown(ITestResult result) throws Exception {

        if (PermissionsVariables.getPermissionsDriver() != null) {
            ResultWriter2.checkForFailureAndScreenshot(result, PermissionsVariables.getPermissionsDriver());
        }

        testCleanup();
    }

    protected Payroll_Logins login;

    private ThreadLocal<String> testName = new ThreadLocal<>();

    @Override
    public String getTestName() {
        return testName.get();
    }

    @BeforeMethod(alwaysRun = true)
    public void BeforeMethod(Method method, Object[] testData) {
        if (login != null) {
            testName.set(method.getName() + "_" + login.toString());
        }
    }



    public void testCleanup() throws Exception {
    }
}
