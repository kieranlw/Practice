package payroll.data;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import payroll.functions.LoginUtils;
import payroll.pages.payroll.LoginPage_Payroll;
import payroll.pages.payroll.dashboard.DashboardPage_Payroll;
import utils2.DriverInfo;
import utils2.DriverSetup;
import utils2.ResultWriter2;
import utils2.page_components.*;

public abstract class BaseTest_Permissions2 {

    public WebDriver driver;
    protected DriverInfo defaultDriverInfo;
    protected String url_Onboarding;
    protected String url_Payroll;
    protected String url_Workflow;

    protected DashboardPage_Payroll dashboardPagePayroll;
    protected boolean isWorkflowUser;
    protected Payroll_Logins login;

    private static final String ACCOUNT = "Testtest";


    @Parameters({"user"})
    @BeforeClass(alwaysRun = true)
    public void config_setup_method2(String user) throws Exception {
        DataImport.retrieve_EnvironmentData();
        url_Onboarding = SessionVariables.getEnvironment().urlOnboarding;
        url_Payroll = SessionVariables.getEnvironment().urlPayroll;
        url_Workflow = SessionVariables.getEnvironment().urlWorkflow;
        defaultDriverInfo = new DriverInfo(SessionVariables.getBrowserType());
        defaultDriverInfo.setDownloadLocation("C:\\DAF\\Downloads\\");
        login = Payroll_Logins.valueOf(user);
        isWorkflowUser = login.isWorkflowUserLogin();

        if (!isWorkflowUser) {
            driver = new DriverSetup(defaultDriverInfo).startDriver(url_Payroll);
            LoginPage_Payroll loginPage = BasePageObject.createAndLoad(LoginPage_Payroll::new, driver);
            dashboardPagePayroll = loginPage.login(login.getLoginInfo());
        } else {
            try {
                driver = new DriverSetup(defaultDriverInfo).startDriver(url_Workflow);
                dashboardPagePayroll = new LoginUtils(driver).loginToPayrollViaWorkflow(login.getLoginInfo(), ACCOUNT);
            }catch(Exception e){
                driver.quit();
                driver = new DriverSetup(defaultDriverInfo).startDriver(url_Workflow);
                dashboardPagePayroll = new LoginUtils(driver).loginToPayrollViaWorkflow(login.getLoginInfo(), ACCOUNT);
            }
        }
    }

    @AfterMethod(alwaysRun = true)
    public void testTeardown(ITestResult result) throws Exception {
        if (driver != null) {
            ResultWriter2.checkForFailureAndScreenshot(result, driver);
        }
        testCleanup();
    }

    @AfterClass(alwaysRun = true)
    public void finalTestClassTeardown() throws Exception {
        if (driver != null) {
            driver.quit();
        }
    }

    public void testCleanup() throws Exception {
    }
}
