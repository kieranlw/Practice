package payroll.data;

import org.apache.commons.lang3.EnumUtils;
import payroll.classObjects.LoginInfo;
import payroll.classObjects.PermissionSet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public enum Payroll_Logins {

    //TODO: Change from enum to be in a csv or excel document
    WORKFLOW_DEFAULT("nilly", "apples", "", true, "CSR Admin"),
    CPA("Bridget22", "Welcome1", "", false, "CPA/Bookkeeper"),
    CLIENT_ADMIN("Ryan22", "welcome1", "", false, ""),
    TAX_USER("tax1","welcome1", "", true, "Tax User"),
    SYSTEM_ADMINISTRATOR("sysadm", "welcome1", "",true, "System Administrator"),
    CLIENT_ADMIN_DPA_API("autosample222", "@Welcome1", "", false, ""),
    POWER("Powertester", "Welcome1", "", false, "Power User"),
    STANDARD("Shakey22", "welcome1", "",  false, "Standard"),
    MINIMAL("Clint22", "welcome1", "",false, "Minimal"),
    NO_ACCESS("Kevin22", "welcome1", "", false, ""),
    CPA_EMPLOYEE("Enid22", "welcome1", "",  false, ""),
    CLIENT_ADMIN_EMPLOYEE("Sheila22", "welcome1", "",  false, "Client Admin"),
    POWER_EMPLOYEE("Sandra23", "welcome1", "", false, ""),
    STANDARD_EMPLOYEE("Rene22", "welcome1", "", false, ""),
    MINIMAL_EMPLOYEE("Angela22", "welcome1", "", false, ""),
    DEPARTMENT_ADMIN_EMPLOYEE("michael22", "Welcome1", "",  false, "Departmental Admin"),
    SALES_ADMIN("salesadmin", "welcome1", "", true, "Sales Admin"),
    PRODUCTION_MANAGER("ProductionManager", "Welcome1", "", true, "Production Manager"),
    ONBOARDING("onboarding", "Welcome1", "",  true, "Onboarding"),
    CSR("CSR", "welcome1", "", true, "CSR1"),
    CSR_TRAINEE("trainee", "welcome1", "", true, "CSR Trainee"),
    EXTERNAL_INTEGRATOR_ADMIN("autexternal", "@Welcome1", "Testtest", false, "External Integrator Admin"),
    EXTERNAL_INTEGRATOR_ADMIN_EMPLOYEE("autexternalintegratoremployee", "@Welcome1", "Testtest", false, "External Integrator Admin");


    private final String userName;
    private final String password;
    private final String account;
    private final boolean isWorkflowUserLogin;
    private final String securityType;
    private static final Map<String, Payroll_Logins> ENUM_MAP;
   // private final PermissionSet permissionSet;

    Payroll_Logins(String userName, String password, String account, boolean isWorkflowUserLogin, String securityType) {
        this.userName = userName;
        this.password = password;
        this.account = account;
        this.isWorkflowUserLogin = isWorkflowUserLogin;
        this.securityType = securityType;
      //  this.permissionSet = setPermissionSet();
    }

//    public PermissionSet getPermissions(){
//        return permissionSet;
//    }

    public PermissionSet getPermissionSet(){
        List<PermissionSet> permissionSetList = SessionVariables.getPermissionSets();
        for(PermissionSet permissionSet : permissionSetList){
            if(permissionSet.getLoginSecurityType().equals(securityType)){
                return permissionSet;
            }
        }

        return null;
    }

    public LoginInfo getLoginInfo() {
        LoginInfo loginInfo = LoginInfo.builder()
                .setLoginName(userName)
                .setPassword(password)
                .setAccount(account)
                .build();
        return loginInfo;
    }

    static {
        Map<String,Payroll_Logins> map = new ConcurrentHashMap<String, Payroll_Logins>();
        for (Payroll_Logins instance : Payroll_Logins.values()) {
            map.put(instance.getSecurityType(),instance);
        }
        ENUM_MAP = Collections.unmodifiableMap(map);
    }

    public static Payroll_Logins get (String securityType) {
        return ENUM_MAP.get(securityType);
    }


    public static List<Payroll_Logins> getEmployees() {

        return EnumUtils.getEnumList(Payroll_Logins.class);
    }

    public static List<Payroll_Logins> getEmployeesWithCompanyProfileAccess() {
        List<Payroll_Logins> employees = getEmployees();
        List<Payroll_Logins> employeesWithAccess = new ArrayList<>();

        for (Payroll_Logins payrollEmployee : employees) {
            if (payrollEmployee.getPermissionSet() != null
                    && payrollEmployee.getPermissionSet().getHasModifyClientPreferences()) {
                employeesWithAccess.add(payrollEmployee);
            }
        }

        return employeesWithAccess;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public boolean isWorkflowUserLogin(){return isWorkflowUserLogin;}

    public String getSecurityType(){
        return securityType;
    }
}
