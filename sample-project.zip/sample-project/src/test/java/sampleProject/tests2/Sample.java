package sampleProject.tests2;


import org.testng.Assert;
import org.testng.annotations.Test;

public class Sample {


    @Test
    public void DLX_1() throws Exception {
        System.out.println("Testing Success");
    }

    @Test
    public void DLX_2() throws Exception {
        Assert.fail("Testing failure");
    }

}
