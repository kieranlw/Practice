package sampleProject.pageControl;

import org.openqa.selenium.WebDriver;
import sampleProject.pages.BasePage;
import sampleProject.pages.Product_Page;
import utils2.page_components.*;

public class ProductContainer_HomePage extends BasePage {

    private String _productXpath = "";


    @ComponentFindBy(friendlyName = "Sign In Link", xpath="{0}//a[@class='product_img_link']/img")
    public GenericComponent imageLink;

    private ProductContainer_HomePage(WebDriver driver, int indexOfContainer) {
        _productXpath = "(//ul[contains(@class,'active')]//div[@class='product-container'])[" + String.valueOf(indexOfContainer) + "]";
        _driver = driver;
        ComponentFactory.initElements(_driver, this, new String[]{_productXpath});
    }

    private ProductContainer_HomePage(WebDriver driver, String productText) {
        _productXpath = "//ul[contains(@class,'active')]//div[@class='product-container'][.//h5[@itemprop='name']/a[normalize-space(text()='" + productText + "')]]";
        _driver = driver;
        ComponentFactory.initElements(_driver, this, new String[]{_productXpath});
    }

    @Override
    public void waitForPageToLoad() throws Exception{

    }

    public Product_Page navigate_ProductPage() throws Exception {
        return createAndLoad(Product_Page::new, _driver);
    }

    //Xpath indexing starts at 1.
    public static ProductContainer_HomePage getProductContainer_ByIndex(WebDriver driver, int index){
        return new ProductContainer_HomePage(driver, index);
    }

    public static ProductContainer_HomePage getProductContainer_ByName(WebDriver driver, String name){
        return new ProductContainer_HomePage(driver, name);
    }

}
