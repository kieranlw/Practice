package sampleProject.autosmoketest.pages;

import org.openqa.selenium.WebDriver;
import utils2.autosmoketestable.AutoSmokeTestable;
import utils2.page_components.*;

import java.time.Duration;

public class TestAutomationUHomePage extends BasePageObject implements AutoSmokeTestable {

    private WebDriver driver;

    @ComponentFindBy(friendlyName = "Terms and Conditions Link", linkText = "Terms and Conditions")
    public GenericComponent termsAndConditionsLink;

    public TestAutomationUHomePage(WebDriver driver) {
        this.driver = driver;
        ComponentFactory.initElements(driver, this);
    }

    @Override
    public TestAutomationUHomePage navigateTo() {
        driver.get("https://testautomationu.applitools.com/");
        waitForPageToLoad();
        return this;
    }

    @Override
    public void waitForPageToLoad() {
        termsAndConditionsLink.waitUntil(Duration.ofSeconds(30)).displayed();
    }

    @Override
    public TestAutomationUHomePage verifyPageLoaded() {
        termsAndConditionsLink.verify().displayed();
        return this;
    }


}
