package sampleProject.autosmoketest.pages;

import org.openqa.selenium.WebDriver;
import utils2.autosmoketestable.AutoSmokeTestable;
import utils2.page_components.*;

import java.time.Duration;

public class GoogleSearchPage extends BasePageObject implements AutoSmokeTestable {

    private WebDriver driver;

    @ComponentFindBy(friendlyName = "Searchbox", name = "q")
    private TextBox searchBox;

    public GoogleSearchPage(WebDriver driver) {
        this.driver = driver;
        ComponentFactory.initElements(driver, this);
    }

    @Override
    public void waitForPageToLoad() {
        searchBox.waitUntil(Duration.ofSeconds(30)).displayed();
    }

    @Override
    public GoogleSearchPage navigateTo() {
        driver.get("https://www.google.com");
        waitForPageToLoad();
        return this;
    }

    @Override
    public GoogleSearchPage verifyPageLoaded() {
        searchBox.verify().displayed();
        return this;
    }
}
