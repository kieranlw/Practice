package sampleProject.autosmoketest;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils2.autosmoketestable.AutoSmokeTestable;
import utils2.autosmoketestable.PageAutoSmokeTestUtils;
import utils2.DriverInfo;
import utils2.DriverSetup;

public class PageAutoSmokeTests {

    private static final String PACKAGE_TO_TEST = "sampleProject.autosmoketest";

    private WebDriver driver;

    @BeforeClass
    public void classSetup() {
        DriverInfo driverInfo = new DriverInfo(DriverSetup.DriverType.CHROME);
        driver = new DriverSetup(driverInfo).startDriver("about::blank", false);
    }

    @DataProvider(name = "pageObjectClasses")
    public Object[][] pageObjectClasses() throws Exception {
        return PageAutoSmokeTestUtils.getAutoSmokeTestableClasses(PACKAGE_TO_TEST);
    }

    @Test(dataProvider = "pageObjectClasses")
    public void smokeTest(Class<AutoSmokeTestable> clz) throws Exception {
        PageAutoSmokeTestUtils.verifyPageObjectLoads(driver, clz);
    }

    @AfterClass
    public void classTeardown() {
        driver.quit();
    }

}
