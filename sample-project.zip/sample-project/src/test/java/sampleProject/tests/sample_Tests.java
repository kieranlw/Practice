package sampleProject.tests;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import sampleProject.pages.*;
import utils2.DriverSetup;
import sampleProject.data.BaseTest;

import java.util.ArrayList;
import java.util.List;

public class sample_Tests extends BaseTest {

    private Home_Page _homePage;
    private MyAccount_Page _myAccountPage;
    private SignIn_Page _signInPage;

    @Override
    public void setup_for_tests() throws Exception  {
        _driver = new DriverSetup(_driverInfo).startDriver(_environment.getUrl());

        _homePage = new Home_Page(_driver);
        _homePage.waitForPageToLoad();
    }

    @Test(groups = {"all_Tests", "regression_Tests"})
    public void PT101_Verify_BreadCrumb_Value() throws Exception {
        _myAccountPage = new NavigationBar_Page(_driver)
                .signIn.clickToNavigate()
                .signIn(_loginInfo);

        _myAccountPage.myAccountBreadcrumb.verify()
                .enabled()
                .displayed()
                .textEquals("My account");
    }

    @Test(groups = {"all_Tests", "regression_Tests"})
    public void PT102_ProductPage_Verify_CheckboxesAreDisplayed() throws Exception {
        Product_Page productPage = _homePage.product_ByIndex(1).navigate_ProductPage();

        List<WebElement> checkboxes = _driver.findElements(By.xpath(
                "//input[@type='checkbox']"));

        SoftAssert softAssert = new SoftAssert();
        for(int i = 0; i < checkboxes.size(); i++){
            softAssert.assertTrue(checkboxes.get(i).isDisplayed(), "Checkbox "+ String.valueOf(i) +" was not displayed");
        }
        softAssert.assertAll();

    }

    @Test(groups = {"all_Tests", "regression_Tests"})
    public void PT103_ProductPage_Verify_DropdownOptionsCorrect() throws Exception {
        Product_Page productPage = _homePage.product_ByIndex(1).navigate_ProductPage();

        List<WebElement> dropdownOptionElements = _driver.findElements(By.xpath(
                "//label[contains(text(),'Size')]/following-sibling::*[1]//select/option"));
        List<String> options = new ArrayList<>();
        for(WebElement dropdownOption: dropdownOptionElements){
            options.add(dropdownOption.getText());
        }

        SoftAssert softAssert = new SoftAssert();
        for(String option : options){
            softAssert.assertTrue(options.contains(option), "Option " + option + " was not found in dropdown");
        }
        softAssert.assertAll();
    }




    @Test(groups = {"all_Tests", "regression_Tests"})
    public void PT104_ProductPage_Verify_DropdownOptions_DoesNOTContainXL() throws Exception {
        Product_Page productPage = _homePage.product_ByIndex(1).navigate_ProductPage();

        List<WebElement> dropdownOptionElements = _driver.findElements(By.xpath(
                "//label[contains(text(),'Size')]/following-sibling::*[2]//select/option"));
        List<String> options = new ArrayList<>();
        for(WebElement dropdownOption: dropdownOptionElements){
            options.add(dropdownOption.getText());
        }

        SoftAssert softAssert = new SoftAssert();
        for(String option : options){
            softAssert.assertTrue(options.contains("XL"), "Dropdown " + option + " contained XL");
        }
        softAssert.assertAll();
    }

    @Test(groups = {"all_Tests", "regression_Tests"})
    public void PT105_ProductPage_Verify_ProductName() throws Exception {
        Product_Page productPage = _homePage.product_ByIndex(1).navigate_ProductPage();

        WebElement productName = _driver.findElement(By.xpath("//*[@id='center_column']/div/div/div[3]/h1"));
        productName.getText().equals("Blouse");
    }



    @Override
    protected void test_teardown() throws Exception  {
        _homePage = new NavigationBar_Page(_driver).nav_HomePage();
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() throws Exception {
       _driver.close();
    }
}
