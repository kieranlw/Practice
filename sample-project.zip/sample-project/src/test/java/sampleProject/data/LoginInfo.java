package sampleProject.data;

public class LoginInfo {

    private String _userName;
    private String _password;
    private String _email;

    public LoginInfo(String userName, String password, String email){
        _userName = userName;
        _password = password;
        _email = email;
    }

    public String getEmail() {
        return _email;
    }

    public String getUserName() {
        return _userName;
    }

    public String getPassword() {
        return _password;
    }





}
