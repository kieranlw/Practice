package sampleProject.data;

import common.ResourceFile;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import utils.DataBuilder;
import utils.ResultWriter;
import utils.TableData;
import utils2.DriverInfo;

import java.util.Map;

public abstract class BaseTest {

    protected LoginInfo _loginInfo;
    protected WebDriver _driver;
    protected EnvironmentInfo _environment;
    protected DriverInfo _driverInfo;

    private boolean _initialTestClassSetup = true;
    private TableData _availableEnvironments;
    private Map<String, String> _configData;

    @BeforeClass(alwaysRun = true)
    public void config_setup_method() {
        _configData = DataBuilder.readConfigFile(new ResourceFile("sampleProject/data/config.txt"));
        _availableEnvironments = DataBuilder
                .returnTableData_ForComparison(new ResourceFile("sampleProject/data/environmentData.csv"), "\\|");

        _loginInfo = new LoginInfo(getValue("userName"), getValue("password"), getValue("email"));

        String environment = getValue("environment");
        _environment = new EnvironmentInfo(environment, _availableEnvironments.return_Row_BasedOn_1MatchingField("environment", environment).get("url"));
        _driverInfo = new DriverInfo(getValue("browser"));
    }

    @BeforeMethod(alwaysRun = true)
    public void class_setup_method() throws Exception {
        if (_initialTestClassSetup) {
            try {
                setup_for_tests();
            } finally {
                _initialTestClassSetup = false;
            }
        }
    }

    //Instead of using BeforeClass in test class you override this method
    protected void setup_for_tests() throws Exception {

    }

    @AfterMethod(alwaysRun = true)
    public void test_cleanup(ITestResult result) throws Exception {
        //this method needs to be updated for screenshots.  Currently calls Browser.driver.  Need it to pass in driver;
        ResultWriter.checkForFailureAndScreenshot(result);
        test_teardown();
    }

    //Instead of calling AfterMethod you would call the test_teardown
    protected void test_teardown() throws Exception {

    }

    // Gets the specified value from first the System Property. If that is null it
    // reverts to config file.
    private String getValue(String valueToGet) {
        String value = "";
        value = System.getProperty(valueToGet);
        if (value == null) {
            value = _configData.get(valueToGet);
        }

        if (value != null) {
            System.setProperty(valueToGet, value);
        }
        return value;
    }
}
