package sampleProject.data;

public class EnvironmentInfo {

    private String _environment;
    private String _url;



    public EnvironmentInfo(String environment, String url){
        _environment = environment;
        _url = url;
    }

    public String getEnvironment() {
        return _environment;
    }

    public String getUrl() {
        return _url;
    }

}
