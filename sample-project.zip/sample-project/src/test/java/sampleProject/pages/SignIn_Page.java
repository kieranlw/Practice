package sampleProject.pages;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import sampleProject.data.LoginInfo;
import utils2.page_components.*;

import java.time.Duration;

public class SignIn_Page extends BasePage {

    @ComponentFindBy(friendlyName = "Email Address", id="email")
    public TextBox emailAddress;

    @ComponentFindBy(friendlyName = "Password", id="passwd")
    public TextBox password;

    @ComponentFindBy(friendlyName = "Sign In Button", id="SubmitLogin")
    public GenericComponent signInButton;



    public MyAccount_Page signIn(LoginInfo loginInfo) throws Exception {
        emailAddress.enterText(loginInfo.getEmail());
        password.enterText(loginInfo.getPassword());
        signInButton.click();

        return createAndLoad(MyAccount_Page::new, _driver);
    }


//    @WaitForPage
//    public SignIn_Page wait_ForPage() throws Exception{
//        SignIn_Page signIn_page = new SignIn_Page(_driver);
//        signIn_page.waitForPageToLoad();
//        return signIn_page;
//    }

    @Override
    public void waitForPageToLoad() throws Exception{
        emailAddress.waitUntil(Duration.ofSeconds(20)).displayed();
        ThreadUtils.sleep(500);
    }



    public SignIn_Page(WebDriver driver){
        _driver = driver;
        ComponentFactory.initElements(_driver, this);
    }
}
