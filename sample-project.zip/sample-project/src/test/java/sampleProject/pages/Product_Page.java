package sampleProject.pages;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

import java.time.Duration;

public class Product_Page extends BasePage {

    @ComponentFindBy(friendlyName = "Reviews Header", xpath="//h3[text()='Reviews']")
    public Label reviewsHeader;

    @Override
    public void waitForPageToLoad() throws Exception {
        reviewsHeader.waitUntil(Duration.ofSeconds(20)).displayed();
        ThreadUtils.sleep(500);
    }

    public Product_Page(WebDriver driver){
        _driver = driver;
    }

}
