package sampleProject.pages;

import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

public abstract class BasePage extends BasePageObject{

    protected WebDriver _driver;


    public BasePage(){

    }

}
