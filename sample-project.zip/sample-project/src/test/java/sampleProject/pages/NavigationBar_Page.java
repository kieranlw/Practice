package sampleProject.pages;

import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

public class NavigationBar_Page extends BasePage {


    @ComponentFindBy(friendlyName = "Sign In Link", xpath="//a[@title='Log in to your customer account']")
    public NavigateTo<SignIn_Page> signIn;

    @ComponentFindBy(friendlyName = "Logo Link", xpath="//div[@id='header_logo']/a[@title='My Store']")
    public GenericComponent logoLink;


    public Home_Page nav_HomePage() throws Exception {
        logoLink.click();
        return createAndLoad(Home_Page::new, _driver);
    }

    @Override
    public void waitForPageToLoad() throws Exception {

    }

    public SignIn_Page nav_SignInPage() throws Exception {
        return signIn.clickToNavigate();
       // return new SignIn_Page(_driver);
    }

    public NavigationBar_Page(WebDriver driver) {
        _driver = driver;
        ComponentFactory.initElements(_driver, this);
    }
}
