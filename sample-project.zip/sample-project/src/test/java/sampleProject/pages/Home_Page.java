package sampleProject.pages;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import sampleProject.pageControl.ProductContainer_HomePage;
import utils2.page_components.*;

import java.time.Duration;

public class Home_Page extends BasePage {

    @ComponentFindBy(friendlyName = "Popular Tab", xpath = "//a[./text()='Popular']")
    public GenericComponent popularTab;

    @ComponentFindBy(friendlyName = "Search Box", id = "search_query_top")
    public TextBox searchBox;

    //xpath indexing starts at 1.
    public ProductContainer_HomePage product_ByIndex(int indexOfProduct) {
        return ProductContainer_HomePage.getProductContainer_ByIndex(_driver, indexOfProduct);
    }

    public ProductContainer_HomePage product_ByName(String productName) {
        return ProductContainer_HomePage.getProductContainer_ByName(_driver, productName);
    }

    @Override
    public void waitForPageToLoad() throws Exception {
        popularTab.waitUntil(Duration.ofSeconds(30)).displayed();
        ThreadUtils.sleep(500);
    }

    public Home_Page(WebDriver driver) {
        _driver = driver;
        ComponentFactory.initElements(_driver, this);
    }
}
