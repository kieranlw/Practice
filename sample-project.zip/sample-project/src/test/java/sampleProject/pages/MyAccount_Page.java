package sampleProject.pages;

import common.ThreadUtils;
import org.openqa.selenium.WebDriver;
import utils2.page_components.*;

import java.time.Duration;

public class MyAccount_Page extends BasePage {

    @ComponentFindBy(friendlyName = "My Account Breadcrumb", xpath="//span[@class='navigation_page'][./text()='My account']")
    public GenericComponent myAccountBreadcrumb;

    @Override
    public void waitForPageToLoad() throws Exception {
        myAccountBreadcrumb.waitUntil(Duration.ofSeconds(20)).displayed();
        ThreadUtils.sleep(500);
    }



    public MyAccount_Page(WebDriver driver) {
        _driver = driver;
        ComponentFactory.initElements(_driver, this);
    }
}
